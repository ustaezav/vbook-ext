load('config.js');

// A tapped list item opens the reader directly; this returns the article body.
function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let body = doc.select(".entry-content").first();
    if (!body) return Response.error("Content not found");

    // The table-of-contents widget is navigation, not article text.
    body.select(".elementor-widget-uael-table-of-contents, script, style").remove();

    // The "其它章节" chapter list sits at the very bottom; copy it to the top.
    // Some pages render an empty container, so only copy one with real links.
    let related = body.select(".related-posts-container").first();
    let relatedHtml = (related && related.select("a").size() > 0)
        ? '<div class="related-posts-container">' + related.html() + '</div>' : '';

    let content = body.html();

    // Elementor's gallery paints images as CSS backgrounds on empty divs.
    // Convert them to real img tags so the reader can display them.
    content = content.replace(/<div\b[^>]*\bdata-thumbnail="([^"]+)"[^>]*>\s*<\/div>/gi, '<img src="$1">');

    if (relatedHtml) content = relatedHtml + content;

    // Chapter titles (h3) keep their heading formatting. Body text arrives as
    // h4, which the reader renders bold; make those ordinary paragraphs.
    content = content.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi, '<p>$1</p>');

    // The editor wraps some paragraphs in <span style="font-size: 1.25rem; ...">
    // and prefixes them with &nbsp;. Unwrap so the reader's text style applies.
    content = content.replace(/<span\b[^>]*>([\s\S]*?)<\/span>/gi, '$1');
    content = content.replace(/&nbsp;|&#160;|\u00a0/gi, ' ');
    content = content.replace(/<p>\s+/g, '<p>');

    return Response.success({
        name: doc.select("h1.entry-title").text(),
        cover: doc.select("meta[property='og:image']").attr("content"),
        source_name: "海角情",
        content: content,
        content_format: "html"
    });
}
