// The category navigation is a fixed set of pages on this site, so list it statically.
function execute() {
    return Response.success([
        { title: "最近更新", input: "/zjgx", script: "search.js" },
        { title: "海角母子", input: "/hjmz", script: "search.js" },
        { title: "海角姐弟", input: "/hjjd", script: "search.js" },
        { title: "海角父女", input: "/hjfn", script: "search.js" },
        { title: "海角嫂子", input: "/hjsz", script: "search.js" },
        { title: "海角人妻", input: "/hjwf", script: "search.js" },
        { title: "海角原创", input: "/origin", script: "search.js" },
        { title: "海角合集", input: "/hjsets", script: "search.js" }
    ]);
}
