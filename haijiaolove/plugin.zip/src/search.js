load('config.js');

function absoluteUrl(href) {
    if (!href) return "";
    if (href.indexOf("http") === 0) return href;
    if (href.indexOf("//") === 0) return "https:" + href;
    if (href.indexOf("/") === 0) return BASE_URL + href;
    return BASE_URL + "/" + href;
}

// Category pages use the pt-content-views grid. Its thumbnails are lazy-loaded:
// the real image URL lives in data-cvpsrc, while src is a placeholder.
function categoryItems(doc) {
    return doc.select(".pt-cv-content-item").map(function (el) {
        let a = el.select(".pt-cv-title a").first();
        let img = el.select("img.pt-cv-thumbnail").first();
        return {
            name: a ? a.text() : "",
            cover: img ? (img.attr("data-cvpsrc") || img.attr("src")) : "",
            link: a ? absoluteUrl(a.attr("href")) : "",
            description: el.select(".pt-cv-ctf-value").text()
        };
    });
}

// Keyword searches use the standard WordPress blog loop.
function searchItems(doc) {
    return doc.select("article.ast-archive-post").map(function (el) {
        let a = el.select("h2.entry-title a").first();
        let img = el.select(".post-thumb img").first();
        return {
            name: a ? a.text() : "",
            cover: img ? img.attr("src") : "",
            link: a ? absoluteUrl(a.attr("href")) : "",
            description: el.select(".entry-content p").text()
        };
    });
}

function execute(query, page) {
    query = query || "";
    page = page || "1";

    let isCategory = query.indexOf("/") === 0 || query.indexOf("http") === 0;
    let url;
    if (isCategory) {
        let base = query.indexOf("http") === 0 ? normalizeUrl(query) : BASE_URL + query;
        url = page === "1" ? base : base + (base.indexOf("?") === -1 ? "?" : "&") + "_page=" + page;
    } else {
        let keyword = encodeURIComponent(query);
        url = page === "1"
            ? BASE_URL + "/?s=" + keyword
            : BASE_URL + "/page/" + page + "?s=" + keyword;
    }

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = isCategory ? categoryItems(doc) : searchItems(doc);
    let hasNext = false;
    if (isCategory) {
        // pt-cv exposes its paging state on the pagination list.
        let pager = doc.select("ul.pt-cv-pagination").first();
        if (pager) {
            hasNext = parseInt(pager.attr("data-totalpages")) > parseInt(pager.attr("data-currentpage"));
        }
    } else {
        hasNext = !doc.select("a.next.page-numbers").isEmpty();
    }

    return Response.success(items, hasNext ? String(parseInt(page) + 1) : "");
}
