// Tabs are the site's fixed category pages. Each tab's input is handed to search.js,
// which treats a "/"-prefixed path as a category, not a keyword.
function execute() {
  return Response.success([
    { title: "最近", input: "/zjgx", script: "search.js" },
    { title: "母子", input: "/hjmz", script: "search.js" },
    { title: "姐弟", input: "/hjjd", script: "search.js" },
    { title: "父女", input: "/hjfn", script: "search.js" },
    { title: "嫂子", input: "/hjsz", script: "search.js" },
    { title: "人妻", input: "/hjwf", script: "search.js" },
    { title: "原创", input: "/origin", script: "search.js" },
    { title: "合集", input: "/hjsets", script: "search.js" },
  ]);
}
