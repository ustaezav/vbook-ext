let BASE_URL = "https://example.com";
try {
  if (DOMAIN) {
    BASE_URL = DOMAIN;
  }
} catch (error) {}

// Rewrite an incoming url's host (old/mirror/www-prefixed) to BASE_URL, keeping
// path/query. Call this first thing in every url-receiving execute(url).
function normalizeUrl(url) {
  return url.replace(
    /^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/gim,
    BASE_URL,
  );
}
