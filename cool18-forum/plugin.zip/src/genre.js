load('config.js');

// Category chips. The board files every main post under one of its own categories;
// `type` searches it with first=1 so replies never leak into the list.
function execute() {
    return Response.success([
        { title: "原创", input: "type:原创", script: "list.js" },
        { title: "转载", input: "type:转载", script: "list.js" },
        { title: "AI辅助", input: "type:AI辅助", script: "list.js" }
    ]);
}
