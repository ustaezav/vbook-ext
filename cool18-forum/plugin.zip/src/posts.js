load('config.js');

// One page of a thread: the main post first, then its replies oldest first. Every post
// body lives on its own thread page, so a page of N posts costs N requests. `page` is
// the page number the previous call returned (empty means the first page).
function execute(url, page) {
    url = normalizeUrl(url);
    let tid = tidOf(url);
    if (!tid) return Response.error("URL không hợp lệ");

    let doc = fetchDoc(threadUrl(tid));
    if (doc === null) return Response.error("HTTP " + threadUrl(tid));

    // A reply carries the root thread in a hidden field; read from the root instead.
    let hidden = doc.select("input[name=rootid]").first();
    let rootTid = hidden !== null ? parseInt(hidden.attr("value"), 10) : 0;
    if (!isNaN(rootTid) && rootTid > 0 && rootTid !== tid) {
        tid = rootTid;
        doc = fetchDoc(threadUrl(tid));
        if (doc === null) return Response.error("HTTP " + threadUrl(tid));
    }

    let rows = replyRows(tid);
    let totalEntries = rows.length + 1;
    let totalPages = Math.max(1, Math.ceil(totalEntries / PAGE_SIZE));
    let current = parseInt(page, 10);
    if (isNaN(current) || current < 1) current = 1;
    if (current > totalPages) current = totalPages;

    let firstIndex = (current - 1) * PAGE_SIZE;
    let lastIndex = Math.min(totalEntries, firstIndex + PAGE_SIZE);

    // Floor and author of every post, so a reply can name the post it answers.
    let floors = {};
    let authors = {};
    floors[String(tid)] = 1;
    for (let i = 0; i < rows.length; i++) {
        floors[String(rows[i].tid)] = i + 2;
        authors[String(rows[i].tid)] = rows[i].username || "";
    }

    let posts = [];
    if (firstIndex === 0) {
        posts.push(mainPost(doc, tid));
    }
    for (let j = firstIndex === 0 ? 1 : firstIndex; j < lastIndex; j++) {
        let row = rows[j - 1];
        posts.push(replyPost(row, fetchDoc(threadUrl(row.tid)), floors, authors));
    }

    return Response.success(
        { posts: posts, page: current, total_pages: totalPages },
        current < totalPages ? String(current + 1) : ""
    );
}

// Author, time and read count from the sender/views line above a post body.
function postMeta(doc) {
    let sender = doc.select(".sender").first();
    let author = "";
    let time = "";
    if (sender !== null) {
        let link = sender.select("a").first();
        if (link !== null) author = link.text().trim();
        let match = sender.text().match(/于\s*([0-9]{4}-[0-9]{2}-[0-9]{2}\s+[0-9]{1,2}:[0-9]{2})/);
        if (match) time = match[1];
    }
    let views = doc.select(".views").text().replace(/[^0-9]/g, "");
    return { author: author, time: time, views: views };
}

// The affiliation line sits right after the author name: "[★品衔R5★]".
function userOf(doc, fallbackName) {
    if (!fallbackName) return null;
    let user = { name: fallbackName, link: userLink(fallbackName) };
    let sender = doc !== null ? doc.select(".sender").first() : null;
    if (sender !== null) {
        let raw = sender.text().replace(/[\s\u3000]+/g, " ");
        let title = raw.match(/\[([^\[\]]{1,24})\]/);
        let badge = raw.match(/\[([★☆][^\[\]]*[★☆])\]/);
        if (badge) user.title = badge[1];
        else if (title) user.title = title[1];
    }
    return user;
}

function mainPost(doc, tid) {
    let meta = postMeta(doc);
    return {
        id: String(tid),
        floor: 1,
        url: threadUrl(tid),
        is_op: true,
        time: meta.time,
        views: meta.views,
        user: userOf(doc, meta.author),
        content: contentHtml(readContent(doc)),
        content_format: "html"
    };
}

function replyPost(row, doc, floors, authors) {
    let meta = doc !== null ? postMeta(doc) : { time: "", views: "" };
    let body = doc !== null ? readContent(doc) : "";
    let post = {
        id: String(row.tid),
        floor: floors[String(row.tid)],
        url: threadUrl(row.tid),
        is_op: false,
        time: meta.time || row.dateline || "",
        views: meta.views,
        user: userOf(doc, row.username),
        content: contentHtml(body || row.subject),
        content_format: "html"
    };

    // A reply answers the post its uptid points at: floor 1 for the main post, else a
    // reply of this thread.
    let parent = String(row.uptid || "");
    if (parent && parent !== "0" && parent !== String(row.rootid)) {
        let floor = floors[parent];
        if (floor) post.reply_to = { floor: floor, user: authors[parent] || "" };
    }
    return post;
}
