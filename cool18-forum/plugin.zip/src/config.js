// Shared helpers for the Cool18 forum extension. Every script starts with
// load('config.js'); a loaded library must not load another file, so all shared code
// lives here.
//
// 性趣论坛 (cool18.com/bj) runs on the same forum engine as the sibling Cool18
// extensions: lists are server-rendered (search, gold, hot) or come from the board's
// AJAX feed (latest), while a thread's replies are listed by `achildlist` and each
// reply's body lives on its own thread page.

let BASE_URL = "https://www.cool18.com/bj";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

// Threads per reader page. Each reply body costs one request, so keep the page small.
let PAGE_SIZE = 10;

function siteOrigin() {
    let match = String(BASE_URL).match(/^(https?:\/\/[^\/]+)/);
    return match ? match[1] : BASE_URL;
}

// Board path of BASE_URL ("", "/bj", ...), without a trailing slash. An origin-only
// DOMAIN falls back to this extension's board.
function boardPath() {
    let match = String(BASE_URL).match(/^https?:\/\/[^\/]+(\/.*)?$/);
    let path = match && match[1] ? match[1] : "";
    path = path.replace(/\/+$/, "");
    return path || "/bj";
}

function boardBase() {
    return siteOrigin() + boardPath();
}

// Board token used by the search form ("bj" for /bj).
function boardId() {
    let path = boardPath();
    let cut = path.lastIndexOf("/");
    return cut === -1 ? path : path.substring(cut + 1);
}

// Rewrite an incoming url (mirror / www / mobile host) onto the configured board,
// keeping path and query.
function normalizeUrl(url) {
    let text = String(url || "");
    let match = text.match(/^(?:https?:\/\/)?(?:[^@\n]+@)?[^\/\n]+(\/[^#]*)?$/);
    if (match) {
        return siteOrigin() + (match[1] || boardPath() || "/");
    }
    if (text.indexOf("/") === 0) {
        return siteOrigin() + text;
    }
    if (text) {
        return boardBase() + "/" + text.replace(/^\/+/, "");
    }
    return text;
}

// Resolve a link found on a board page into an absolute url.
function absUrl(href) {
    if (!href) return "";
    let text = String(href);
    if (/^https?:\/\//i.test(text)) return normalizeUrl(text);
    if (text.charAt(0) === "/") return siteOrigin() + text;
    return boardBase() + "/" + text;
}

function threadUrl(tid) {
    return boardBase() + "/index.php?app=forum&act=threadview&tid=" + tid;
}

function tidOf(url) {
    let match = String(url || "").match(/[?&]tid=(\d+)/);
    return match ? parseInt(match[1], 10) : 0;
}

function escapeHtml(value) {
    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

// Display text of a list row: collapse whitespace, decode stray entities, drop the
// separators the board prepends to a subject.
function cleanText(value) {
    if (!value) return "";
    return String(value)
        .replace(/<[^>]*>/g, "")
        .replace(/&nbsp;/gi, " ")
        .replace(/&amp;/gi, "&")
        .replace(/&lt;/gi, "<")
        .replace(/&gt;/gi, ">")
        .replace(/&quot;/gi, '"')
        .replace(/&#39;/g, "'")
        .replace(/[\s\u3000]+/g, " ")
        .trim()
        .replace(/^[.．·\-\s]+/, "")
        .replace(/[\s.．·\-\/]+$/, "")
        .trim();
}

// The ajax feed appends the poster's category to the subject: "标题[原创]".
function splitSubject(subject) {
    let text = cleanText(subject);
    let match = text.match(/^(.*?)\s*\[([^\]]{1,12})\]\s*$/);
    if (match) return { name: match[1], tag: match[2] };
    return { name: text, tag: "" };
}

function typeTag(type) {
    if (type === "original") return "原创";
    if (type === "reprint") return "转载";
    if (type === "ai") return "AI辅助";
    return "";
}

function userLink(username) {
    if (!username) return "";
    return boardBase() + "/index.php?app=forum&act=userview&username=" + encodeURIComponent(username);
}

// Next-page token from the pager: the board numbers pages as "p=2", "p=3", ...
function nextPageToken(doc) {
    let link = doc.select("nav.pagination-bar a.next").first();
    if (link === null) return "";
    let match = String(link.attr("href") || "").match(/[?&]p=(\d+)/);
    return match ? match[1] : "";
}

// Rows of a main-post list: the board renders
// <li class="l-m1"><a href=…>title</a>- <font>poster</font><i> date </i></li>
function parseThreadRows(doc) {
    let items = [];
    doc.select("ul.post-list.thread-list li.l-m1").forEach(function (row) {
        let link = row.select("a").first();
        if (link === null) return;
        let href = link.attr("href");
        if (!href || String(href).indexOf("threadview") === -1) return;
        let name = cleanText(link.text());
        if (!name) return;
        let poster = row.select("font").first();
        let date = row.select("i").first();
        items.push({
            name: name,
            link: absUrl(href),
            author: poster !== null ? poster.text().trim() : "",
            time: date !== null ? date.text().trim() : "",
            host: siteOrigin()
        });
    });
    return items;
}

// 精华热帖 — editor picks, and 人气热帖 — reading ranking.
function parseGoldRows(doc) {
    let items = [];
    doc.select("ul.post-list li.post-item a").forEach(function (link) {
        let href = link.attr("href");
        if (!href || String(href).indexOf("threadview") === -1) return;
        let name = cleanText(link.text());
        if (!name) return;
        items.push({ name: name, link: absUrl(href), host: siteOrigin() });
    });
    return items;
}

function parseHotRows(doc) {
    let items = [];
    doc.select("tr").forEach(function (row) {
        let link = row.select("td.title-col a").first();
        if (link === null) return;
        let href = link.attr("href");
        if (!href || String(href).indexOf("threadview") === -1) return;
        // The row glues "- poster (N bytes) date (M reads)" onto the title.
        let raw = cleanText(link.text());
        let cut = raw.lastIndexOf(" - ");
        let name = (cut > 0 ? raw.substring(0, cut) : raw).trim();
        if (!name) return;
        let tail = cut > 0 ? raw.substring(cut + 3) : "";
        let reads = tail.match(/\(([\d,]+)\s*reads\)$/i);
        items.push({
            name: name,
            link: absUrl(href),
            tag: cleanText(row.select("td.rank-col").text()),
            time: row.select("i").text().trim(),
            views: reads ? reads[1] : "",
            host: siteOrigin()
        });
    });
    return items;
}

// 最新 — the board's own AJAX feed. `page` is a tid cursor: the feed answers with rows
// older than it. The rows mix main posts (uptid/rootid 0) and their replies, and one
// answer carries only a handful of main posts, so follow the cursor until a page is full.
function latestFeed(page) {
    // The token is a tid cursor, so a page number ("1") is not a real position: the app
    // may send it for the first page.
    let cursor = page && page !== "1" ? String(page) : "0";
    let items = [];
    let next = cursor;
    let seen = {};
    for (let round = 0; round < 4 && items.length < 15; round++) {
        let response = fetch(
            boardBase() + "/index.php?app=forum&act=ajax&mtid=" + encodeURIComponent(cursor) + "&aifilter=0"
        );
        if (!response.ok) break;
        let rows = response.json();
        if (!rows || rows.length === 0) {
            next = "";
            break;
        }
        let lowestRoot = 0;
        let lowestRow = 0;
        for (let i = 0; i < rows.length; i++) {
            let row = rows[i];
            let tid = parseInt(row.tid, 10);
            if (!lowestRow || tid < lowestRow) lowestRow = tid;
            if (String(row.uptid) !== "0" || String(row.rootid) !== "0") continue;
            if (!lowestRoot || tid < lowestRoot) lowestRoot = tid;
            if (seen[row.tid]) continue;
            let meta = splitSubject(row.subject);
            if (!meta.name) continue;
            seen[row.tid] = true;
            items.push({
                name: meta.name,
                link: threadUrl(row.tid),
                author: row.username || "",
                time: row.dateline || "",
                tag: meta.tag || typeTag(row.type),
                host: siteOrigin()
            });
        }
        // Advance past everything this answer held, so the next round never repeats it.
        let stop = lowestRoot || lowestRow;
        if (!stop || String(stop) === String(cursor)) {
            next = "";
            break;
        }
        cursor = String(stop);
        next = cursor;
    }
    return { items: items, next: next };
}

function goldFeed(page) {
    let url = boardBase() + "/index.php?app=forum&act=gold";
    if (page) url += "&p=" + encodeURIComponent(page);
    let response = fetch(url);
    if (!response.ok) return null;
    let doc = response.html();
    return { items: parseGoldRows(doc), next: nextPageToken(doc) };
}

function hotFeed() {
    let response = fetch(boardBase() + "/index.php?app=forum&act=hot");
    if (!response.ok) return null;
    return { items: parseHotRows(response.html()), next: "" };
}

// Search with `first=1` (main posts only), doubled as the type / poster listing:
// extra is "keywords=…" | "type=…" | "uid=…".
function searchFeed(extra, page) {
    let url =
        boardBase() +
        "/index.php?action=search&act=threadsearch&app=forum&bbsdr=" +
        encodeURIComponent(boardId()) +
        "&first=1&" +
        extra +
        "&submit=" +
        encodeURIComponent("查询");
    if (page) url += "&p=" + encodeURIComponent(page);
    let response = fetch(url);
    if (!response.ok) return null;
    let doc = response.html();
    return { items: parseThreadRows(doc), next: nextPageToken(doc) };
}

// Read counts are not in the listing markup; the board answers them for a whole batch
// at once. One POST per page, and a failure must not break the list.
function attachViews(items) {
    let tids = [];
    for (let i = 0; i < items.length; i++) {
        let tid = tidOf(items[i].link);
        if (tid) tids.push(String(tid));
    }
    if (tids.length === 0) return items;
    try {
        let response = fetch(boardBase() + "/index.php?app=forum&act=getviews", {
            method: "POST",
            headers: {
                "Referer": boardBase() + "/index.php",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
            },
            body: "tids=" + tids.join(",")
        });
        if (!response.ok) return items;
        let rows = response.json();
        let counts = {};
        for (let j = 0; j < (rows ? rows.length : 0); j++) {
            counts[String(rows[j][0])] = String(rows[j][1]);
        }
        for (let k = 0; k < items.length; k++) {
            let views = counts[String(tidOf(items[k].link))];
            if (views) items[k].views = views;
        }
    } catch (error) {
    }
    return items;
}

// Reply rows of a thread, oldest first. The board answers the whole tree at once as
// { tid, rootid, uptid, uid, username, subject, dateline, size }; `size` is the body
// byte count, and notices (votes, gifts) are stored here with no body.
function replyRows(rootTid) {
    let response = fetch(boardBase() + "/index.php?app=forum&act=achildlist&tid=" + rootTid);
    if (!response.ok) return [];
    let rows = response.json();
    let list = [];
    for (let i = 0; i < (rows ? rows.length : 0); i++) {
        let row = rows[i];
        if (!row || !row.tid) continue;
        if (isSystemPost(row.subject)) continue;
        list.push(row);
    }
    list.sort(function (a, b) {
        return parseInt(a.tid, 10) - parseInt(b.tid, 10);
    });
    return list;
}

// Vote / gift / reward notices are stored as replies with no body: drop them. They all
// follow "<sender> 给 <receiver> <verb> …" or the board's own reward line.
function isSystemPost(subject) {
    let text = cleanText(subject);
    if (!text) return true;
    if (/^(?:\(\^-?\^\)\s*)?[^\s]{1,24}\s+给\s+[^\s]{1,24}\s+(?:点.赞|赠送|颁发|献上|送上|戴上|挥来|舞动|调上|摘来|聘请|抢到|表达|敬上)/.test(text)) return true;
    if (/^已经使用版块基金对/.test(text)) return true;
    if (/邀请您访问/.test(text)) return true;
    return false;
}

// The body of a post: <pre> inside #content-section. In-page ads and vote widgets are
// injected around it and never belong to the text.
function readContent(doc) {
    let node = doc.select("#content-section pre").first();
    if (node === null) node = doc.select("#content-section").first();
    if (node === null) return "";
    node.select(".view_ad_incontent, .ai-detection-feedback, script, style, iframe").remove();
    // An edited post ends with "贴主:<name>于<date>编辑"; it is not part of the text.
    let html = node.html().replace(/<br\s*\/?>\s*贴主:[^<]*编辑\s*$/i, "");
    return html.replace(/^[\s\u3000]+/, "").replace(/[\s\u3000]+$/, "");
}

// Wrap plain text so the reader lays it out as a paragraph.
function contentHtml(raw) {
    let text = String(raw || "").trim();
    if (!text) return "";
    if (text.indexOf("<") !== -1) return text;
    return "<p>" + escapeHtml(text) + "</p>";
}

function fetchDoc(url) {
    let response = fetch(url);
    if (!response.ok) return null;
    return response.html();
}
