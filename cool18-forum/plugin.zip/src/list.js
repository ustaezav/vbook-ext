load('config.js');

// Paged list behind the home tabs and the category chips. The token is the list key:
//   ""                 newest threads (tid cursor, returned as data2)
//   "gold"             本版精华区 — editor picks
//   "hot"              人气热贴 — reading ranking, one page
//   "type:<category>"  one board category (原创 / 转载 / AI辅助)
function execute(query, page) {
    let key = String(query || "").trim();
    let feed;
    if (key === "gold") {
        feed = goldFeed(page);
    } else if (key === "hot") {
        feed = hotFeed();
    } else if (key.indexOf("type:") === 0) {
        feed = searchFeed("type=" + encodeURIComponent(key.substring(5)), page);
    } else {
        feed = latestFeed(page);
    }
    if (feed === null) return Response.error("Không tải được danh sách");
    return Response.success(attachViews(feed.items), feed.next);
}
