load('config.js');

// Home tabs. Each tab's input is the list key read by list.js: "" = latest updates,
// "gold" = editor picks, "hot" = reading ranking.
function execute() {
    return Response.success([
        { title: "Mới nhất", input: "", script: "list.js" },
        { title: "Nổi bật", input: "gold", script: "list.js" },
        { title: "Đang hot", input: "hot", script: "list.js" }
    ]);
}
