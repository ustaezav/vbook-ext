load('config.js');

// Search. The board searches main posts only when asked with first=1; `page` is its
// "p" pager token.
function execute(query, page) {
    let keyword = String(query || "").trim();
    let feed = searchFeed("keywords=" + encodeURIComponent(keyword), page);
    if (feed === null) return Response.error("Không tải được kết quả tìm kiếm");
    return Response.success(attachViews(feed.items), feed.next);
}
