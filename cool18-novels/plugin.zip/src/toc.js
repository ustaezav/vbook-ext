load('config.js');

// A post is one part of a novel; the later parts are replies under the first post.
// The first post, then every content reply in posting order, is the chapter list.
const MIN_PART_SIZE = 512;

function execute(url) {
    url = normalizeUrl(url);
    if (isSeries(url)) return seriesToc(url);
    if (isBookGroup(url)) return bookGroupToc(url);
    if (isBookView(url)) return bookViewToc(url);
    return threadToc(url);
}

// A serial: one chapter per part thread. A one-thread serial is an ordinary post,
// so its content replies are the chapters.
function seriesToc(url) {
    let params = seriesParams(url);
    let chapters = seriesChapters(params.name, params.author);
    if (chapters.length === 0) {
        if (params.tid) return threadToc(threadUrl(params.tid));
        return Response.error("Không tìm thấy mục lục");
    }
    if (chapters.length === 1) return threadToc(threadUrl(chapters[0].tid));

    let list = [];
    for (let i = 0; i < chapters.length; i++) {
        list.push({
            name: chapters[i].subject,
            url: threadUrl(chapters[i].tid),
            description: "",
            lock: false,
            pay: false
        });
    }
    return Response.success(list);
}

function bookGroupToc(url) {
    let params = bookGroupParams(url);
    let part = shuPartByTid(params.tid);
    let books = part ? shuBooks(part) : null;
    if (books === null || !books[params.index]) return Response.error("Không tìm thấy mục lục");

    let book = books[params.index];
    let chapters = [];
    for (let i = 0; i < book.parts.length; i++) {
        chapters.push({
            name: book.parts[i].name,
            url: book.parts[i].url,
            description: "",
            lock: false,
            pay: false
        });
    }
    return Response.success(chapters);
}

// A single-page library book is one chapter.
function bookViewToc(url) {
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    return Response.success([{
        name: bookViewTitle(doc) || "Toàn văn",
        url: url,
        description: "",
        lock: false,
        pay: false
    }]);
}

function threadToc(url) {
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let rootTid = tidOf(url);
    let rootSubject = doc.select("h1.main-title").text().trim();
    let hidden = doc.select("input[name=rootid]").first();
    if (hidden !== null) {
        let parent = parseInt(hidden.attr("value"), 10);
        if (!isNaN(parent) && parent > 0 && parent !== rootTid) {
            rootTid = parent;
            url = threadUrl(parent);
        }
    }
    let firstPost = doc.select(".reply-info a").first();
    if (firstPost !== null && firstPost.text().trim()) rootSubject = firstPost.text().trim();

    let chapters = [{
        name: rootSubject,
        url: url,
        description: "",
        lock: false,
        pay: false
    }];

    if (rootTid > 0) {
        let childResponse = fetch(BASE_URL + "/index.php?app=forum&act=achildlist&tid=" + rootTid);
        if (childResponse.ok) {
            let rows = childResponse.json();
            let parts = [];
            for (let i = 0; i < (rows ? rows.length : 0); i++) {
                let row = rows[i];
                // Only direct replies with real content are parts; the rest are comments,
                // thanks and vote posts.
                if (parseInt(row.uptid, 10) !== rootTid) continue;
                if (parseInt(row.size, 10) < MIN_PART_SIZE) continue;
                parts.push(row);
            }
            parts.sort(function (a, b) { return parseInt(a.tid, 10) - parseInt(b.tid, 10); });
            for (let j = 0; j < parts.length; j++) {
                chapters.push({
                    name: cleanSubject(parts[j].subject),
                    url: threadUrl(parts[j].tid),
                    description: "",
                    lock: false,
                    pay: false
                });
            }
        }
    }

    return Response.success(chapters);
}
