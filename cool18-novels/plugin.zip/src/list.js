load('config.js');

// Generic paged list behind the home tabs and the genre chips.
//   ""            latest updates (tid cursor)
//   "gold"        本版精华区 — editor picks
//   "hot"         人气热贴 — reading ranking
//   "shu:1|2|3"   书库藏文 — one page of the book library index
//   "cat:<name>"  category listing
//   "uid:<id>"    one poster's threads
//
// Serial parts are collapsed into one entry per novel; the library is already
// one entry per book.
function execute(query, page) {
    query = query || "";
    let feed;
    let grouped = true;
    if (query === "gold") {
        feed = goldFeed(page);
    } else if (query === "hot") {
        feed = hotFeed();
    } else if (query.indexOf("shu:") === 0) {
        feed = shuFeed(query.substring(4), page);
        grouped = false;
    } else if (query.indexOf("cat:") === 0) {
        feed = categoryFeed(query.substring(4), page);
    } else if (query.indexOf("uid:") === 0) {
        feed = posterFeed(query.substring(4), page);
    } else {
        feed = latestFeed(page);
    }
    if (feed === null) return Response.error("Không tải được danh sách");
    return Response.success(grouped ? groupSeries(feed.items) : feed.items, feed.next);
}
