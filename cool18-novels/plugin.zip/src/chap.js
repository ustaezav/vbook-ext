load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    if (isBookView(url)) {
        let content = bookViewContent(doc);
        if (!content) return Response.error("Không tìm thấy nội dung chương");
        return Response.success(content, bookViewTitle(doc));
    }

    let content = postContentHtml(doc);
    if (!content) return Response.error("Không tìm thấy nội dung chương");

    return Response.success(content, doc.select("h1.main-title").text().trim());
}
