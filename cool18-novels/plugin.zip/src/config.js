// Shared helpers for the Cool18 Novels extension. Every script starts with
// load('config.js'); a loaded library must not load another file, so all shared code
// lives here.

// The board itself is a forum: one "post" is one part of a novel, and the later parts
// are posted as replies under the first post. A book is therefore the first post plus
// its content replies.
let BASE_URL = "https://www.cool18.com/bbs4";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

function siteOrigin() {
    let match = BASE_URL.match(/^(https?:\/\/[^\/]+)/);
    return match ? match[1] : BASE_URL;
}

// Rewrite an incoming url's host to the configured domain, keeping path and query.
// Call this first thing in every url-receiving execute(url).
function normalizeUrl(url) {
    let match = String(url).match(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?[^\/\n]+(\/.*)$/);
    return match ? siteOrigin() + match[1] : url;
}

// Resolve a link found on a page into an absolute url.
function absUrl(href) {
    if (!href) return "";
    href = String(href);
    if (/^https?:\/\//i.test(href)) return normalizeUrl(href);
    if (href.charAt(1) === "/") return siteOrigin().replace(/\/\/[^\/]*$/, "") + href;
    if (href.charAt(0) === "/") return siteOrigin() + href;
    return BASE_URL + "/" + href;
}

function threadUrl(tid) {
    return BASE_URL + "/index.php?app=forum&act=threadview&tid=" + tid;
}

function tidOf(url) {
    let match = String(url).match(/[?&]tid=(\d+)/);
    return match ? parseInt(match[1], 10) : 0;
}

function stripTags(value) {
    if (!value) return "";
    return String(value)
        .replace(/<[^>]*>/g, "")
        .replace(/&nbsp;/gi, " ")
        .replace(/&amp;/gi, "&")
        .replace(/&lt;/gi, "<")
        .replace(/&gt;/gi, ">")
        .replace(/&quot;/gi, '"')
        .replace(/&#39;/g, "'")
        .replace(/[\s\u3000]+/g, " ")
        .trim();
}

// List subjects carry the category twice: as a trailing <span> and as a 『…』 label.
function cleanSubject(subject) {
    if (!subject) return "";
    return stripTags(String(subject).replace(/<span[^>]*list-type-show[^>]*>[\s\S]*?<\/span>/gi, ""));
}

function subjectMeta(subject) {
    let match = subject ? String(subject).match(/『([^』]*)』/) : null;
    return { name: cleanSubject(subject), type: match ? match[1] : "" };
}

function isCompleted(subject) {
    return /[（(][^（()）]{0,12}完[)）]|全文完|\[完\]|[（(]\s*全\s*[)）]/.test(subject || "");
}

function absoluteMedia(src) {
    if (!src) return src;
    if (/^(https?:|data:)/i.test(src)) return src;
    if (/^\/\//.test(src)) return "https:" + src;
    return absUrl(src);
}

// A post body lives in <pre> inside #content-section and separates paragraphs with
// either <p></p> or <br />. Turn that into plain reading HTML.
function contentToHtml(html) {
    if (!html) return "";
    let text = String(html)
        // Every paragraph carries a background-coloured site watermark.
        .replace(/<font[^>]*>\s*(?:www\.)?(?:6park|cool18)\.com\s*<\/font>/gi, "")
        .replace(/<p>\s*<\/p>/gi, "\n")
        .replace(/<br\s*\/?>/gi, "\n")
        .replace(/<p(?:\s[^>]*)?>/gi, "")
        .replace(/<\/p>/gi, "\n");
    text = text.replace(/(<img[^>]+src=["'])([^"']+)(["'])/gi, function (all, head, src, tail) {
        return head + absoluteMedia(src) + tail;
    });
    let lines = text.split("\n");
    let out = [];
    for (let i = 0; i < lines.length; i++) {
        let line = lines[i].replace(/^[\s\u3000]+|[\s\u3000]+$/g, "");
        if (line !== "") out.push("<p>" + line + "</p>");
    }
    return out.join("\n");
}

function contentNode(doc) {
    let node = doc.select("#content-section pre").first();
    if (node === null) node = doc.select("#content-section").first();
    if (node === null) return null;
    node.select(".view_ad_incontent, .ai-detection-feedback, script, style, iframe").remove();
    return node;
}

function postContentHtml(doc) {
    let node = contentNode(doc);
    return node === null ? "" : contentToHtml(node.html());
}

function postText(doc) {
    return stripTags(postContentHtml(doc));
}

// First uid linked from the page, used for the "more by this poster" tab.
function firstUid(doc) {
    let links = doc.select("a");
    for (let i = 0; i < links.size(); i++) {
        let href = links.get(i).attr("href");
        let match = href ? String(href).match(/[?&]uid=(\d+)/) : null;
        if (match) return match[1];
    }
    return "";
}

// The poster's uid on one part thread. The board only publishes it on a thread
// page, so a novel that spans several threads costs one extra fetch to keep the
// "same poster" suggestion.
function posterUidOf(tid) {
    if (!tid) return "";
    let response = fetch(threadUrl(tid));
    if (!response.ok) return "";
    return firstUid(response.html());
}

function categories() {
    let names = ["都市", "校园", "乡野", "古风", "异国", "玄幻", "红绿", "伦理", "独爱", "暴虐", "摄心", "其他"];
    let list = [];
    for (let i = 0; i < names.length; i++) {
        list.push({ title: names[i], input: "cat:" + names[i], script: "list.js" });
    }
    return list;
}

// Board list rows (search / category / uid results).
function parseThreadList(doc) {
    let items = [];
    doc.select("ul.thread-list li").forEach(function (row) {
        let link = row.select("a").first();
        if (link === null) return;
        let href = link.attr("href");
        if (!href || String(href).indexOf("threadview") === -1) return;
        let name = link.text().replace(/[\s\u3000]+/g, " ").trim();
        if (!name) return;
        let poster = row.select("font").first();
        let date = row.select("i").first();
        let bits = [];
        if (poster !== null && poster.text().trim()) bits.push(poster.text().trim());
        if (date !== null && date.text().trim()) bits.push(date.text().trim());
        items.push({
            name: name,
            link: absUrl(href),
            description: bits.join(" · "),
            host: siteOrigin()
        });
    });
    return items;
}

// Next-page token from the pager: the board numbers pages as "p=2", "p=3", …
function nextPageToken(doc) {
    let link = doc.select("nav.pagination-bar a.next").first();
    if (link === null) return "";
    let match = String(link.attr("href") || "").match(/[?&]p=(\d+)/);
    return match ? match[1] : "";
}

function pagedSearchUrl(extra, page) {
    let url = BASE_URL + "/index.php?action=search&act=threadsearch&app=forum&first=1&" +
        extra + "&submit=" + encodeURIComponent("查询");
    if (page) url += "&p=" + encodeURIComponent(page);
    return url;
}

function boardFeed(url) {
    let response = fetch(url);
    if (!response.ok) return null;
    let doc = response.html();
    return { items: parseThreadList(doc), next: nextPageToken(doc) };
}

// Newest posts, from the board's own AJAX feed. `page` is a tid cursor: the feed
// returns posts older than it.
function latestFeed(page) {
    let mtid = page ? String(page) : "0";
    let response = fetch(BASE_URL + "/index.php?app=forum&act=ajax&mtid=" + encodeURIComponent(mtid) + "&aifilter=0");
    if (!response.ok) return null;
    let rows = response.json();
    let items = [];
    let cursor = 0;
    for (let i = 0; i < (rows ? rows.length : 0); i++) {
        let row = rows[i];
        let tid = parseInt(row.tid, 10);
        let uptid = parseInt(row.uptid, 10);
        if (uptid === 0 && (cursor === 0 || tid < cursor)) cursor = tid;
        if (uptid !== 0 || parseInt(row.rootid, 10) !== 0) continue;
        let meta = subjectMeta(row.subject);
        if (!meta.name) continue;
        items.push({
            name: meta.name,
            link: threadUrl(row.tid),
            description: meta.type ? "『" + meta.type + "』" : "",
            tag: meta.type || "",
            host: siteOrigin()
        });
    }
    return { items: items, next: cursor ? String(cursor) : "" };
}

// 精华热帖 — editor-picked threads.
function goldFeed(page) {
    let url = BASE_URL + "/index.php?app=forum&act=gold";
    if (page) url += "&p=" + encodeURIComponent(page);
    let response = fetch(url);
    if (!response.ok) return null;
    let doc = response.html();
    let items = [];
    doc.select("ul.post-list li.post-item a").forEach(function (link) {
        let href = link.attr("href");
        if (!href || String(href).indexOf("threadview") === -1) return;
        let name = stripTags(link.text()).replace(/^[.．·\s]+/, "").trim();
        if (!name) return;
        items.push({ name: name, link: absUrl(href), host: siteOrigin() });
    });
    return { items: items, next: nextPageToken(doc) };
}

// 人气榜 — reading ranking, one page only.
function hotFeed() {
    let response = fetch(BASE_URL + "/index.php?app=forum&act=hot");
    if (!response.ok) return null;
    let doc = response.html();
    let items = [];
    doc.select("tr").forEach(function (row) {
        let link = row.select("td.title-col a").first();
        if (link === null) return;
        let href = link.attr("href");
        if (!href || String(href).indexOf("threadview") === -1) return;
        let raw = stripTags(link.text());
        // The rank row glues "- poster (N bytes) date (M reads)" onto the title.
        let cut = raw.search(/\s-\s[^()]*\([\d,]+ bytes\)/i);
        let name = (cut > 0 ? raw.substring(0, cut) : raw).trim();
        if (!name) return;
        items.push({
            name: name,
            link: absUrl(href),
            tag: stripTags(row.select("td.rank-col").text()),
            host: siteOrigin()
        });
    });
    return { items: items, next: "" };
}

function categoryFeed(name, page) {
    return boardFeed(pagedSearchUrl("type=" + encodeURIComponent(name), page));
}

function keywordFeed(keyword, page) {
    return boardFeed(pagedSearchUrl("keywords=" + encodeURIComponent(keyword), page));
}

function posterFeed(uid, page) {
    return boardFeed(pagedSearchUrl("uid=" + encodeURIComponent(uid), page));
}

// ---------------------------------------------------------------------------
// 书库藏文 — the board's legacy book library.
//
// The mods index the library (留园经典情色书库, served from index.php?app=book)
// with three forum posts. One library book is one or more "bookview" pages, and
// the 2nd/3rd posts list each book as "N 书名" followed by N links. The 1st post
// is a flat list of single-page books.
// ---------------------------------------------------------------------------

let SHU_INDEX = {
    "1": { tid: 14131297, title: "总目录" },
    "2": { tid: 14131299, title: "2-20帖" },
    "3": { tid: 14131300, title: "21帖以上" }
};

function isIndexTid(tid) {
    let key = String(tid);
    for (let part in SHU_INDEX) {
        if (String(SHU_INDEX[part].tid) === key) return true;
    }
    return false;
}

function indexTidOf(url) {
    let match = String(url).match(/[?&]tid=(\d+)/);
    return match ? match[1] : "";
}

function shuPartByTid(tid) {
    let key = String(tid);
    for (let part in SHU_INDEX) {
        if (String(SHU_INDEX[part].tid) === key) return part;
    }
    return "";
}

// A library page (one part of a book) versus a library book (a group of parts).
function isBookView(url) {
    return String(url).indexOf("app=book&act=bookview") !== -1;
}

function isBookGroup(url) {
    return String(url).indexOf("app=book&act=bookgroup") !== -1;
}

// A grouped book has no page of its own, so it is addressed by the index post it
// was listed in plus its position there.
function bookGroupUrl(tid, index) {
    return BASE_URL + "/index.php?app=book&act=bookgroup&tid=" + tid + "&i=" + index;
}

function bookGroupParams(url) {
    let tid = String(url).match(/[?&]tid=(\d+)/);
    let index = String(url).match(/[?&]i=(\d+)/);
    return { tid: tid ? tid[1] : "", index: index ? parseInt(index[1], 10) : -1 };
}

// Parse an index post into books. `grouped` is true for the posts that list a
// book as "N 书名" plus N links; the flat post gives every link its own book.
function parseShuBooks(html, grouped) {
    let books = [];
    let current = null;
    // Some links are written as href=" url " with stray spaces around the url.
    let re = /<a\b[^>]*href\s*=\s*["']?\s*([^"'\s>]+)\s*["']?[^>]*>([\s\S]*?)<\/a>/gi;
    let lastEnd = 0;
    let match;
    while ((match = re.exec(html)) !== null) {
        // The html is re-serialised by the parser, so attribute values come back
        // with "&amp;" instead of "&".
        let href = String(match[1]).replace(/&amp;/gi, "&").replace(/&#38;/g, "&").trim().split("#")[0];
        let label = stripTags(match[2]).replace(/^[.\s\u3000·．]+|[.\s\u3000·．]+$/g, "");
        let gap = html.substring(lastEnd, match.index);
        lastEnd = re.lastIndex;

        // A part is a library page or, for long books, a forum collection post.
        let isPart = href.indexOf("act=bookview") !== -1 || /[?&]tid=\d+/.test(href);
        // The other two index posts are linked from the intro; skip them.
        if (!isPart || !label || isIndexTid(indexTidOf(href))) continue;

        if (grouped) {
            let header = gap.replace(/<[^>]*>/g, " ").replace(/[\s\u3000]+/g, " ").trim();
            // The header is the last "N 书名" in the text before this link.
            let head = header.match(/(?:.*\s|^)(\d+)\s+(\S.*)$/);
            if (head && head[2].length <= 45) {
                current = { name: head[2], parts: [] };
                books.push(current);
            }
        } else {
            current = { name: label, parts: [] };
            books.push(current);
        }
        if (current === null) {
            current = { name: label, parts: [] };
            books.push(current);
        }
        current.parts.push({ name: label, url: absUrl(href) });
    }
    return books;
}

function shuBooks(part) {
    let info = SHU_INDEX[String(part)];
    if (!info) return null;
    let cacheKey = "cool18-shu-v3-" + info.tid;
    let cached = null;
    try {
        cached = cacheStorage.getItem(cacheKey);
    } catch (error) {
    }
    if (cached) {
        try {
            return JSON.parse(cached);
        } catch (error) {
        }
    }

    let response = fetch(threadUrl(info.tid));
    if (!response.ok) return null;
    let node = contentNode(response.html());
    if (node === null) return null;

    let books = parseShuBooks(node.html(), String(part) !== "1");
    try {
        cacheStorage.setItem(cacheKey, JSON.stringify(books));
    } catch (error) {
    }
    return books;
}

// Paged list of the library, one page of the index post at a time.
function shuFeed(part, page) {
    let books = shuBooks(part);
    if (books === null) return null;

    let offset = page ? parseInt(page, 10) : 0;
    if (isNaN(offset) || offset < 0) offset = 0;
    let limit = 300;
    let end = Math.min(offset + limit, books.length);

    let items = [];
    for (let i = offset; i < end; i++) {
        let book = books[i];
        let single = book.parts.length === 1;
        items.push({
            name: book.name,
            link: single ? book.parts[0].url : bookGroupUrl(SHU_INDEX[String(part)].tid, i),
            description: book.parts.length + " phần",
            host: siteOrigin()
        });
    }
    return { items: items, next: end < books.length ? String(end) : "" };
}

// Book-view pages are an old flat template: a "show_content" cell holding the
// title, the poster and one <pre> body between HTML comment markers.
function bookViewBody(doc) {
    let node = doc.select("td.show_content").first();
    if (node === null) return null;
    node.select("script, style, iframe").remove();
    return node;
}

function bookViewTitle(doc) {
    let node = doc.select("td.show_content center b").first();
    if (node !== null) {
        let name = stripTags(node.text());
        if (name) return name;
    }
    let title = doc.select("title").first();
    if (title !== null) {
        let text = stripTags(title.text());
        let cut = text.indexOf(" - ");
        return (cut > 0 ? text.substring(0, cut) : text).trim();
    }
    return "";
}

function bookViewByline(doc) {
    let node = bookViewBody(doc);
    if (node === null) return "";
    let match = node.text().match(/送交者\s*[:：]\s*([^\s]+)/);
    return match ? match[1] : "";
}

function bookViewContent(doc) {
    let node = bookViewBody(doc);
    if (node === null) return "";

    let body = node.select("pre").first();
    let html;
    if (body !== null) {
        body.select("script, style, iframe").remove();
        html = body.html();
    } else {
        // No <pre> body: fall back to the markers the template wraps it in.
        html = node.html();
        let open = "<!--bodybegin-->";
        let close = "<!--bodyend-->";
        let begin = html.indexOf(open);
        if (begin !== -1) {
            let end = html.indexOf(close);
            html = html.substring(begin + open.length, end > begin ? end : html.length);
        }
        html = html.replace(/<\/?pre[^>]*>/gi, "");
    }

    return contentToHtml(html);
}

function bookViewText(doc) {
    return stripTags(bookViewContent(doc));
}

// ---------------------------------------------------------------------------
// Forum serials — one novel posted as one thread per part.
//
// A part thread is titled 【novel】（435-440）作者：X, though plenty of posters write
// it without brackets. Feeds collapse the parts of one novel into a single entry,
// and the entry resolves its chapters through the board's own search. That search
// rejects queries longer than a few characters and matches a superset for a shorter
// prefix, so the title is queried by prefix and the hits are filtered back down by
// full title and credit.
// ---------------------------------------------------------------------------

const SERIES_SEARCH_LENGTH = 7;
const SERIES_MAX_PAGES = 6;
// Chapter numerals, ASCII or full-width digits or Chinese.
const CHAPTER_NUMERALS = "0-9０-９一二三四五六七八九十百零两";

function isSeries(url) {
    return String(url).indexOf("app=forum&act=series") !== -1;
}

function seriesDisplayName(name, label, author) {
    return "【" + name + "】" + (author ? " " + (label || "作者") + "：" + author : "");
}

function seriesUrl(name, label, author, tid) {
    return BASE_URL + "/index.php?app=forum&act=series" +
        "&n=" + encodeURIComponent(name) +
        "&l=" + encodeURIComponent(label || "") +
        "&a=" + encodeURIComponent(author || "") +
        "&t=" + encodeURIComponent(tid || 0);
}

function urlParam(url, key) {
    let match = String(url).match(new RegExp("[?&]" + key + "=([^&]*)"));
    if (match === null) return "";
    let value = match[1].replace(/\+/g, " ");
    try {
        return decodeURIComponent(value);
    } catch (error) {
        return value;
    }
}

function seriesParams(url) {
    return {
        name: urlParam(url, "n"),
        label: urlParam(url, "l"),
        author: urlParam(url, "a"),
        tid: parseInt(urlParam(url, "t"), 10) || 0
    };
}

// The novel title and the author/translator credit carried by one part thread.
function seriesName(subject) {
    let text = cleanSubject(subject).trim();
    let match = text.match(/^\s*[【［]([^】］]+)[】］]/);
    if (match) return match[1].trim();

    // Plenty of posters never bracket the title — "我的妻子是退役空姐（二十二）",
    // "我的警花妻子 （6-7）作者：X" — so fall back to it. A trailing chapter marker
    // is what separates a serial from a one-off post.
    let rest = text
        .replace(/(作者|译者)\s*[:：]?\s*[^\s【】［］（）()]+[\s]*$/, "")
        .replace(/(\[[^\]\n]{0,12}\]|【[^】\n]{0,12}】)[\s]*$/, "")
        .trim();
    let tail = "[" + CHAPTER_NUMERALS + "]+";
    let marker = rest.match(new RegExp("^(.*?)[\\s]*[（(][\\s]*" + tail + "[\\s]*[-－–—~～至][\\s]*" + tail + "[\\s]*[章节集卷回篇夜话节]?[\\s]*[）)]$"));
    if (!marker) {
        marker = rest.match(new RegExp("^(.*?)[\\s]*[（(][\\s]*" + tail + "[\\s]*[章节集卷回篇夜话节]?[\\s]*[）)]$"));
    }
    if (!marker) {
        marker = rest.match(new RegExp("^(.*?)[\\s]*第[\\s]*" + tail + "[\\s]*[章节集卷回篇夜话]$"));
    }
    if (!marker) return "";

    let name = marker[1].trim();
    return name.length >= 2 ? name : "";
}

function seriesCredit(subject) {
    let match = cleanSubject(subject).match(/(作者|译者)\s*[:：]?\s*([^\s『』【】［］（）()]+)/);
    if (match === null) return { label: "", value: "" };
    return { label: match[1], value: match[2].replace(/[.,，。:：、]+$/, "") };
}

function creditKey(value) {
    return String(value || "").replace(/[^\u4e00-\u9fffa-zA-Z0-9]/g, "");
}

// Credits drift between parts (月乌 / 月烏, a truncated 月), so an empty credit, one
// extending the other, or a shared first character counts as the same author.
function creditsMatch(a, b) {
    let x = creditKey(a);
    let y = creditKey(b);
    if (!x || !y || x === y) return true;
    if (x.indexOf(y) === 0 || y.indexOf(x) === 0) return true;
    return x.charAt(0) === y.charAt(0);
}

function halfWidth(value) {
    return String(value)
        .replace(/[０-９]/g, function (ch) {
            return String.fromCharCode(ch.charCodeAt(0) - 65248);
        })
        .replace(/[－–—~～]/g, "-");
}

// 二十二 -> 22, 九 -> 9, 22 -> 22; -1 when the text is not a number at all.
function chineseNumber(text) {
    let value = String(text === undefined || text === null ? "" : text).trim();
    if (!value) return -1;
    let ascii = halfWidth(value);
    if (/^[0-9]+$/.test(ascii)) return parseInt(ascii, 10);

    let digits = { "零": 0, "〇": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9 };
    let total = 0;
    let section = 0;
    let seen = false;
    for (let i = 0; i < value.length; i++) {
        let ch = value.charAt(i);
        if (digits[ch] !== undefined) {
            section = digits[ch];
            seen = true;
        } else if (ch === "十") {
            total += (section || 1) * 10;
            section = 0;
            seen = true;
        } else if (ch === "百") {
            total += (section || 1) * 100;
            section = 0;
            seen = true;
        } else {
            return -1;
        }
    }
    return seen ? total + section : -1;
}

// Reading position of a part, from its "（435-440）", "（二十二）" or "第99章" marker;
// -1 when the subject carries none, which leaves the parts in posting order.
function chapterOrder(subject) {
    let text = cleanSubject(subject);
    let cut = Math.max(text.indexOf("】"), text.indexOf("］"));
    let rest = halfWidth(cut === -1 ? text : text.substring(cut + 1));
    let numerals = "[" + CHAPTER_NUMERALS + "]";
    let part = rest.match(new RegExp("第\\s*(" + numerals + "+)\\s*[章集卷回篇]"));
    if (part) return chineseNumber(part[1]);
    let range = rest.match(new RegExp("[（(]?\\s*(" + numerals + "+)\\s*[-－–—~～至]"));
    if (range) return chineseNumber(range[1]);
    let single = rest.match(new RegExp("[（(]\\s*(" + numerals + "+)"));
    if (single) return chineseNumber(single[1]);
    return -1;
}

function compareChapters(a, b) {
    if (a.order >= 0 && b.order >= 0 && a.order !== b.order) return a.order - b.order;
    return a.tid - b.tid;
}

// Collapse the part threads of one novel into a single list entry.
function groupSeries(items) {
    let entries = [];
    let groups = [];
    for (let i = 0; i < items.length; i++) {
        let item = items[i];
        let name = seriesName(item.name);
        if (!name) {
            entries.push(item);
            continue;
        }
        let credit = seriesCredit(item.name);
        let group = null;
        for (let g = 0; g < groups.length; g++) {
            if (groups[g].name === name && creditsMatch(groups[g].author, credit.value)) {
                group = groups[g];
                break;
            }
        }
        if (group === null) {
            group = { name: name, label: credit.label, author: credit.value, count: 1, item: item };
            groups.push(group);
            entries.push({ series: group });
        } else {
            group.count++;
        }
    }

    let result = [];
    for (let i = 0; i < entries.length; i++) {
        let entry = entries[i];
        if (!entry.series) {
            result.push(entry);
            continue;
        }
        let group = entry.series;
        let item = group.item;
        item.name = seriesDisplayName(group.name, group.label, group.author);
        item.link = seriesUrl(group.name, group.label, group.author, tidOf(item.link));
        // The count is only what this page saw; a novel's other parts live on other
        // pages, so it would understate. Show it only when parts were actually merged.
        if (group.count > 1) item.description = group.count + " phần";
        result.push(item);
    }
    return result;
}

function addSeriesQueries(queries, text) {
    for (let length = Math.min(text.length, SERIES_SEARCH_LENGTH); length >= 4; length--) {
        queries.push(text.substring(0, length));
    }
    if (text.length > 0 && text.length < 4) queries.push(text);
}

function seriesQueries(name) {
    let queries = [];
    addSeriesQueries(queries, String(name).trim());
    let cleaned = creditKey(name);
    if (cleaned !== String(name).trim()) addSeriesQueries(queries, cleaned);
    let unique = [];
    for (let i = 0; i < queries.length; i++) {
        if (queries[i] && unique.indexOf(queries[i]) === -1) unique.push(queries[i]);
    }
    return unique;
}

function collectSeries(query, name, author) {
    let chapters = [];
    let seen = {};
    let page = "";
    let pages = 0;
    while (pages < SERIES_MAX_PAGES) {
        pages++;
        let feed = boardFeed(pagedSearchUrl("keywords=" + encodeURIComponent(query), page));
        if (feed === null || feed.items.length === 0) break;
        for (let i = 0; i < feed.items.length; i++) {
            let tid = tidOf(feed.items[i].link);
            if (!tid || seen[tid]) continue;
            let subject = cleanSubject(feed.items[i].name);
            if (seriesName(subject) !== name) continue;
            if (!creditsMatch(seriesCredit(subject).value, author)) continue;
            seen[tid] = true;
            chapters.push({ tid: tid, subject: subject, order: chapterOrder(subject) });
        }
        if (!feed.next) break;
        page = feed.next;
    }
    chapters.sort(compareChapters);
    return chapters;
}

// Every part thread of the novel, in reading order.
function seriesChapters(name, author) {
    let queries = seriesQueries(name);
    for (let i = 0; i < queries.length; i++) {
        let chapters = collectSeries(queries[i], name, author);
        if (chapters.length > 0) return chapters;
    }
    return [];
}
