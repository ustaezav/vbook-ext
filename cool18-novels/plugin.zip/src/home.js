load('config.js');

// Home tabs. Every tab is a paged list.js run with its own input token.
function execute() {
    let tabs = [
        { title: "最新更新", input: "", script: "list.js" },
        { title: "本版精华区", input: "gold", script: "list.js" }
    ];
    for (let part in SHU_INDEX) {
        tabs.push({ title: "书库藏文·" + SHU_INDEX[part].title, input: "shu:" + part, script: "list.js" });
    }
    tabs.push({ title: "人气热贴", input: "hot", script: "list.js" });
    return Response.success(tabs);
}
