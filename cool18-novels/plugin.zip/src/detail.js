load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    if (isSeries(url)) return seriesDetail(url);
    if (isBookGroup(url)) return bookGroupDetail(url);
    if (isBookView(url)) return bookViewDetail(url);
    return threadDetail(url);
}

// A novel whose parts are separate threads. A one-thread novel is the ordinary
// post-plus-replies case, so it stays on the thread reader.
function seriesDetail(url) {
    let params = seriesParams(url);
    let chapters = seriesChapters(params.name, params.author);
    if (chapters.length === 0) {
        if (params.tid) return threadDetail(threadUrl(params.tid));
        return Response.error("Không tìm thấy tác phẩm");
    }
    if (chapters.length === 1) return threadDetail(threadUrl(chapters[0].tid));

    let names = [];
    for (let i = 0; i < chapters.length && i < 3; i++) names.push(chapters[i].subject);
    let info = [];
    if (params.author) info.push((params.label || "作者") + "：" + params.author);
    info.push("Số phần: " + chapters.length);

    // Same-poster suggestion, read off the part thread this entry came from.
    let uid = posterUidOf(params.tid || chapters[chapters.length - 1].tid);
    let suggests = [];
    if (uid) suggests.push({ title: "Cùng người đăng", input: "uid:" + uid, script: "list.js" });

    return Response.success({
        name: seriesDisplayName(params.name, params.label, params.author),
        author: params.author,
        description: "Gồm " + chapters.length + " phần: " + names.join(", ") + "…",
        detail: info.join("<br>"),
        url: url,
        type: "novel",
        format: "novel",
        ongoing: !isCompleted(chapters[chapters.length - 1].subject),
        nsfw: true,
        locale: "zh",
        suggests: suggests
    });
}

// A library book made of several parts.
function bookGroupDetail(url) {
    let params = bookGroupParams(url);
    let part = shuPartByTid(params.tid);
    let books = part ? shuBooks(part) : null;
    if (books === null || !books[params.index]) return Response.error("Không tìm thấy sách");

    let book = books[params.index];
    let names = [];
    for (let i = 0; i < book.parts.length && i < 3; i++) names.push(book.parts[i].name);

    return Response.success({
        name: book.name,
        author: "",
        description: "Gồm " + book.parts.length + " phần: " + names.join(", ") + (book.parts.length > 3 ? "…" : ""),
        detail: "Số phần: " + book.parts.length,
        url: url,
        type: "novel",
        format: "novel",
        ongoing: !isCompleted(book.name),
        nsfw: true,
        locale: "zh"
    });
}

// A single library page, i.e. a whole short book.
function bookViewDetail(url) {
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let name = bookViewTitle(doc);
    if (!name) return Response.error("Không tìm thấy tên sách");
    let author = bookViewByline(doc);
    let text = bookViewText(doc);

    let info = [];
    if (author) info.push("Người đăng: " + author);
    info.push("Nguồn: 留园经典情色书库");

    return Response.success({
        name: name,
        author: author,
        description: text.length > 300 ? text.substring(0, 300) + "…" : text,
        detail: info.join("<br>"),
        url: url,
        type: "novel",
        format: "novel",
        ongoing: !isCompleted(name),
        nsfw: true,
        locale: "zh"
    });
}

// A forum post: the root post plus its content replies make the whole series.
function threadDetail(url) {
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let rootUrl = url;
    let subject = doc.select("h1.main-title").text().trim();
    let postedSubject = subject;

    // A later part carries a link back to the first post of the series; that first post
    // is the real book, so the whole set of parts lands in one chapter list.
    let firstPost = doc.select(".reply-info a").first();
    if (firstPost !== null) {
        let href = firstPost.attr("href");
        if (href) rootUrl = absUrl(href);
        let rootSubject = firstPost.text().trim();
        if (rootSubject) subject = rootSubject;
    }

    let poster = doc.select(".sender a").first();
    let author = poster !== null ? poster.text().trim() : "";
    let sentAt = doc.select(".sender").text().match(/于\s*([0-9]{4}-[0-9]{2}-[0-9]{2}[^\s]*)/);
    let views = doc.select(".views").text().trim();

    // The novel author usually sits in the subject as "作者：X".
    let byline = subject.match(/作者\s*[:：]?\s*([^\s】\]（()【]+)/);
    let novelAuthor = byline ? byline[1] : "";

    let info = [];
    if (author) info.push("Người đăng: " + author);
    if (novelAuthor && novelAuthor !== author) info.push("Tác giả: " + novelAuthor);
    if (sentAt) info.push("Ngày: " + sentAt[1]);
    if (views) info.push(views);

    let text = postText(doc);
    let uid = firstUid(doc);
    let suggests = [];
    if (uid) suggests.push({ title: "Cùng người đăng", input: "uid:" + uid, script: "list.js" });

    return Response.success({
        name: subject,
        author: author,
        description: text.length > 300 ? text.substring(0, 300) + "…" : text,
        detail: info.join("<br>"),
        url: rootUrl,
        type: "novel",
        format: "novel",
        ongoing: !(isCompleted(postedSubject) || isCompleted(subject)),
        nsfw: true,
        locale: "zh",
        suggests: suggests
    });
}
