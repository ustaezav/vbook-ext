load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    let response = request(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let chapters = [];
    let episodes = doc.select(".episode a[href]");

    if (!episodes.isEmpty()) {
        episodes.forEach(function (el) {
            let name = el.select("img").attr("alt").trim();
            if (!name) name = el.select("li").text().replace(/[0-9]{10}\s*$/, "").trim();
            if (!name) name = el.text().trim();
            chapters.push({
                name: name,
                url: el.attr("href"),
                description: "",
                lock: false,
                pay: false
            });
        });
        chapters.reverse();
        return Response.success(chapters);
    }

    let readLink = doc.select("a[href*='/moeupup-']").first();
    let chapterUrl = readLink ? readLink.attr("href") : "";
    if (!chapterUrl) {
        let match = url.match(/\/moehome-([0-9]+)-([0-9]+)\.html/);
        if (!match) match = url.match(/\/showinfo-([0-9]+)-([0-9]+)-[0-9]+\.html/);
        if (match) chapterUrl = "/moeupup-" + match[1] + "-" + match[2] + ".html";
    }
    if (!chapterUrl) return Response.error("Không tìm thấy chương");

    chapters.push({
        name: "Đọc toàn bộ",
        url: chapterUrl,
        description: "",
        lock: false,
        pay: false
    });

    return Response.success(chapters);
}
