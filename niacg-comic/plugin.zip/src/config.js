let BASE_URL = "https://www.niacg.com";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function absoluteUrl(path) {
    if (!path) return "";
    if (path.indexOf("//") === 0) return "https:" + path;
    if (path.indexOf("http") === 0) return path;
    return BASE_URL + (path.charAt(0) === "/" ? path : "/" + path);
}

function request(url, options) {
    let opts = options || {};
    let headers = {
        "User-Agent": UserAgent.chrome(),
        "Referer": BASE_URL + "/"
    };
    if (opts.headers) {
        Object.assign(headers, opts.headers);
    }
    opts.headers = headers;
    return fetch(url, opts);
}
