function execute() {
    return Response.success([
        { title: "Mới nhất", input: "/listinfo-9-0.html", script: "search.js" },
        { title: "COS", input: "/listinfo-1-0.html", script: "search.js" },
        { title: "CG", input: "/listinfo-2-0.html", script: "search.js" },
        { title: "本子", input: "/listinfo-3-0.html", script: "search.js" },
        { title: "套图", input: "/listinfo-4-0.html", script: "search.js" },
        { title: "日漫", input: "/listinfo-14-0.html", script: "search.js" },
        { title: "韩漫", input: "/listinfo-15-0.html", script: "search.js" }
    ]);
}
