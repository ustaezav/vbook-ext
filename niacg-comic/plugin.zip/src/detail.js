load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    let response = request(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let name = doc.select("h1.book-name").text().trim();
    if (!name) name = doc.select(".panel-heading .pull-left").text().trim();
    if (!name) name = doc.select("title").text().replace(/\s+-\s+.*$/, "");

    let coverEl = doc.select("img[itemprop=image]").first();
    let cover = coverEl ? coverEl.attr("src") : "";

    let description = doc.select("meta[name=description]").attr("content");

    let info = [];
    let date = doc.select("p.p-t-5.float-left").text().trim();
    if (date) info.push(date);
    let pages = doc.select(".pagecount").text().trim();
    if (pages) info.push(pages);

    let tags = [];
    let seenTags = {};
    doc.select("span[itemprop=genre] a[href]").forEach(function (el) {
        let href = el.attr("href");
        let title = el.text().trim();
        if (!title || seenTags[href]) return;
        seenTags[href] = true;
        tags.push({ title: title, input: href, script: "search.js" });
    });

    let authorEl = doc.select("span[itemprop=author]").first();
    let author = authorEl ? authorEl.text().trim() : "";

    let result = {
        name: name,
        author: author,
        cover: cover,
        description: description,
        detail: info.join(" · "),
        url: url,
        type: "comic",
        format: "comic",
        ongoing: true,
        nsfw: true,
        tags: tags
    };

    if (tags.length) {
        result.genres = [{ title: "Cùng thể loại", input: tags[0].input, script: "search.js" }];
    }

    result.suggests = [{ title: "Truyện liên quan", input: url, script: "similar.js" }];
    if (!doc.select("script[src*='lgyPl2.0']").isEmpty()) {
        result.comments = [{ title: "Bình luận", input: url, script: "comments.js" }];
    }

    return Response.success(result);
}
