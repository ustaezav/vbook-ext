load('config.js');

function splitCommentLink(link) {
    let html = link.html().replace(/<em[\s\S]*?<\/em>/gi, "");
    let parsed = Html.parse("<div>" + html + "</div>");
    return parsed.select("div").first().text().trim();
}

function absoluteImage(path) {
    if (!path) return "";
    if (path.indexOf("http") === 0) return path;
    return absoluteUrl(path);
}

function replyItems(el) {
    let replies = [];
    el.select(".lgyPl_v2_record_reply_item").forEach(function (reply) {
        let userLink = reply.select(".lgyPl_v2_record_reply_item_userinfo_link").first();
        let content = reply.select(".lgyPl_v2_record_reply_saytext").html();
        if (!content) content = reply.select(".lgyPl_v2_record_reply_item_saytext").html();
        replies.push({
            name: userLink ? splitCommentLink(userLink) : "",
            avatar: absoluteImage(reply.select(".lgyPl_v2_record_reply_item_userinfo_link img").attr("src")),
            content: content,
            description: reply.select(".lgyPl_v2_record_reply_saytime").text().trim(),
            replies: []
        });
    });
    return replies;
}

function execute(input, page) {
    let match = String(input || "").match(/\/(?:moehome|showinfo)-([0-9]+)-([0-9]+)(?:-[0-9]+)?\.html/);
    if (!match) return Response.error("Không xác định được bài viết");

    let classid = match[1];
    let id = match[2];
    let pageIndex = parseInt(page || "1", 10);
    if (!pageIndex || pageIndex < 1) pageIndex = 1;

    let api = BASE_URL + "/e/extend/lgyPl2.0/api/record.php?orderby=0&id=" + id +
        "&classid=" + classid;
    if (pageIndex > 1) api += "&pageIndex=" + pageIndex;

    let response = request(api);
    if (!response.ok) return Response.error("HTTP " + response.status);

    let json;
    try {
        json = JSON.parse(response.text());
    } catch (error) {
        return Response.error("Không đọc được bình luận");
    }

    let root = Html.parse("<div>" + (json.result || "") + "</div>");
    let items = [];

    root.select(".lgyPl_v2_record_item").forEach(function (el) {
        let userLink = el.select(".lgyPl_v2_record_item_userinfo_link").first();
        let content = el.select(".lgyPl_v2_record_item_saytext").html();
        content = content.replace(/<fieldset[\s\S]*?<\/fieldset>/gi, "");

        items.push({
            name: userLink ? splitCommentLink(userLink) : "",
            avatar: absoluteImage(el.select(".lgyPl_v2_record_item_userinfo_link img").attr("src")),
            content: content,
            description: userLink ? userLink.select("em").text().trim() : "",
            replies: replyItems(el)
        });
    });

    let totalPages = parseInt(json.pageTotal || 0, 10);
    let next = pageIndex < totalPages ? String(pageIndex + 1) : "";

    return Response.success(items, next);
}
