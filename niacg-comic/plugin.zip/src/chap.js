load('config.js');

function collectImages(doc) {
    let images = [];
    doc.select("img.comic_img").forEach(function (el) {
        let src = el.attr("data-src") || el.attr("src");
        if (src && src.indexOf("data:") !== 0) images.push(src);
    });
    if (images.length) return images;

    doc.select(".niacg-niuniu img").forEach(function (el) {
        let src = el.attr("data-src") || el.attr("src");
        if (src && src.indexOf("http") === 0 && src.indexOf("imgloading") === -1) {
            images.push(src);
        }
    });
    return images;
}

function execute(url) {
    url = normalizeUrl(url);

    let fetchUrl = url;
    let match = url.match(/\/showinfo-([0-9]+)-([0-9]+)-[0-9]+\.html/);
    if (match) {
        fetchUrl = BASE_URL + "/moeupup-" + match[1] + "-" + match[2] + ".html";
    }

    let response = request(fetchUrl);
    if (!response.ok && fetchUrl !== url) {
        fetchUrl = url;
        response = request(url);
    }
    if (!response.ok) return Response.error("HTTP " + response.status);

    let images = collectImages(response.html());
    if (!images.length) return Response.error("Không tìm thấy ảnh");

    return Response.success(images);
}
