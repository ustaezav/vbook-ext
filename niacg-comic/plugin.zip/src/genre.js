load('config.js');
function execute() {
    let genres = [
        { title: "COS", input: "/listinfo-1-0.html", script: "search.js" },
        { title: "CG", input: "/listinfo-2-0.html", script: "search.js" },
        { title: "本子", input: "/listinfo-3-0.html", script: "search.js" },
        { title: "套图", input: "/listinfo-4-0.html", script: "search.js" },
        { title: "日漫", input: "/listinfo-14-0.html", script: "search.js" },
        { title: "韩漫", input: "/listinfo-15-0.html", script: "search.js" }
    ];

    let response = request(BASE_URL + "/");
    if (!response.ok) return Response.success(genres);
    let doc = response.html();

    let seen = {};
    genres.forEach(function (item) {
        seen[item.title] = true;
    });

    doc.select(".tag-hot a[href]").forEach(function (el) {
        let title = el.text().trim();
        if (!title || seen[title]) return;
        seen[title] = true;
        genres.push({ title: title, input: el.attr("href"), script: "search.js" });
    });

    return Response.success(genres);
}
