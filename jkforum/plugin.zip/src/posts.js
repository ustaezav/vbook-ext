load('config.js');

let PAGE_SIZE = 20;

// One reader page: the thread starter on page 1, then 20 comments per page. The
// site's own pager works the same way, so page numbers match what the reader shows.
function execute(url, page) {
    let articleId = parseArticleId(url);
    if (!articleId) return Response.error("URL không hợp lệ");

    let threadData = getJson(apiUrl("ArticleThread/" + articleId));
    if (!threadData || !threadData.content) return Response.error("Không tải được chủ đề");
    let thread = threadData.content;

    let totalPages = Math.max(1, Math.ceil(Number(thread.replyCount || 0) / PAGE_SIZE));
    let current = parseInt(page, 10);
    if (isNaN(current) || current < 1) current = 1;
    if (current > totalPages) current = totalPages;
    let offset = (current - 1) * PAGE_SIZE;

    let commentData = getJson(
        apiUrl(
            "CommentThread/" +
                articleId +
                "?sortingType=1&commentSortingColumn=0&Offset=" +
                offset +
                "&Limit=" +
                PAGE_SIZE
        )
    );
    let comments = commentData && commentData.content ? commentData.content : [];

    let posts = [];
    let seen = {};
    if (current === 1) {
        posts.push(threadPost(thread, articleId));
        seen[String(thread.id || articleId)] = true;
    }

    for (let i = 0; i < comments.length; i++) {
        let comment = comments[i];
        if (!comment || comment.isDeleted) continue;
        if (comment.id && seen[String(comment.id)]) continue;
        if (comment.id) seen[String(comment.id)] = true;
        posts.push(commentPost(comment, null, articleId));

        let replies = comment.replyComments || [];
        for (let j = 0; j < replies.length; j++) {
            let reply = replies[j];
            if (!reply || reply.isDeleted) continue;
            if (reply.id && seen[String(reply.id)]) continue;
            if (reply.id) seen[String(reply.id)] = true;
            posts.push(commentPost(reply, comment, articleId));
        }
    }

    return Response.success(
        { posts: posts, page: current, total_pages: totalPages },
        current < totalPages ? String(current + 1) : ""
    );
}

function threadPost(thread, articleId) {
    let post = {
        id: String(thread.id || articleId),
        floor: 1,
        url: threadUrl(articleId),
        is_op: true,
        time: formatTime(thread.publishDate),
        user: userFromAuthor(thread.author),
        content: bbcodeToHtml(thread.content, thread.attachments),
        content_format: "html"
    };
    if (thread.likeCount) post.likes = Number(thread.likeCount);
    if (thread.author && thread.author.signatureLine) {
        post.signature = escapeHtml(thread.author.signatureLine).replace(/\n/g, "<br>");
    }
    if (thread.modificationDate && thread.modificationDate !== thread.publishDate) {
        post.edited = { time: formatTime(thread.modificationDate) };
    }
    return post;
}

function commentPost(comment, parent, articleId) {
    let post = {
        id: String(comment.id || ""),
        url: threadUrl(articleId),
        is_op: false,
        time: formatTime(comment.creationDate),
        user: userFromAuthor(comment.author),
        content: bbcodeToHtml(comment.content, comment.attachments),
        content_format: "html"
    };
    if (comment.floor) post.floor = Number(comment.floor);
    if (comment.likeCount) post.likes = Number(comment.likeCount);
    if (comment.dislikeCount) post.dislikes = Number(comment.dislikeCount);
    if (parent) {
        post.reply_to = {
            floor: parent.floor ? Number(parent.floor) : 0,
            user: parent.author && parent.author.name ? String(parent.author.name) : ""
        };
    }
    return post;
}
