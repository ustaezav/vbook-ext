load('config.js');

// Home opens on the area's newest threads; the second tab is the board tree of
// https://jkforum.net/forum?gid=51 (card-51, 成人娛樂).
function execute() {
    return Response.success([
        { title: "最新文章", input: "area:51", script: "list.js" },
        { title: "版區", input: "", script: "explore.js", type: "explore" }
    ]);
}
