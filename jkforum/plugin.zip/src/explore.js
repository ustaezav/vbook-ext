load('config.js');

// The area page mixes the board tabs and each board's newest threads in one answer.
// Board items open list.js; the latest section is filled from the same response.
function execute() {
    let data = getJson(apiUrl("AreaArticle/51?Offset=0&Limit=3"));
    if (!data || !data.content) return Response.error("Không tải được khu 成人娛樂");

    let area = data.content;
    let titles = {};
    let boards = area.boardTabs || [];
    let boardItems = [];
    for (let i = 0; i < boards.length; i++) {
        let board = boards[i];
        if (!board || !board.id) continue;
        titles[String(board.id)] = String(board.title || "");
        if (board.redirectUrl) continue;
        boardItems.push({
            name: String(board.title || ""),
            link: boardUrl(board.id),
            description: String(board.description || ""),
            action: {
                type: "list",
                name: String(board.title || ""),
                script: "list.js",
                input: String(board.id)
            }
        });
    }

    let sections = [
        {
            id: "boards",
            type: "board_list",
            title: String(area.areaTitle || "成人娛樂"),
            items: boardItems
        }
    ];

    let latest = [];
    let groups = area.boardArticles || [];
    for (let j = 0; j < groups.length; j++) {
        let group = groups[j];
        if (!group) continue;
        let boardId = String(group.boardId || "");
        let articles = group.articles || [];
        for (let k = 0; k < articles.length; k++) {
            latest.push({ article: articles[k], board: titles[boardId] || "" });
        }
    }
    latest.sort(function (a, b) {
        return String(b.article.publishDate || "").localeCompare(String(a.article.publishDate || ""));
    });

    let seen = {};
    let threadItems = [];
    for (let n = 0; n < latest.length && threadItems.length < 20; n++) {
        let entry = latest[n];
        let key = String(entry.article.id || "");
        if (!key || seen[key]) continue;
        seen[key] = true;
        threadItems.push(articleToItem(entry.article, entry.board));
    }
    if (threadItems.length) {
        sections.push({ id: "latest", type: "thread_list", title: "最新文章", items: threadItems });
    }

    return Response.success(sections);
}
