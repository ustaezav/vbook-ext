// Shared helpers for the JKF forum extension.

let BASE_URL = "https://jkforum.net";
try {
    if (DOMAIN) BASE_URL = String(DOMAIN).replace(/\/+$/, "");
} catch (error) {
}

// JKF moved to a Nuxt client that reads everything from this JSON API. The public
// endpoints used here need no login and no age-gate cookie.
function apiUrl(path) {
    return BASE_URL + "/api/jkf-forum/v1/" + path;
}

function getJson(url) {
    let response = fetch(url, { headers: { "Accept": "application/json" } });
    if (!response.ok) return null;
    try {
        return response.json();
    } catch (error) {
        return null;
    }
}

function threadUrl(articleId) {
    return BASE_URL + "/thread-" + articleId + "-1-1.html";
}

function boardUrl(boardId) {
    return BASE_URL + "/forum-" + boardId + "-1.html";
}

function parseArticleId(value) {
    let text = String(value || "");
    let match = text.match(/thread-(\d+)-/i);
    if (match) return match[1];
    match = text.match(/[?&]articleId=(\d+)/i);
    if (match) return match[1];
    match = text.match(/(\d{5,})/);
    return match ? match[1] : "";
}

function parseBoardId(value) {
    let text = String(value || "");
    let match = text.match(/forum-(\d+)-/i);
    if (match) return match[1];
    match = text.match(/[?&](?:boardId|gid)=(\d+)/i);
    if (match) return match[1];
    match = text.match(/^\d+$/);
    return match ? text : "";
}

// The site stores uploads behind numeric ids and serves them from these paths.
function mediaUrl(source) {
    let text = String(source || "").trim();
    if (!text) return "";
    if (/^\d+$/.test(text)) return BASE_URL + "/attachment/" + text;
    if (/^https?:\/\//i.test(text)) return text;
    if (text.indexOf("//") === 0) return "https:" + text;
    if (text.charAt(0) === "/") return BASE_URL + text;
    return "";
}

// Link targets in post bodies come from users: keep web and site-relative URLs only.
function safeLink(value) {
    let text = String(value || "").trim();
    if (!text) return "";
    if (/^(?:javascript|data|vbscript):/i.test(text)) return "";
    if (/^https?:\/\//i.test(text)) return text;
    if (text.indexOf("//") === 0) return "https:" + text;
    if (text.charAt(0) === "/") return BASE_URL + text;
    if (/^[a-z][a-z0-9+.-]*:/i.test(text)) return "";
    return text;
}

function coverUrl(cover, coverType, size) {
    let text = String(cover || "").trim();
    if (!text) return "";
    if (/^https?:\/\//i.test(text)) return text;
    let suffix = size ? "?s=" + size : "";
    if (Number(coverType) === 1) return BASE_URL + "/attachment/" + text + suffix;
    return BASE_URL + "/media/" + text + "/thumb.png" + suffix;
}

function avatarUrl(authorId) {
    return authorId ? BASE_URL + "/avatar/" + authorId : "";
}

function formatTime(value) {
    let text = String(value || "");
    let match = text.match(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})/);
    return match ? match[1] + " " + match[2] : text;
}

function escapeHtml(value) {
    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

function escapeAttr(value) {
    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/"/g, "&quot;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

function decodeEntities(value) {
    return String(value || "")
        .replace(/&nbsp;/gi, " ")
        .replace(/&lt;/gi, "<")
        .replace(/&gt;/gi, ">")
        .replace(/&quot;/gi, '"')
        .replace(/&#0*39;/g, "'")
        .replace(/&#x0*27;/gi, "'")
        .replace(/&#(\d+);/g, function (all, code) {
            return String.fromCharCode(parseInt(code, 10));
        })
        .replace(/&#x([0-9a-f]+);/gi, function (all, code) {
            return String.fromCharCode(parseInt(code, 16));
        })
        .replace(/&amp;/gi, "&");
}

function cleanText(value) {
    let text = decodeEntities(String(value || ""));
    text = text.replace(/\[img\][\s\S]*?\[\/img\]/gi, " ");
    text = text.replace(/\[video\][\s\S]*?\[\/video\]/gi, " ");
    text = text.replace(/\[[a-zA-Z][^\]]*\]/g, " ");
    text = text.replace(/\[\/[a-zA-Z]+\]/g, " ");
    return text.replace(/[\s\u3000\u2800]+/g, " ").trim();
}

function shortDescription(value) {
    let text = cleanText(value);
    if (text.length > 180) text = text.substring(0, 177) + "...";
    return text;
}

function userFromAuthor(author) {
    if (!author) return { name: "Guest" };
    let user = {
        name: String(author.name || "Guest")
    };
    if (author.id) {
        user.id = String(author.id);
        user.avatar = avatarUrl(author.id);
    }
    let title = author.groupName || author.group || "";
    if (title) user.title = String(title);
    let count = author.articleCount;
    if (count !== undefined && count !== null && Number(count) > 0) user.posts_count = Number(count);
    if (author.credit !== undefined && author.credit !== null) user.reputation = String(author.credit);
    return user;
}

function articleToItem(article, boardName) {
    let item = {
        name: String(article.title || "").replace(/[\u2800]+/g, "").trim(),
        link: threadUrl(article.id),
        author: String(article.creatorName || ""),
        avatar: article.creatorId ? avatarUrl(article.creatorId) : "",
        time: formatTime(article.publishDate),
        replies: String(article.replyCount || 0),
        views: String(article.viewCount || 0),
        description: shortDescription(article.content)
    };
    let cover = coverUrl(article.cover, article.coverType, "312f");
    if (cover) item.cover = cover;
    if (boardName) item.board = boardName;
    if (article.pinType && Number(article.pinType) > 0) item.pinned = true;
    if (article.recommend) item.hot = true;
    return item;
}

function attachmentKind(fileType, source) {
    if (Number(fileType) === 2) return "video";
    if (Number(fileType) === 1) return "image";
    let text = String(source || "");
    if (/\.(?:mp4|mov|m3u8)(?:$|\?)/i.test(text)) return "video";
    if (/\.(?:jpg|jpeg|png|gif|webp|heic)(?:$|\?)/i.test(text)) return "image";
    return "file";
}

// The API returns post bodies as BBCode, mixing numeric upload ids and external links.
// Decoding entities before re-escaping keeps the original text visible while any raw
// markup in the source is neutralised.
function bbcodeToHtml(value, attachments) {
    let stashed = [];
    let referenced = {};
    let text = escapeHtml(decodeEntities(String(value || "")));

    text = text.replace(/\[code\]([\s\S]*?)\[\/code\]/gi, function (all, body) {
        stashed.push("<pre>" + body + "</pre>");
        return "\u0000CODE" + (stashed.length - 1) + "\u0000";
    });

    text = text.replace(/\[(img|attachimg|media)\]([\s\S]*?)\[\/\1\]/gi, function (all, tag, source) {
        let key = String(source || "").trim();
        let url = mediaUrl(key);
        if (!url) return "";
        referenced[key] = true;
        return '<p><img src="' + url + '"></p>';
    });

    text = text.replace(/\[video\]([\s\S]*?)\[\/video\]/gi, function (all, source) {
        let key = String(source || "").trim();
        if (!key) return "";
        referenced[key] = true;
        if (/^\d+$/.test(key)) {
            let manifest = BASE_URL + "/media/" + key + "/manifest.m3u8";
            let poster = BASE_URL + "/media/" + key + "/thumb.png";
            return '<p><a href="' + escapeAttr(manifest) + '"><img src="' + escapeAttr(poster) + '"></a></p>';
        }
        let url = mediaUrl(key);
        return url ? '<p><a href="' + url + '">▶ ' + key + "</a></p>" : "";
    });

    text = text.replace(/\[stick\](\d+)\[\/stick\]/gi, function (all, stickerId) {
        return '<img src="' + BASE_URL + "/sticker/" + stickerId + '">';
    });

    text = text.replace(/\[url=["']?([^\]"']+)["']?\]([\s\S]*?)\[\/url\]/gi, function (all, href, label) {
        let url = safeLink(href);
        return url ? '<a href="' + url + '">' + label + "</a>" : label;
    });
    text = text.replace(/\[url\]([\s\S]*?)\[\/url\]/gi, function (all, href) {
        let url = safeLink(href);
        return url ? '<a href="' + url + '">' + href + "</a>" : href;
    });

    text = text.replace(/\[at=\d+\]([\s\S]*?)\[\/at\]/gi, "@$1");
    text = text.replace(/\[quote\]([\s\S]*?)\[\/quote\]/gi, "<blockquote>$1</blockquote>");
    text = text.replace(/\[b\]([\s\S]*?)\[\/b\]/gi, "<b>$1</b>");
    text = text.replace(/\[i\]([\s\S]*?)\[\/i\]/gi, "<i>$1</i>");
    text = text.replace(/\[u\]([\s\S]*?)\[\/u\]/gi, "<u>$1</u>");
    text = text.replace(/\[s\]([\s\S]*?)\[\/s\]/gi, "<s>$1</s>");
    text = text.replace(/\[center\]([\s\S]*?)\[\/center\]/gi, '<div style="text-align:center">$1</div>');
    text = text.replace(/\[right\]([\s\S]*?)\[\/right\]/gi, '<div style="text-align:right">$1</div>');
    text = text.replace(/\[color=([^\]]+)\]([\s\S]*?)\[\/color\]/gi, '<span style="color:$1">$2</span>');
    text = text.replace(/\[size=([^\]]+)\]([\s\S]*?)\[\/size\]/gi, '<span style="font-size:$1">$2</span>');

    text = text.replace(/\[list(?:=[^\]]*)?\]/gi, "<ul>");
    text = text.replace(/\[\/list\]/gi, "</ul>");
    text = text.replace(/\[\*\]/gi, "<li>");
    text = text.replace(/\[hr\]/gi, "<hr>");
    text = text.replace(/\[\/?table\]/gi, "");
    text = text.replace(/\[\/?tr\]/gi, "");
    text = text.replace(/\[\/?td\]/gi, "");
    text = text.replace(/\[\/?th\]/gi, "");

    text = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, "<br>");
    text = text.replace(/\[[\/!]?[a-zA-Z][^\]]*\]/g, "");
    text = text.replace(/\u0000CODE(\d+)\u0000/g, function (all, index) {
        return stashed[Number(index)];
    });

    if (attachments && attachments.length) {
        let extra = "";
        for (let i = 0; i < attachments.length; i++) {
            let attachment = attachments[i] || {};
            let source = String(attachment.source || "").trim();
            if (!source || referenced[source]) continue;
            if (attachment.includeContent === false) continue;
            let kind = attachmentKind(attachment.fileType, source);
            if (kind === "image") {
                let url = mediaUrl(source);
                if (url) extra += '<p><img src="' + url + '"></p>';
            } else if (kind === "video") {
                if (/^\d+$/.test(source)) {
                    extra +=
                        '<p><a href="' +
                        escapeAttr(BASE_URL + "/media/" + source + "/manifest.m3u8") +
                        '"><img src="' +
                        escapeAttr(BASE_URL + "/media/" + source + "/thumb.png") +
                        '"></a></p>';
                } else {
                    extra += '<p><a href="' + escapeAttr(mediaUrl(source)) + '">附件</a></p>';
                }
            } else {
                let name = attachment.name ? String(attachment.name) : "附件";
                extra += '<p><a href="' + escapeAttr(mediaUrl(source)) + '">' + escapeHtml(name) + "</a></p>";
            }
        }
        if (extra) text += extra;
    }

    return text;
}
