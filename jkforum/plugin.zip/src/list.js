load('config.js');

let PAGE_SIZE = 40;

// Thread list of one board, or the area's newest threads when the input is "area:51".
function execute(input, page) {
    let value = String(input || "").trim();
    let current = parseInt(page, 10);
    if (isNaN(current) || current < 1) current = 1;

    if (value.indexOf("area:") === 0) {
        return areaList(value.substring(5), current);
    }
    return boardList(parseBoardId(value), current);
}

function boardList(boardId, page) {
    if (!boardId) return Response.error("Chuyên mục không hợp lệ");
    let offset = (page - 1) * PAGE_SIZE;
    let url = apiUrl(
        "Article/" +
            boardId +
            "?tab=0&isQueryPin=" +
            (page === 1 ? "true" : "false") +
            "&Offset=" +
            offset +
            "&Limit=" +
            PAGE_SIZE
    );
    let data = getJson(url);
    if (!data || !data.content) return Response.error("Không tải được danh sách chủ đề");

    let content = data.content;
    let items = [];
    let seen = {};
    if (page === 1) {
        let pinned = content.pinArticles || [];
        for (let i = 0; i < pinned.length; i++) {
            let item = articleToItem(pinned[i], "");
            if (!item.link || seen[item.link]) continue;
            seen[item.link] = true;
            item.pinned = true;
            items.push(item);
        }
    }
    let articles = content.articles || [];
    for (let j = 0; j < articles.length; j++) {
        let item = articleToItem(articles[j], "");
        if (!item.name || seen[item.link]) continue;
        seen[item.link] = true;
        items.push(item);
    }

    let next = "";
    let paging = data.paging || {};
    let count = Number(paging.count || 0);
    if (articles.length >= PAGE_SIZE && (!count || offset + PAGE_SIZE < count)) {
        next = String(page + 1);
    }
    return Response.success(items, next);
}

function areaList(areaId, page) {
    if (page > 1) return Response.success([], "");
    let data = getJson(apiUrl("AreaArticle/" + areaId + "?Offset=0&Limit=3"));
    if (!data || !data.content) return Response.error("Không tải được khu chuyên mục");

    let area = data.content;
    let titles = {};
    let boards = area.boardTabs || [];
    for (let i = 0; i < boards.length; i++) {
        if (boards[i] && boards[i].id) titles[String(boards[i].id)] = String(boards[i].title || "");
    }

    let entries = [];
    let groups = area.boardArticles || [];
    for (let j = 0; j < groups.length; j++) {
        let group = groups[j];
        if (!group) continue;
        let articles = group.articles || [];
        for (let k = 0; k < articles.length; k++) {
            entries.push({ article: articles[k], board: titles[String(group.boardId || "")] || "" });
        }
    }
    entries.sort(function (a, b) {
        return String(b.article.publishDate || "").localeCompare(String(a.article.publishDate || ""));
    });

    let items = [];
    let seen = {};
    for (let n = 0; n < entries.length; n++) {
        let article = entries[n].article;
        let key = String(article.id || "");
        if (!key || seen[key]) continue;
        seen[key] = true;
        items.push(articleToItem(article, entries[n].board));
    }
    return Response.success(items, "");
}
