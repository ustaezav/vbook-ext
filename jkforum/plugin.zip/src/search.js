load('config.js');

let PAGE_SIZE = 20;

function execute(query, page) {
    let keyword = String(query || "").trim();
    if (!keyword) return Response.success([], "");

    let current = parseInt(page, 10);
    if (isNaN(current) || current < 1) current = 1;
    let offset = (current - 1) * PAGE_SIZE;

    let url = apiUrl(
        "ArticleSearch?keyword=" +
            encodeURIComponent(keyword) +
            "&sortingType=1&includeAdult=true&Offset=" +
            offset +
            "&Limit=" +
            PAGE_SIZE
    );
    let data = getJson(url);
    if (!data || !data.content) return Response.error("Không tải được kết quả tìm kiếm");

    let articles = data.content.articles || [];
    let items = [];
    for (let i = 0; i < articles.length; i++) {
        let article = articles[i];
        if (!article || !article.id) continue;
        items.push(articleToItem(article, String(article.boardName || "")));
    }

    let next = "";
    let count = Number((data.paging || {}).count || 0);
    if (articles.length >= PAGE_SIZE && (!count || offset + PAGE_SIZE < count)) {
        next = String(current + 1);
    }
    return Response.success(items, next);
}
