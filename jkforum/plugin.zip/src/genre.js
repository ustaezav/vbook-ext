load('config.js');

// Boards of area 51. Each entry feeds list.js with the numeric board id.
function execute() {
    let data = getJson(apiUrl("AreaArticle/51?Offset=0&Limit=3"));
    if (!data || !data.content) return Response.error("Không tải được danh sách chuyên mục");

    let boards = data.content.boardTabs || [];
    let items = [];
    for (let i = 0; i < boards.length; i++) {
        let board = boards[i];
        if (!board || !board.id || board.redirectUrl) continue;
        items.push({
            title: String(board.title || ""),
            input: String(board.id),
            script: "list.js"
        });
    }
    return Response.success(items);
}
