load('config.js');

function execute(query, page) {
    query = String(query || "").trim();
    page = parseInt(page, 10) || 1;
    if (page < 1) page = 1;
    if (!query) return Response.success([], "");

    let url = BASE_URL + PREFIX + "/search/";
    if (page > 1) url += "page/" + page + "/";
    url += "?s=" + encodeURIComponent(query);

    let response = fetch(url, { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    return Response.success(listFromDoc(doc), hasNextPage(doc) ? String(page + 1) : "");
}
