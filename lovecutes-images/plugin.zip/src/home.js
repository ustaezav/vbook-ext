function execute() {
    return Response.success([
        { title: "Mới cập nhật", input: "/vi/sort/new/", script: "list.js" },
        { title: "Phổ biến", input: "/vi/sort/hot/", script: "list.js" },
        { title: "Cosplay", input: "/vi/type/6/", script: "list.js" },
        { title: "người đẹp sexy", input: "/vi/type/1/", script: "list.js" }
    ]);
}
