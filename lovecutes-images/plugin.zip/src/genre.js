load('config.js');

function execute() {
    let genres = [
        { title: "người đẹp sexy", input: "/vi/type/1/", script: "list.js" },
        { title: "Người đẹp thuần khiết", input: "/vi/type/2/", script: "list.js" },
        { title: "Gái đẹp Vớ chân", input: "/vi/type/3/", script: "list.js" },
        { title: "Chân đẹp", input: "/vi/type/4/", script: "list.js" },
        { title: "ngực đẹp", input: "/vi/type/5/", script: "list.js" },
        { title: "Cosplay", input: "/vi/type/6/", script: "list.js" },
        { title: "Đồng phục quyến rũ", input: "/vi/type/7/", script: "list.js" },
        { title: "Người đẹp internet", input: "/vi/type/8/", script: "list.js" },
        { title: "Phụ Nữ Đẹp Lớn", input: "/vi/type/9/", script: "list.js" },
        { title: "Ai đẹp", input: "/vi/type/10/", script: "list.js" },
        { title: "Phụ liệu", input: "/vi/bits-of-news/", script: "list.js" }
    ];

    let response = fetch(BASE_URL + PREFIX + "/tag/", { timeout: 30000 });
    if (response.ok) {
        let doc = response.html();
        doc.select(".tagslist li a.name").forEach(function (el) {
            let title = el.text().trim();
            let href = el.attr("href");
            if (title && href) genres.push({ title: title, input: href, script: "list.js" });
        });
    }

    return Response.success(genres);
}
