load('config.js');

function execute(url) {
    url = articleUrl(url);
    let response = fetch(url, { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let max = 1;
    let jump = doc.select("input.jump-input").first();
    if (jump) {
        max = parseInt(jump.attr("max"), 10) || 1;
    } else {
        let pages = doc.select(".pagination a[data-page]");
        pages.forEach(function (el) {
            let n = parseInt(el.attr("data-page"), 10);
            if (n > max) max = n;
        });
    }
    if (max < 1) max = 1;

    let base = url.replace(/\/+$/, "");
    let chapters = [];
    for (let i = 1; i <= max; i++) {
        chapters.push({
            name: max > 1 ? "Trang " + i + "/" + max : "Toàn bộ ảnh",
            url: i === 1 ? base + "/" : base + "/page/" + i + "/",
            description: "",
            lock: false,
            pay: false
        });
    }

    return Response.success(chapters);
}
