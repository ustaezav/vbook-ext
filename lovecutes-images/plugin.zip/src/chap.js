load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url, { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let images = [];
    doc.select("img.item-image__img").forEach(function (el) {
        let src = el.attr("src") || el.attr("data-src");
        if (src) images.push(absUrl(src));
    });

    if (images.length === 0) return Response.error("Không có ảnh");
    return Response.success(images);
}
