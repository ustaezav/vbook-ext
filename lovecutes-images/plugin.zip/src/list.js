load('config.js');

function execute(query, page) {
    query = String(query || "");
    page = parseInt(page, 10) || 1;
    if (page < 1) page = 1;
    if (!query) query = PREFIX + "/sort/new/";

    let base = query.indexOf("http") === 0 ? normalizeUrl(query) : BASE_URL + query;
    let url = base;
    if (page > 1) {
        url = base.replace(/\/+$/, "").replace(/\.html?$/i, "") + "/page/" + page + "/";
    }

    let response = fetch(url, { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    return Response.success(listFromDoc(doc), hasNextPage(doc) ? String(page + 1) : "");
}
