// CryptoJS in the vBook runtime passes WordArray bytes through text, which corrupts
// any byte >= 0x80. The site's HMAC inputs are binary, so SHA-256 and HMAC are done
// here on plain byte arrays.

let SHA256_K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
];

function rotr(value, bits) {
    return ((value >>> bits) | (value << (32 - bits))) >>> 0;
}

function sha256Bytes(input) {
    let bytes = input.slice(0);
    let bitLength = bytes.length * 8;
    bytes.push(0x80);
    while (bytes.length % 64 !== 56) bytes.push(0);

    let high = Math.floor(bitLength / 4294967296);
    let low = bitLength % 4294967296;
    bytes.push((high >>> 24) & 255, (high >>> 16) & 255, (high >>> 8) & 255, high & 255);
    bytes.push((low >>> 24) & 255, (low >>> 16) & 255, (low >>> 8) & 255, low & 255);

    let h = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];

    for (let offset = 0; offset < bytes.length; offset += 64) {
        let w = [];
        for (let i = 0; i < 16; i++) {
            let p = offset + i * 4;
            w.push(((bytes[p] << 24) | (bytes[p + 1] << 16) | (bytes[p + 2] << 8) | bytes[p + 3]) >>> 0);
        }
        for (let i = 16; i < 64; i++) {
            let s0 = (rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >>> 3)) >>> 0;
            let s1 = (rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >>> 10)) >>> 0;
            w.push((w[i - 16] + s0 + w[i - 7] + s1) >>> 0);
        }

        let a = h[0], b = h[1], c = h[2], d = h[3];
        let e = h[4], f = h[5], g = h[6], k = h[7];

        for (let i = 0; i < 64; i++) {
            let s1 = (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) >>> 0;
            let ch = ((e & f) ^ ((~e) & g)) >>> 0;
            let t1 = (k + s1 + ch + SHA256_K[i] + w[i]) >>> 0;
            let s0 = (rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) >>> 0;
            let maj = ((a & b) ^ (a & c) ^ (b & c)) >>> 0;
            let t2 = (s0 + maj) >>> 0;

            k = g;
            g = f;
            f = e;
            e = (d + t1) >>> 0;
            d = c;
            c = b;
            b = a;
            a = (t1 + t2) >>> 0;
        }

        h[0] = (h[0] + a) >>> 0;
        h[1] = (h[1] + b) >>> 0;
        h[2] = (h[2] + c) >>> 0;
        h[3] = (h[3] + d) >>> 0;
        h[4] = (h[4] + e) >>> 0;
        h[5] = (h[5] + f) >>> 0;
        h[6] = (h[6] + g) >>> 0;
        h[7] = (h[7] + k) >>> 0;
    }

    let out = [];
    for (let i = 0; i < 8; i++) {
        out.push((h[i] >>> 24) & 255, (h[i] >>> 16) & 255, (h[i] >>> 8) & 255, h[i] & 255);
    }
    return out;
}

function hmacSha256Bytes(keyBytes, messageBytes) {
    let key = keyBytes.slice(0);
    if (key.length > 64) key = sha256Bytes(key);
    while (key.length < 64) key.push(0);

    let inner = [];
    let outer = [];
    for (let i = 0; i < 64; i++) {
        inner.push(key[i] ^ 0x36);
        outer.push(key[i] ^ 0x5c);
    }
    return sha256Bytes(outer.concat(sha256Bytes(inner.concat(messageBytes))));
}

function utf8Bytes(text) {
    text = String(text);
    let out = [];
    for (let i = 0; i < text.length; i++) {
        let code = text.charCodeAt(i);
        if (code < 0x80) {
            out.push(code);
        } else if (code < 0x800) {
            out.push(0xc0 | (code >> 6), 0x80 | (code & 0x3f));
        } else if (code >= 0xd800 && code <= 0xdbff && i + 1 < text.length) {
            let next = text.charCodeAt(i + 1);
            if (next >= 0xdc00 && next <= 0xdfff) {
                let point = 0x10000 + ((code - 0xd800) << 10) + (next - 0xdc00);
                out.push(0xf0 | (point >> 18), 0x80 | ((point >> 12) & 0x3f), 0x80 | ((point >> 6) & 0x3f), 0x80 | (point & 0x3f));
                i++;
                continue;
            }
            out.push(0xe0 | (code >> 12), 0x80 | ((code >> 6) & 0x3f), 0x80 | (code & 0x3f));
        } else {
            out.push(0xe0 | (code >> 12), 0x80 | ((code >> 6) & 0x3f), 0x80 | (code & 0x3f));
        }
    }
    return out;
}

let B64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

function bytesFromB64Url(text) {
    let source = String(text);
    let out = [];
    let buffer = 0;
    let bits = 0;
    for (let i = 0; i < source.length; i++) {
        let value = B64_CHARS.indexOf(source.charAt(i));
        if (value < 0) continue;
        buffer = (buffer << 6) | value;
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            out.push((buffer >> bits) & 255);
            buffer = buffer & ((1 << bits) - 1);
        }
    }
    return out;
}

function b64UrlFromBytes(bytes) {
    let out = "";
    for (let i = 0; i < bytes.length; i += 3) {
        let b0 = bytes[i];
        let b1 = i + 1 < bytes.length ? bytes[i + 1] : 0;
        let b2 = i + 2 < bytes.length ? bytes[i + 2] : 0;

        out += B64_CHARS.charAt(b0 >> 2);
        out += B64_CHARS.charAt(((b0 & 3) << 4) | (b1 >> 4));
        if (i + 1 < bytes.length) out += B64_CHARS.charAt(((b1 & 15) << 2) | (b2 >> 6));
        if (i + 2 < bytes.length) out += B64_CHARS.charAt(b2 & 63);
    }
    return out;
}
