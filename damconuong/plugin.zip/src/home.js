load('config.js');

// Home tabs open the site's own listing pages through search.js.
function execute() {
    return Response.success([
        { title: "Mới cập nhật", input: BASE_URL + "/danh-sach", script: "search.js" },
        { title: "Truyện mới", input: BASE_URL + "/tim-kiem?sort=-created_at", script: "search.js" },
        { title: "Truyện Nhà Làm", input: BASE_URL + "/nhom-dich/dam-co-nuong", script: "search.js" },
        { title: "Hot ngày", input: BASE_URL + "/tim-kiem?sort=-views_day", script: "search.js" },
        { title: "Hot tuần", input: BASE_URL + "/tim-kiem?sort=-views_week", script: "search.js" },
        { title: "Hot mọi lúc", input: BASE_URL + "/tim-kiem?sort=-views", script: "search.js" }
    ]);
}
