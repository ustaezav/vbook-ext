load('config.js');

function statValue(label) {
    let value = cleanText(label.select("strong").text());
    if (!value) return "";
    let unit = cleanText(label.select("span").last().text());
    if (unit.indexOf("lượt)") >= 0) return value + " " + unit;
    return value;
}

function execute(url) {
    url = normalizeUrl(url).replace(/[?#].*$/, "");
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let name = cleanText(doc.select("h1.md-title").text());
    if (!name) return Response.error("Không tìm thấy truyện");

    let author = "";
    let translator = "";
    let translatorUrl = "";
    let chapterCount = "";
    doc.select("dl.md-rail > div").forEach(function (el) {
        let label = cleanText(el.select("dt").text());
        let value = cleanText(el.select("dd").text());
        if (label === "Tác giả") {
            author = value;
        } else if (label === "Nhóm dịch") {
            translator = value;
            translatorUrl = absUrl(el.select("dd a").attr("href"));
        } else if (label === "Tổng số chương") {
            chapterCount = value;
        }
    });

    if (!author) author = cleanText(doc.select("a.md-uploader strong").text());

    let description = cleanText(doc.select(".md-synopsis > p").text());

    let rating = "";
    let views = "";
    let follows = "";
    doc.select("ul.md-stats li").forEach(function (el) {
        let value = statValue(el);
        if (!value) return;
        let unit = cleanText(el.select("span").last().text());
        if (unit.indexOf("lượt)") >= 0) {
            rating = value;
        } else if (unit === "lượt xem") {
            views = value;
        } else if (unit === "theo dõi") {
            follows = value;
        }
    });

    let detailParts = [];
    if (translator) detailParts.push("Nhóm dịch: " + translator);
    if (chapterCount) detailParts.push("Tổng số chương: " + chapterCount);
    if (rating) detailParts.push("Đánh giá: " + rating);
    if (views) detailParts.push("Lượt xem: " + views);
    if (follows) detailParts.push("Theo dõi: " + follows);
    let detail = detailParts.join(" · ");

    // Each genre chip is its own entry so the detail screen shows the real
    // genres (Adult, Manhwa, Ahegao...) instead of a single generic link.
    let genres = [];
    doc.select(".md-rail-genres a.md-chip").forEach(function (el) {
        let href = absUrl(el.attr("href"));
        let title = cleanText(el.text());
        if (!href || !title) return;
        genres.push({ title: title, input: href, script: "search.js" });
    });
    if (translator && translatorUrl) {
        genres.push({
            title: "Nhóm dịch: " + translator,
            input: translatorUrl,
            script: "search.js"
        });
    }

    let suggests = [];
    if (!doc.select("ul.md-rel li").isEmpty()) {
        suggests.push({
            title: "Có thể bạn thích",
            input: url,
            script: "suggest.js"
        });
    }

    let comments = [];
    let commentUrl = doc.select("[data-comments-root]").attr("data-list-url");
    if (commentUrl) {
        comments.push({
            title: "Bình luận",
            input: absUrl(commentUrl),
            script: "comments.js"
        });
    }

    let ongoing = doc.select("a.md-badge-done").isEmpty();

    return Response.success({
        name: name,
        author: author,
        cover: doc.select(".md-cover img").attr("src"),
        description: description,
        detail: detail,
        url: url,
        type: "comic",
        format: "comic",
        ongoing: ongoing,
        nsfw: true,
        locale: "vi",
        tags: [],
        genres: genres,
        suggests: suggests,
        comments: comments
    });
}
