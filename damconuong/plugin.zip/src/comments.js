load('config.js');

// Comment threads are nested by data-depth: a depth-0 comment owns the
// depth-1 comments in its .cmt-thread, each of which owns depth-2 replies.
function commentItem(el, depth) {
    let name = cleanText(el.select(".cmt-name").first().text());
    let content = el.select(".cmt-text").first().html();

    let meta = [];
    let chapter = cleanText(el.select(".cmt-ch").first().text());
    if (chapter) meta.push(chapter);
    let time = cleanText(el.select(".cmt-meta").first().text());
    if (time) meta.push(time);

    let replies = [];
    if (depth < 4) {
        el.select(".cmt[data-depth=\"" + (depth + 1) + "\"]").forEach(function (child) {
            replies.push(commentItem(child, depth + 1));
        });
    }

    return {
        name: name || "Ẩn danh",
        avatar: el.select(".cmt-av img").first().attr("src"),
        content: content || cleanText(el.text()),
        description: meta.join(" · "),
        replies: replies
    };
}

function execute(input, page) {
    let url = normalizeUrl(input);
    page = page === undefined || page === null ? "1" : String(page);
    if (page && page !== "1") {
        url += (url.indexOf("?") === -1 ? "?" : "&") + "before=" + encodeURIComponent(page);
    }

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = [];
    doc.select(".cmt[data-depth=\"0\"]").forEach(function (el) {
        items.push(commentItem(el, 0));
    });

    let more = doc.select("[data-comments-more-button]");
    let next = more.isEmpty() ? "" : cleanText(more.first().attr("data-before"));

    return Response.success(items, next);
}
