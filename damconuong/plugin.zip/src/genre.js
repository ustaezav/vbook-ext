load('config.js');

// The site has no genre index page; the header menu already lists every genre.
function execute() {
    let response = fetch(BASE_URL);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let genres = [];
    let seen = {};
    doc.select("a[href*='/the-loai/']").forEach(function (el) {
        let href = absUrl(el.attr("href"));
        let title = cleanText(el.text());
        if (!href || !title || seen[href]) return;
        seen[href] = true;
        genres.push({ title: title, input: href, script: "search.js" });
    });

    if (genres.length === 0) return Response.error("Không tìm thấy thể loại");
    return Response.success(genres);
}
