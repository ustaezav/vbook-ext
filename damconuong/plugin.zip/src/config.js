let BASE_URL = "https://damconuong.win";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}
BASE_URL = String(BASE_URL).replace(/\/+$/, "");

// Chapter page payloads are encrypted with this static site key. The site keeps it
// inside its bookmark decoder script; it is not user-specific.
let PAGE_KEY = "YVdGuT8RjDWkeQjt7s7mv53smMpLrcKBuGMs8erg8Bs";

function normalizeUrl(url) {
    return String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function absUrl(href) {
    if (!href) return "";
    href = String(href);
    if (/^https?:\/\//i.test(href)) return normalizeUrl(href);
    if (href.charAt(0) === "/") return BASE_URL + href;
    return BASE_URL + "/" + href;
}

function cleanText(text) {
    return String(text === undefined || text === null ? "" : text)
        .replace(/[\s\u3000]+/g, " ")
        .trim();
}

// "https://host/truyen/<slug>/<chapter>" -> "<slug>/<chapter>".
function chapterPath(url) {
    let path = normalizeUrl(url).replace(/^https?:\/\/[^\/]+/i, "").replace(/^\/+/, "");
    if (path.indexOf("truyen/") === 0) path = path.substring("truyen/".length);
    return path.replace(/[?#].*$/, "").replace(/\/+$/, "");
}

// One story card. Every listing (home rows, search, genre and translator pages)
// renders the same `div.manga-vertical` block.
function cardItem(el) {
    let linkEl = el.select("h3 a").first();
    if (linkEl === null) linkEl = el.select("a[href]").first();
    if (linkEl === null) return null;

    let href = linkEl.attr("href");
    if (!href) return null;

    let img = el.select("img.cover").first();
    if (img === null) img = el.select("img").first();

    let name = cleanText(el.select("h3").text());
    if (!name && img !== null) name = cleanText(img.attr("alt"));
    if (!name) return null;

    let chapter = el.select("h4 a").first();
    let badge = el.select("div.absolute span").first();

    return {
        name: name,
        cover: img === null ? "" : img.attr("src"),
        link: absUrl(href),
        description: chapter === null ? "" : cleanText(chapter.text()),
        tag: badge === null ? "" : cleanText(badge.text())
    };
}

function listingItems(node) {
    let items = [];
    node.select("div.manga-vertical").forEach(function (el) {
        let item = cardItem(el);
        if (item) items.push(item);
    });
    return items;
}

function pagedUrl(base, page) {
    return base + (base.indexOf("?") === -1 ? "?" : "&") + "page=" + page;
}
