load('config.js');
load('hash.js');
load('gcm.js');

// The reader page ships no image markup: the page list is fetched from /_c and
// decrypted. The token is bound to "<slug>/<chapter>".
function pageToken(path) {
    let key = bytesFromB64Url(PAGE_KEY);
    let tokKey = hmacSha256Bytes(key, utf8Bytes("tok"));
    let signature = hmacSha256Bytes(tokKey, utf8Bytes(path));

    let tokenBytes = [1];
    for (let i = 0; i < 16; i++) tokenBytes.push(signature[i]);
    return b64UrlFromBytes(tokenBytes);
}

function decryptPages(encoded, token, path) {
    let cipher = bytesFromB64Url(encoded);

    // 12-byte nonce | ciphertext | 16-byte tag
    let iv = cipher.slice(0, 12);
    let tag = cipher.slice(cipher.length - 16);
    let body = cipher.slice(12, cipher.length - 16);

    let encKey = hmacSha256Bytes(bytesFromB64Url(PAGE_KEY), utf8Bytes("enc"));
    let aesKey = hmacSha256Bytes(encKey, utf8Bytes(token));

    let plain = gcmDecrypt(aesKey, iv, utf8Bytes(path), body, tag);
    if (!plain) throw new Error("bad tag");
    return JSON.parse(utf8StringFromBytes(plain));
}

function execute(url) {
    url = normalizeUrl(url);
    let path = chapterPath(url);
    if (!path || path.indexOf("/") === -1) return Response.error("URL chương không hợp lệ");

    let token = pageToken(path);
    let parts = path.split("/");
    let apiUrl = BASE_URL + "/_c/mangas/" + parts[0] + "/chapters/" + parts.slice(1).join("/") + "/pages?_=" + token;
    let response = fetch(apiUrl, {
        headers: {
            "X-Requested-With": "XMLHttpRequest"
        }
    });
    if (!response.ok) {
        let message = "";
        try {
            let body = response.json();
            if (body && body.message) message = cleanText(body.message);
        } catch (error) {
        }
        if (response.status === 403 && message) return Response.error("Chương yêu cầu đăng nhập");
        return Response.error("HTTP " + response.status + (message ? ": " + message : ""));
    }

    let payload = response.json();
    if (!payload || !payload.e) return Response.error("Không tìm thấy ảnh chương");

    let data;
    try {
        data = decryptPages(payload.e, token, path);
    } catch (error) {
        return Response.error("Không giải mã được chương");
    }
    if (!data || !data.p) return Response.error("Không tìm thấy ảnh chương");

    let images = [];
    let keys = data.s || [];
    for (let i = 0; i < data.p.length; i++) {
        let src = data.p[i];
        if (!src) continue;
        let key = keys[i];
        if (key) {
            images.push({
                link: src + (src.indexOf("?") === -1 ? "?" : "&") + "k=" + encodeURIComponent(key),
                script: "image.js"
            });
        } else {
            images.push(src);
        }
    }

    if (images.length === 0) return Response.error("Chương trống");
    return Response.success(images);
}
