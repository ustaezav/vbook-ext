load('config.js');
load('hash.js');

// Keyed pages are cut into horizontal bands and shuffled. The key carries the
// band count and permutation, derived from an HMAC stream seeded by the key.
function makeRng(keyBytes) {
    let counter = 0;
    let words = [];
    let position = 0;

    return function () {
        if (position >= words.length) {
            let message = [
                (counter >>> 24) & 255,
                (counter >>> 16) & 255,
                (counter >>> 8) & 255,
                counter & 255
            ];
            counter++;
            let digest = hmacSha256Bytes(keyBytes, message);
            words = [];
            for (let i = 0; i < 32; i += 4) {
                words.push(((digest[i] << 24) | (digest[i + 1] << 16) | (digest[i + 2] << 8) | digest[i + 3]) >>> 0);
            }
            position = 0;
        }
        return words[position++];
    };
}

function nextRand(rng, n) {
    let limit = Math.floor(4294967296 / n) * n;
    let value = rng();
    while (value >= limit) value = rng();
    return value % n;
}

function layoutFor(keyBytes, height) {
    let rng = makeRng(keyBytes);
    let bands = 8 + nextRand(rng, 13);
    let bandHeight = Math.floor(height / (16 * bands)) * 16;
    if (bandHeight < 16) return null;

    let perm = [];
    for (let i = 0; i < bands; i++) perm.push(i);
    for (let i = bands - 1; i >= 1; i--) {
        let j = nextRand(rng, i + 1);
        let tmp = perm[i];
        perm[i] = perm[j];
        perm[j] = tmp;
    }
    return { bands: bands, height: bandHeight, perm: perm };
}

function execute(link) {
    let keyAt = link.indexOf("?k=");
    let src = keyAt === -1 ? link : link.substring(0, keyAt);
    let keyText = keyAt === -1 ? "" : decodeURIComponent(link.substring(keyAt + 3));

    let response = fetch(src);
    if (!response.ok) return "";

    let original = response.base64();
    if (keyText.length !== 46 || keyText.substring(0, 3) !== "x1.") return original;

    let key = bytesFromB64Url(keyText.substring(3));
    if (key.length !== 32) return original;

    let image;
    try {
        image = Graphics.createImage(original);
    } catch (error) {
        return original;
    }
    if (!image || !image.width || !image.height) return original;

    let width = image.width;
    let height = image.height;
    let layout = layoutFor(key, height);
    if (layout === null) return original;

    let canvas;
    try {
        canvas = Graphics.createCanvas(width, height);
    } catch (error) {
        return original;
    }

    for (let i = 0; i < layout.bands; i++) {
        let sourceY = i * layout.height;
        let targetY = layout.perm[i] * layout.height;
        canvas.drawImage(image, 0, sourceY, width, layout.height, 0, targetY, width, layout.height);
    }
    let covered = layout.bands * layout.height;
    if (height > covered) {
        canvas.drawImage(image, 0, covered, width, height - covered, 0, covered, width, height - covered);
    }

    try {
        return canvas.capture();
    } catch (error) {
        return original;
    }
}
