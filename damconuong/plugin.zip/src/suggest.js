load('config.js');

// "Có thể bạn thích": the detail sidebar renders the same cards twice (a
// translator-group list and a genre list). Both are parsed and deduped.
function execute(url) {
    url = normalizeUrl(url).replace(/[?#].*$/, "");
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = [];
    let seen = {};
    doc.select("ul.md-rel li").forEach(function (el) {
        let linkEl = el.select("a[href]").first();
        if (linkEl === null) return;
        let link = absUrl(linkEl.attr("href"));
        if (!link || seen[link]) return;

        let name = cleanText(el.select(".md-rel-name").text());
        if (!name) return;
        seen[link] = true;

        let meta = [];
        el.select(".md-rel-meta span").forEach(function (span) {
            let text = cleanText(span.text());
            if (text) meta.push(text);
        });

        items.push({
            name: name,
            cover: el.select(".md-thumb img").attr("src"),
            link: link,
            description: meta.join(" · "),
            tag: ""
        });
    });

    if (!items.length) return Response.success([]);
    return Response.success(items);
}
