load('config.js');

// The site prints chapters newest first; return them oldest first so reading order
// matches the story.
function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let chapters = [];
    doc.select("a.md-ch").forEach(function (el) {
        let href = el.attr("href");
        if (!href) return;
        let title = cleanText(el.select(".md-ch-title").text());
        if (!title) title = cleanText(el.text());
        let meta = el.select(".md-ch-meta span").first();
        chapters.push({
            name: title,
            url: absUrl(href),
            description: meta === null ? "" : cleanText(meta.text()),
            lock: false,
            pay: false
        });
    });

    if (chapters.length === 0) return Response.error("Không tìm thấy chương");
    chapters.reverse();
    return Response.success(chapters);
}
