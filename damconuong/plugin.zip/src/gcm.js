// AES-256-GCM decryption in plain JS. The runtime's native cipher path only
// round-trips WordArray bytes below 0x80, and chapter payloads are binary, so
// the cipher is implemented here on byte arrays.

let AES_SBOX = [
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
    0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
    0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
    0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
    0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
    0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
    0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
    0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
    0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
    0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
    0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
    0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
    0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
    0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
    0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
];

function aesXtime(value) {
    value = value & 0xff;
    return ((value << 1) ^ (value & 0x80 ? 0x1b : 0)) & 0xff;
}

function aes256ExpandKey(key) {
    let words = [];
    for (let i = 0; i < 8; i++) words.push(key.slice(i * 4, i * 4 + 4));

    let rcon = 1;
    for (let i = 8; i < 60; i++) {
        let temp = words[i - 1].slice(0);
        if (i % 8 === 0) {
            temp = [AES_SBOX[temp[1]] ^ rcon, AES_SBOX[temp[2]], AES_SBOX[temp[3]], AES_SBOX[temp[0]]];
            rcon = aesXtime(rcon);
        } else if (i % 8 === 4) {
            temp = [AES_SBOX[temp[0]], AES_SBOX[temp[1]], AES_SBOX[temp[2]], AES_SBOX[temp[3]]];
        }
        let prev = words[i - 8];
        words.push([
            prev[0] ^ temp[0],
            prev[1] ^ temp[1],
            prev[2] ^ temp[2],
            prev[3] ^ temp[3]
        ]);
    }

    let roundKeys = [];
    for (let round = 0; round < 15; round++) {
        let rk = [];
        for (let c = 0; c < 4; c++) rk = rk.concat(words[round * 4 + c]);
        roundKeys.push(rk);
    }
    return roundKeys;
}

function aes256EncryptBlock(roundKeys, input) {
    let state = input.slice(0);

    for (let i = 0; i < 16; i++) state[i] ^= roundKeys[0][i];

    for (let round = 1; round <= 14; round++) {
        for (let i = 0; i < 16; i++) state[i] = AES_SBOX[state[i]];

        let shifted = state.slice(0);
        for (let row = 1; row < 4; row++) {
            for (let col = 0; col < 4; col++) {
                shifted[4 * col + row] = state[4 * ((col + row) % 4) + row];
            }
        }
        state = shifted;

        if (round !== 14) {
            for (let col = 0; col < 4; col++) {
                let p = 4 * col;
                let a0 = state[p], a1 = state[p + 1], a2 = state[p + 2], a3 = state[p + 3];
                let all = a0 ^ a1 ^ a2 ^ a3;
                state[p] = a0 ^ all ^ aesXtime(a0 ^ a1);
                state[p + 1] = a1 ^ all ^ aesXtime(a1 ^ a2);
                state[p + 2] = a2 ^ all ^ aesXtime(a2 ^ a3);
                state[p + 3] = a3 ^ all ^ aesXtime(a3 ^ a0);
            }
        }

        for (let i = 0; i < 16; i++) state[i] ^= roundKeys[round][i];
    }

    return state;
}

function gcmMultiply(x, y) {
    let z = new Array(16).fill(0);
    let v = y.slice(0);

    for (let i = 0; i < 128; i++) {
        if ((x[i >> 3] >> (7 - (i & 7))) & 1) {
            for (let j = 0; j < 16; j++) z[j] ^= v[j];
        }
        let lsb = v[15] & 1;
        for (let j = 15; j > 0; j--) v[j] = ((v[j] >> 1) | ((v[j - 1] & 1) << 7)) & 0xff;
        v[0] = (v[0] >> 1) & 0xff;
        if (lsb) v[0] ^= 0xe1;
    }
    return z;
}

function gcmGhash(hashKey, aad, cipher) {
    let state = new Array(16).fill(0);

    function absorb(block, length) {
        for (let i = 0; i < length; i++) state[i] ^= block[i];
        state = gcmMultiply(state, hashKey);
    }

    for (let offset = 0; offset < aad.length; offset += 16) {
        let block = new Array(16).fill(0);
        for (let i = 0; i < 16 && offset + i < aad.length; i++) block[i] = aad[offset + i];
        absorb(block, 16);
    }
    for (let offset = 0; offset < cipher.length; offset += 16) {
        let block = new Array(16).fill(0);
        for (let i = 0; i < 16 && offset + i < cipher.length; i++) block[i] = cipher[offset + i];
        absorb(block, 16);
    }

    let lengths = new Array(16).fill(0);
    let aadBits = aad.length * 8;
    let cipherBits = cipher.length * 8;
    lengths[7] = aadBits & 0xff;
    lengths[6] = (aadBits >>> 8) & 0xff;
    lengths[5] = (aadBits >>> 16) & 0xff;
    lengths[4] = (aadBits >>> 24) & 0xff;
    lengths[15] = cipherBits & 0xff;
    lengths[14] = (cipherBits >>> 8) & 0xff;
    lengths[13] = (cipherBits >>> 16) & 0xff;
    lengths[12] = (cipherBits >>> 24) & 0xff;
    absorb(lengths, 16);

    return state;
}

function gcmDecrypt(key, iv, aad, cipher, tag) {
    if (key.length !== 32 || iv.length !== 12 || tag.length !== 16) return null;

    let roundKeys = aes256ExpandKey(key);
    let hashKey = aes256EncryptBlock(roundKeys, new Array(16).fill(0));

    let j0 = iv.concat([0, 0, 0, 1]);
    let expected = gcmGhash(hashKey, aad, cipher);
    let mask = aes256EncryptBlock(roundKeys, j0);
    for (let i = 0; i < 16; i++) expected[i] ^= mask[i];

    let diff = 0;
    for (let i = 0; i < 16; i++) diff |= expected[i] ^ tag[i];
    if (diff !== 0) return null;

    let plain = [];
    let counter = j0.slice(0);
    for (let offset = 0; offset < cipher.length; offset += 16) {
        let carry = 1;
        for (let i = 15; i >= 12 && carry; i--) {
            let value = counter[i] + carry;
            counter[i] = value & 0xff;
            carry = value >> 8;
        }

        let stream = aes256EncryptBlock(roundKeys, counter);
        for (let i = 0; i < 16 && offset + i < cipher.length; i++) {
            plain.push(cipher[offset + i] ^ stream[i]);
        }
    }
    return plain;
}

function utf8StringFromBytes(bytes) {
    let out = "";
    for (let i = 0; i < bytes.length; i++) {
        let byte = bytes[i];
        if (byte < 0x80) {
            out += String.fromCharCode(byte);
        } else if (byte >= 0xc0 && byte < 0xe0 && i + 1 < bytes.length) {
            out += String.fromCharCode(((byte & 0x1f) << 6) | (bytes[++i] & 0x3f));
        } else if (byte >= 0xe0 && byte < 0xf0 && i + 2 < bytes.length) {
            out += String.fromCharCode(((byte & 0x0f) << 12) | ((bytes[++i] & 0x3f) << 6) | (bytes[++i] & 0x3f));
        } else if (byte >= 0xf0 && i + 3 < bytes.length) {
            let point = ((byte & 0x07) << 18) | ((bytes[++i] & 0x3f) << 12) | ((bytes[++i] & 0x3f) << 6) | (bytes[++i] & 0x3f);
            point -= 0x10000;
            out += String.fromCharCode(0xd800 + (point >> 10), 0xdc00 + (point & 0x3ff));
        }
    }
    return out;
}
