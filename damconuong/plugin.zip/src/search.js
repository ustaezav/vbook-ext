load('config.js');

// `query` is a search keyword or a listing URL supplied by home.js, genre.js,
// detail.js or an explore "Xem tất cả" action.
function execute(query, page) {
    query = cleanText(query);
    page = parseInt(page, 10);
    if (isNaN(page) || page < 1) page = 1;

    let url;
    if (query.indexOf("/") === 0 || query.indexOf("http") === 0) {
        let base = query.indexOf("http") === 0 ? normalizeUrl(query) : BASE_URL + query;
        url = pagedUrl(base, page);
    } else {
        url = BASE_URL + "/tim-kiem?filter%5Bname%5D=" + encodeURIComponent(query) + "&page=" + page;
    }

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = listingItems(doc);
    let hasNext = !doc.select("a[aria-label='Next']").isEmpty();

    return Response.success(items, hasNext ? String(page + 1) : "");
}
