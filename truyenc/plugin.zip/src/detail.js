load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let name = cleanText(doc.select("div.page-title h1").text());
    if (!name) return Response.error("Không tìm thấy truyện");

    let img = doc.select("img.story-image").first();
    let author = cleanText(doc.select("h3 b").text());
    let status = cleanText(doc.select("p.h6").text());

    let description = cleanText(doc.select("div.d-none.d-sm-block").text());
    if (!description) description = cleanText(doc.select("div.d-block.d-sm-none").text());

    let detail = [];
    if (status) detail.push(status);
    let latest = cleanText(doc.select("p.mt-2.mb-2").text());
    if (latest) detail.push(latest);
    // The publish date and view count sit in one `p` as two `span.pr-2` values.
    let stats = doc.select("span.pr-2");
    if (stats.size() >= 2) {
        detail.push("Đăng " + cleanText(stats.get(0).text()) + " · " + cleanText(stats.get(1).text()) + " lượt xem");
    }

    let genres = [];
    doc.select("h6.color-highlight a.badge").forEach(function (el) {
        let title = cleanText(el.text());
        if (title) genres.push({ title: title, input: absUrl(el.attr("href")), script: "list.js" });
    });

    return Response.success({
        name: name,
        author: author,
        cover: img === null ? "" : img.attr("src"),
        description: description,
        detail: detail.join("<br>"),
        url: url,
        type: "novel",
        format: "novel",
        ongoing: status.indexOf("Hoàn") === -1,
        nsfw: true,
        locale: "vi",
        genres: genres
    });
}
