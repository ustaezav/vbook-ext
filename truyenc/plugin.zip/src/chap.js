load('config.js');

// Chapter body. The content block also carries an ad slot (inline style, script and an
// injected div) and the page's trailing "Trang N" pager; strip them before returning the
// HTML. The chapter title is left to the table of contents, which already names it.
function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let node = doc.select("div.story-content").first();
    if (node === null) return Response.error("Không tìm thấy nội dung chương");

    node.select("script, style, iframe, div[id*=ScriptRoot]").remove();
    node.select("input, span.pages, span.current, span.extend").remove();

    let content = node.html();
    if (!cleanText(content)) return Response.error("Chương trống");

    return Response.success(content, "");
}
