load('config.js');

// The site has no keyword search, so the query is matched against the story slugs in its
// sitemap (see config.js). Each visible result is then read from its story page to show
// the real title and cover; those reads are cached per story.
let SEARCH_PAGE_SIZE = 12;

function resolveStory(slug) {
    let url = siteOrigin() + "/truyen/" + slug;
    let key = "truyenc-story-v1:" + slug;

    let cached = null;
    try {
        cached = cacheStorage.getItem(key);
    } catch (error) {
    }
    if (cached) {
        try {
            return JSON.parse(cached);
        } catch (error) {
        }
    }

    let item = null;
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        let name = cleanText(doc.select("div.page-title h1").text());
        if (name) {
            let img = doc.select("img.story-image").first();
            item = {
                name: name,
                link: url,
                cover: img === null ? "" : img.attr("src"),
                host: siteOrigin()
            };
        }
    }

    if (item === null) {
        // The story page could not be read: fall back to the slug from the sitemap.
        return { name: slug.replace(/-/g, " "), link: url, host: siteOrigin() };
    }

    try {
        cacheStorage.setItem(key, JSON.stringify(item));
    } catch (error) {
    }
    return item;
}

function execute(query, page) {
    query = cleanText(query);
    if (!query) return Response.success([], "");

    let tokens = queryTokens(query);
    if (tokens.length === 0) return Response.success([], "");

    let slugs = sitemapSlugs();
    if (slugs === null) return Response.error("Không tải được danh sách truyện");

    // Stories whose slug starts with the query rank first, then the rest by name.
    let prefix = tokens.join("-");
    let leading = [];
    let rest = [];
    for (let i = 0; i < slugs.length; i++) {
        if (!slugMatches(slugs[i], tokens)) continue;
        if (slugs[i].indexOf(prefix) === 0) leading.push(slugs[i]); else rest.push(slugs[i]);
    }
    leading.sort();
    rest.sort();
    let matches = leading.concat(rest);

    let current = parseInt(page, 10);
    if (isNaN(current) || current < 1) current = 1;
    let offset = (current - 1) * SEARCH_PAGE_SIZE;
    let end = Math.min(offset + SEARCH_PAGE_SIZE, matches.length);

    let items = [];
    for (let j = offset; j < end; j++) {
        items.push(resolveStory(matches[j]));
    }

    return Response.success(items, end < matches.length ? String(current + 1) : "");
}
