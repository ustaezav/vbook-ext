load('config.js');

// Paged story listing behind the explore sections and the genre chips. `query` is a
// category url ("/truyen-sex", "/tim-truyen-18"); the 18+ listing is the fallback.
function execute(query, page) {
    let url = cleanText(query) || "/tim-truyen-18";
    if (url.indexOf("/") === 0) url = siteOrigin() + url;

    let response = fetch(pagedUrl(absUrl(url), page));
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    return Response.success(storyItems(doc), nextPageToken(doc));
}
