load('config.js');

// One tab per category of the site's 18+ section; list.js pages each one.
function execute() {
    let categories = eighteenCategories();
    if (categories === null) return Response.error("Không tải được danh mục");

    let tabs = [];
    for (let i = 0; i < categories.length; i++) {
        tabs.push({ title: categories[i].title, input: categories[i].input, script: "list.js" });
    }
    return Response.success(tabs);
}
