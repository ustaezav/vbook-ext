// Shared code for the TruyenC extension. Every other script starts with
// load('config.js'); a loaded library must not load another file, so all helpers
// live here.

// Pages are served from truyenc.com; covers live on the i.truyenc.com image CDN.
// BASE_URL is only the page host — cover URLs come back absolute and are never
// rewritten.
let BASE_URL = "https://truyenc.com";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

let SITEMAP_CACHE_KEY = "truyenc-sitemap-v1";

function siteOrigin() {
    let match = BASE_URL.match(/^(https?:\/\/[^\/]+)/);
    return match ? match[1] : BASE_URL;
}

// Rewrite an incoming url's host (old/mirror/www-prefixed) to BASE_URL, keeping path
// and query. Call this first thing in every url-receiving execute(url).
function normalizeUrl(url) {
    let match = String(url).match(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?[^\/\n]+(\/.*)$/);
    return match ? siteOrigin() + match[1] : String(url);
}

// Resolve a link found on a page into an absolute site url.
function absUrl(href) {
    if (!href) return "";
    href = String(href);
    if (/^https?:\/\//i.test(href)) return normalizeUrl(href);
    if (href.charAt(0) === "/") return siteOrigin() + href;
    return BASE_URL + "/" + href;
}

function cleanText(text) {
    return String(text === undefined || text === null ? "" : text)
        .replace(/[\s\u3000]+/g, " ")
        .trim();
}

// One story row. Every listing (home page and category pages alike) renders the same
// `div.d-flex` block: cover in `img.story-image`, category badge, title in `h2`,
// excerpt in `p.mt-2` and the story link on both the cover and the button.
function storyItem(el) {
    let img = el.select("img.story-image").first();
    if (img === null) return null;

    let link = "";
    let anchors = el.select("a");
    for (let i = 0; i < anchors.size(); i++) {
        let href = anchors.get(i).attr("href");
        if (href && String(href).indexOf("/truyen/") !== -1) {
            link = absUrl(href);
            break;
        }
    }
    if (!link) return null;

    let name = cleanText(el.select("h2").text()) || cleanText(img.attr("alt"));
    if (!name) return null;

    let description = el.select("p.mt-2").first();
    let badge = el.select("a.badge").first();

    return {
        name: name,
        cover: img.attr("src"),
        link: link,
        description: description === null ? "" : cleanText(description.text()),
        tag: badge === null ? "" : cleanText(badge.text()),
        host: siteOrigin()
    };
}

function storyItems(node) {
    let items = [];
    node.select("div.d-flex").forEach(function (el) {
        let item = storyItem(el);
        if (item) items.push(item);
    });
    return items;
}

// Next page number from `ul.pagination`, or "" on the last page. The last page still
// renders a "Trang sau" link pointing at itself, so compare with the highest page
// number the pager links to instead of testing for that link.
function nextPageToken(doc) {
    let current = 1;
    let active = doc.select("ul.pagination li.active a.page-link").first();
    if (active !== null) {
        let match = String(active.attr("href")).match(/[?&]page=(\d+)/);
        if (match) current = parseInt(match[1], 10);
    }

    let last = current;
    doc.select("ul.pagination a.page-link").forEach(function (el) {
        let match = String(el.attr("href")).match(/[?&]page=(\d+)/);
        if (match) last = Math.max(last, parseInt(match[1], 10));
    });

    return last > current ? String(current + 1) : "";
}

function pagedUrl(url, page) {
    let number = parseInt(page, 10);
    if (isNaN(number) || number < 1) number = 1;
    if (number === 1) return url;
    return url + (url.indexOf("?") === -1 ? "?" : "&") + "page=" + number;
}

// Audio books are an embedded player with no chapter list, so the novel reader cannot
// show them; their categories are kept out of the browse shortcuts.
function isAudioCategory(url) {
    return String(url).toLowerCase().indexOf("audio") !== -1;
}

// The category list the 18+ section publishes on its own page. Returns
// [{ title, input }], or null when the page cannot be read.
function eighteenCategories() {
    let response = fetch(siteOrigin() + "/tim-truyen-18");
    if (!response.ok) return null;
    let doc = response.html();

    let categories = [];
    let seen = {};
    doc.select("div.content.mb-2 div.list-group a").forEach(function (el) {
        let href = el.attr("href");
        if (!href) return;
        let url = absUrl(href);
        if (seen[url] || isAudioCategory(url)) return;

        // The row holds the name in its first span and the story count in a badge span.
        let label = el.select("span").first();
        let title = cleanText(label === null ? "" : label.text());
        if (!title) return;

        seen[url] = true;
        categories.push({ title: title, input: url });
    });

    return categories.length > 0 ? categories : null;
}

// ---------------------------------------------------------------------------
// Search support.
//
// The site publishes no keyword search (its /tim-kiem route answers "not found" for
// every term), so search matches the query against the story slugs in the site's own
// sitemap.xml, then reads the matching story pages for their real titles and covers.
// ---------------------------------------------------------------------------

// Vietnamese diacritics are folded so "đế chế" matches the slug "de-che".
function foldVietnamese(text) {
    return String(text).toLowerCase()
        .replace(/[àáạảãâầấậẩẫăằắặẳẵ]/g, "a")
        .replace(/[èéẹẻẽêềếệểễ]/g, "e")
        .replace(/[ìíịỉĩ]/g, "i")
        .replace(/[òóọỏõôồốộổỗơờớợởỡ]/g, "o")
        .replace(/[ùúụủũưừứựửữ]/g, "u")
        .replace(/[ỳýỵỷỹ]/g, "y")
        .replace(/đ/g, "d");
}

function queryTokens(query) {
    let folded = foldVietnamese(query).replace(/[^a-z0-9]+/g, " ").trim();
    if (!folded) return [];
    return folded.split(" ");
}

// Every token must be a whole word of the slug, so "han" does not match "hanh-trinh".
function slugMatches(slug, tokens) {
    let padded = "-" + slug + "-";
    for (let i = 0; i < tokens.length; i++) {
        if (tokens[i] && padded.indexOf("-" + tokens[i] + "-") === -1) return false;
    }
    return true;
}

// Story slugs from the site's sitemap (~2000 entries), cached. Returns an array, or
// null when the sitemap cannot be read.
function sitemapSlugs() {
    let cached = null;
    try {
        cached = cacheStorage.getItem(SITEMAP_CACHE_KEY);
    } catch (error) {
    }
    if (cached) {
        try {
            return JSON.parse(cached);
        } catch (error) {
        }
    }

    let response = fetch(siteOrigin() + "/sitemap.xml");
    if (!response.ok) return null;

    // An XML sitemap is not queryable through the DOM parser, so read the raw text and
    // pull the story slugs out of the <loc> entries.
    let xml = response.text();
    let slugs = [];
    let pattern = /<loc>([^<]*\/truyen\/[^<]+)<\/loc>/g;
    let match;
    while ((match = pattern.exec(xml)) !== null) {
        let url = match[1].replace(/\s+$/, "");
        let slug = url.substring(url.indexOf("/truyen/") + 8);
        if (slug && slug.indexOf("/") === -1) slugs.push(slug);
    }
    if (slugs.length === 0) return null;

    try {
        cacheStorage.setItem(SITEMAP_CACHE_KEY, JSON.stringify(slugs));
    } catch (error) {
    }
    return slugs;
}
