load('config.js');

// The chapter list is rendered in full on the story page.
function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let chapters = [];
    doc.select("a.story-chap-item").forEach(function (el) {
        let href = el.attr("href");
        let name = cleanText(el.select("span.story-chap-name").text()) || cleanText(el.attr("title"));
        if (!href || !name) return;
        chapters.push({
            name: name,
            url: absUrl(href),
            description: "",
            lock: false,
            pay: false
        });
    });

    if (chapters.length === 0) {
        // One-page stories (the joke section) carry no chapter list: their text is on the
        // story page itself, which is what chap.js reads.
        if (doc.select("div.story-content").size() > 0) {
            chapters.push({ name: "Toàn văn", url: url, description: "", lock: false, pay: false });
        }
    }

    if (chapters.length === 0) return Response.error("Không tìm thấy chương");
    return Response.success(chapters);
}
