load('config.js');

// The 18+ section's categories, each paged by list.js.
function execute() {
    let categories = eighteenCategories();
    if (categories === null) return Response.error("Không tải được thể loại");

    let genres = [];
    for (let i = 0; i < categories.length; i++) {
        genres.push({ title: categories[i].title, input: categories[i].input, script: "list.js" });
    }
    return Response.success(genres);
}
