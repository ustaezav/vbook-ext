load('config.js');

// A handful of files on this host are behind a membership tier. AList answers
// those with code 403 rather than an HTTP error, and names the tier it wants, so
// the message is read from the body instead of being reported as a generic failure.
function lockMessage(response) {
    let data = response && response.data ? response.data : {};
    let reason = data.reason || "";
    let tier = Number(data.required_tier) || 0;

    if (reason === "tier" || String(response.message || "").indexOf("membership tier") !== -1) {
        if (tier > 0) return "File này cần membership tier " + tier + " mới phát được";
        return "File này cần membership mới phát được";
    }
    if (reason === "password") return "Thư mục này cần mật khẩu";
    return "Không lấy được link phát";
}

// track.js (step 2 of the chap -> track chain) — turns the AList path from
// chap.js into a playable stream.
//
// AList returns a signed CDN link (`mooncdn.asmrmoon.com/...?sign=...`) whose
// signature expires one hour after it is issued, so it is resolved here, at play
// time, and never cached in chap.js.
function execute(data) {
    let raw = String(data || "").trim();
    if (!raw) return Response.error("Thiếu dữ liệu track");

    let path = toPath(raw);
    if (!path || path === "/") return Response.error("Đường dẫn không hợp lệ");

    let info = apiPostRaw("/fs/get", { path: path });
    if (!info) return Response.error("Không lấy được link phát");
    if (info.code !== 200) return Response.error(lockMessage(info));

    let file = info.data || {};
    let link = file.raw_url || "";
    if (!link) return Response.error("File này không hỗ trợ phát trực tiếp");

    let name = file.name || baseName(path);
    return Response.success({
        type: "native",
        data: link,
        mimeType: mimeFor(name),
        headers: { "Referer": BASE_URL + "/" }
    });
}
