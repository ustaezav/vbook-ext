load('config.js');

// chap.js (step 1 of the chap -> track chain) — resolves one track URL to the
// source handles track.js will play.
//
// A track URL is one media file, so this returns a single handle and makes no
// network call at all: the signed direct link is fetched in track.js, at play
// time, because it expires one hour after it is issued.
function execute(url) {
    url = normalizeUrl(url);
    let path = toPath(url);
    if (!path || path === "/") return Response.error("Đường dẫn không hợp lệ");

    let name = baseName(path);

    if (isMedia(name)) {
        let ext = (name.match(/\.([A-Za-z0-9]+)$/) || ["", ""])[1];
        return Response.success([
            { title: ext ? ext.toUpperCase() : "Default", data: path }
        ]);
    }

    // A folder URL opened directly: offer every media file below it. Titles stay
    // unique so a picked source can be restored.
    let items = collectMedia(path, MAX_DIRS, MAX_FILES);
    if (items.length === 0) return Response.error("Thư mục này không có file audio/video");

    let tracks = [];
    for (let i = 0; i < items.length; i++) {
        tracks.push({ title: items[i].name, data: items[i].path });
    }
    return Response.success(tracks);
}
