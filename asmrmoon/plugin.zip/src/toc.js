load('config.js');

// toc.js — the track list. Each entry is one media file; a folder's subfolders
// are flattened into it (with the subfolder kept in the name) so nothing below
// the book's folder is unreachable.
function execute(url) {
    url = normalizeUrl(url);
    let path = toPath(url);
    if (!path || path === "/") return Response.error("Đường dẫn không hợp lệ");

    let name = baseName(path);

    if (isMedia(name)) {
        return Response.success([
            {
                name: stripExt(name),
                url: folderUrl(path),
                description: "",
                lock: false,
                pay: false
            }
        ]);
    }

    let items = collectMedia(path, MAX_DIRS, MAX_FILES);
    if (items.length === 0) return Response.error("Thư mục này không có file audio/video");

    let chapters = [];
    for (let i = 0; i < items.length; i++) {
        chapters.push({
            name: items[i].name,
            url: folderUrl(items[i].path),
            description: sizeText(items[i].size),
            lock: false,
            pay: false
        });
    }
    return Response.success(chapters);
}
