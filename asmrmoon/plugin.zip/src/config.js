// BASE_URL is the site base. Hardcode the current default here, then let the DOMAIN
// config key (injected as a const from plugin.json.config) override it when present.
let BASE_URL = "https://asmrmoon.com";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

// asmrmoon.com is an AList V3 file host. Everything is a same-origin JSON POST:
// /api/fs/list browses a folder, /api/fs/get returns a short-lived signed direct
// link for one file, /api/fs/search searches the Meilisearch index. There is no
// site HTML to scrape and no login — the anonymous "guest" role can read.
let API = BASE_URL + "/api";

// AList gives no per-album artwork, so the site's own default cover is used.
let COVER = BASE_URL + "/img/cover.jpeg";

// Browsing caps: one detail/toc tap must never fan out into thousands of requests.
let MAX_DIRS = 80;
let MAX_FILES = 1500;
let PAGE_SIZE = 40;
let SEARCH_PAGE_SIZE = 30;

// Rewrite an incoming url's host (mirror/www-prefixed) to BASE_URL, keeping path/query.
function normalizeUrl(url) {
    return String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

// The app passes URLs, but AList addresses objects by path. Both directions are
// encoded segment-by-segment so a name containing #, ?, % or a space survives.
function toPath(url) {
    let s = String(url || "").trim();
    s = s.replace(/^https?:\/\/[^\/]+/i, "");
    s = s.replace(/[?#].*$/, "");
    if (s.charAt(0) !== "/") s = "/" + s;
    if (s.length > 1 && s.charAt(s.length - 1) === "/") s = s.substring(0, s.length - 1);

    let parts = s.split("/");
    let out = [];
    for (let i = 0; i < parts.length; i++) {
        if (parts[i] === "") continue;
        try {
            out.push(decodeURIComponent(parts[i]));
        } catch (error) {
            out.push(parts[i]);
        }
    }
    return "/" + out.join("/");
}

function encodePath(path) {
    let parts = String(path).split("/");
    let out = [];
    for (let i = 0; i < parts.length; i++) {
        if (parts[i] === "") continue;
        out.push(encodeURIComponent(parts[i]));
    }
    return "/" + out.join("/");
}

function folderUrl(path) {
    return BASE_URL + encodePath(path);
}

function baseName(path) {
    let s = String(path || "");
    if (s.length > 1 && s.charAt(s.length - 1) === "/") s = s.substring(0, s.length - 1);
    let i = s.lastIndexOf("/");
    return i < 0 ? s : s.substring(i + 1);
}

function parentPath(path) {
    let s = String(path || "");
    if (s.length > 1 && s.charAt(s.length - 1) === "/") s = s.substring(0, s.length - 1);
    let i = s.lastIndexOf("/");
    return i <= 0 ? "/" : s.substring(0, i);
}

function joinPath(dir, name) {
    return dir === "/" ? "/" + name : dir + "/" + name;
}

function stripExt(name) {
    return String(name).replace(/\.[A-Za-z0-9]{1,6}$/, "");
}

// AList item.type: 1 = folder; any other value is a file.
function isDir(entry) {
    return !!entry && (entry.is_dir === true || entry.type === 1);
}

let VIDEO_EXT = /\.(?:m3u8|mp4|mkv|webm|mov|ts|m4v)$/i;
let AUDIO_EXT = /\.(?:mp3|m4a|wav|flac|opus|aac|ogg|m4b|ape)$/i;

function mediaKind(name) {
    let n = String(name || "").replace(/[?#].*$/, "");
    if (VIDEO_EXT.test(n)) return "video";
    if (AUDIO_EXT.test(n)) return "audio";
    return "";
}

function isMedia(name) {
    return mediaKind(name) !== "";
}

// POST a JSON body to the AList API and return the parsed envelope
// ({ code, message, data }), or null when nothing usable came back.
//
// The envelope is read whatever the HTTP status is, because AList reports its own
// errors (locked tier, wrong password) inside the JSON body. fetch() never throws
// on network errors, and json() throws on a non-JSON body, so the parse is guarded.
function apiPostRaw(endpoint, payload, timeout) {
    let body = Object.assign({}, payload || {});
    if (body.password === undefined) body.password = "";

    let text = "";
    try {
        let response = fetch(API + endpoint, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
            timeout: timeout || 30000
        });
        text = response.text();
    } catch (error) {
        return null;
    }
    if (!text) return null;

    try {
        return JSON.parse(text);
    } catch (error) {
        return null;
    }
}

// Same request, but only the successful payload: data.data, or null on any failure.
function apiPost(endpoint, payload, timeout) {
    let parsed = apiPostRaw(endpoint, payload, timeout);
    if (!parsed || parsed.code !== 200) return null;
    return parsed.data;
}

function listDir(path, timeout) {
    let data = apiPost("/fs/list", { path: path, page: 1, per_page: 0, refresh: false }, timeout);
    return data && data.content ? data.content : null;
}

// Every media file at or below `path`, breadth-first and capped. A folder that
// mixes loose files with subfolders keeps both reachable, and nested tracks keep
// their subfolder in the name so the playlist stays readable.
function collectMedia(root, maxDirs, maxFiles) {
    let dirBudget = maxDirs || MAX_DIRS;
    let fileBudget = maxFiles || MAX_FILES;
    let result = [];
    let queue = [{ path: root, prefix: "" }];
    let visited = 0;

    while (queue.length > 0 && visited < dirBudget && result.length < fileBudget) {
        let current = queue.shift();
        visited++;

        let entries = listDir(current.path);
        if (!entries) continue;

        // AList returns folders first, then files, each sorted by name.
        for (let i = 0; i < entries.length; i++) {
            let entry = entries[i];
            let name = entry.name || "";
            if (isDir(entry)) {
                queue.push({
                    path: joinPath(current.path, name),
                    prefix: current.prefix + name + " / "
                });
            } else if (isMedia(name)) {
                result.push({
                    name: current.prefix + name,
                    path: joinPath(current.path, name),
                    size: entry.size || 0,
                    kind: mediaKind(name)
                });
                if (result.length >= fileBudget) break;
            }
        }
    }
    return result;
}

// Majority media kind of a set. A tie goes to video, because the video player
// also plays audio-only streams while the audio player cannot show HLS video.
function dominantKind(items) {
    let audio = 0;
    let video = 0;
    for (let i = 0; i < items.length; i++) {
        if (items[i].kind === "video") video++;
        else audio++;
    }
    return (video > 0 && video >= audio) ? "video" : "audio";
}

function mimeFor(name) {
    let n = String(name || "").toLowerCase();
    if (n.indexOf(".m3u8") !== -1) return "application/x-mpegURL";
    if (n.indexOf(".mp4") !== -1) return "video/mp4";
    if (n.indexOf(".mkv") !== -1) return "video/x-matroska";
    if (n.indexOf(".webm") !== -1) return "video/webm";
    if (n.indexOf(".wav") !== -1) return "audio/wav";
    if (n.indexOf(".flac") !== -1) return "audio/flac";
    if (n.indexOf(".opus") !== -1) return "audio/opus";
    if (n.indexOf(".ogg") !== -1) return "audio/ogg";
    if (n.indexOf(".aac") !== -1) return "audio/aac";
    if (n.indexOf(".m4a") !== -1 || n.indexOf(".m4b") !== -1) return "audio/mp4";
    if (n.indexOf(".mp3") !== -1) return "audio/mpeg";
    return "";
}

function sizeText(bytes) {
    let b = Number(bytes) || 0;
    if (b <= 0) return "";
    if (b >= 1073741824) return (Math.round(b / 10737418.24) / 100) + " GB";
    if (b >= 1048576) return (Math.round(b / 10485.76) / 100) + " MB";
    return Math.max(1, Math.round(b / 1024)) + " KB";
}

// "Same folder" tab: jumps back to the artist/album this item lives in.
function parentTags(path) {
    let parent = parentPath(path);
    if (!parent || parent === "/") return [];
    return [{ title: baseName(parent), input: parent, script: "list.js" }];
}

// --- Folder avatars ---------------------------------------------------------
// The host publishes one avatar per artist at /img/<artist>.webp, where <artist>
// is the first path segment after the section: /img/扶桑大红花.webp for
// /中文音声/扶桑大红花. Sections and anything below artist level have none (89
// nested folders checked), so every item under an artist shows that artist's
// avatar, and the app's fallback image covers artists that have no avatar.
let AVATAR_BASE = BASE_URL + "/img";
let AVATAR_EXT = "webp";

function folderCover(path) {
    let raw = toPath(path).split("/");
    let segments = [];
    for (let i = 0; i < raw.length; i++) {
        if (raw[i]) segments.push(raw[i]);
    }
    if (segments.length < 2) return "";
    return AVATAR_BASE + "/" + encodeURIComponent(segments[1]) + "." + AVATAR_EXT;
}


