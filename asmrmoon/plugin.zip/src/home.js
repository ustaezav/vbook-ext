// home.js — tabs shown on the home page. Each tab's `input` is passed as
// `query` to `script` (list.js), which treats it as an AList folder path.
function execute() {
    return Response.success([
        { title: "中文音声", input: "/中文音声", script: "list.js" },
        { title: "日韩音声", input: "/日韩音声", script: "list.js" },
        { title: "English", input: "/English", script: "list.js" },
        { title: "全部", input: "/", script: "list.js" }
    ]);
}
