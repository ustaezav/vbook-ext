load('config.js');

// search.js — keyword search over the whole AList tree (Meilisearch index).
// Search hits are files or folders; file hits are folded into the album folder
// that contains them, because a folder is the playable unit in vBook.
function execute(query, page) {
    query = String(query || "").trim();
    if (!query) return Response.success([], "");

    let current = parseInt(page, 10) || 1;
    if (current < 1) current = 1;

    let data = apiPost("/fs/search", {
        parent: "/",
        keywords: query,
        scope: 0,
        page: current,
        per_page: SEARCH_PAGE_SIZE
    }, 40000);
    if (!data) return Response.error("Không tìm được kết quả");

    let content = data.content || [];
    let items = [];
    let seen = {};

    for (let i = 0; i < content.length; i++) {
        let entry = content[i];
        let name = entry.name || "";
        if (!name) continue;
        let parent = toPath(entry.parent || "/");

        let key;
        let item;
        if (isDir(entry)) {
            key = joinPath(parent, name);
            item = {
                name: name,
                link: folderUrl(key),
                description: "Thư mục"
            };
        } else if (isMedia(name)) {
            key = parent;
            item = {
                name: baseName(parent),
                link: folderUrl(parent),
                description: stripExt(name)
            };
        } else {
            continue;
        }

        if (seen[key]) continue;
        seen[key] = true;

        let cover = folderCover(key);
        if (cover) item.cover = cover;
        items.push(item);
    }

    // AList's search total is unreliable between pages, so the returned count is
    // what decides whether another page may exist.
    let hasMore = content.length >= SEARCH_PAGE_SIZE;
    return Response.success(items, hasMore ? String(current + 1) : "");
}
