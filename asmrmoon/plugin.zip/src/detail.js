load('config.js');

// detail.js — the URL is either a folder (an artist/album book) or a single
// media file. `type` is decided per book, so one extension serves both the
// audio and the video content in the same tree:
//   audio album  -> type "audio", format "album"  (playlist)
//   single file  -> type "audio", format "audio"  (one track)
//   video album  -> type "video", format "series" (episodes)
function execute(url) {
    url = normalizeUrl(url);
    let path = toPath(url);
    if (!path || path === "/") return Response.error("Đường dẫn không hợp lệ");

    let name = baseName(path);

    if (isMedia(name)) {
        let kind = mediaKind(name);
        return Response.success({
            name: stripExt(name),
            cover: folderCover(path) || COVER,
            description: path,
            url: folderUrl(path),
            type: kind,
            format: kind === "video" ? "series" : "audio",
            ongoing: false,
            nsfw: true,
            tags: parentTags(path)
        });
    }

    let items = collectMedia(path, MAX_DIRS, MAX_FILES);
    if (items.length === 0) return Response.error("Thư mục này không có file audio/video");

    let kind = dominantKind(items);
    let info = [];
    info.push("Thư mục: " + path);
    info.push("Số file: " + items.length);
    if (items.length >= MAX_FILES) info.push("(chỉ hiển thị " + MAX_FILES + " file đầu)");

    return Response.success({
        name: name,
        cover: folderCover(path) || COVER,
        description: path,
        detail: info.join("\n"),
        url: folderUrl(path),
        type: kind,
        format: kind === "video" ? "series" : "album",
        ongoing: false,
        nsfw: true,
        tags: parentTags(path)
    });
}
