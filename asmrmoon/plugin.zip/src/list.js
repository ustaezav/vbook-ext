load('config.js');

// list.js — listing script for the home tabs and for "same folder" tags.
// `query` is a folder path (e.g. "/中文音声"), `page` is a page number.
//
// Every folder is openable as a book: detail/toc walk the folder and its
// subfolders, so a category, an artist and an album all reach their tracks
// without this screen having to guess which is which.
function execute(query, page) {
    let path = toPath(query || "/");
    if (!path) path = "/";

    let current = parseInt(page, 10) || 1;
    if (current < 1) current = 1;

    let data = apiPost("/fs/list", {
        path: path,
        page: current,
        per_page: PAGE_SIZE,
        refresh: false
    });
    if (!data) return Response.error("Không tải được danh sách thư mục");

    let content = data.content || [];
    let items = [];
    for (let i = 0; i < content.length; i++) {
        let entry = content[i];
        let name = entry.name || "";
        if (!name) continue;

        let child = joinPath(path, name);
        let directory = isDir(entry);
        if (!directory && !isMedia(name)) continue;

        let item = {
            name: directory ? name : stripExt(name),
            link: folderUrl(child),
            description: directory ? "" : sizeText(entry.size)
        };
        let cover = folderCover(child);
        if (cover) item.cover = cover;
        items.push(item);
    }

    return Response.success(items, data.has_more ? String(current + 1) : "");
}
