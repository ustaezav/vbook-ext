load('config.js');
load('thumb.js');

// Handles the home tabs, genre listings and keyword search:
//   "rank:<0-3>"          today / week / month / all-time ranking from the homepage
//   "home"                latest books from the homepage
//   "/wapsort/3_1.html"   genre listing (paged)
//   anything else         keyword search (POST /s.php)
function execute(query, page) {
    query = String(query === undefined || query === null ? "" : query);
    page = String(page === undefined || page === null || page === "" ? "1" : page);

    if (query.indexOf("rank:") === 0) {
        return Response.success(rankList(parseInt(query.substring(5), 10)), "");
    }
    if (query === "home") {
        return Response.success(latestList(), "");
    }
    if (query.indexOf("/") === 0 || query.indexOf("http") === 0) {
        return browse(query, page);
    }
    return keywordSearch(query);
}

function rankList(index) {
    if (isNaN(index) || index < 0) index = 0;

    let response = fetch(BASE_URL);
    if (!response.ok) return [];

    let tabs = response.html().select("#ct > div");
    if (tabs.size() === 0) return [];
    let tab = tabs.get(Math.min(index, tabs.size() - 1));

    let seen = {};
    let items = [];
    tab.select("li").forEach(function (el) {
        let linkEl = el.select("a[href]").first();
        if (linkEl === null) return;
        let name = cleanText(linkEl.text());
        let href = absUrl(linkEl.attr("href"));
        if (!name || !href || seen[href]) return;
        seen[href] = true;

        let genre = /【([^】]+)】/.exec(el.text());
        items.push({
            name: name,
            cover: "",
            link: href,
            description: genre ? genre[1] : "",
            tag: genre ? genre[1] : ""
        });
    });

    return thumbAll(items);
}

function latestList() {
    let response = fetch(BASE_URL);
    if (!response.ok) return [];
    let doc = response.html();

    let items = [];
    doc.select(".last_li").forEach(function (el) {
        let linkEl = el.select("a.name").first();
        if (linkEl === null) return;

        let name = cleanText(linkEl.text());
        let href = absUrl(linkEl.attr("href"));
        if (!name || !href) return;

        let author = cleanText(el.select(".author").text());
        let words = el.select(".words");
        let genre = words.size() > 0 ? cleanText(words.get(0).text()).replace(/^类型[：:]\s*/, "") : "";
        let time = cleanText(el.select(".words time").text());

        let info = [];
        if (author) info.push("作者：" + author);
        if (genre) info.push("类型：" + genre);
        if (time) info.push("时间：" + time);

        items.push({
            name: name,
            cover: "",
            link: href,
            description: info.join(" · "),
            tag: genre
        });
    });

    return thumbAll(items);
}

function browse(query, page) {
    let url = query.indexOf("http") === 0 ? normalizeUrl(query) : BASE_URL + query;
    if (page !== "1") {
        url = url.replace(/_([0-9]+)\.html/, "_" + page + ".html");
    }

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = [];
    doc.select(".common-bookele").forEach(function (el) {
        let linkEl = el.select("h3 a[href]").first();
        if (linkEl === null) return;

        let name = cleanText(linkEl.text());
        let href = absUrl(linkEl.attr("href"));
        if (!name || !href) return;

        let author = cleanText(el.select("p strong").text());
        let time = cleanText(el.select(".lastupdate time").text());

        let info = [];
        if (author) info.push("作者：" + author);
        if (time) info.push("更新：" + time);

        items.push({
            name: name,
            cover: "",
            link: href,
            description: info.join(" · ")
        });
    });

    let current = parseInt(page, 10);
    if (isNaN(current)) current = 1;
    let nextUrl = doc.select("#page .next").attr("href");
    let nextMatch = /_([0-9]+)\.html/.exec(nextUrl);
    let nextPage = nextMatch && parseInt(nextMatch[1], 10) > current ? String(parseInt(nextMatch[1], 10)) : "";

    return Response.success(thumbAll(items), nextPage);
}

function keywordSearch(query) {
    query = cleanText(query);
    if (!query) return Response.success([], "");

    let response = fetch(BASE_URL + "/s.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "Referer": BASE_URL + "/"
        },
        body: { type: "articlename", s: query }
    });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = [];
    doc.select(".common-bookele").forEach(function (el) {
        let linkEl = el.select("a.articlename").first();
        if (linkEl === null) return;

        let name = cleanText(linkEl.text());
        let href = absUrl(linkEl.attr("href"));
        if (!name || !href) return;

        let author = cleanText(el.select("p strong").text());
        let genre = cleanText(el.select(".lastupdate").text()).replace(/^栏目[：:]\s*/, "");

        let info = [];
        if (author) info.push("作者：" + author);
        if (genre) info.push("栏目：" + genre);

        items.push({
            name: name,
            cover: "",
            link: href,
            description: info.join(" · "),
            tag: genre
        });
    });

    return Response.success(thumbAll(items), "");
}
