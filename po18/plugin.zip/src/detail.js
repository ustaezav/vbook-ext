load('config.js');
load('thumb.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let heading = doc.select("#novelMain h3").first();
    let name = heading === null ? "" : cleanText(heading.text());
    name = name.replace(/^《/, "").replace(/》简介$/, "");
    if (!name) {
        name = cleanText(doc.select("title").text()).replace(/_[^_]*_[^_]*$/, "");
    }
    if (!name) return Response.error("Không tìm thấy truyện");

    let author = cleanText(doc.select(".article_info_td h2").text());

    let intro = doc.select("#novelMain pre").first();
    let description = intro === null ? "" : stripPromo(intro.text());
    if (!description) {
        description = doc.select("meta[name=description]").attr("content");
    }

    let detail = cleanText(doc.select(".lb_fm").text());

    let genres = [];
    let category = doc.select(".article_info_td a[href*=wapsort]").first();
    if (category !== null) {
        let title = cleanText(category.text());
        let href = absUrl(category.attr("href"));
        if (title && href) genres.push({ title: title, input: href, script: "search.js" });
    }

    return Response.success({
        name: name,
        author: author,
        cover: thumb(name),
        description: description,
        detail: detail,
        url: url,
        type: "novel",
        format: "novel",
        ongoing: true,
        nsfw: true,
        locale: "zh_CN",
        genres: genres
    });
}

// Some descriptions carry a site-wide promo line for an unrelated video site.
function stripPromo(text) {
    let lines = String(text === undefined || text === null ? "" : text).split(/\n+/);
    let kept = [];
    for (let i = 0; i < lines.length; i++) {
        let line = lines[i].trim();
        if (!line || /po18hub|激情视频请收藏/i.test(line)) continue;
        kept.push(line);
    }
    return kept.join("\n");
}

