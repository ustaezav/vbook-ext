load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let contentEl = doc.select("#nr1").first();
    if (contentEl === null) return Response.error("Không tìm thấy nội dung chương");

    contentEl.select("script, style").forEach(function (el) { el.remove(); });
    let content = contentEl.html();
    if (!cleanText(content)) return Response.error("Chương trống");

    let title = cleanText(doc.select("h1#nr_title").text());
    let separator = title.indexOf(" - ");
    if (separator !== -1) title = title.substring(separator + 3);

    return Response.success(content, title);
}
