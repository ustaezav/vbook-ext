load('config.js');

// The detail page only renders the first and last ten chapters; the complete
// list lives on /novel/list/<id>/1.html (not paginated — it returns every entry).
function execute(url) {
    url = normalizeUrl(url);

    let idMatch = /\/novel\/([0-9]+)\.html/.exec(url);
    let listMatch = /\/novel\/list\/([0-9]+)\//.exec(url);
    let id = idMatch ? idMatch[1] : (listMatch ? listMatch[1] : "");
    if (!id) return Response.error("Không xác định được truyện");

    let response = fetch(BASE_URL + "/novel/list/" + id + "/1.html");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let chapterPattern = new RegExp("/novel/" + id + "/[0-9]+\\.html");
    let chapters = [];
    doc.select("ul li a[href]").forEach(function (el) {
        let href = el.attr("href");
        if (!chapterPattern.test(href)) return;

        let name = cleanText(el.text());
        if (!name) return;

        chapters.push({
            name: name,
            url: absUrl(href),
            description: "",
            lock: false,
            pay: false
        });
    });

    return Response.success(chapters);
}
