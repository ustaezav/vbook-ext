// Deterministic placeholder thumbnails for sources that have no cover (or a
// broken one). The Gallery Worker maps any string to a fixed image, so the same
// book always gets the same thumb — list, search and detail stay consistent.
//
// Copy this file verbatim into an extension's src/ and load it there:
//
//     load('thumb.js');
//     ...
//     cover: thumbCover(raw.cover, name)   // keep the site cover, else a thumb
//     items = thumbAll(items)              // fills every empty item.cover from item.name
//
// It needs its settings sibling: copy thumb_settings.js too and declare it as
// the extension's dynamic config script ("config": "thumb_settings.js").
// RANDOM_THUMB turns the feature off; THUMB_STYLE picks the image folder.
//
// Every resolved seed is cached in persistent storage, so each book costs at
// most one /pick call ever (within the TTL) — opening a detail page that was
// already listed on screen makes no request at all. /pick bills one request per
// call regardless of how many strings it carries, so batching + caching is what
// keeps the request count down. The cache is keyed per folder, so switching
// style never returns an image from the previous style.
//
// A loaded file must not load another file (runtime rule), so this is
// self-contained: it never references config.js and never declares `execute`.
var THUMB_ENDPOINT = "https://gallery-worker.knighjok1.workers.dev/pick";
var THUMB_KEY = "1417e2fe30968d284b1c5256e86053d71c95c0804a22df52d6da79d907264bc2";
var THUMB_LIMIT = 100;

// THUMB_STYLE label -> worker folder. Keep in step with thumb_settings.js.
var THUMB_DEFAULT_FOLDER = "images";
var THUMB_FOLDERS = {
    "NSFW": "images",
    "Gái xinh": "girls",
    "Hentai": "hentai",
    "Gái Anime": "anime"
};

// Resolved seeds live in localStorage (persistent, unlike cacheStorage which
// the system may clear). A seed is refreshed after THUMB_TTL_MS because the
// worker reassigns strings when a folder's image set changes; the store is
// capped and drops its oldest rows when it grows past THUMB_CACHE_MAX.
var THUMB_STORE_KEY = "thumb_map_v1";
var THUMB_TTL_MS = 7 * 24 * 60 * 60 * 1000;
var THUMB_CACHE_MAX = 2000;

// --- settings ---------------------------------------------------------------

// The settings are dynamic config items (see thumb_settings.js); unlike static
// settings they are not injected as constants. A missing table, an unset key or
// a failing native call all read as "" and fall back to the defaults below.
function thumbSetting(key) {
    try {
        let value = localConfig.getItem(key);
        return value === undefined || value === null ? "" : String(value);
    } catch (error) {
        return "";
    }
}

// Random thumbs are on unless the user turned them off.
function thumbEnabled() {
    return thumbSetting("RANDOM_THUMB") !== "false";
}

function thumbFolder() {
    let style = thumbSetting("THUMB_STYLE");
    return THUMB_FOLDERS[style] || THUMB_DEFAULT_FOLDER;
}

// --- request ----------------------------------------------------------------

// Seeds are normalised so incidental spacing never splits one book into two
// images; the worker itself trims and lowercases before hashing.
function thumbSeed(value) {
    return String(value === undefined || value === null ? "" : value).replace(/\s+/g, " ").trim();
}

// POST up to THUMB_LIMIT seeds to one folder, returning URLs aligned with the
// input, or null when the call fails. Never throws: a dead worker — or an
// unknown folder — must not break the caller.
function thumbFetch(seeds, folder) {
    if (!seeds || seeds.length === 0) return [];
    let response;
    try {
        response = fetch(THUMB_ENDPOINT, {
            method: "POST",
            headers: {
                "Authorization": "Bearer " + THUMB_KEY,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ strings: seeds, folder: folder }),
            timeout: 20000
        });
    } catch (error) {
        return null;
    }
    if (!response || !response.ok) return null;

    let data;
    try {
        data = response.json();
    } catch (error) {
        return null;
    }
    // An unknown folder answers { error: ... }, and a short array would misalign
    // covers; both read as a failed call so nothing wrong gets cached.
    if (!data || !data.length || data.length !== seeds.length) return null;

    let urls = [];
    for (let i = 0; i < data.length; i++) {
        urls.push(data[i] && data[i].u ? String(data[i].u) : "");
    }
    return urls;
}

// --- cache ------------------------------------------------------------------

function thumbCacheRead() {
    let map = {};
    try {
        let raw = localStorage.getItem(THUMB_STORE_KEY);
        if (!raw) return map;
        let data = JSON.parse(raw);
        for (let key in data) {
            if (data.hasOwnProperty(key)) map[key] = data[key];
        }
    } catch (error) {
        return {};
    }
    return map;
}

// Drop the oldest rows once the store outgrows THUMB_CACHE_MAX.
function thumbCacheTrim(map) {
    let keys = [];
    for (let key in map) {
        if (map.hasOwnProperty(key)) keys.push(key);
    }
    if (keys.length <= THUMB_CACHE_MAX) return map;

    keys.sort(function (a, b) {
        return (map[a][1] || 0) - (map[b][1] || 0);
    });
    let kept = {};
    for (let i = keys.length - THUMB_CACHE_MAX; i < keys.length; i++) {
        kept[keys[i]] = map[keys[i]];
    }
    return kept;
}

function thumbCacheWrite(map) {
    try {
        localStorage.setItem(THUMB_STORE_KEY, JSON.stringify(thumbCacheTrim(map)));
    } catch (error) {
    }
}

// Forget every cached thumb (debugging, or after a bucket reset).
function thumbClearCache() {
    try {
        localStorage.removeItem(THUMB_STORE_KEY);
    } catch (error) {
    }
}

// Resolve seeds to URLs: serve fresh cache hits, fetch only the misses, store
// what came back. Failed fetches stay uncached so the next call retries.
function thumbResolve(seeds) {
    let urls = [];
    if (!seeds || seeds.length === 0) return urls;

    let folder = thumbFolder();
    let cache = thumbCacheRead();
    let now = Date.now();
    let missing = [];
    let positions = [];

    for (let i = 0; i < seeds.length; i++) {
        let key = folder + "|" + seeds[i];
        let entry = cache[key];
        if (entry && entry[0] && entry[1] && (now - entry[1]) < THUMB_TTL_MS) {
            urls.push(entry[0]);
        } else {
            urls.push("");
            missing.push(seeds[i]);
            positions.push(i);
        }
    }

    for (let start = 0; start < missing.length; start += THUMB_LIMIT) {
        let batch = missing.slice(start, start + THUMB_LIMIT);
        let fetched = thumbFetch(batch, folder);
        if (!fetched) continue;
        for (let i = 0; i < fetched.length; i++) {
            if (!fetched[i]) continue;
            urls[positions[start + i]] = fetched[i];
            cache[folder + "|" + missing[start + i]] = [fetched[i], now];
        }
        thumbCacheWrite(cache);
    }
    return urls;
}

// --- public -----------------------------------------------------------------

// One thumb for a seed, or "" when seeding is off, the seed is blank or the
// worker is down.
function thumb(seed) {
    if (!thumbEnabled()) return "";
    let key = thumbSeed(seed);
    if (!key) return "";
    let urls = thumbResolve([key]);
    return urls.length && urls[0] ? urls[0] : "";
}

// Keep a real cover; fall back to a deterministic thumb only when it is empty.
function thumbCover(cover, seed) {
    let value = String(cover === undefined || cover === null ? "" : cover).trim();
    return value ? value : thumb(seed);
}

// Fill item.cover from the item's name for every item that has no cover yet.
// Only the uncached seeds are fetched, in batches of 100, so a full page costs
// one call the first time and none afterwards. Returns `items`.
function thumbAll(items, nameField, coverField) {
    if (!items || !items.length || !thumbEnabled()) return items;
    let nameKey = nameField || "name";
    let coverKey = coverField || "cover";

    let seeds = [];
    let targets = [];
    for (let i = 0; i < items.length; i++) {
        let item = items[i];
        if (!item || item[coverKey]) continue;
        let key = thumbSeed(item[nameKey]);
        if (!key) continue;
        seeds.push(key);
        targets.push(item);
    }
    if (seeds.length === 0) return items;

    let urls = thumbResolve(seeds);
    for (let i = 0; i < urls.length; i++) {
        if (urls[i]) targets[i][coverKey] = urls[i];
    }
    return items;
}
