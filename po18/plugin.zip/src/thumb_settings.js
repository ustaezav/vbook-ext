// Dynamic settings for the gallery thumbnails. Copy this file next to thumb.js
// and declare it as the extension's config script in plugin.json:
//
//     "script": { "config": "thumb_settings.js", ... }
//
// Both keys are dynamic so that turning RANDOM_THUMB off re-runs this script
// (the app re-runs a dynamic config script when a dynamic value changes) and
// THUMB_STYLE disappears with it. Values are read at run time with
// localConfig.getItem(key) — never as injected constants.
//
// A loaded library must not load another file, but this is a normal script, so
// it only exposes `execute`.
function execute() {
    let items = {
        RANDOM_THUMB: {
            title: "Thumb ngẫu nhiên",
            subtitle: "Gán ảnh đại diện cố định cho truyện không có cover",
            default: "true",
            mode: "toggle"
        }
    };

    if (thumbSetting("RANDOM_THUMB") !== "false") {
        items.THUMB_STYLE = {
            title: "Kiểu thumb",
            subtitle: "Bộ ảnh dùng để gán đại diện",
            default: thumbSetting("THUMB_STYLE") || "NSFW",
            values: ["NSFW", "Gái xinh", "Hentai", "Gái Anime"],
            mode: "select"
        };
    }

    return Response.success(items);
}

function thumbSetting(key) {
    try {
        let value = localConfig.getItem(key);
        return value === undefined || value === null ? "" : String(value);
    } catch (error) {
        return "";
    }
}
