let BASE_URL = "https://wap.po18me.com";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function absUrl(href) {
    let value = String(href === undefined || href === null ? "" : href);
    if (!value) return "";
    if (value.indexOf("//") === 0) return "https:" + value;
    if (value.indexOf("http") === 0) return value;
    if (value.charAt(0) === "/") return BASE_URL + value;
    return BASE_URL + "/" + value;
}

function cleanText(value) {
    return String(value === undefined || value === null ? "" : value).replace(/\s+/g, " ").trim();
}
