load('config.js');
function execute() {
    let response = fetch(BASE_URL);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let genres = [];
    doc.select(".sort ul li a[href]").forEach(function (el) {
        let title = cleanText(el.text());
        let href = absUrl(el.attr("href"));
        if (!title || !href) return;
        genres.push({ title: title, input: href, script: "search.js" });
    });

    return Response.success(genres);
}
