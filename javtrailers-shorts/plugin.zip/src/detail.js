load('config.js');

function esc(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function buildDetail(url, name, cover, v) {
    let title = v.title || v.jpTitle || name;
    let dvd = v.dvdId || v.contentId || "";
    let fullName = dvd ? (dvd + " " + title) : title;
    let image = v.image ? String(v.image) : cover;

    let text = [];
    if (v.description) text.push(String(v.description));
    if (v.jpTitle) text.push(String(v.jpTitle));
    if (v.zhTitle) text.push(String(v.zhTitle));

    let info = [];
    if (v.dvdId) info.push("<b>Mã DVD:</b> " + esc(v.dvdId));
    if (v.contentId) info.push("<b>Content ID:</b> " + esc(v.contentId));
    if (v.studio && v.studio.name) info.push("<b>Hãng:</b> " + esc(v.studio.name));
    if (v.releaseDate) info.push("<b>Phát hành:</b> " + esc(String(v.releaseDate).substring(0, 10)));
    if (v.duration) info.push("<b>Thời lượng:</b> " + esc(v.duration) + " phút");
    if (v.director || v.jpDirector) info.push("<b>Đạo diễn:</b> " + esc((v.director || "") + " " + (v.jpDirector || "")).trim());

    let casts = [];
    if (v.casts) {
        for (let i = 0; i < v.casts.length; i++) {
            let c = v.casts[i];
            if (c && c.name) casts.push(c.name + (c.jpName ? " (" + c.jpName + ")" : ""));
        }
    }
    if (casts.length) info.push("<b>Diễn viên:</b> " + esc(casts.join(", ")));

    let cats = [];
    if (v.categories) {
        for (let i = 0; i < v.categories.length; i++) {
            if (v.categories[i] && v.categories[i].name) cats.push(v.categories[i].name);
        }
    }
    if (cats.length) info.push("<b>Thể loại:</b> " + esc(cats.join(", ")));

    let detail = info.join("<br>");

    return {
        name: fullName,
        cover: image,
        description: text.join("<br>"),
        detail: detail,
        url: url,
        type: "video",
        format: "short",
        ongoing: true,
        nsfw: true
    };
}

function execute(url) {
    url = normalizeUrl(url);
    let stream = queryParam(url, "v");
    if (!stream) return Response.error("Thiếu nguồn phát");

    let contentId = queryParam(url, "c");
    let name = queryParam(url, "n") || "JavTrailers Short";
    let cover = queryParam(url, "i");

    if (contentId) {
        let response = apiCall("/api/video/" + encodeURIComponent(contentId));
        if (response.ok) {
            let json = null;
            try {
                json = JSON.parse(response.text);
            } catch (error) {
                json = null;
            }
            if (json && json.video) {
                return Response.success(buildDetail(url, name, cover, json.video));
            }
        }
    }

    return Response.success({
        name: name,
        cover: cover,
        description: "",
        detail: "",
        url: url,
        type: "video",
        format: "short",
        ongoing: true,
        nsfw: true
    });
}
