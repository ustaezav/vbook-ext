load('config.js');

function execute(query, page) {
    query = String(query || "");
    page = String(page || "0");

    let sort = "for-you";
    if (query === "for-you" || query === "new" || query === "trailer") {
        sort = query;
    }
    let p = parseInt(page, 10);
    if (isNaN(p) || p < 0) p = 0;

    let response = apiCall("/api/shorts?page=" + p + "&sort=" + sort + "&excludemodels=");
    if (!response.ok) return Response.error(response.status ? ("HTTP " + response.status) : "Không kết nối được máy chủ");

    let json;
    try {
        json = JSON.parse(response.text);
    } catch (error) {
        return Response.error("Phản hồi không hợp lệ");
    }

    let shorts = (json && json.shorts) ? json.shorts : [];
    let items = [];
    for (let i = 0; i < shorts.length; i++) {
        let it = shorts[i];
        if (!it || it.ad || it.live) continue;

        let cryptoId = (it.cryptoId === 0 || it.cryptoId) ? String(it.cryptoId) : "";
        if (!cryptoId) continue;

        let creator = (it.creator && it.creator.username) ? String(it.creator.username) : "";
        let bid = it.bid ? String(it.bid) : "";
        let stream = "";
        if (sort === "trailer" && it.csuid) {
            stream = String(it.csuid);
        } else if (bid) {
            stream = streamBase(it.thumbnail, bid) + "/" + bid + "/playlist.m3u8";
        }
        if (!stream) continue;

        let name = it.videoContentId ? String(it.videoContentId) : (creator || "JavTrailers");
        let cover = it.thumbnail ? String(it.thumbnail) : (it.avatar ? String(it.avatar) : "");
        let contentId = it.videoContentId ? String(it.videoContentId) : "";
        // The feed resolves items straight to toc/chap (skipping detail), and detail
        // re-opens the film page. Both need data that is not in the short's own URL,
        // so the resolved stream, cover, title and film id are carried as query params.
        let link = BASE_URL + "/shorts/" + cryptoId +
            "?v=" + encodeURIComponent(stream) +
            "&c=" + encodeURIComponent(contentId) +
            "&i=" + encodeURIComponent(cover) +
            "&n=" + encodeURIComponent(name);

        items.push({
            name: name,
            cover: cover,
            link: link,
            description: creator,
            tag: it.duration ? String(it.duration) : "",
            type: "short",
            host: BASE_URL
        });
    }

    let next = shorts.length > 0 ? String(p + 1) : "";
    return Response.success(items, next);
}
