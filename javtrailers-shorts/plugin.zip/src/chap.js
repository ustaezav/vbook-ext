load('config.js');

function filmTrailer(contentId) {
    if (!contentId) return "";
    let response = apiFetch("/api/video/" + encodeURIComponent(contentId), BASE_URL + "/video/" + contentId);
    if (!response.ok) return "";
    let json;
    try {
        json = response.json();
    } catch (error) {
        return "";
    }
    let v = json && json.video;
    if (!v) return "";
    return v.trailerG ? String(v.trailerG) : (v.trailer ? String(v.trailer) : "");
}

function execute(url) {
    url = normalizeUrl(url);

    if (queryParam(url, "t") === "1") {
        let trailer = filmTrailer(queryParam(url, "c"));
        if (!trailer) return Response.error("Không có trailer");
        return Response.success([{ title: "Trailer", data: trailer }]);
    }

    let stream = queryParam(url, "v");
    if (!stream) return Response.error("Thiếu nguồn phát");
    return Response.success([{ title: "Auto", data: stream }]);
}
