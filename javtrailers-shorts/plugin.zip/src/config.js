let BASE_URL = "https://javtrailers.com";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

// The API token is the site's public AUTH_TOKEN from its Nuxt runtime config
// (window.__NUXT__.config). It can rotate, so it is scraped from the page and cached
// in localStorage; these constants are only a bootstrap fallback when the page fails.
let FALLBACK_TOKEN = "AELAbPQCh_fifd93wMvf_kxMD_fqkUAVf@BVgb2!md@TNW8bUEopFExyGCoKRcZX";
let FALLBACK_STREAM = "https://vz-c20a9510-a5e.b-cdn.net";

let TOKEN_KEY = "jt_auth_token";
let STREAM_KEY = "jt_api_stream";

function readStore(key) {
    try {
        return localStorage.getItem(key) || "";
    } catch (error) {
        return "";
    }
}

function writeStore(key, value) {
    try {
        if (value) localStorage.setItem(key, value);
    } catch (error) {
    }
}

// The origin cold-starts behind a gateway, so the first request often returns a
// gateway/timeout error (502/503/504) before the upstream warms up. fetch also reports
// network errors and timeouts as a synthetic 504, so retrying 504 covers both. Retry
// those (and 429) a few times with a short pause; other statuses are returned as-is.
function retriable(status) {
    return status === 429 || status === 502 || status === 503 || status === 504;
}

function fetchRetry(url, options, attempts) {
    let tries = attempts || 5;
    let response = null;
    for (let i = 0; i < tries; i++) {
        response = fetch(url, options);
        if (response && response.ok) return response;
        if (!retriable(response ? response.status : 0)) return response;
        if (i < tries - 1) sleep(2000);
    }
    return response;
}

function fetchRuntimeConfig() {
    try {
        let response = fetchRetry(BASE_URL + "/", {
            headers: { "Accept": "text/html", "User-Agent": UserAgent.chrome() },
            timeout: 30000
        });
        if (!response.ok) return null;
        let html = String(response.text() || "");
        let token = html.match(/AUTH_TOKEN:\s*"([^"]+)"/);
        let stream = html.match(/apiStream:\s*"([^"]+)"/);
        if (!token && !stream) return null;
        return { token: token ? token[1] : "", stream: stream ? stream[1] : "" };
    } catch (error) {
        return null;
    }
}

function getToken(forceRefresh) {
    let override = "";
    try {
        if (TOKEN) override = String(TOKEN);
    } catch (error) {
    }
    if (override) return override;

    if (!forceRefresh) {
        let cached = readStore(TOKEN_KEY);
        if (cached) return cached;
    }

    let config = fetchRuntimeConfig();
    if (config && config.token) {
        writeStore(TOKEN_KEY, config.token);
        writeStore(STREAM_KEY, config.stream);
        return config.token;
    }

    let fallback = readStore(TOKEN_KEY) || FALLBACK_TOKEN;
    writeStore(TOKEN_KEY, fallback);
    return fallback;
}

function getStreamHost() {
    return readStore(STREAM_KEY) || FALLBACK_STREAM;
}

function apiHeaders(token, referer) {
    return {
        "Authorization": token,
        "userCountry": "none",
        "Accept": "application/json, text/plain, */*",
        "User-Agent": UserAgent.chrome(),
        "Referer": referer || (BASE_URL + "/")
    };
}

// Calls an API path with the resolved token; on an auth failure it refreshes the
// token once and retries (covers token rotation).
function apiFetch(path, referer) {
    let token = getToken(false);
    let response = fetchRetry(BASE_URL + path, { headers: apiHeaders(token, referer), timeout: 30000 });
    if (response && (response.status === 401 || response.status === 403)) {
        let fresh = getToken(true);
        if (fresh && fresh !== token) {
            response = fetchRetry(BASE_URL + path, { headers: apiHeaders(fresh, referer), timeout: 30000 });
        }
    }
    return response;
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function queryParam(url, key) {
    let q = url.indexOf("?");
    if (q === -1) return "";
    let parts = url.substring(q + 1).split("&");
    for (let i = 0; i < parts.length; i++) {
        let idx = parts[i].indexOf("=");
        if (idx === -1) continue;
        if (parts[i].substring(0, idx) === key) {
            let v = parts[i].substring(idx + 1);
            try {
                return decodeURIComponent(v);
            } catch (error) {
                return v;
            }
        }
    }
    return "";
}

function streamBase(thumbnail, bid) {
    let t = thumbnail ? String(thumbnail) : "";
    let marker = "/" + bid + "/";
    let idx = t.indexOf(marker);
    if (idx > 0) return t.substring(0, idx);
    return getStreamHost();
}
