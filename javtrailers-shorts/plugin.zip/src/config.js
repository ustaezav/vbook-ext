let BASE_URL = "https://javtrailers.com";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

// The API token is the site's public AUTH_TOKEN from its Nuxt runtime config. The
// extension reads the live value from the loaded page, so a rotated token heals by
// itself; these constants are only the seed for a page that has not finished loading.
let FALLBACK_TOKEN = "AELAbPQCh_fifd93wMvf_kxMD_fqkUAVf@BVgb2!md@TNW8bUEopFExyGCoKRcZX";
let FALLBACK_STREAM = "https://vz-c20a9510-a5e.b-cdn.net";

let TOKEN_KEY = "jt_auth_token";
let STREAM_KEY = "jt_api_stream";

function readStore(key) {
    try {
        return localStorage.getItem(key) || "";
    } catch (error) {
        return "";
    }
}

function writeStore(key, value) {
    try {
        if (value) localStorage.setItem(key, value);
    } catch (error) {
    }
}

function getToken() {
    let override = "";
    try {
        if (TOKEN) override = String(TOKEN);
    } catch (error) {
    }
    if (override) return override;

    let cached = readStore(TOKEN_KEY);
    if (cached) return cached;

    writeStore(TOKEN_KEY, FALLBACK_TOKEN);
    return FALLBACK_TOKEN;
}

function jsString(value) {
    return JSON.stringify(String(value));
}

function apiHeaders(token, referer) {
    return {
        "Authorization": token,
        "userCountry": "none",
        "Accept": "application/json, text/plain, */*",
        "User-Agent": UserAgent.chrome(),
        "Referer": referer || (BASE_URL + "/")
    };
}

// Cloudflare fronts the site and resets requests that do not come from a real browser
// session, so the app's native fetch fails for every call (reported as a synthetic
// 504). The API is therefore called as an XHR inside the app's WebView engine, which
// passes Cloudflare like a normal browser; the XHR also reads the live AUTH_TOKEN
// straight from the page.
function waitPage(browser) {
    for (let i = 0; i < 6; i++) {
        try {
            let el = browser.callJs(
                "String(!!(window.__NUXT__&&window.__NUXT__.config&&window.__NUXT__.config.public&&window.__NUXT__.config.public.AUTH_TOKEN))",
                3000
            );
            if (el && String(el.text()) === "true") return true;
        } catch (error) {
        }
        try {
            browser.html(1000);
        } catch (error) {
        }
    }
    return false;
}

// Runs one API request inside the WebView page. Returns {status, text}, or null when
// the browser engine itself is unavailable.
function browserCall(path) {
    let browser = null;
    try {
        browser = Engine.newBrowser();
    } catch (error) {
        return null;
    }
    if (!browser) return null; // iOS bridge failure returns undefined instead of throwing
    try {
        try {
            // The page only exists to give the request a browser session; its own
            // images and media are the bulk of the load and are not needed.
            browser.block([".*\\.(png|jpe?g|gif|webp|svg|mp4|m3u8|woff2?)(\\?.*)?$"]);
        } catch (error) {
        }
        try {
            browser.launch(BASE_URL + "/shorts", 30000);
        } catch (error) {
        }
        waitPage(browser);

        let js = "(function(){" +
            "try{" +
            "var c=(window.__NUXT__&&window.__NUXT__.config&&window.__NUXT__.config.public)||{};" +
            "var x=new XMLHttpRequest();" +
            "x.open('GET'," + jsString(BASE_URL + path) + ",false);" +
            "x.setRequestHeader('Authorization',c.AUTH_TOKEN||" + jsString(getToken()) + ");" +
            "x.setRequestHeader('userCountry','none');" +
            "x.setRequestHeader('Accept','application/json, text/plain, */*');" +
            "x.send();" +
            "_callNativeFunction(JSON.stringify(['putVariable','jt_status',String(x.status)]));" +
            "_callNativeFunction(JSON.stringify(['putVariable','jt_body',x.responseText]));" +
            "return 'ok';" +
            "}catch(e){" +
            "_callNativeFunction(JSON.stringify(['putVariable','jt_error',String(e)]));" +
            "return 'ok';" +
            "}})()";
        browser.callJs(js, 30000);

        let status = 0;
        let text = "";
        try {
            let raw = browser.getVariable("jt_status");
            if (raw !== undefined && raw !== null) status = parseInt(String(raw), 10) || 0;
        } catch (error) {
        }
        try {
            let body = browser.getVariable("jt_body");
            if (body !== undefined && body !== null) text = String(body);
        } catch (error) {
        }
        return { status: status, text: text };
    } catch (error) {
        return null;
    } finally {
        try {
            browser.close();
        } catch (error) {
        }
    }
}

function isChallenge(result) {
    return !!result && result.text.indexOf("Just a moment") !== -1;
}

// Calls an API path and returns { ok, status, text }. When the WebView engine is not
// available the app's native fetch is used as a last resort; that path cannot pass
// Cloudflare, but it still serves setups where the engine is missing.
function apiCall(path) {
    let result = browserCall(path);
    if (isChallenge(result)) {
        // The first page load was still serving the Cloudflare challenge when the
        // request went out; a second load usually carries the clearance cookie.
        result = browserCall(path);
    }

    if (result && result.status > 0) {
        return {
            ok: result.status >= 200 && result.status < 300,
            status: result.status,
            text: result.text
        };
    }

    let response = fetch(BASE_URL + path, { headers: apiHeaders(getToken(), BASE_URL + "/"), timeout: 15000 });
    if (!response) return { ok: false, status: 0, text: "" };
    let text = "";
    if (response.ok) {
        try {
            text = String(response.text() || "");
        } catch (error) {
            text = "";
        }
    }
    return { ok: !!response.ok, status: response.status, text: text };
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function queryParam(url, key) {
    let q = url.indexOf("?");
    if (q === -1) return "";
    let parts = url.substring(q + 1).split("&");
    for (let i = 0; i < parts.length; i++) {
        let idx = parts[i].indexOf("=");
        if (idx === -1) continue;
        if (parts[i].substring(0, idx) === key) {
            let v = parts[i].substring(idx + 1);
            try {
                return decodeURIComponent(v);
            } catch (error) {
                return v;
            }
        }
    }
    return "";
}

function streamBase(thumbnail, bid) {
    let t = thumbnail ? String(thumbnail) : "";
    let marker = "/" + bid + "/";
    let idx = t.indexOf(marker);
    if (idx > 0) return t.substring(0, idx);
    return getStreamHost();
}

function getStreamHost() {
    return readStore(STREAM_KEY) || FALLBACK_STREAM;
}
