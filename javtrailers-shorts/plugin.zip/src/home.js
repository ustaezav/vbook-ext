function execute() {
    return Response.success([
        { title: "For You", input: "for-you", script: "search.js" },
        { title: "New", input: "new", script: "search.js" },
        { title: "Trailer (cần VPN Nhật)", input: "trailer", script: "search.js" }
    ]);
}
