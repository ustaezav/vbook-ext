load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    return Response.success([
        { name: "Short", url: url, description: "", lock: false, pay: false },
        { name: "Trailer (cần VPN Nhật)", url: url + "&t=1", description: "", lock: false, pay: false }
    ]);
}
