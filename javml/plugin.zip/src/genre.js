load('config.js');

function execute() {
    let genres = [];

    // Curated categories from the category grid.
    let response = fetch(BASE_URL + "/categories.html", { timeout: 30000 });
    if (response.ok) {
        let doc = response.html();
        doc.select("#categories_list .video-img-box").forEach(function (el) {
            let linkEl = el.select(".img-box > a").first();
            let href = linkEl.attr("href");
            let name = el.select("h4").text().replace(/\s+/g, " ").trim();
            if (!href || !name) return;
            genres.push({ title: name, input: href, script: "list.js" });
        });
    }

    // The full tag list lives in the site's slide-out nav and footer.
    let home = fetch(BASE_URL + "/", { timeout: 30000 });
    if (home.ok) {
        let doc = home.html();
        let seen = {};
        doc.select("a[href*='/tags/'], a[href*='/categories/']").forEach(function (el) {
            let href = el.attr("href");
            let name = el.text().replace(/\s+/g, " ").trim();
            if (!href || !name || seen[href]) return;
            seen[href] = true;
            genres.push({ title: name, input: href, script: "list.js" });
        });
    }

    if (genres.length === 0) return Response.error("Không tải được thể loại");
    return Response.success(genres);
}
