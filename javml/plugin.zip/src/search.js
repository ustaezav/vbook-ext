load('config.js');

// javml.com has no keyword search box. Search therefore resolves, in order:
//   1. a pasted URL / path -> listed as-is;
//   2. a JAV code (e.g. "DVAJ-533", "dvaj 533") -> the direct video page;
//   3. a tag/category label or slug from the site nav -> that listing.

function listing(input, page) {
    let result = fetchListing(input, page);
    if (result.error) return Response.error(result.error);
    return Response.success(result.items, result.next);
}

function normalizeCode(query) {
    let m = String(query).match(/([A-Za-z]{2,10})[\s\-_]*(\d{2,6})/);
    if (!m) return "";
    return (m[1] + "-" + m[2]).toLowerCase();
}

function tagMatches(query) {
    let q = String(query).toLowerCase();
    let response = fetch(BASE_URL + "/", { timeout: 30000 });
    if (!response.ok) return [];
    let doc = response.html();
    let matches = [];
    doc.select("a[href*='/tags/'], a[href*='/categories/']").forEach(function (el) {
        let href = el.attr("href");
        let label = el.text().replace(/\s+/g, " ").trim();
        if (!href || !label) return;
        let slug = href.replace(BASE_URL, "").replace(/^\//, "").replace(/\.html$/, "").replace(/\/\d+$/, "");
        if ((label + " " + slug).toLowerCase().indexOf(q) !== -1) {
            matches.push({ title: label, input: href });
        }
    });
    return matches;
}

function execute(query, page) {
    query = String(query || "").trim();
    page = String(page || "1");
    if (!query) return Response.success([], "");

    if (query.indexOf("http") === 0 || query.charAt(0) === "/") {
        return listing(query, page);
    }

    let code = normalizeCode(query);
    if (code) {
        let url = BASE_URL + "/videos/" + code + ".html";
        let response = fetch(url, { timeout: 30000 });
        if (response.ok) {
            let doc = response.html();
            let name = videoName(doc);
            if (isVideoPage(doc) && name) {
                return Response.success([{
                    name: name,
                    cover: absolute(doc.select("meta[property=og:image]").attr("content")),
                    link: url,
                    host: BASE_URL
                }], "");
            }
        }
    }

    let matches = tagMatches(query);
    if (matches.length > 0) return listing(matches[0].input, page);

    return Response.success([], "");
}
