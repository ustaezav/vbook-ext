let BASE_URL = "https://javml.com";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

function normalizeUrl(url) {
    return String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function absolute(url) {
    url = String(url || "");
    if (!url) return "";
    if (url.indexOf("http") === 0) return url;
    if (url.indexOf("//") === 0) return "https:" + url;
    return BASE_URL + (url.charAt(0) === "/" ? "" : "/") + url;
}

// The site tracks its "free preview" quota with the javml_free_play_fp cookie. Once a
// fingerprint is used up the playback API answers ready:false, so every playback
// request rotates the fingerprint to keep a fresh quota.
function randomFingerprint() {
    let chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
    let value = "";
    for (let i = 0; i < 24; i++) {
        value += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return value;
}

function rotateFingerprint() {
    let value = randomFingerprint();
    try {
        localCookie.setCookie("javml_free_play_fp=" + value + "; path=/; Secure; SameSite=Lax");
    } catch (error) {
    }
    return value;
}

// Listing pages use both "/tags/x.html" (page 1) -> "/tags/x/2.html" and
// "/tags/中文/1.html" -> "/tags/中文/2.html" shapes; build the right one.
function listUrl(base, page) {
    let p = parseInt(page, 10);
    if (!p || p < 1) p = 1;
    base = String(base || "");
    if (!base) base = "/latest-updates";
    base = absolute(base).replace(/\/+$/, "");
    if (/\d+\.html$/.test(base)) return base.replace(/\d+\.html$/, p + ".html");
    if (/\.html$/.test(base)) {
        return p <= 1 ? base : base.replace(/\.html$/, "/" + p + ".html");
    }
    return p <= 1 ? base + ".html" : base + "/" + p + ".html";
}

function hasNextPage(doc, page) {
    let p = parseInt(page, 10) || 1;
    let last = 0;
    doc.select("ul.pagination a").forEach(function (a) {
        if (a.text().indexOf("最後") !== -1) {
            let m = a.attr("href").match(/(\d+)\.html/);
            if (m) last = parseInt(m[1], 10);
        }
    });
    if (last) return p < last;
    let found = false;
    doc.select("ul.pagination a").forEach(function (a) {
        if (a.attr("href").indexOf("/" + (p + 1) + ".html") !== -1) found = true;
    });
    return found;
}

// The site answers unknown paths with the homepage. A detail-page genre link can point
// at such a dead tag; return no items instead of the homepage's unrelated videos.
function isHomeFallback(doc) {
    let canonical = doc.select("link[rel=canonical]").attr("href");
    return !!canonical && /^https?:\/\/[^\/]+\/?$/.test(canonical);
}

function fetchListing(query, page) {
    let response = fetch(listUrl(query, page), { timeout: 30000 });
    if (!response.ok) return { error: "HTTP " + response.status };
    let doc = response.html();
    if (isHomeFallback(doc)) return { items: [], next: "" };
    let items = parseItems(doc);

    // Some tag listings (the "瀑布流" ones) intermittently serve page 1 again for a later
    // page. Compare the first item with the one remembered for page 1 and stop instead of
    // appending the same videos again.
    let p = parseInt(page, 10) || 1;
    let key = "javml_first_" + String(query);
    let firstLink = items.length ? items[0].link : "";

    if (p > 1 && firstLink) {
        let prev = "";
        try {
            prev = localStorage.getItem(key) || "";
        } catch (error) {
            prev = "";
        }
        if (prev && prev === firstLink) return { items: [], next: "" };
    }
    if (p <= 1 && firstLink) {
        try {
            localStorage.setItem(key, firstLink);
        } catch (error) {
        }
    }

    return { items: items, next: hasNextPage(doc, page) ? String(p + 1) : "" };
}

function parseItems(doc) {
    let items = [];
    doc.select(".video-img-box").forEach(function (el) {
        let linkEl = el.select(".img-box > a").first();
        let link = linkEl ? linkEl.attr("href") : "";
        let name = el.select(".detail .title").text().replace(/\s+/g, " ").trim();
        if (!name && linkEl) name = String(linkEl.attr("title") || "").trim();
        if (!link || !name) return;
        let img = el.select(".img-box img").first();
        let cover = img ? (img.attr("data-src") || img.attr("src")) : "";
        items.push({
            name: name,
            cover: absolute(cover),
            link: absolute(link),
            description: el.select(".detail .sub-title").text().replace(/\s+/g, " ").trim(),
            tag: el.select(".img-box .label").text().trim(),
            host: BASE_URL
        });
    });
    return items;
}

function videoName(doc) {
    let name = doc.select(".video-info .info-header .header-left h4").text().trim();
    if (!name) name = doc.select("meta[property=og:title]").attr("content");
    return String(name || "").replace(/\s+/g, " ").trim();
}

function isVideoPage(doc) {
    return /\/videos\/[^\/]+\.html/.test(doc.select("link[rel=canonical]").attr("href"));
}

// __JAVML_TRIAL__ is an inline script object; regex is the only way to read it.
function extractTrial(text) {
    let m = String(text || "").match(/__JAVML_TRIAL__\s*=\s*(\{[\s\S]*?\})\s*;/);
    if (!m) return null;
    try {
        return JSON.parse(m[1]);
    } catch (error) {
        return null;
    }
}
