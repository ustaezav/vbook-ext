load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url, { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);

    let trial = extractTrial(response.text());
    if (!trial || !trial.videoId) return Response.error("Không tìm thấy mã phim");

    let videoId = trial.videoId;
    let source = trial.sourceKind || "jable";

    let tracks = [];
    let srcRes = fetch(BASE_URL + "/trial-api/sources/?video_id=" + videoId + "&source=" + encodeURIComponent(source), {
        headers: { "Referer": url },
        timeout: 30000
    });
    if (srcRes.ok) {
        try {
            let payload = srcRes.json();
            let sources = payload.sources || [];
            for (let i = 0; i < sources.length; i++) {
                tracks.push({
                    title: sources[i].label || ("Nguồn " + (i + 1)),
                    data: JSON.stringify({ v: videoId, f: sources[i].id || 0, s: source })
                });
            }
        } catch (error) {
        }
    }

    if (tracks.length === 0) {
        tracks.push({
            title: "Nguồn 1",
            data: JSON.stringify({ v: videoId, f: trial.videoFileId || 0, s: source })
        });
    }

    return Response.success(tracks);
}
