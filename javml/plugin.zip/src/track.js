load('config.js');

function playbackUrl(videoId, fileId, source) {
    return BASE_URL + "/trial-api/playback/?video_id=" + videoId +
        "&video_file_id=" + fileId + "&source=" + encodeURIComponent(source);
}

// Rotate the fingerprint and send it as a header: after the site's own free preview is
// used up a stale cookie would keep answering ready:false, so retry with a new one.
function resolvePlayback(videoId, fileId, source) {
    let url = playbackUrl(videoId, fileId, source);
    for (let attempt = 0; attempt < 3; attempt++) {
        let fingerprint = rotateFingerprint();
        let response = fetch(url, {
            headers: {
                "Referer": BASE_URL + "/",
                "Cookie": "javml_free_play_fp=" + fingerprint
            },
            timeout: 30000
        });
        if (!response.ok) continue;
        let payload = null;
        try {
            payload = response.json();
        } catch (error) {
            payload = null;
        }
        if (payload && payload.url) return payload;
    }
    return null;
}

function execute(data) {
    let payload;
    try {
        payload = JSON.parse(String(data || ""));
    } catch (error) {
        return Response.error("Nguồn phát không hợp lệ");
    }

    let videoId = payload.v;
    if (!videoId) return Response.error("Thiếu mã phim");

    let result = resolvePlayback(videoId, payload.f || 0, payload.s || "jable");
    if (!result || !result.url) return Response.error("Không lấy được nguồn phát");

    return Response.success({
        type: "native",
        data: result.url,
        mimeType: "application/x-mpegURL",
        headers: {
            "User-Agent": UserAgent.chrome(),
            "Referer": BASE_URL + "/"
        },
        timeSkip: []
    });
}
