load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url, { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let name = videoName(doc) || "Full";
    return Response.success([
        { name: name, url: url, description: "", lock: false, pay: false }
    ]);
}
