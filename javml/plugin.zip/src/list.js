load('config.js');

function execute(query, page) {
    query = String(query || "") || "/latest-updates";
    page = String(page || "1");

    let result = fetchListing(query, page);
    if (result.error) return Response.error(result.error);
    return Response.success(result.items, result.next);
}
