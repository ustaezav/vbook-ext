load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url, { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let title = videoName(doc);
    let code = (url.match(/\/videos\/([^\/]+)\.html/) || [])[1] || "";

    // <h5 class="tags h6-md"> holds both category links (a.cat, -> /categories/) and
    // plain tag links (-> /tags/); everything but the homepage "返回首页" link is a genre.
    let genres = [];
    doc.select("h5.tags a").forEach(function (el) {
        let name = el.text().replace(/\s+/g, " ").trim();
        let href = el.attr("href");
        if (!name || !href) return;
        if (href.indexOf("/tags/") === -1 && href.indexOf("/categories/") === -1) return;
        genres.push({ title: name, input: href, script: "list.js" });
    });

    let views = doc.select(".video-info .info-header .header-left h6 span").get(1).text().trim();
    let released = doc.select(".video-info .info-header .header-right .inactive-color").text().trim();

    let info = [];
    if (code) info.push("Mã: " + code.toUpperCase());
    if (views) info.push("Lượt xem: " + views);
    if (released) info.push(released);

    return Response.success({
        name: title || code.toUpperCase(),
        cover: absolute(doc.select("meta[property=og:image]").attr("content")),
        description: genres.map(function (g) { return g.title; }).join(", "),
        detail: info.join("\n"),
        url: url,
        type: "video",
        format: "series",
        ongoing: true,
        genres: genres,
        suggests: [
            { title: "Có thể bạn thích", input: url, script: "similar.js" }
        ]
    });
}
