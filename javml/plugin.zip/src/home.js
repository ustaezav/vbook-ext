function execute() {
    return Response.success([
        { title: "Mới nhất", input: "/latest-updates", script: "list.js" },
        { title: "Hot nhất", input: "/hot", script: "list.js" },
        { title: "Mới phát hành", input: "/new-release", script: "list.js" },
        { title: "FC2PPV", input: "https://javml.com/tags/fc2ppv_falls/1.html", script: "list.js" },
        { title: "国产无码瀑布流 (Quốc sản vô mã)", input: "https://javml.com/tags/%E5%9B%BD%E4%BA%A7%E6%97%A0%E7%A0%81%E7%80%91%E5%B8%83%E6%B5%81/1.html", script: "list.js" },
        { title: "精选影片 (Tuyển chọn)", input: "https://javml.com/tags/%E7%B2%BE%E9%80%89%E5%BD%B1%E7%89%87/1.html", script: "list.js" },
        { title: "無碼 / Không che", input: "/categories/uncensored", script: "list.js" },
        { title: "中文字幕 / Phụ đề Trung", input: "/categories/chinese-subtitle", script: "list.js" },
        { title: "角色劇情", input: "/categories/roleplay", script: "list.js" },
        { title: "制服誘惑", input: "/categories/uniform", script: "list.js" },
        { title: "絲襪美腿", input: "/categories/pantyhose", script: "list.js" }
    ]);
}
