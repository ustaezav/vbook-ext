load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url, { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    return Response.success(parseItems(doc), "");
}
