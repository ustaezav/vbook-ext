// The site is served from a single host; BASE_URL stays usable even when the
// DOMAIN setting is not injected, and the setting only overrides it when present.
let BASE_URL = "https://www.novels.com.tw";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

// Every URL this source produces is rebuilt on BASE_URL: detail pages, chapter
// pages and listing pages all live under the same host, and incoming links may
// be relative ("/novels/...") or carry an old/mirror host.
function normalizeUrl(url) {
    let value = String(url || "");
    if (value.indexOf("//") === 0) return "https:" + value;
    if (/^https?:\/\//i.test(value)) {
        return value.replace(/^https?:\/\/[^\/]+/i, BASE_URL);
    }
    if (value.charAt(0) === "/") return BASE_URL + value;
    return value;
}

// Resolve a value that may be relative, protocol-relative or absolute.
function absolute(url) {
    let value = String(url || "").trim();
    if (!value) return "";
    if (value.indexOf("//") === 0) return "https:" + value;
    if (/^https?:\/\//i.test(value)) return value;
    return BASE_URL + (value.charAt(0) === "/" ? "" : "/") + value;
}

function text(el) {
    return el ? String(el.text() || "").trim() : "";
}

function attr(el, name) {
    return el ? String(el.attr(name) || "") : "";
}

// First element matching any selector in order, or null. An empty selection's
// first() is not reliably null in this runtime, so the size is checked first.
function firstEl(scope, selectors) {
    if (!scope) return null;
    for (let i = 0; i < selectors.length; i++) {
        let list = scope.select(selectors[i]);
        if (list.size() > 0) return list.first();
    }
    return null;
}

function excerpt(value, limit) {
    let out = String(value || "").replace(/\s+/g, " ").trim();
    let max = limit || 150;
    return out.length > max ? out.substring(0, max) + "…" : out;
}

// Cover images are lazily loaded: the real URL lives in data-original and the
// src attribute points at the shared "nocover" placeholder until the script runs.
function coverOf(img) {
    if (!img) return "";
    let original = attr(img, "data-original");
    if (original && original.indexOf("nocover") === -1) return absolute(original);

    let src = attr(img, "src");
    if (src && src.indexOf("nocover") === -1) return absolute(src);
    return "";
}

// Two different walls stand in front of the content:
// - Cloudflare's interactive check (403 / "Just a moment") needs a clearance
//   cookie, which the user obtains by opening the source in the app's browser.
// - The site's own anti-bot loader ("載入中…") is served to requests it does not
//   trust (rapid requests, or a protected book) and cannot be solved from a
//   plain HTTP request at all.
function verifyMessage() {
    return "Trang nguồn yêu cầu xác minh Cloudflare. Hãy mở " + BASE_URL +
        " trong trình duyệt của app, vượt qua xác minh rồi quay lại thử lại.";
}

function loaderMessage() {
    return "Trang đang tạm chặn truy cập tự động (anti-bot). Thử lại sau 1-2 phút hoặc mở truyện khác.";
}

function isLoader(body) {
    return body.indexOf("<title>載入中…</title>") !== -1;
}

// Both checks look at the page title: ordinary pages also reference Cloudflare's
// challenge-platform script (analytics beacon), so a plain substring match on it
// would turn every normal response into a false "verify" error.
function isCloudflare(response, body) {
    if (response.status === 403) return true;
    if (body.indexOf("<title>Just a moment") !== -1) return true;
    return false;
}

function readBody(response) {
    try {
        return String(response.text());
    } catch (error) {
        return "";
    }
}

function fetchDoc(url, timeout) {
    let ms = timeout || 45000;
    let response = fetch(url, { timeout: ms });
    let body = readBody(response);

    if (response.status === 429) {
        return { error: "Trang đang giới hạn truy cập (HTTP 429). Đợi vài phút rồi thử lại." };
    }
    if (isLoader(body)) return { error: loaderMessage() };
    if (isCloudflare(response, body)) return { error: verifyMessage() };
    if (!response.ok) return { error: "HTTP " + response.status };
    return { doc: Html.parse(body), url: response.url || url };
}

// A plain fetch always receives the chapter page with a
// "請前往www.novels.com.tw..." placeholder instead of the text: the site only
// renders chapters for real page navigations. The app's WebView does a real
// navigation (and runs the site's scripts), so chapters are loaded there.
function isGated(doc) {
    let articles = doc.select("#article");
    if (articles.size() === 0) return true;
    let content = articles.first().text();
    return content.indexOf("請前往") !== -1 && content.length < 200;
}

function chapterDoc(url) {
    let browser = null;
    let html = "";
    let blocked = false;
    let loader = false;
    try {
        browser = Engine.newBrowser();
        let doc = browser.launch(url, 30000);
        for (let i = 0; i < 5 && isGated(doc); i++) {
            sleep(2500);
            doc = browser.html(1500);
        }
        html = String(doc.html());
        let title = doc.select("title").text();
        blocked = title.indexOf("Just a moment") !== -1 || title.indexOf("Chờ một chút") !== -1;
        loader = isLoader(html);
    } catch (error) {
    }

    if (browser) {
        try {
            browser.close();
        } catch (error) {
        }
    }

    // Re-parse the serialized HTML so the result never depends on a closed browser,
    // and re-check: the page may still be showing a challenge screen.
    if (html) {
        let parsed = Html.parse(html);
        if (!isGated(parsed)) return { doc: parsed, url: url };
        let title = parsed.select("title").text();
        blocked = blocked || title.indexOf("Just a moment") !== -1 || title.indexOf("Chờ một chút") !== -1;
        loader = loader || isLoader(html);
    }

    if (loader) return { error: loaderMessage() };
    if (blocked) return { error: verifyMessage() };
    return { error: "Không tải được nội dung chương" };
}
