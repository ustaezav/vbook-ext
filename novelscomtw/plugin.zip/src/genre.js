load('config.js');
// Categories come from the library sidebar (/nosort/), which lists every genre
// with its first page attached; entries are normalised to a bare category path
// so the listing script only has to append the requested page number.
function execute() {
    let res = fetchDoc(BASE_URL + "/nosort/");
    if (res.error) return Response.error(res.error);
    let doc = res.doc;

    let genres = [];
    let seen = {};
    doc.select(".store_left a[href]").forEach(function (el) {
        let href = attr(el, "href");
        if (href.indexOf("/nosort/") !== 0) return;

        let title = text(el);
        if (!title) return;

        let input = href.replace(/[?#].*$/, "").replace(/\/\d+\/?$/, "/");
        if (seen[input]) return;
        seen[input] = true;

        genres.push({ title: title, input: input, script: "list.js" });
    });

    // "完本" is a separate listing tree rather than a category link in the sidebar.
    genres.push({ title: "全本", input: "/quanben/nosort/", script: "list.js" });

    return Response.success(genres, "");
}
