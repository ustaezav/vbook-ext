load('config.js');
// The search form posts to /search/, but the same endpoint answers a GET with
// the query string, which keeps the request simple. Results are capped at 100
// entries server-side and are not paginated.
function execute(query, page) {
    let keyword = String(query || "").trim();
    if (!keyword) {
        return Response.success([], "");
    }

    let url = BASE_URL + "/search/?searchkey=" + encodeURIComponent(keyword) + "&searchtype=all";
    let res = fetchDoc(url);
    if (res.error) return Response.error(res.error);
    let doc = res.doc;

    let items = [];
    let seen = {};
    doc.select("li.searchresult").forEach(function (el) {
        let nameEl = el.select("h3").first();
        let linkEl = firstEl(el, ["h3 a[href]", ".img_span a[href]", "a[href]"]);
        let link = absolute(attr(linkEl, "href"));
        let name = text(nameEl);
        if (!name || !link || seen[link]) return;
        seen[link] = true;

        items.push({
            name: name,
            cover: coverOf(el.select(".img_span img").first()),
            link: link,
            description: excerpt(text(el.select(".searchresult_p").first())),
            tag: text(el.select(".img_span span").first())
        });
    });

    if (items.length === 0) return Response.error("Không tìm thấy truyện");
    return Response.success(items, "");
}
