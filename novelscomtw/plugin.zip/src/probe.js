load('config.js');
function execute() {
    let out = [];
    let urls = [
        "https://www.novels.com.tw/static/shipsay/favicon.ico",
        "https://www.novels.com.tw/favicon.ico"
    ];
    for (let i = 0; i < urls.length; i++) {
        let r = fetch(urls[i], { timeout: 30000 });
        let b64 = "";
        try { b64 = String(r.base64()); } catch (e) {}
        out.push(urls[i] + " status=" + r.status + " type=" + r.header("content-type") + " size=" + b64.length);
        if (b64) out.push(b64);
    }
    return Response.success(out);
}
