load('config.js');
// Listing script for the browse tabs and the genre entries. `query` is a
// category path such as "/nosort/12/" or "/quanben/nosort/"; the page number is
// appended as a path segment.
function execute(query, page) {
    let base = String(query || "/nosort/");
    page = String(page || "1");

    base = base.replace(/[?#].*$/, "").replace(/\/+$/, "");

    // Tabs and genre entries pass a category path ("/nosort/12"), never a page.
    // A full URL copied from the site may carry both ("/nosort/12/2"); in that
    // case drop only the page segment, never the category number.
    let match = /^\/(quanben\/)?nosort\/(\d+)\/\d+$/.exec(base);
    if (match) base = "/" + (match[1] || "") + "nosort/" + match[2];

    let url = normalizeUrl(base + "/" + page + "/");

    let res = fetchDoc(url);
    if (res.error) return Response.error(res.error);
    let doc = res.doc;

    let items = [];
    let seen = {};
    doc.select(".store li").forEach(function (el) {
        let nameEl = el.select("h2").first();
        if (!nameEl) return;

        let linkEl = firstEl(el, [".img_span a[href]", "h2 a[href]", "a[href]"]);
        let link = absolute(attr(linkEl, "href"));
        let name = text(nameEl);
        if (!name || !link || seen[link]) return;
        seen[link] = true;

        items.push({
            name: name,
            cover: coverOf(el.select(".img_span img").first()),
            link: link,
            description: excerpt(text(el.select(".indent").first())),
            tag: text(el.select(".img_span span").first())
        });
    });

    if (items.length === 0) {
        if (page !== "1") return Response.success([], "");
        return Response.error("Không có dữ liệu");
    }

    return Response.success(items, nextPage(doc, parseInt(page, 10)));
}

// The pager always prints the last page as a trailing link, so the highest
// number in it is the end of the list.
function nextPage(doc, current) {
    let last = 1;
    doc.select(".pagelink a[href]").forEach(function (el) {
        let match = /\/(\d+)\/?$/.exec(attr(el, "href"));
        if (match) {
            let value = parseInt(match[1], 10);
            if (value > last) last = value;
        }
    });
    return current < last ? String(current + 1) : "";
}
