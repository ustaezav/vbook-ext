load('config.js');
// Chapters are split into sub-pages ("<id>_2.html", "<id>_3.html", …) and the
// page selector lists all of them, so a chapter is the concatenation of every
// page in that selector.
function execute(url) {
    url = normalizeUrl(url);

    let res = chapterDoc(url);
    if (res.error) return Response.error(res.error);
    let doc = res.doc;

    let article = firstEl(doc, ["#article", "article.content"]);
    if (!article) return Response.error("Không tìm thấy nội dung");

    let title = cleanTitle(text(doc.select(".text_title h1").first()));
    let parts = [cleanArticle(article)];

    let pageUrls = [];
    doc.select("#pageselect option").forEach(function (el) {
        let link = absolute(attr(el, "value"));
        if (link && pagePath(link) !== pagePath(url)) pageUrls.push(link);
    });

    for (let i = 0; i < pageUrls.length && i < 50; i++) {
        if (i > 0) sleep(700);
        let next = chapterDoc(pageUrls[i]);
        if (next.error) continue;

        let nextArticle = firstEl(next.doc, ["#article", "article.content"]);
        if (!nextArticle) continue;

        let html = cleanArticle(nextArticle);
        if (html) parts.push(html);
    }

    let content = parts.join("\n");
    if (!content.replace(/<[^>]*>/g, "").trim()) return Response.error("Chương trống");

    return Response.success(content, title);
}

// The page indicator ("（1 / 3）") is appended to the heading on multi-page
// chapters and is not part of the chapter name.
function cleanTitle(value) {
    return String(value || "").replace(/[（(]\s*\d+\s*\/\s*\d+\s*(?:頁|页)?\s*[）)]\s*$/, "").trim();
}

function pagePath(url) {
    return String(url || "").replace(/[?#].*$/, "");
}

// The reader injects ad blocks between paragraphs. Besides the server-side
// wrappers, the WebView lets ad scripts render rich blocks (e.g. "mys-wrapper")
// with their own text; any block that links away from the source is an ad.
function cleanArticle(article) {
    article.select("script, style, iframe, ins, noscript, form, button, video, audio").remove();
    article.select("[id^=div-tam-ad], [id^=div-gpt-ad], [id^=div-onead], [id^=div-], [id^=mys-], [id^=compass-fit], .compass-fit-widget, .kwinread, .adsbygoogle, .ad-container").remove();

    let divs = article.select("div");
    for (let i = divs.size() - 1; i >= 0; i--) {
        let el = divs.get(i);
        if (hasExternalLink(el)) {
            el.remove();
            continue;
        }
        if (el.select("img").size() > 0) continue;
        if (el.text().replace(/\s+/g, "") !== "") continue;
        el.remove();
    }

    return article.html();
}

function hasExternalLink(el) {
    let links = el.select("a[href]");
    for (let i = 0; i < links.size(); i++) {
        let href = attr(links.get(i), "href");
        if (/^https?:\/\//i.test(href) && href.indexOf("novels.com.tw") === -1) return true;
    }
    return false;
}
