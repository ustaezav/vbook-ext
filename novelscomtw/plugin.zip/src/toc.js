load('config.js');
// The whole catalogue is rendered inside the detail page (#catalog), hidden
// behind a tab, so one request yields every chapter — no TOC pagination.
function execute(url) {
    url = normalizeUrl(url);

    let res = fetchDoc(url);
    if (res.error) return Response.error(res.error);
    let doc = res.doc;

    let chapters = [];
    let seen = {};
    doc.select("#catalog a[href]").forEach(function (el) {
        let link = absolute(attr(el, "href"));
        let name = text(el);
        if (!name || !link || seen[link]) return;
        seen[link] = true;

        chapters.push({
            name: name,
            url: link,
            description: "",
            lock: false,
            pay: false
        });
    });

    if (chapters.length === 0) return Response.error("Không có chương");
    return Response.success(chapters);
}
