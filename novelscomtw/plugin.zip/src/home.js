// Home tabs. Each tab's `input` is a listing path passed to list.js as the
// query, and the page token is appended there.
function execute() {
    return Response.success([
        { title: "最新小說", input: "/nosort/", script: "list.js" },
        { title: "完本", input: "/quanben/nosort/", script: "list.js" },
        { title: "肉文", input: "/nosort/12/", script: "list.js" },
        { title: "成人", input: "/nosort/11/", script: "list.js" },
        { title: "玄幻", input: "/nosort/1/", script: "list.js" },
        { title: "都市", input: "/nosort/3/", script: "list.js" },
        { title: "女生", input: "/nosort/7/", script: "list.js" }
    ]);
}
