load('config.js');
function execute(url) {
    url = normalizeUrl(url);

    let res = fetchDoc(url);
    if (res.error) return Response.error(res.error);
    let doc = res.doc;

    let name = text(doc.select(".novel_info_title h1").first());
    if (!name) return Response.error("Không tìm thấy truyện");

    // The page repeats the catalogue data in og:novel meta tags, including the
    // category and status labels that are not linked anywhere in the body.
    let category = meta(doc, "og:novel:category");
    let status = meta(doc, "og:novel:status");
    let updated = meta(doc, "og:novel:update_time");
    let latest = meta(doc, "og:novel:lastest_chapter_name");
    let words = text(doc.select(".novel_info_title p span").get(1));

    let detail = [];
    if (category) detail.push("分類：" + category);
    if (status) detail.push("狀態：" + status);
    if (words) detail.push("字數：" + words);
    if (latest) detail.push("最新：" + latest + (updated ? "（" + updated + "）" : ""));

    let genres = [];
    let genre = genreEntry(doc, category);
    if (genre) genres.push(genre);

    let intro = doc.select("#info .intro").first();

    return Response.success({
        name: name,
        author: text(doc.select(".novel_info_title i a").first()),
        cover: coverOf(doc.select(".novel_info_main img").first()),
        description: intro ? intro.html() : "",
        detail: detail.join("\n"),
        url: url,
        type: "novel",
        format: "novel",
        ongoing: status.indexOf("全本") === -1 && status.indexOf("完結") === -1 && status.indexOf("完结") === -1,
        nsfw: true,
        locale: "zh_CN",
        genres: genres
    });
}

function meta(doc, property) {
    return attr(doc.select("meta[property=\"" + property + "\"]").first(), "content");
}

// The category label ("肉文小說") is longer than the nav label ("肉文"), so the
// matching nav link is found by prefix instead of by exact text.
function genreEntry(doc, category) {
    if (!category) return null;

    let links = doc.select(".navigation nav a[href]");
    for (let i = 0; i < links.size(); i++) {
        let el = links.get(i);
        let title = text(el);
        let href = attr(el, "href");
        if (!title || href.indexOf("/nosort/") !== 0) continue;
        if (category.indexOf(title) !== 0) continue;

        return {
            title: category,
            input: href.replace(/[?#].*$/, "").replace(/\/\d+\/?$/, "/"),
            script: "list.js"
        };
    }
    return null;
}
