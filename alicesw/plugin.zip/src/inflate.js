// Some chapters come back as base64(zlib(deflate(html))) after the site's
// migration (the web reader itself shows them as gibberish). Decode them here.
// Loaded by chap.js only.

var ALICE_B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

function aliceBase64Bytes(str) {
    let clean = String(str).replace(/[^A-Za-z0-9+\/=]/g, "");
    let out = [];
    for (let i = 0; i < clean.length; i += 4) {
        let c1 = ALICE_B64.indexOf(clean.charAt(i));
        let c2 = ALICE_B64.indexOf(clean.charAt(i + 1));
        let c3 = ALICE_B64.indexOf(clean.charAt(i + 2));
        let c4 = ALICE_B64.indexOf(clean.charAt(i + 3));
        if (c1 < 0 || c2 < 0) break;
        out.push(((c1 << 2) | (c2 >> 4)) & 255);
        if (c3 >= 0) out.push(((c2 << 4) | (c3 >> 2)) & 255);
        if (c4 >= 0) out.push(((c3 << 6) | c4) & 255);
    }
    return out;
}

// Inflate a stored/dynamic/fixed DEFLATE stream (puff-style canonical Huffman).
function aliceInflateRaw(data, start) {
    let out = [];
    let pos = start || 0;
    let bitbuf = 0;
    let bitcnt = 0;

    function bits(need) {
        let val = bitbuf;
        while (bitcnt < need) {
            if (pos >= data.length) throw new Error("unexpected end of deflate stream");
            val |= data[pos++] << bitcnt;
            bitcnt += 8;
        }
        bitbuf = val >>> need;
        bitcnt -= need;
        return val & ((1 << need) - 1);
    }

    function construct(lengths, n) {
        let count = [];
        let symbol = [];
        for (let i = 0; i < 16; i++) count.push(0);
        for (let i = 0; i < n; i++) count[lengths[i]]++;
        if (count[0] !== n) {
            let left = 1;
            for (let len = 1; len <= 15; len++) {
                left <<= 1;
                left -= count[len];
                if (left < 0) throw new Error("over-subscribed huffman table");
            }
        }
        let offs = [];
        offs.push(0);
        offs.push(0);
        for (let len = 1; len < 15; len++) offs.push(offs[len] + count[len]);
        for (let i = 0; i < n; i++) {
            if (lengths[i] !== 0) symbol[offs[lengths[i]]++] = i;
        }
        return { count: count, symbol: symbol };
    }

    function decode(h) {
        let code = 0;
        let first = 0;
        let index = 0;
        for (let len = 1; len <= 15; len++) {
            code |= bits(1);
            let count = h.count[len];
            if (code - count < first) return h.symbol[index + (code - first)];
            index += count;
            first += count;
            first <<= 1;
            code <<= 1;
        }
        throw new Error("invalid huffman code");
    }

    let lenBase = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31,
        35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
    let lenExtra = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2,
        3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
    let distBase = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193,
        257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
    let distExtra = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6,
        7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
    let clcOrder = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];

    let fixedLen = null;
    let fixedDist = null;

    let last = 0;
    while (last === 0) {
        last = bits(1);
        let type = bits(2);

        if (type === 0) {
            bitbuf = 0;
            bitcnt = 0;
            if (pos + 4 > data.length) throw new Error("truncated stored block");
            let len = data[pos] | (data[pos + 1] << 8);
            pos += 4;
            for (let i = 0; i < len; i++) {
                if (pos >= data.length) throw new Error("truncated stored block");
                out.push(data[pos++]);
            }
            continue;
        }

        let lit, dist;
        if (type === 1) {
            if (fixedLen == null) {
                let lengths = [];
                for (let i = 0; i < 288; i++) {
                    lengths.push(i < 144 ? 8 : (i < 256 ? 9 : (i < 280 ? 7 : 8)));
                }
                fixedLen = construct(lengths, 288);
                let dl = [];
                for (let i = 0; i < 30; i++) dl.push(5);
                fixedDist = construct(dl, 30);
            }
            lit = fixedLen;
            dist = fixedDist;
        } else if (type === 2) {
            let hlit = bits(5) + 257;
            let hdist = bits(5) + 1;
            let hclen = bits(4) + 4;
            let clc = [];
            for (let i = 0; i < 19; i++) clc.push(0);
            for (let i = 0; i < hclen; i++) clc[clcOrder[i]] = bits(3);
            let clTree = construct(clc, 19);

            let lengths = [];
            while (lengths.length < hlit + hdist) {
                let sym = decode(clTree);
                if (sym < 16) {
                    lengths.push(sym);
                } else if (sym === 16) {
                    if (lengths.length === 0) throw new Error("repeat with no previous length");
                    let prev = lengths[lengths.length - 1];
                    let rep = 3 + bits(2);
                    for (let i = 0; i < rep; i++) lengths.push(prev);
                } else if (sym === 17) {
                    let rep = 3 + bits(3);
                    for (let i = 0; i < rep; i++) lengths.push(0);
                } else {
                    let rep = 11 + bits(7);
                    for (let i = 0; i < rep; i++) lengths.push(0);
                }
            }
            lit = construct(lengths.slice(0, hlit), hlit);
            dist = construct(lengths.slice(hlit, hlit + hdist), hdist);
        } else {
            throw new Error("invalid deflate block type");
        }

        while (true) {
            let sym = decode(lit);
            if (sym < 256) {
                out.push(sym);
            } else if (sym === 256) {
                break;
            } else {
                let idx = sym - 257;
                if (idx >= lenBase.length) throw new Error("invalid length code");
                let length = lenBase[idx] + bits(lenExtra[idx]);
                let dsym = decode(dist);
                if (dsym >= distBase.length) throw new Error("invalid distance code");
                let distance = distBase[dsym] + bits(distExtra[dsym]);
                let from = out.length - distance;
                if (from < 0) throw new Error("distance too far back");
                for (let i = 0; i < length; i++) out.push(out[from + i]);
            }
        }
    }
    return out;
}

function aliceUtf8(bytes) {
    let out = "";
    let i = 0;
    while (i < bytes.length) {
        let b = bytes[i++];
        if (b < 0x80) {
            out += String.fromCharCode(b);
        } else if (b >= 0xC0 && b < 0xE0) {
            out += String.fromCharCode(((b & 0x1F) << 6) | (bytes[i++] & 0x3F));
        } else if (b >= 0xE0 && b < 0xF0) {
            let b2 = bytes[i++];
            let b3 = bytes[i++];
            out += String.fromCharCode(((b & 0x0F) << 12) | ((b2 & 0x3F) << 6) | (b3 & 0x3F));
        } else if (b >= 0xF0) {
            let b2 = bytes[i++];
            let b3 = bytes[i++];
            let b4 = bytes[i++];
            let cp = ((b & 0x07) << 18) | ((b2 & 0x3F) << 12) | ((b3 & 0x3F) << 6) | (b4 & 0x3F);
            cp -= 0x10000;
            out += String.fromCharCode(0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF));
        } else {
            out += "\uFFFD";
        }
    }
    return out;
}

// Returns the decoded text, or "" when the value is not a zlib/gzip payload.
function aliceDecodeCompressed(text) {
    let s = String(text || "");
    // Real chapters that are not compressed are HTML or plain prose; only try
    // inflating values that are pure base64 (the site salts it with zero-width
    // characters, so strip those before testing).
    if (!/^[A-Za-z0-9+\/=\u200B-\u200F\u2060-\u2064\uFEFF\s]+$/.test(s)) return "";
    let bytes = aliceBase64Bytes(s);
    if (bytes.length < 8) return "";
    let body = bytes;
    let start = 0;
    if (bytes[0] === 0x1F && bytes[1] === 0x8B) {
        // gzip: skip the 10-byte header, then walk optional extra fields
        let flags = bytes[3];
        start = 10;
        if (flags & 4) start += 2 + (bytes[start] | (bytes[start + 1] << 8));
        if (flags & 8) while (start < bytes.length && bytes[start++] !== 0) { }
        if (flags & 16) while (start < bytes.length && bytes[start++] !== 0) { }
        if (flags & 2) start += 2;
    } else if (bytes[0] === 0x78 && ((bytes[0] << 8) + bytes[1]) % 31 === 0) {
        // zlib header, deflate body
        start = 2;
    } else {
        return "";
    }
    try {
        let raw = aliceInflateRaw(body, start);
        return aliceUtf8(raw);
    } catch (error) {
        return "";
    }
}
