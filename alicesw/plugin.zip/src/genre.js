load('config.js');

function execute() {
    let response = fetch(BASE_URL + "/");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let genres = [];
    pickEls(doc, ["div.fenlei_ds ul li a", "ul.fenlei-item a"]).forEach(function (el) {
        genres.push({ title: el.text(), input: el.attr("href"), script: "search.js" });
    });

    return Response.success(genres);
}
