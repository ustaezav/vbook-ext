load('config.js');

function execute() {
    let genres = [];

    let cats = apiData("/api/v1/categories");
    if (cats.error == null) {
        let rows = cats.data;
        for (let i = 0; i < rows.length; i++) {
            let c = rows[i];
            if (c == null || !c.name || c.is_active === false) continue;
            genres.push({
                title: c.name,
                input: "filter:cat=" + c.id,
                script: "search.js"
            });
        }
    }

    let tags = apiData("/api/v1/tags?limit=60");
    if (tags.error == null) {
        let rows = tags.data;
        for (let i = 0; i < rows.length; i++) {
            let t = rows[i];
            if (t == null || !t.slug || !t.name) continue;
            genres.push({
                title: t.name,
                input: "filter:tag=" + encodeURIComponent(t.slug),
                script: "search.js"
            });
        }
    }

    return Response.success(genres);
}
