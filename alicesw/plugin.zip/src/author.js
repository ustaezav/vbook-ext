load('config.js');

// "Same author" list — referenced from detail.js "suggests". input = author user_no.
function execute(authorNo, page) {
    authorNo = String(authorNo || "").trim();
    if (authorNo === "") return Response.success([], "");
    let n = parseInt(page, 10) || 1;

    let res = apiData("/api/v1/books?page=" + n + "&page_size=30"
        + "&author_id=" + encodeURIComponent(authorNo)
        + "&sort_by=last_chapter_at&sort_order=desc");
    if (res.error) return Response.error(res.error);

    let data = res.data;
    let rows = data.books || [];
    return Response.success(bookItems(rows), nextPageToken(data, n, rows.length));
}
