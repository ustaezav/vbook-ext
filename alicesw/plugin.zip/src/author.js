load('config.js');

// "Same author" list — referenced from detail.js `suggests`. query = author name.
function execute(query, page) {
    query = query || "";
    page = page || "1";
    let n = parseInt(page, 10) || 1;
    if (query === "") return Response.success([], "");

    let url = BASE_URL + "/api/novel/lists?limit=30&page=" + n
        + "&author=" + encodeURIComponent(query)
        + "&order=" + encodeURIComponent(cfgApiOrder());

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let json = response.json();
    if (json == null || json.data == null) return Response.error("Bad API response");

    let out = apiListItems(json);
    return Response.success(out.items, out.next);
}
