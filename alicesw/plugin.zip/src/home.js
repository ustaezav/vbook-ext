function execute() {
    return Response.success([
        { title: "最新更新", input: "/all/order/update_time+desc.html", script: "search.js" },
        { title: "原创专区", input: "/original.html", script: "search.js" },
        { title: "本日排行", input: "/other/rank_hits/order/hits_day.html", script: "search.js" },
        { title: "本周排行", input: "/other/rank_hits/order/hits_week.html", script: "search.js" },
        { title: "本月排行", input: "/other/rank_hits/order/hits_month.html", script: "search.js" },
        { title: "总排行", input: "/other/rank_hits/order/hits.html", script: "search.js" }
    ]);
}
