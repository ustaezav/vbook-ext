load('config.js');

// Tabs follow the site's own sections. Each input pins its own sort/status so the
// user's filter settings don't silently rewrite a named tab; ranking tabs pass the
// block id and let search.js apply the RANK_PERIOD setting.
function execute() {
    let tabs = [
        { title: "最新更新", input: "filter:sort=last_chapter_at&order=desc", script: "search.js" },
        { title: "最新上架", input: "filter:sort=created_at&order=desc", script: "search.js" },
        { title: "最多阅读", input: "filter:sort=view_count&order=desc", script: "search.js" },
        { title: "最多收藏", input: "filter:sort=favorite_count&order=desc", script: "search.js" },
        { title: "已完结", input: "filter:status=completed", script: "search.js" },
        { title: "原创", input: "filter:original=1&sort=last_chapter_at&order=desc", script: "search.js" }
    ];

    let blocks = apiData("/api/v1/operations/blocks?placement=ranking");
    if (blocks.error == null) {
        let rows = blocks.data;
        for (let i = 0; i < rows.length; i++) {
            let b = rows[i];
            if (b == null || !b.title || b.id == null) continue;
            tabs.push({
                title: b.title,
                input: "filter:rank=" + b.id,
                script: "search.js"
            });
        }
    }

    return Response.success(tabs);
}
