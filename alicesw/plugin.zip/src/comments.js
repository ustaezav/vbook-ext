load('config.js');

// Comments of one book — referenced from detail.js "comments".
// input = the API's numeric book id (not the public book_no), page = page no.
function execute(input, page) {
    let id = numberFromUrl(input);
    if (id === "") return Response.error("Thiếu ID truyện");
    let n = parseInt(page, 10) || 1;

    let res = apiData("/api/v1/comments?target_type=book&target_id=" + encodeURIComponent(id)
        + "&page=" + n + "&page_size=20");
    if (res.error) return Response.error(res.error);

    let data = res.data;
    let rows = data.comments || [];
    return Response.success(commentItems(rows), nextPageToken(data, n, rows.length));
}
