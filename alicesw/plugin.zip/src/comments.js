load('config.js');

// Comments — referenced from detail.js `comments`. input = novel id, page = page no.
function execute(input, page) {
    page = page || "1";
    let n = parseInt(page, 10) || 1;
    let mid = String(input).match(/\d+/);
    if (mid == null) return Response.error("Missing novel id");

    let url = BASE_URL + "/api/comment/lists?id=" + mid[0] + "&type=novel&limit=20&page=" + n;
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let json = response.json();
    if (json == null || json.data == null) return Response.error("Bad API response");

    let meta = json.data;
    let rows = apiRows(meta);
    // Cap reply lookups so a busy comment page stays fast.
    let replyBudget = 8;
    let items = [];
    for (let i = 0; i < rows.length; i++) {
        let c = rows[i];
        if (c == null) continue;
        let replies = [];
        if (c.replyCount > 0 && replyBudget > 0) {
            replies = commentReplies(mid[0], c.id);
            replyBudget--;
        }
        items.push({
            name: c.user ? c.user.username : "",
            avatar: avatarUrl(c.user ? c.user.headimgurl : ""),
            content: c.content,
            description: formatTime(c.create_time),
            replies: replies
        });
    }

    let cur = parseInt(meta.current_page, 10) || 1;
    let last = parseInt(meta.last_page, 10) || 1;
    let next = cur < last ? String(cur + 1) : "";
    return Response.success(items, next);
}
