load('config.js');

function execute(url) {
    url = normalizeUrl(url);

    let m = url.match(/\/(?:books|novel|book)\/(\d+)/) || url.match(/\/(\d+)(?:\.html)?$/);
    if (m == null) return Response.error("Liên kết không hợp lệ: " + url);

    // The chapters endpoint takes the internal book id; the public book_no also
    // works (old /novel/{id}.html links may carry either one).
    let res = apiData("/api/v1/books/by-no/" + encodeURIComponent(m[1]) + "/chapters");
    if (res.error) res = apiData("/api/v1/books/" + encodeURIComponent(m[1]) + "/chapters");
    if (res.error) return Response.error(res.error);

    let rows = res.data;
    let chapters = [];
    for (let i = 0; i < rows.length; i++) {
        let c = rows[i];
        if (c == null || c.chapter_no == null) continue;
        if (c.status != null && c.status !== "published") continue;
        let name = c.display_title || c.title || "";
        if (name === "") name = "Chương " + (c.display_number || i + 1);
        let locked = c.is_free === false && c.is_unlocked !== true;
        chapters.push({
            name: name,
            url: BASE_URL + "/read/" + c.chapter_no,
            description: "",
            lock: locked,
            pay: locked && parseInt(c.unlock_price, 10) > 0
        });
    }

    if (chapters.length === 0) return Response.error("Không tìm thấy chương");
    return Response.success(chapters);
}
