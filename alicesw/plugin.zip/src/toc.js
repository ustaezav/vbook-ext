load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let m = url.match(/\/novel\/(\d+)\.html/) || url.match(/\/other\/chapters\/id\/(\d+)\.html/);
    if (m == null) return Response.error("Invalid book url: " + url);

    let response = fetch(BASE_URL + "/other/chapters/id/" + m[1] + ".html");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let chapters = [];
    pickEls(doc, ["ul.section-list li a", "ul.mulu_list li a"]).forEach(function (el) {
        chapters.push({
            name: el.text(),
            url: BASE_URL + el.attr("href"),
            description: "",
            lock: false,
            pay: false
        });
    });

    if (chapters.length === 0) return Response.error("No chapters found");
    return Response.success(chapters);
}
