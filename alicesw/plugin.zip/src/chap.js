load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let content = firstEl(doc, ["div.content_txt", "div.read-content.j_readContent"]);
    if (content == null) return Response.error("No content found");
    content.select("script").remove();
    content.select("#user_ad, .user_img_ad, .user_text_ad, .author-say-wrap").remove();

    let heading = firstEl(doc, ["article#chapterContent h3", "h3.j_chapterName"]);
    let title = heading == null ? "" : heading.text();

    return Response.success(content.html(), title);
}
