load('config.js');
load('inflate.js');

// The site mixes a long run of zero-width characters into each paragraph as an
// anti-scrape marker; drop them so the reader shows clean text.
function stripInvisible(html) {
    return String(html).replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u2064\uFEFF]+/g, "");
}

// Chapter images come back as site-relative /api/v1/media paths.
function absoluteImages(html) {
    return html.replace(/(<img\b[^>]*?\bsrc=["'])(\/[^"']*)/gi, function (all, head, src) {
        return head + BASE_URL + src;
    });
}

// Plain text (no markup) is shown one <p> per line, like the site's own reader.
function textToHtml(text) {
    let lines = stripInvisible(text).replace(/\r\n?/g, "\n").replace(/\n+$/, "").split("\n");
    let out = [];
    for (let i = 0; i < lines.length; i++) {
        let line = lines[i].replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").trim();
        if (line !== "") out.push("<p>" + line + "</p>");
    }
    return out.join("");
}

function execute(url) {
    url = normalizeUrl(url);

    // /read/{chapter_no}, or a legacy chapter URL whose last path number is the chapter.
    let m = url.match(/\/read\/(\d+)/) || url.match(/\/chapters?\/(\d+)/);
    if (m == null) {
        let path = url.split(/[?#]/)[0];
        let all = path.match(/\d+/g);
        if (all == null) return Response.error("Liên kết không hợp lệ: " + url);
        m = [all[all.length - 1], all[all.length - 1]];
    }

    let res = apiData("/api/v1/chapters/" + encodeURIComponent(m[1]));
    if (res.error) return Response.error(res.error);

    let d = res.data;
    if (d.can_read !== true) return Response.error("Chương này cần mua hoặc đăng nhập");

    // Some chapters are plain HTML, others a base64(zlib(html)) payload left over
    // from the old site's scheme (the web reader shows those as gibberish).
    let raw = String(d.content || "");
    let text = aliceDecodeCompressed(raw);
    let html = text !== "" ? text : raw;
    if (html.indexOf("<") === -1) html = textToHtml(html);

    let content = stripInvisible(absoluteImages(html));
    if (content.replace(/<[^>]*>/g, "").trim() === "") return Response.error("Chương trống");

    let chapter = d.chapter || {};
    let title = chapter.display_title || chapter.title || "";
    return Response.success(content, title);
}
