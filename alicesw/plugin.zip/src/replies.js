load('config.js');

// Replies of one comment — referenced from config.js "commentItems". input = comment_no.
function execute(input, next) {
    let no = numberFromUrl(input);
    if (no === "") return Response.error("Thiếu ID bình luận");
    let n = parseInt(next, 10) || 1;

    let res = apiData("/api/v1/comments/" + encodeURIComponent(no)
        + "/replies?page=" + n + "&page_size=20");
    if (res.error) return Response.error(res.error);

    let data = res.data;
    let rows = data.comments || [];
    return Response.success(commentItems(rows), nextPageToken(data, n, rows.length));
}
