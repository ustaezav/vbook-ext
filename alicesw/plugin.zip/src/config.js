let BASE_URL = "https://www.alicesw.com";
try {
    if (DOMAIN) BASE_URL = String(DOMAIN).replace(/\/+$/, "");
} catch (error) {
}

// The whole site moved to a JSON API; every script talks to /api/v1 and never
// touches the rendered HTML.
function apiGet(path) {
    let response = fetch(BASE_URL + path);
    let out = { ok: response.ok, status: response.status, json: null };
    if (!out.ok) return out;
    try {
        out.json = response.json();
    } catch (error) {
        out.json = null;
    }
    return out;
}

function apiData(path) {
    let res = apiGet(path);
    if (!res.ok) return { error: "HTTP " + res.status };
    if (res.json == null) return { error: "Bad API response" };
    if (res.json.data == null) return { error: res.json.message || "Bad API response" };
    return { data: res.json.data };
}

function normalizeUrl(url) {
    return String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

// First number in a URL: /books/109195, /read/77271295, or a legacy /novel/109195.html.
function numberFromUrl(url) {
    let m = String(url).match(/(\d+)/);
    return m == null ? "" : m[1];
}

function coverUrl(path) {
    if (!path) return "";
    let c = String(path);
    if (c.indexOf("//") === 0) return "https:" + c;
    if (c.indexOf("http") === 0) return c;
    return BASE_URL + (c.charAt(0) === "/" ? c : "/" + c);
}

function avatarUrl(path) {
    return coverUrl(path);
}

// 1294334 -> "129.43万", 842 -> "842"
function numberText(n) {
    let v = parseInt(n, 10);
    if (isNaN(v) || v <= 0) return "";
    if (v >= 100000000) return trimZero(v / 100000000) + "亿";
    if (v >= 10000) return trimZero(v / 10000) + "万";
    return String(v);
}

function trimZero(num) {
    let s = num.toFixed(2);
    if (s.indexOf(".") !== -1) s = s.replace(/0+$/, "").replace(/\.$/, "");
    return s;
}

// 19340 -> "1.93万字", 842 -> "842字"
function wordText(n) {
    let v = numberText(n);
    return v === "" ? "" : v + "字";
}

function statusText(b) {
    let done = b.status === "completed" || b.is_finished === true;
    return done ? "已完结" : "连载中";
}

function dateText(value) {
    let s = String(value || "");
    return s.length >= 10 ? s.substring(0, 10) : s;
}

function esc(value) {
    return String(value == null ? "" : value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

// One list item from a book payload (/books and /search/books share most fields).
function bookItem(b) {
    if (b == null || !b.title) return null;
    let cat = b.category && b.category.name ? b.category.name : "";
    let author = b.author && b.author.pen_name ? b.author.pen_name : (b.author_name || "");
    let parts = [];
    if (author) parts.push(author);
    if (cat) parts.push(cat);
    let words = wordText(b.word_count);
    if (words) parts.push(words);
    parts.push(statusText(b));
    let views = numberText(b.view_count);
    if (views) parts.push(views + "阅读");
    let tag = cat;
    if (tag === "" && b.content_rating === "r18") tag = "R18";
    return {
        name: b.title,
        cover: coverUrl(b.cover_url),
        link: BASE_URL + "/books/" + b.book_no,
        description: parts.join(" · "),
        tag: tag
    };
}

function bookItems(rows) {
    let items = [];
    if (rows == null) return items;
    for (let i = 0; i < rows.length; i++) {
        let item = bookItem(rows[i]);
        if (item != null) items.push(item);
    }
    return items;
}

// Next page token from a paged payload. Comments report has_more; listings only
// report page/total_pages. An empty page always ends paging — the comment API
// echoes the requested page back as total_pages once you pass the last one.
function nextPageToken(data, page, rowCount) {
    if (rowCount === 0) return "";
    if (data == null) return "";
    if (data.has_more === true) return String((parseInt(data.page, 10) || page) + 1);
    if (data.has_more === false) return "";
    let cur = parseInt(data.page, 10) || page;
    let last = parseInt(data.total_pages, 10) || 0;
    return last > cur ? String(cur + 1) : "";
}

// One comment row from /comments or /comments/{id}/replies.
function commentItems(rows) {
    let items = [];
    for (let i = 0; i < rows.length; i++) {
        let c = rows[i];
        if (c == null || !c.content) continue;
        let user = c.user || {};
        let item = {
            name: user.nickname || "",
            content: c.content,
            description: c.created_at || "",
            replies: []
        };
        let avatar = avatarUrl(user.avatar_url);
        if (avatar !== "") item.avatar = avatar;
        if (c.reply_count > 0 && c.parent_no == null && c.comment_no != null) {
            item.reply = { input: String(c.comment_no), script: "replies.js" };
            item.reply_count = c.reply_count;
        }
        items.push(item);
    }
    return items;
}

// ---- User filters -----------------------------------------------------------
// Mirrors the site's own filter rows: 状态 (status), 来源 (source), 排序 (sort).

function cfgOption(key) {
    try {
        if (key === "STATUS" && typeof STATUS !== "undefined") return String(STATUS);
        if (key === "SOURCE" && typeof SOURCE !== "undefined") return String(SOURCE);
        if (key === "SORT" && typeof SORT !== "undefined") return String(SORT);
        if (key === "RANK_PERIOD" && typeof RANK_PERIOD !== "undefined") return String(RANK_PERIOD);
    } catch (error) {
    }
    return "";
}

// Ranking blocks (运营配置) take day / week / month; 收藏榜 also has "total".
function cfgRankPeriod() {
    let v = cfgOption("RANK_PERIOD");
    if (v === "Ngày") return "day";
    if (v === "Tháng") return "month";
    return "week";
}

// A block only accepts the periods it declares, so keep its own default when the
// chosen one is not offered (e.g. a block limited to "total").
function blockPeriod(block) {
    let wanted = cfgRankPeriod();
    let periods = block.periods || [];
    for (let i = 0; i < periods.length; i++) {
        if (periods[i] === wanted) return wanted;
    }
    return block.period || wanted;
}

// /api/v1/books?status= takes the raw status; "Tất cả" means no parameter.
function cfgStatusList() {
    let v = cfgOption("STATUS");
    if (v === "Đang ra") return "published";
    if (v === "Hoàn thành") return "completed";
    return "";
}

// /api/v1/search/books only filters finished state.
function statusToFinished(status) {
    if (status === "completed") return "1";
    if (status === "published") return "0";
    return "";
}

// 来源: 原创 only, or everything.
function cfgOriginal() {
    return cfgOption("SOURCE") === "Sáng tác gốc" ? "1" : "";
}

// One canonical key for both list endpoints (综合排序 is the site's default);
// search.js maps it to the search endpoint's own names via searchSortName.
function cfgSortKey() {
    let v = cfgOption("SORT");
    if (v === "Đọc nhiều") return "view_count";
    if (v === "Yêu thích nhiều") return "favorite_count";
    if (v === "Cập nhật") return "last_chapter_at";
    if (v === "Mới đăng") return "created_at";
    return "hot";
}

function searchSortName(key) {
    if (key === "hot" || key === "relevance") return "relevance";
    if (key === "favorite_count" || key === "favorites") return "favorites";
    if (key === "last_chapter_at" || key === "latest") return "latest";
    if (key === "created_at" || key === "newest") return "newest";
    if (key === "view_count") return "view_count";
    return "";
}
