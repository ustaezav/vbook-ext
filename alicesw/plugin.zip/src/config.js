let BASE_URL = "https://www.alicesw.com";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

// First element matching any selector in order, or null. Checks the selection
// size because .first() on an empty selection is not reliably null here.
function firstEl(doc, selectors) {
    for (let i = 0; i < selectors.length; i++) {
        let list = doc.select(selectors[i]);
        if (list.size() > 0) return list.first();
    }
    return null;
}

// Elements from the first selector that matches anything, as a plain array.
function pickEls(doc, selectors) {
    let out = [];
    for (let i = 0; i < selectors.length; i++) {
        let list = doc.select(selectors[i]);
        if (list.size() > 0) {
            list.forEach(function (el) {
                out.push(el);
            });
            break;
        }
    }
    return out;
}

// First matching descendant of `el`, or null (see firstEl for the size check).
function child(el, selector) {
    let list = el.select(selector);
    return list.size() > 0 ? list.first() : null;
}

// The listing API returns cover paths on the site host, but /img/* only exist on
// the image CDN (img.321cdn.com), which also serves /uploads and /image/cover.
function coverUrl(pic) {
    if (!pic) return "";
    let c = String(pic);
    if (c.indexOf("img.321cdn.com") !== -1) return c;
    if (c.indexOf("//") === 0) c = "https:" + c;
    if (c.indexOf("http") === 0) {
        return c.replace(/^https?:\/\/(?:www\.)?alicesw\.(?:com|tw)\//i, "https://img.321cdn.com/");
    }
    return "https://img.321cdn.com" + (c.charAt(0) === "/" ? c : "/" + c);
}

// User's sort settings (injected config; default = newest first).
function cfgOrderField() {
    let v = "";
    try { v = String(ORDER); } catch (e) {}
    if (v === "Số chữ") return "word";
    if (v === "Lượt xem") return "hits";
    return "update_time";
}

function cfgOrderAsc() {
    let v = "";
    try { v = String(ORDER_DIR); } catch (e) {}
    return v === "Tăng dần";
}

// For /api/novel/lists?order=
function cfgApiOrder() {
    return cfgOrderField() + (cfgOrderAsc() ? "+asc" : "+desc");
}

// For /search.html?sort=
function cfgSearchSort() {
    return cfgOrderField() + (cfgOrderAsc() ? "_ASC" : "_DESC");
}

// Compact a large count: 1294334 -> "129.43万", 28703 -> "2.87万", 842 -> "842".
function shortNumber(n) {
    let v = parseInt(n, 10);
    if (isNaN(v)) return n == null ? "" : String(n);
    let num, unit;
    if (v >= 100000000) {
        num = v / 100000000;
        unit = "亿";
    } else if (v >= 10000) {
        num = v / 10000;
        unit = "万";
    } else {
        return String(v);
    }
    let s = num.toFixed(2);
    if (s.indexOf(".") !== -1) s = s.replace(/0+$/, "").replace(/\.$/, "");
    return s + unit;
}

// ---- JSON API helpers -------------------------------------------------------

// Rows of a paginated payload whose `data` is an array or a numeric-keyed object.
function apiRows(container) {
    if (container == null) return [];
    let raw = container.data;
    let rows = [];
    if (raw == null) return rows;
    if (raw.length != null && typeof raw.length === "number") {
        for (let i = 0; i < raw.length; i++) rows.push(raw[i]);
    } else {
        for (let k in raw) {
            if (/^\d+$/.test(k)) rows.push(raw[k]);
        }
    }
    return rows;
}

// Map one /api/novel/lists payload to list items (used by search.js, author.js).
function apiListItems(json) {
    let meta = json.data;
    let rows = apiRows(meta);
    let cur = parseInt(meta.current_page, 10) || 1;
    let last = parseInt(meta.last_page, 10) || 1;
    // The API returns one look-ahead row past the page; drop it so pages don't overlap.
    if (cur < last && rows.length > 0) rows = rows.slice(0, rows.length - 1);

    let items = [];
    for (let i = 0; i < rows.length; i++) {
        let it = rows[i];
        if (it == null || !it.title) continue;
        let parts = [];
        if (it.hits != null) parts.push(shortNumber(it.hits));
        let words = it.word_million ? it.word_million + "万字" : (it.word ? it.word + "字" : "");
        if (words) parts.push(words);
        if (it.serialize_text) parts.push(it.serialize_text);
        items.push({
            name: it.title,
            cover: coverUrl(it.pic),
            link: it.url,
            description: parts.join(" | "),
            tag: it.ctitle || ""
        });
    }
    let next = cur < last ? String(cur + 1) : "";
    return { items: items, next: next };
}

// ---- Comment helpers --------------------------------------------------------

function formatTime(ts) {
    let d = new Date(parseInt(ts, 10) * 1000);
    if (isNaN(d.getTime())) return "";
    function two(x) { return (x < 10 ? "0" : "") + x; }
    return d.getFullYear() + "-" + two(d.getMonth() + 1) + "-" + two(d.getDate())
        + " " + two(d.getHours()) + ":" + two(d.getMinutes());
}

function avatarUrl(u) {
    if (!u) return "";
    let c = String(u);
    if (c.indexOf("http") === 0 || c.indexOf("//") === 0) return c;
    return BASE_URL + (c.charAt(0) === "/" ? c : "/" + c);
}

function mapComment(mid, c) {
    return {
        name: c.user ? c.user.username : "",
        avatar: avatarUrl(c.user ? c.user.headimgurl : ""),
        content: c.content,
        description: formatTime(c.create_time),
        replies: c.replyCount > 0 ? commentReplies(mid, c.id) : []
    };
}

// Replies of one comment (/api/comment/lists?pid=). Flat, no deeper nesting.
function commentReplies(mid, pid) {
    let res = fetch(BASE_URL + "/api/comment/lists?limit=50&page=1&pid=" + pid
        + "&id=" + mid + "&type=novel");
    if (!res.ok) return [];
    let json = res.json();
    if (json == null || json.data == null) return [];
    let rows = apiRows(json.data);
    let out = [];
    for (let i = 0; i < rows.length; i++) {
        let c = rows[i];
        if (c == null) continue;
        out.push({
            name: c.user ? c.user.username : "",
            avatar: avatarUrl(c.user ? c.user.headimgurl : ""),
            content: c.content,
            description: formatTime(c.create_time),
            replies: []
        });
    }
    return out;
}
