load('config.js');

// This script serves both the search box and every list tab.
//   plain text          -> keyword search (/api/v1/search/books)
//   "filter:a=1&b=2"    -> browsing list (/api/v1/books)
// Recognised filters: rank (+period), cat, tag, status, original, keyword.
// The status / source / sort settings in plugin.json are applied on top, unless
// the input pins its own value (home tabs do that).
function execute(query, page) {
    query = String(query || "").trim();
    let n = parseInt(page, 10) || 1;

    if (query.indexOf("filter:") === 0) return browse(filters(query.substring(7)), n);
    if (query === "") return browse({}, n);
    return search(query, n);
}

function filters(text) {
    let out = {};
    let parts = String(text).split("&");
    for (let i = 0; i < parts.length; i++) {
        let part = parts[i];
        if (part === "") continue;
        let eq = part.indexOf("=");
        if (eq <= 0) continue;
        out[part.substring(0, eq)] = safeDecode(part.substring(eq + 1));
    }
    return out;
}

// Inputs are percent-encoded by genre.js/detail.js, but a plain value may already
// be decoded when it reaches us.
function safeDecode(value) {
    try {
        return decodeURIComponent(value);
    } catch (error) {
        return value;
    }
}

function browse(cfg, n) {
    if (cfg.rank) return ranking(cfg, n);

    let status = cfg.status || cfgStatusList();
    let original = cfg.original || cfgOriginal();
    let sortKey = cfg.sort || cfgSortKey();
    let keyword = cfg.keyword || "";

    // The list endpoint supports every facet; the search endpoint only knows how
    // to filter by finished state, so keyword queries go through it.
    if (keyword !== "") return keywordSearch(keyword, cfg.cat, status, original, sortKey, n);

    let path = "/api/v1/books?page=" + n + "&page_size=30"
        + "&sort_by=" + encodeURIComponent(sortKey)
        + "&sort_order=" + encodeURIComponent(cfg.order || "desc");
    if (cfg.cat) path += "&category_id=" + encodeURIComponent(cfg.cat);
    if (cfg.tag) path += "&tag=" + encodeURIComponent(cfg.tag);
    if (status) path += "&status=" + encodeURIComponent(status);
    if (original) path += "&original=1";
    if (cfg.author) path += "&author_id=" + encodeURIComponent(cfg.author);
    return respond(path, n, "books");
}

function ranking(cfg, n) {
    // The block's own period list decides what it accepts; RANK_PERIOD picks among
    // those, and an explicit input value wins.
    let period = cfg.period || "";
    if (period === "") {
        let block = apiData("/api/v1/operations/blocks?placement=ranking");
        let rows = block.error == null ? block.data : [];
        for (let i = 0; i < rows.length; i++) {
            if (rows[i] != null && String(rows[i].id) === String(cfg.rank)) {
                period = blockPeriod(rows[i]);
                break;
            }
        }
    }
    if (period === "") period = cfgRankPeriod();

    let path = "/api/v1/operations/blocks/" + encodeURIComponent(cfg.rank) + "/books"
        + "?page=" + n + "&page_size=30"
        + "&period=" + encodeURIComponent(period);
    if (cfg.cat) path += "&category_id=" + encodeURIComponent(cfg.cat);
    if (cfg.original) path += "&original=1";
    return respond(path, n, "books");
}

// Plain search box: keyword only, sorted by the SORT setting.
function search(keyword, n) {
    return keywordSearch(keyword, "", "", "", cfgSortKey(), n);
}

function keywordSearch(keyword, cat, status, original, sortKey, n) {
    let path = "/api/v1/search/books?q=" + encodeURIComponent(keyword)
        + "&page=" + n + "&page_size=30"
        + "&sort=" + encodeURIComponent(searchSortName(sortKey));
    if (cat) path += "&category_id=" + encodeURIComponent(cat);
    if (original) path += "&original=1";
    let finished = statusToFinished(status);
    if (finished) path += "&is_finished=" + finished;
    return respond(path, n, "items");
}

function respond(path, n, key) {
    let res = apiData(path);
    if (res.error) return Response.error(res.error);
    let data = res.data;
    let rows = data[key];
    if (rows == null) rows = [];
    return Response.success(bookItems(rows), nextPageToken(data, n, rows.length));
}
