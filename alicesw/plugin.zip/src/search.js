load('config.js');

// ---- JSON listing API (has covers) ------------------------------------------
// /api/novel/lists?limit=&page=&order=<field>+desc&id=<categoryId>

// The API sorts ascending; every listing tab here wants descending.
function apiOrder(query) {
    let m = query.match(/\/other\/rank_hits\/order\/([a-z_]+)\.html/);
    if (m != null) return m[1] + "+desc";
    m = query.match(/\/all\/order\/([a-z_]+)/);
    if (m != null) return m[1] + "+desc";
    return "";
}

function apiCategory(query) {
    let m = query.match(/\/lists\/(\d+)\.html/);
    return m != null ? m[1] : "";
}

// ---- HTML listing fallback (no covers) --------------------------------------

function parseSearchItems(doc) {
    let items = [];
    doc.select("div.list-group-item").forEach(function (el) {
        let a = child(el, "h5 a");
        if (a == null) return;
        items.push({
            name: a.text().replace(/^\s*\d+\.\s*/, ""),
            link: a.attr("href"),
            description: el.select("p.content-txt").text(),
            tag: el.select("h5 small").text().replace(/[\[\]]/g, "")
        });
    });
    return items;
}

function parseTxtItems(doc) {
    let items = [];
    doc.select("ul.txt-list > li").forEach(function (el) {
        let a = child(el, "span.s2 a");
        if (a == null) return;
        let cat = el.select("span.fenleibt").text().replace(/[\[\]\s]/g, "");
        items.push({
            name: a.text().replace(/^\s*\[[^\]]*\]\s*/, ""),
            link: a.attr("href"),
            description: el.select("span.s5").text(),
            tag: cat
        });
    });
    return items;
}

function parseTableItems(doc) {
    let items = [];
    doc.select("div.rec_rullist > ul").forEach(function (el) {
        let a = child(el, "li.two a");
        if (a == null) return;
        items.push({
            name: a.text(),
            link: a.attr("href"),
            description: el.select("li.three a").text(),
            tag: ""
        });
    });
    return items;
}

function maxNextPage(doc) {
    let max = 0;
    doc.select("a[data-page]").forEach(function (a) {
        let v = parseInt(a.attr("data-page"), 10);
        if (!isNaN(v) && v > max) max = v;
    });
    doc.select("ul.pager a, ul.pagination a").forEach(function (a) {
        let m = a.attr("href").match(/[?&]page=(\d+)/);
        if (m != null) {
            let v = parseInt(m[1], 10);
            if (v > max) max = v;
        }
    });
    return max;
}

function buildListUrl(query, page) {
    let base = query.indexOf("http") === 0 ? normalizeUrl(query) : BASE_URL + query;
    let sep = base.indexOf("?") === -1 ? "?" : "&";
    if (base.indexOf("/search") !== -1) {
        let sort = base.indexOf("sort=") === -1 ? "&sort=" + cfgSearchSort() : "";
        return base + sep + "p=" + page + sort;
    }
    return base + sep + "page=" + page;
}

function execute(query, page) {
    query = query || "";
    page = page || "1";
    let n = parseInt(page, 10) || 1;

    // Home tabs (latest/rankings) keep their own order; genre/tag/search lists
    // follow the ORDER / ORDER_DIR settings.
    let cid = apiCategory(query);
    let order;
    if (cid !== "") {
        order = cfgApiOrder();
    } else if (query === "") {
        order = "update_time+desc";
    } else {
        order = apiOrder(query);
    }
    if (order !== "" || cid !== "") {
        let apiUrl = BASE_URL + "/api/novel/lists?limit=30&page=" + n;
        if (order !== "") apiUrl += "&order=" + encodeURIComponent(order);
        if (cid !== "") apiUrl += "&id=" + cid;

        let apiRes = fetch(apiUrl);
        if (!apiRes.ok) return Response.error("HTTP " + apiRes.status);
        let json = apiRes.json();
        if (json == null || json.data == null) return Response.error("Bad API response");
        let out = apiListItems(json);
        if (out.items.length > 0) return Response.success(out.items, out.next);
    }

    // Keyword search and other HTML listings (no covers available).
    let url;
    if (query.indexOf("http") === 0 || query.indexOf("/") === 0) {
        url = buildListUrl(query, n);
    } else {
        url = BASE_URL + "/search.html?q=" + encodeURIComponent(query)
            + "&f=_all&sort=" + cfgSearchSort() + "&p=" + n + "&serialize=";
    }

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = parseSearchItems(doc);
    if (items.length === 0) items = parseTxtItems(doc);
    if (items.length === 0) items = parseTableItems(doc);

    let max = maxNextPage(doc);
    let next = max > n ? String(n + 1) : "";
    return Response.success(items, next);
}
