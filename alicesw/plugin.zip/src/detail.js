load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    // Site serves a mobile template to non-desktop user agents; try both.
    let name = firstEl(doc, ["div.detail-box h1", "div.novel_title"]);
    let author = firstEl(doc, ["div.detail-box div.info a[href*='f=author']", "div.novel_info a[href*='f=author']"]);
    let cover = firstEl(doc, ["div.detail-box div.imgbox img", "div.box_intro div.pic img"]);
    let description = firstEl(doc, ["div.jianjie p", "div.jianjie"]);
    // Info rows only: the mobile wrapper also holds the title (h1/.xs-title) and a
    // trailing .desc intro block, both duplicated elsewhere.
    let info = firstEl(doc, ["div.detail-box div.info div.fix", "div.novel_info"]);
    if (info != null) info.select(".xs-title").remove();

    let ongoing = true;
    pickEls(doc, ["div.detail-box div.info p", "div.novel_info p"]).forEach(function (el) {
        let t = el.text();
        if (t.indexOf("态") !== -1) ongoing = t.indexOf("完结") === -1;
    });

    let genres = [];
    pickEls(doc, ["div.detail-box div.info a[href*='/lists/']", "div.novel_info a[href*='/lists/']"]).forEach(function (el) {
        genres.push({ title: el.text(), input: el.attr("href"), script: "search.js" });
    });
    pickEls(doc, ["div.tags a", "div.tags_list a"]).forEach(function (el) {
        genres.push({ title: el.text().replace(/^#/, ""), input: el.attr("href"), script: "search.js" });
    });

    let authorName = author == null ? "" : author.text();
    let idMatch = url.match(/\/novel\/(\d+)\.html/);
    let novelId = idMatch == null ? "" : idMatch[1];

    return Response.success({
        name: name == null ? "" : name.text(),
        author: authorName,
        cover: cover == null ? "" : cover.attr("src"),
        description: description == null ? "" : description.html(),
        detail: info == null ? "" : info.html(),
        url: url,
        type: "novel",
        format: "novel",
        ongoing: ongoing,
        nsfw: true,
        locale: "zh-CN",
        genres: genres,
        suggests: authorName === ""
            ? []
            : [{ title: "Cùng tác giả", input: authorName, script: "author.js" }],
        comments: novelId === ""
            ? []
            : [{ title: "Bình luận", input: novelId, script: "comments.js" }]
    });
}
