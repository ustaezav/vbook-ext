load('config.js');

// Old library entries point at /novel/{id}.html with the previous site's id.
// /books/{x} is the public book_no, while /read/{chapter} needs the chapter's
// internal book_id; try the public lookup first and fall back to a raw id.
function findBook(no, isId) {
    if (isId) {
        let byId = apiData("/api/v1/books/" + encodeURIComponent(no));
        if (byId.error == null) return byId;
    }
    let map = apiData("/api/v1/books/by-no/" + encodeURIComponent(no));
    let id = map.error == null && map.data && map.data.id != null ? String(map.data.id) : String(no);
    let book = apiData("/api/v1/books/" + encodeURIComponent(id));
    if (book.error) return { error: book.error };
    return book;
}

function execute(url) {
    url = normalizeUrl(url);

    let m = url.match(/\/(?:books|novel|book)\/(\d+)/) || url.match(/\/(\d+)(?:\.html)?$/);
    if (m == null) return Response.error("Liên kết không hợp lệ: " + url);

    let no = m[1];
    let isId = false;
    // A shared chapter link (/read/...) resolves through the chapter's book_id.
    if (url.indexOf("/read/") !== -1) {
        let chapter = apiData("/api/v1/chapters/" + encodeURIComponent(no));
        if (chapter.error) return Response.error(chapter.error);
        no = String((chapter.data.chapter || {}).book_id || "");
        if (no === "") return Response.error("Không tìm thấy truyện");
        isId = true;
    }

    let found = findBook(no, isId);
    if (found.error) return Response.error(found.error);

    let d = found.data;
    let authorName = d.author && d.author.pen_name ? d.author.pen_name : "";
    let authorNo = d.author_no != null ? String(d.author_no) : (d.author && d.author.user_no != null ? String(d.author.user_no) : "");
    let categoryName = d.category && d.category.name ? d.category.name : "";
    let categoryId = d.category_id != null ? d.category_id : (d.category ? d.category.id : null);
    let ongoing = d.status !== "completed";

    let rows = [];
    if (categoryName) rows.push("<p>Thể loại: " + esc(categoryName) + "</p>");
    rows.push("<p>Trạng thái: " + (ongoing ? "Đang ra" : "Hoàn thành") + "</p>");
    if (d.chapter_count != null) rows.push("<p>Số chương: " + d.chapter_count + "</p>");
    if (d.word_count != null) rows.push("<p>Số chữ: " + wordText(d.word_count) + "</p>");
    if (d.view_count != null) rows.push("<p>Lượt đọc: " + numberText(d.view_count) + "</p>");
    if (d.favorite_count != null) rows.push("<p>Lượt thích: " + numberText(d.favorite_count) + "</p>");
    if (d.comment_count != null) rows.push("<p>Bình luận: " + d.comment_count + "</p>");
    if (d.last_chapter_at) rows.push("<p>Cập nhật: " + dateText(d.last_chapter_at) + "</p>");

    let genres = [];
    if (categoryName && categoryId != null) {
        genres.push({ title: categoryName, input: "filter:cat=" + categoryId, script: "search.js" });
    }
    let tags = d.tags || [];
    for (let i = 0; i < tags.length; i++) {
        let t = tags[i];
        if (t == null || !t.name) continue;
        genres.push({
            title: t.name,
            input: "filter:tag=" + encodeURIComponent(t.slug || t.name),
            script: "search.js"
        });
    }

    let suggests = [];
    if (authorNo !== "") {
        suggests.push({ title: "Cùng tác giả", input: authorNo, script: "author.js" });
    }

    let comments = [];
    if (d.id != null) {
        comments.push({ title: "Bình luận", input: String(d.id), script: "comments.js" });
    }

    return Response.success({
        name: d.title,
        author: authorName,
        cover: coverUrl(d.cover_url),
        description: d.synopsis || "",
        detail: rows.join(""),
        url: BASE_URL + "/books/" + d.book_no,
        type: "novel",
        format: "novel",
        ongoing: ongoing,
        nsfw: d.is_18plus === true || d.content_rating === "r18",
        locale: "zh-CN",
        genres: genres,
        suggests: suggests,
        comments: comments
    });
}
