load('config.js');

// search.js doubles as the listing script for the home tabs. Their `input` is a
// "cate:<id>" category marker; the site exposes no keyword search for short videos,
// so any real keyword falls back to the aggregated recommend feed.
//
// Covers are left empty. The site stores every poster AES-encrypted and decrypts it
// in the browser, so the raw URL never renders; and the app only treats a cover
// starting with "http" as absolute, so a decrypted data: URI would be joined with the
// host and break too.
function toItem(raw) {
    if (!raw) return null;
    let id = raw.id ? String(raw.id) : "";
    if (!id) return null;

    let name = raw.title ? String(raw.title) : ("Video " + id);
    let description = raw.user_name ? String(raw.user_name) : "";

    return {
        name: name,
        cover: "",
        link: videoPageUrl(id),
        description: description,
        tag: formatDuration(raw.video_duration),
        type: "short",
        host: BASE_URL
    };
}

function execute(query, page) {
    query = String(query || "");
    page = String(page || "");

    let cid = categoryId(query);
    if (cid < 0) cid = 0;

    let p = parseInt(page, 10);
    if (isNaN(p) || p < 1) p = 1;

    let url = BASE_URL + "/melonshort/list?cate_id=" + cid + "&page=" + p;
    let response = fetch(url, { headers: pageHeaders(), timeout: 30000 });
    if (!response.ok) return Response.error(response.status ? ("HTTP " + response.status) : "Không kết nối được máy chủ");

    let json;
    try {
        json = JSON.parse(response.text());
    } catch (error) {
        return Response.error("Phản hồi không hợp lệ");
    }
    if (!json || parseInt(json.code, 10) !== 200 || !json.data) {
        return Response.error(json && json.msg ? String(json.msg) : "Không lấy được danh sách");
    }

    let list = json.data.list || [];
    let items = [];
    for (let i = 0; i < list.length; i++) {
        let item = toItem(list[i]);
        if (item) items.push(item);
    }

    let next = json.data.has_more && items.length > 0 ? String(p + 1) : "";
    return Response.success(items, next);
}
