load('config.js');

function execute() {
    let tabs = [];
    for (let i = 0; i < CATEGORY_LIST.length; i++) {
        tabs.push({
            title: CATEGORY_LIST[i].name,
            input: "cate:" + CATEGORY_LIST[i].id,
            script: "search.js"
        });
    }
    return Response.success(tabs);
}
