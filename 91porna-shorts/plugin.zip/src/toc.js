load('config.js');

// A short is one video, so its "table of contents" is a single episode. Kept
// fetch-free: the short feed resolves it for every queued item while the user watches.
function execute(url) {
    url = normalizeUrl(url);
    let id = videoId(url);

    return Response.success([
        {
            name: id ? ("Video " + id) : "Video ngắn",
            url: url,
            description: "",
            lock: false,
            pay: false
        }
    ]);
}
