load('config.js');

// The playable .m3u8 only exists on the video page (bootstrap JSON / SSR slide), so
// this is the one fetch per episode; track.js then just declares it native.
function execute(url) {
    url = normalizeUrl(url);
    let id = videoId(url);

    let response = fetch(url, { headers: pageHeaders(), timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);

    let stream = streamFromPage(response.html(), id);
    if (!stream) return Response.error("Không tìm thấy nguồn phát");

    return Response.success([{ title: "Auto", data: stream }]);
}
