// cover.js — the app loads a cover through this file when its URL carries
// "#script=cover.js". It must return the image bytes as a bare base64 string.
//
// 91porna serves posters from the same pic.qnlycc.cn CDN as huangguoai, which stores
// them as AES-128-CBC blobs (NoPadding) and decrypts them in the browser with the key
// shipped in that site's crypto-image-protocol.js.
load('crypto.js');

let COVER_KEY = "f5d965df75336270";
let COVER_IV = "97b60394abc2fbe1";

function execute(url) {
    let response = fetch(url, { timeout: 30000 });
    if (!response.ok) return "";

    let plain = CryptoJS.AES.decrypt(
        CryptoJS.lib.CipherParams.create({ ciphertext: CryptoJS.enc.Base64.parse(response.base64()) }),
        CryptoJS.enc.Utf8.parse(COVER_KEY),
        {
            iv: CryptoJS.enc.Utf8.parse(COVER_IV),
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.NoPadding
        }
    );

    let image = plain.toString(CryptoJS.enc.Base64);
    if (!image || image.length < 32) return "";
    return image;
}
