let BASE_URL = "https://91porna.com";
try {
    if (DOMAIN) BASE_URL = String(DOMAIN).replace(/\/+$/, "");
} catch (error) {
}

// "cate_id" values used by the site's /melonshort/list endpoint. They are the ids the
// site ships in its own page bootstrap; 0 is the aggregated "recommend" feed.
let CATEGORY_LIST = [
    { id: 0, code: "recommend", name: "Đề xuất" },
    { id: 19, code: "amateur", name: "Tự quay" },
    { id: 14, code: "zipai", name: "Tự quay gốc" },
    { id: 18, code: "hunjian", name: "Cắt ghép" },
    { id: 17, code: "fancha", name: "Tương phản" },
    { id: 16, code: "wanghong", name: "Hot girl mạng" },
    { id: 15, code: "mingxing", name: "Sao" },
    { id: 20, code: "ai", name: "AI" }
];

// Home tabs pass "cate:<id>"; a bare category code is also accepted. Any other
// non-empty value is a keyword, which this site has no short-video search for, so it
// is reported as -1 and the caller falls back to the recommend feed.
function categoryId(value) {
    let v = String(value || "").replace(/^\s+|\s+$/g, "");
    if (!v) return 0;
    let m = v.match(/^cate:(\d+)$/);
    if (m) return parseInt(m[1], 10);
    for (let i = 0; i < CATEGORY_LIST.length; i++) {
        if (CATEGORY_LIST[i].code === v) return CATEGORY_LIST[i].id;
    }
    return -1;
}

function categoryName(id) {
    for (let i = 0; i < CATEGORY_LIST.length; i++) {
        if (CATEGORY_LIST[i].id === id) return CATEGORY_LIST[i].name;
    }
    return "";
}

function normalizeUrl(url) {
    return String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function videoId(url) {
    let m = String(url).match(/\/melonshort\/video\/(\d+)/);
    return m ? m[1] : "";
}

function videoPageUrl(id) {
    return BASE_URL + "/melonshort/video/" + id;
}

function pageHeaders() {
    return {
        "User-Agent": UserAgent.chrome(),
        "Referer": BASE_URL + "/melonshort"
    };
}

function formatDuration(seconds) {
    let s = parseInt(seconds, 10);
    if (isNaN(s) || s <= 0) return "";
    let h = Math.floor(s / 3600);
    let m = Math.floor((s % 3600) / 60);
    let r = s % 60;
    if (h > 0) {
        return h + ":" + (m < 10 ? "0" + m : m) + ":" + (r < 10 ? "0" + r : r);
    }
    return (m < 10 ? "0" + m : m) + ":" + (r < 10 ? "0" + r : r);
}

// The video page ships a <script id="ms-bootstrap"> JSON blob holding the current
// video plus the rest of its feed page: the one place the resolved stream URL is
// exposed outside the player's own JS.
function bootstrapJson(doc) {
    let el = doc.select("script#ms-bootstrap").first();
    if (!el) return null;
    let raw = el.html();
    if (!raw) return null;
    try {
        return JSON.parse(raw);
    } catch (error) {
        return null;
    }
}

function bootstrapItem(doc, id) {
    let data = bootstrapJson(doc);
    if (!data || !data.first_screen || !data.first_screen.list) return null;
    let list = data.first_screen.list;
    let first = null;
    for (let i = 0; i < list.length; i++) {
        if (!list[i]) continue;
        if (!first) first = list[i];
        if (id && String(list[i].id) === String(id)) return list[i];
    }
    return first;
}

// Resolves the playable .m3u8 for the page: the bootstrap entry first, then the
// slide's data-url attribute (the SSR page renders only the current video).
function streamFromPage(doc, id) {
    let item = bootstrapItem(doc, id);
    if (item && item.video_url) return String(item.video_url);

    if (id) {
        let byId = doc.select(".dx-sv-slide[data-id=" + id + "]").attr("data-url");
        if (byId) return byId;
    }
    return doc.select(".dx-sv-slide[data-url]").attr("data-url");
}
