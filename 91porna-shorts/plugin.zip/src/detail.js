load('config.js');

function esc(value) {
    return String(value === null || value === undefined ? "" : value)
        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function infoLine(label, value) {
    if (value === null || value === undefined || String(value) === "") return "";
    return "<b>" + esc(label) + ":</b> " + esc(value);
}

function execute(url) {
    url = normalizeUrl(url);
    let id = videoId(url);

    let response = fetch(url, { headers: pageHeaders(), timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let item = bootstrapItem(doc, id);
    if (!id && item && item.id) id = String(item.id);

    let title = item && item.title ? String(item.title) : doc.select(".dx-sv-card-title").text();
    let author = item && item.user_name ? String(item.user_name) : "";
    let description = item && item.desc ? String(item.desc) : "";

    // Cover omitted: the site stores every poster AES-encrypted and decrypts it in
    // the browser, so the raw URL never renders; and the app only loads a cover that
    // starts with "http", so a decrypted data: URI would break too.
    let cover = "";

    if (!author) {
        author = doc.select(".dx-sv-card-author-name").text().replace(/^@/, "");
    }
    if (!title) title = "Video ngắn";

    let cid = item ? parseInt(item.cate_id, 10) : NaN;
    if (isNaN(cid)) {
        cid = parseInt(doc.select(".dx-sv-slide[data-cate-id]").attr("data-cate-id"), 10);
    }
    if (isNaN(cid)) cid = 0;

    let cateName = categoryName(cid);
    if (!cateName && item && item.cate_name) cateName = String(item.cate_name);

    let duration = item ? formatDuration(item.video_duration) : "";
    let publish = item && item.publish_time ? String(item.publish_time) : doc.select(".dx-sv-card-time").text();

    let lines = [];
    lines.push(infoLine("Chuyên mục", cateName));
    lines.push(infoLine("Tác giả", author));
    lines.push(infoLine("Lượt xem", item ? item.play_num : ""));
    lines.push(infoLine("Yêu thích", item ? item.like_num : ""));
    lines.push(infoLine("Bình luận", item ? item.comment_num : ""));
    lines.push(infoLine("Thời lượng", duration));
    lines.push(infoLine("Đăng", publish));

    let detail = [];
    for (let i = 0; i < lines.length; i++) {
        if (lines[i]) detail.push(lines[i]);
    }

    let categoryChip = [];
    if (cateName) {
        categoryChip.push({ title: cateName, input: "cate:" + cid, script: "search.js" });
    }

    return Response.success({
        name: title,
        author: author,
        cover: cover,
        description: description,
        detail: detail.join("<br>"),
        url: videoPageUrl(id),
        type: "video",
        format: "short",
        ongoing: true,
        nsfw: true,
        tags: categoryChip,
        suggests: [{ title: "Cùng chuyên mục", input: "cate:" + cid, script: "search.js" }]
    });
}
