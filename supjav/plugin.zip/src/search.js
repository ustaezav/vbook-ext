load('config.js');

function execute(query, page) {
    query = String(query || "");
    page = String(page || "");

    let url;
    if (query.indexOf("http") === 0) {
        url = query;
    } else if (query.indexOf("/") === 0) {
        url = BASE_URL + query;
    } else if (query !== "") {
        url = BASE_URL + "/?s=" + encodeURIComponent(query);
    } else {
        url = BASE_URL + "/";
    }

    if (page.indexOf("http") === 0) {
        url = page;
    } else if (page !== "" && page !== "1") {
        let queryString = "";
        let queryIndex = url.indexOf("?");
        if (queryIndex !== -1) {
            queryString = url.substring(queryIndex);
            url = url.substring(0, queryIndex);
        }
        if (url.charAt(url.length - 1) === "/") url = url.substring(0, url.length - 1);
        url = url + "/page/" + page + queryString;
    }

    let result = fetchDoc(url);
    if (result.error) return Response.error(result.error);

    let next = result.doc.select(".pagination .next-page a").attr("href");
    return Response.success(postItems(result.doc), next ? absoluteUrl(next) : "");
}
