load('config.js');

function execute(url) {
    url = normalizeUrl(url);

    let result = fetchDoc(url);
    if (result.error) return Response.error(result.error);
    let doc = result.doc;

    let name = doc.select(".post-meta h2").text().trim();
    if (!name) name = doc.select(".archive-title h1").text().trim();
    if (!name) name = doc.select("meta[property=og:title]").attr("content").trim();

    let cover = doc.select(".post-meta img.img").attr("src") ||
        doc.select("meta[property=og:image]").attr("content") || "";

    let description = doc.select(".post-content").text().trim();
    if (!description) {
        description = doc.select("meta[name=description]").attr("content").trim();
        description = description.replace(/^[\s,]+/, "");
    }

    let genres = [];
    let seen = {};
    let addGenre = function (el) {
        let title = el.text().trim();
        let input = el.attr("href");
        if (!title || !input) return;
        if (seen[input]) return;
        seen[input] = true;
        genres.push({ title: title, input: input, script: "search.js" });
    };
    doc.select(".post-meta .cats a").forEach(addGenre);
    doc.select(".post-meta .tags a").forEach(addGenre);

    let category = doc.select(".post-meta .cats p.cat a").text().trim();
    let maker = "";
    doc.select(".post-meta .cats p").forEach(function (p) {
        if (!maker && p.select("span").size() > 0) {
            maker = p.select("a").text().trim();
        }
    });

    let info = [];
    if (category) info.push("Thể loại: " + category);
    if (maker) info.push("Hãng: " + maker);
    let views = doc.select(".dz_view .views").text().trim();
    if (views) info.push("Lượt xem: " + views);

    return Response.success({
        name: name,
        cover: absoluteUrl(cover),
        description: description,
        detail: info.join("\n"),
        url: url,
        type: "video",
        format: "series",
        ongoing: false,
        genres: genres,
        suggests: [
            { title: "Có thể bạn thích", input: url, script: "similar.js" }
        ]
    });
}
