let BASE_URL = "https://supjav.com";
try {
  if (DOMAIN) {
    BASE_URL = String(DOMAIN).replace(/\/+$/, "");
  }
} catch (error) {}

function normalizeUrl(url) {
  let text = String(url || "").trim();
  let match = text.match(
    /^(?:https?:\/\/)?(?:[^@\/\n]+@)?(?:www\.)?([^\/\n?:]+)(?::\d+)?(\/[^\s]*)?$/i,
  );
  if (!match) return text;
  return BASE_URL + (match[2] || "/");
}

function absoluteUrl(path) {
  path = String(path || "");
  if (!path) return "";
  if (path.indexOf("http") === 0) return path;
  if (path.indexOf("//") === 0) return "https:" + path;
  if (path.charAt(0) !== "/") path = "/" + path;
  return BASE_URL + path;
}

function imageUrl(el) {
  let src =
    el.attr("data-original") || el.attr("data-src") || el.attr("src") || "";
  if (src.indexOf("data:") === 0) return "";
  return absoluteUrl(src);
}

function cloudflareMessage() {
  return (
    "Supjav đang yêu cầu xác minh Cloudflare. Hãy mở " +
    BASE_URL +
    " trong trình duyệt của app, vượt qua xác minh rồi quay lại thử lại."
  );
}

function isChallenge(doc) {
  if (doc.select("title").text().indexOf("Just a moment") !== -1) return true;
  if (
    doc
      .select(
        "#challenge-form, #cf-challenge-running, .cf-browser-verification",
      )
      .size() > 0
  )
    return true;
  return doc.select("script[src*='challenge-platform']").size() > 0;
}

function fetchDoc(url, options) {
  let response = options ? fetch(url, options) : fetch(url);
  if (!response.ok) {
    if (
      response.status === 403 ||
      response.status === 503 ||
      response.status === 429
    ) {
      return { error: cloudflareMessage() };
    }
    if (response.status === 504) {
      return {
        error:
          "Bấm nút 'Trang nguồn' phía dưới để mở trang web, vượt capcha Cloudflare hoặc đổi mạng/bật VPN 1.1.1.1 nếu không thể mở trang",
      };
    }
    return { error: "HTTP " + response.status };
  }
  let doc = response.html();
  if (isChallenge(doc)) return { error: cloudflareMessage() };
  return { doc: doc, response: response };
}

function postItems(root) {
  let items = [];
  root.select(".post").forEach(function (el) {
    let titleLink = el.select(".con h3 a");
    let link = absoluteUrl(
      el.select("a.img").attr("href") || titleLink.attr("href"),
    );
    let name = (
      titleLink.text() ||
      el.select("a.img").attr("title") ||
      ""
    ).trim();
    let coverEl = el.select("img.thumb");
    if (!name || !link) return;
    items.push({
      name: name,
      cover: coverEl.size() > 0 ? imageUrl(coverEl) : "",
      link: link,
      description: el.select(".meta").text().trim(),
      host: BASE_URL,
    });
  });
  return items;
}
