function execute() {
    return Response.success([
        { title: "Mới nhất", input: "", script: "search.js" },
        { title: "Popular", input: "/popular", script: "search.js" },
        { title: "Popular tuần", input: "/popular?sort=week", script: "search.js" },
        { title: "Popular tháng", input: "/popular?sort=month", script: "search.js" },
        { title: "Censored", input: "/category/censored-jav", script: "search.js" },
        { title: "Uncensored", input: "/category/uncensored-jav", script: "search.js" },
        { title: "Amateur", input: "/category/amateur", script: "search.js" },
        { title: "Eng Sub", input: "/category/english-subtitles", script: "search.js" },
        { title: "Chn Sub", input: "/category/chinese-subtitles", script: "search.js" },
        { title: "Reducing Mosaic", input: "/category/reducing-mosaic", script: "search.js" },
        { title: "FC2PPV", input: "/category/maker/fc2ppv", script: "search.js" },
        { title: "4K", input: "/tag/4k", script: "search.js" }
    ]);
}
