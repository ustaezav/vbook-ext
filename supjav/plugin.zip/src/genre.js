load('config.js');

function execute() {
    let result = fetchDoc(BASE_URL + "/tag");
    if (result.error) return Response.error(result.error);

    let genres = [];
    result.doc.select(".categorys .child a").forEach(function (el) {
        let title = el.text().replace(/\s*\(\d+\)\s*$/, "").trim();
        let input = el.attr("href");
        if (title && input) {
            genres.push({ title: title, input: input, script: "search.js" });
        }
    });

    return Response.success(genres);
}
