load('config.js');

let RESOLVER = "https://lk1.supremejav.com/supjav.php";

function playerHeaders(referer) {
    return {
        "User-Agent": UserAgent.chrome(),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9,vi;q=0.8",
        "Referer": referer || (BASE_URL + "/")
    };
}

function originOf(url) {
    let m = String(url || "").match(/^(https?:\/\/[^\/]+)/i);
    return m ? m[1] : BASE_URL;
}

function pageReferer(html, embed, media) {
    let host = (String(media || "").match(/^https?:\/\/([^\/]+)/i) || [])[1] || "";
    if (/streamtape\./i.test(host)) return "https://streamtape.com/";

    let domain = String(html || "").match(/domain=\.([a-z0-9-]+(?:\.[a-z0-9-]+)+)/i);
    if (domain) return "https://" + domain[1] + "/";

    if (embed && embed.indexOf(RESOLVER) !== 0) return originOf(embed) + "/";
    return BASE_URL + "/";
}

function reverse(text) {
    return String(text).split("").reverse().join("");
}

function unpack(source) {
    let m = source.match(/eval\(function\(p,a,c,k,e,d\)\{[\s\S]*?\}\('([\s\S]*?)',(\d+),(\d+),'([\s\S]*?)'\.split\('\|'\)/);
    if (!m) return "";

    let payload = m[1];
    let base = parseInt(m[2], 10);
    let count = parseInt(m[3], 10);
    let words = m[4].split("|");

    let toBase = function (number) {
        let text = "";
        while (true) {
            let digit = number % base;
            text = (digit > 35 ? String.fromCharCode(digit + 29) : digit.toString(36)) + text;
            number = Math.floor(number / base);
            if (number === 0) break;
        }
        return text;
    };

    for (let i = count - 1; i >= 0; i--) {
        if (!words[i]) continue;
        let token = toBase(i);
        payload = payload.replace(new RegExp("\\b" + token + "\\b", "g"), function () {
            return words[i];
        });
    }

    return payload;
}

function pickHls(js) {
    if (!js) return "";

    // Player configs may contain a relative highest-quality path that only works
    // from the player origin. The redirected origin is not exposed by fetch, so
    // prefer absolute playlists, and playlists with an .m3u8 path first.
    let keys = ["hls4", "hls3", "hls2", "hls", "file"];
    let other = "";
    for (let i = 0; i < keys.length; i++) {
        let m = js.match(new RegExp('"' + keys[i] + '"\\s*:\\s*"([^"]*)"'));
        if (!m || !/^https?:\/\//i.test(m[1])) continue;
        if (/\.m3u8(\?|$)/i.test(m[1])) return m[1];
        if (!other) other = m[1];
    }
    if (other) return other;

    let direct = js.match(/["'](https?:\/\/[^"']*\.m3u8[^"']*)["']/i);
    if (direct && direct[1]) return direct[1];

    return "";
}

function directMedia(html) {
    let m3u8 = html.match(/https?:\/\/[^"'\s<>\\]+\.m3u8[^"'\s<>\\]*/i);
    if (m3u8) return { url: m3u8[0], mime: "application/x-mpegURL" };

    let decoy = /test-videos\.co\.uk|bigbuckbunny|sample-videos|w3schools/i;
    let mp4s = html.match(/https?:\/\/[^"'\s<>\\]+\.mp4[^"'\s<>\\]*/ig) || [];
    for (let i = 0; i < mp4s.length; i++) {
        if (!decoy.test(mp4s[i])) return { url: mp4s[i], mime: "video/mp4" };
    }

    return null;
}

function native(data, mimeType, referer) {
    return Response.success({
        type: "native",
        data: data,
        host: BASE_URL,
        mimeType: mimeType,
        headers: {
            "User-Agent": UserAgent.chrome(),
            "Referer": referer || (BASE_URL + "/")
        },
        timeSkip: []
    });
}

function auto(data) {
    return Response.success({
        type: "auto",
        data: data,
        host: BASE_URL,
        headers: {
            "User-Agent": UserAgent.chrome(),
            "Referer": BASE_URL + "/"
        },
        timeSkip: []
    });
}

function resolveEmbed(data) {
    if (/^https?:\/\//i.test(data)) return data;
    if (!/^[0-9a-f]{32,}$/i.test(data)) return "";

    let url = RESOLVER + "?c=" + reverse(data);
    let response = fetch(url, {
        headers: playerHeaders(),
        timeout: 30000
    });

    return response.url || url;
}

function execute(data) {
    data = String(data || "").trim();
    if (!data) return Response.error("Nguồn phát không hợp lệ.");

    let embed = resolveEmbed(data);
    if (!embed) return Response.error("Nguồn phát không hợp lệ.");

    if (/\.m3u8(\?|$)/i.test(embed)) {
        return native(embed, "application/x-mpegURL", BASE_URL + "/");
    }
    if (/\.mp4(\?|#|$)/i.test(embed)) {
        return native(embed, "video/mp4", BASE_URL + "/");
    }

    let response = fetch(embed, {
        headers: playerHeaders(),
        timeout: 30000
    });
    if (!response.ok) return auto(embed);

    let html = String(response.text() || "");
    let js = unpack(html);
    let referer = pageReferer(js || html, embed, "");

    let robot = html.match(/id=["']robotlink["'][^>]*>([^<]+)</i);
    if (robot && robot[1]) {
        let path = robot[1].trim().replace(/&amp;/g, "&");
        let url = "";
        if (/^\/[a-z0-9.-]+\.[a-z]{2,}\//i.test(path)) {
            url = "https://" + path.substring(1);
        } else if (path.charAt(0) === "/") {
            url = "https://streamtape.com" + path;
        } else if (/^https?:\/\//i.test(path)) {
            url = path;
        }
        if (url) return native(url, "video/mp4", pageReferer(js || html, embed, url));
    }

    let hls = pickHls(js);
    if (hls) return native(hls, "application/x-mpegURL", referer);

    let media = directMedia(html);
    if (media) return native(media.url, media.mime, referer);

    return auto(embed);
}
