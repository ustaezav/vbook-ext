load('config.js');

function execute(url) {
    url = normalizeUrl(url);

    let result = fetchDoc(url);
    if (result.error) return Response.error(result.error);

    let tracks = [];
    let seen = {};
    result.doc.select(".btn-server").forEach(function (el) {
        let title = el.text().trim() || "Server";
        let data = el.attr("data-link");
        if (!data) return;
        if (seen[title]) {
            let n = 2;
            while (seen[title + " " + n]) n++;
            title = title + " " + n;
        }
        seen[title] = true;
        tracks.push({ title: title, data: data });
    });

    if (tracks.length === 0) {
        return Response.error("Không tìm thấy server phát cho video này.");
    }

    return Response.success(tracks);
}
