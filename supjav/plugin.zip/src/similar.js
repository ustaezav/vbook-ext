load('config.js');

function execute(url) {
    url = normalizeUrl(url);

    let result = fetchDoc(url);
    if (result.error) return Response.error(result.error);

    let posts = [];
    result.doc.select(".posts").forEach(function (el) {
        if (el.select(".post").size() > 0) posts.push(el);
    });

    if (posts.length === 0) return Response.success([]);
    return Response.success(postItems(posts[0]));
}
