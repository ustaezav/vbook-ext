load('config.js');

// A Bunkr file page has a single playable source. Hand the file page URL to
// track.js, which extracts and signs the CDN stream.
function execute(url) {
    url = normalizeUrl(url);
    if (url.indexOf("http") !== 0) url = absolute(BASE_URL, url);
    return Response.success([{ title: "Bunkr", data: url }]);
}
