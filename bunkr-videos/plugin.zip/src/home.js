// Home tabs feed their `input` to search.js as the query (a "?..." query string with
// sort/per already set).
function execute() {
    return Response.success([
        { title: "Mới nhất", input: "?search=&mode=broad&per=100&sort=latest", script: "search.js" },
        { title: "Nhiều file", input: "?search=&mode=broad&per=100&sort=files", script: "search.js" },
        { title: "Cũ nhất", input: "?search=&mode=broad&per=100&sort=oldest", script: "search.js" }
    ]);
}
