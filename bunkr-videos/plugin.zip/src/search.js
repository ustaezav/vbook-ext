load('config.js');

// The index site is a searchable list of albums. `query` is either a search keyword
// or one of the home tab inputs (a "/"-prefixed path with sort/per already set).
function execute(query, page) {
    query = String(query || "");
    page = String(page || "1");
    let p = parseInt(page, 10) || 1;
    if (p < 1) p = 1;

    let url;
    if (query.indexOf("http") === 0) {
        url = query;
    } else if (query.indexOf("/") === 0) {
        url = BASE_URL + query;
    } else if (query) {
        url = BASE_URL + "/?search=" + encodeURIComponent(query) + "&mode=broad&per=40&sort=latest";
    } else {
        url = BASE_URL + "/?search=&mode=broad&per=40&sort=latest";
    }
    url += (url.indexOf("?") === -1 ? "?" : "&") + "page=" + p;

    let response = fetch(url, { headers: { "User-Agent": UserAgent.chrome() } });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = [];
    doc.select("section a.card[href]").forEach(function (el) {
        let link = el.attr("href");
        if (!link || link.indexOf("/a/") === -1) return;
        let name = el.select("h3").text().trim();
        if (!name) return;

        let description = "";
        el.select("span").forEach(function (s) {
            let t = s.text().trim();
            if (/files?$/i.test(t)) description = t;
        });

        items.push({
            name: name,
            cover: el.select("img.thumb-img").attr("src"),
            link: link,
            description: description
        });
    });

    // Search/browse results render their pagination as plain anchors (no shared
    // class), so look for any link to a higher page number.
    let hasNext = false;
    doc.select("a[href]").forEach(function (a) {
        let m = a.attr("href").match(/[?&]page=(\d+)/);
        if (m && parseInt(m[1], 10) > p) hasNext = true;
    });

    return Response.success(items, hasNext ? String(p + 1) : "");
}
