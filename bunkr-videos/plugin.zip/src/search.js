load('config.js');

// The index site is a searchable grid of albums. `query` is either a search keyword or
// one of the home tab inputs (a "?..." query string with sort/per already set).
function execute(query, page) {
    query = String(query || "").trim();
    page = String(page || "1");
    let p = parseInt(page, 10) || 1;
    if (p < 1) p = 1;

    let url;
    if (query.indexOf("http") === 0) {
        url = query;
    } else if (query.charAt(0) === "?") {
        url = BASE_URL + "/" + query;
    } else if (query.charAt(0) === "/") {
        url = BASE_URL + query;
    } else {
        url = BASE_URL + "/?search=" + encodeURIComponent(query) + "&mode=broad&per=40&sort=latest";
    }
    url += (url.indexOf("?") === -1 ? "?" : "&") + "page=" + p;

    let response = fetch(url, { headers: { "User-Agent": UserAgent.chrome() }, timeout: 30000 });
    if (!response.ok) return Response.error(checkpointMessage(response));
    let doc = response.html();

    let items = [];
    doc.select("a.card[href]").forEach(function (el) {
        let link = el.attr("href");
        if (!link || link.indexOf("/a/") === -1) return;

        // The card carries "View album <name> <n> files → Open"; the title itself has no
        // class, so take it from the heading inside the card body.
        let name = el.select("h3").text().trim();
        if (!name) {
            let text = el.text().replace(/\s+/g, " ").trim();
            let m = text.match(/View album\s+(.*?)\s+(\d+\s+files?)\s*(?:&rarr;|→)?\s*Open/i);
            if (m) name = m[1].trim();
        }
        if (!name) return;

        let description = "";
        let files = el.text().match(/(\d+\s+files?)/i);
        if (files) description = files[1];

        items.push({
            name: name,
            cover: el.select("img").attr("src"),
            link: link,
            description: description
        });
    });

    let hasNext = false;
    doc.select("a[href]").forEach(function (a) {
        let m = a.attr("href").match(/[?&]page=(\d+)/);
        if (m && parseInt(m[1], 10) > p) hasNext = true;
    });

    return Response.success(items, hasNext ? String(p + 1) : "");
}
