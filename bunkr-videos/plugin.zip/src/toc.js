load('config.js');

// Each file in an album is one episode. Only video files are kept as chapters; an
// album may also contain images or archives the player cannot open.
//
// Bunkr paginates the album file list server-side with ?page=N (the pagination nav
// always renders the last page number). toc walks those pages itself instead of
// using page.js, so a page that happens to hold no video files cannot fail the list.
function isVideo(name) {
    return /\.(mp4|mkv|webm|mov|m4v|avi|wmv|flv|mpg|mpeg|ts|3gp)$/i.test(String(name).trim());
}

function collect(doc, base, chapters) {
    doc.select(".theItem").forEach(function (el) {
        let link = el.select("a[href*='/f/'], a[href*='/d/']").attr("href");
        let name = (el.attr("title") || el.select(".theName").text()).trim();
        if (!link || !name || !isVideo(name)) return;
        chapters.push({
            name: name,
            url: absolute(base, link),
            description: el.select(".theSize").text().trim(),
            lock: false,
            pay: false
        });
    });
}

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url, { headers: { "User-Agent": UserAgent.chrome() } });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let first = response.html();

    let last = 1;
    first.select(".pagination a").forEach(function (a) {
        let m = a.attr("href").match(/[?&]page=(\d+)/);
        if (m) {
            let n = parseInt(m[1], 10);
            if (n > last) last = n;
        }
    });

    let chapters = [];
    collect(first, url, chapters);
    for (let i = 2; i <= last; i++) {
        let pageUrl = url + (url.indexOf("?") === -1 ? "?" : "&") + "page=" + i;
        let r = fetch(pageUrl, { headers: { "User-Agent": UserAgent.chrome() } });
        if (!r.ok) continue;
        collect(r.html(), pageUrl, chapters);
    }

    if (chapters.length === 0) return Response.error("Album không có video");
    return Response.success(chapters);
}
