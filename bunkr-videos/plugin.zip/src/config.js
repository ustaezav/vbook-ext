// BASE_URL is the album-index site. Album and file pages live on rotating bunkr
// hosts (bunkr.cr, bunkr.si, ...), so they are always fetched as absolute URLs and
// are never rewritten to BASE_URL.
let BASE_URL = "https://balbums.st";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

// Rewrite only the index host (current domain or its mirror) to BASE_URL, keeping
// path/query. Any other host (bunkr.*, cdn.*, static.*) is returned unchanged.
function normalizeUrl(url) {
    return String(url).replace(/^(https?:\/\/)?(?:www\.)?(balbums\.st|bunkr-albums\.io)(?=\/|$)/i, BASE_URL);
}

// Origin (scheme + host) of an absolute URL, e.g. "https://bunkr.cr".
function originOf(url) {
    let m = String(url).match(/^(https?:\/\/[^\/]+)/);
    return m ? m[1] : BASE_URL;
}

// Make a possibly relative link absolute against a base URL.
function absolute(base, link) {
    link = String(link || "");
    if (link.indexOf("http") === 0) return link;
    if (link.charAt(0) !== "/") link = "/" + link;
    return originOf(base) + link;
}
