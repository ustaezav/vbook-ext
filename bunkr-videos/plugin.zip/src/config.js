// BASE_URL is the album-index site. Album and file pages live on rotating bunkr
// hosts (bunkr.cr, bunkr.pw, ...), so they are always fetched as absolute URLs and
// are never rewritten to BASE_URL.
let BASE_URL = "https://bunkr-albums.org";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

// Rewrite only the index hosts (current domain and the older ones) to BASE_URL,
// keeping path/query. Any other host (bunkr.*, cdn.*, static.*) is returned unchanged.
function normalizeUrl(url) {
    return String(url).replace(
        /^(https?:\/\/)?(?:www\.)?(bunkr-albums\.org|bunkr-albums\.io|balbums\.st)(?=\/|$)/i,
        BASE_URL
    );
}

// Origin (scheme + host) of an absolute URL, e.g. "https://bunkr.cr".
function originOf(url) {
    let m = String(url).match(/^(https?:\/\/[^\/]+)/);
    return m ? m[1] : BASE_URL;
}

// Make a possibly relative link absolute against a base URL.
function absolute(base, link) {
    link = String(link || "");
    if (link.indexOf("http") === 0) return link;
    if (link.charAt(0) !== "/") link = "/" + link;
    return originOf(base) + link;
}

// A 403/503 with no album markup means Cloudflare answered instead of the site. Report
// that instead of the bare status, so the message says what the user can do.
function checkpointMessage(response) {
    if (response && (response.status === 403 || response.status === 503)) {
        return "Máy chủ yêu cầu xác minh Cloudflare. Hãy mở Trang nguồn, xác minh rồi Tải lại; " +
            "hoặc dán trực tiếp link album bunkr.* (ví dụ https://bunkr.cr/a/xxxx).";
    }
    return "HTTP " + (response ? response.status : "?");
}
