load('config.js');

// Read one `var name = "..."` from an inline script tag and unescape `\/`.
function scriptVar(html, name) {
    let m = html.match(new RegExp("var\\s+" + name + "\\s*=\\s*[\"']([^\"']+)[\"']"));
    return m ? m[1].replace(/\\\//g, "/") : "";
}

function execute(data) {
    data = String(data || "").trim();
    if (data.indexOf("http") !== 0) return Response.error("Nguồn không hợp lệ");

    // `data` is the Bunkr file page; the real media URL and its signing endpoint are
    // declared in an inline script.
    let response = fetch(data, { headers: { "User-Agent": UserAgent.chrome() } });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let html = response.text();

    let cdn = scriptVar(html, "jsCDN");
    let type = scriptVar(html, "jsType") || "video/mp4";
    let signUrl = scriptVar(html, "signUrl");
    if (!cdn) return Response.error("Không tìm thấy nguồn phát");

    let url = cdn;
    if (url.indexOf("token=") === -1 && signUrl) {
        let pathMatch = cdn.match(/^https?:\/\/[^\/]+(\/.*)$/);
        let path = pathMatch ? pathMatch[1] : cdn;
        let signed = fetch(signUrl + "?path=" + encodeURIComponent(path), {
            headers: { "User-Agent": UserAgent.chrome(), "Referer": data }
        });
        if (signed.ok) {
            try {
                let token = signed.json();
                if (token && token.token) {
                    url = cdn + (cdn.indexOf("?") === -1 ? "?" : "&") + "token=" + token.token + "&ex=" + token.ex;
                }
            } catch (e) {
            }
        }
    }

    return Response.success({
        type: "native",
        data: url,
        host: originOf(data),
        mimeType: type,
        headers: { "User-Agent": UserAgent.chrome(), "Referer": data },
        timeSkip: []
    });
}
