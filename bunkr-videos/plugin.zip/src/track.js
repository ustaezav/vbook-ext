load('config.js');

// A Bunkr file page signs its CDN URL through /api/sign/{slug}; the legacy inline
// jsCDN/signUrl variables are gone from newer hosts. `data` is the file page URL.
function slugOf(url) {
    let m = String(url).match(/\/(?:f|d)\/([A-Za-z0-9]+)/);
    return m ? m[1] : "";
}

function signedUrl(pageUrl) {
    let slug = slugOf(pageUrl);
    if (!slug) return null;

    let origin = originOf(pageUrl);
    let response = fetch(origin + "/api/sign/" + slug, {
        headers: { "User-Agent": UserAgent.chrome(), "Accept": "application/json", "Referer": pageUrl },
        timeout: 30000
    });
    if (!response.ok) return null;

    let payload;
    try {
        payload = response.json();
    } catch (error) {
        return null;
    }
    if (!payload || payload.ok !== true || !payload.url) return null;
    return payload;
}

function execute(data) {
    data = String(data || "").trim();
    if (data.indexOf("http") !== 0) return Response.error("Nguồn không hợp lệ");

    let payload = signedUrl(data);
    if (!payload) return Response.error("Không tìm thấy nguồn phát");

    return Response.success({
        type: "native",
        data: payload.url,
        host: originOf(data),
        mimeType: payload.type || "",
        headers: { "User-Agent": UserAgent.chrome(), "Referer": data },
        timeSkip: []
    });
}
