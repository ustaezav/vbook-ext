load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url, { headers: { "User-Agent": UserAgent.chrome() } });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let name = doc.select("meta[property=og:title]").attr("content").trim();
    if (!name) name = doc.select("title").text().replace(/\s*\|\s*Bunkr\s*$/i, "").trim();

    let cover = doc.select("meta[property=og:image]").attr("content").trim();
    let description = doc.select("meta[property=og:description]").attr("content").trim();

    return Response.success({
        name: name,
        cover: cover,
        description: description,
        detail: "",
        url: url,
        type: "video",
        format: "series",
        ongoing: false,
        genres: [],
        suggests: []
    });
}
