load('config.js');

function execute() {
    let lines = [];
    let r = fetch(BASE_URL + "/usr/themes/Mirages/images/91cg3.jpg", { timeout: 20000 });
    lines.push("fetch=" + r.status);
    let b64 = r.base64();
    lines.push("b64=" + (b64 ? b64.length : "null") + " head=" + (b64 ? b64.substring(0, 4) : ""));
    try {
        let img = Graphics.createImage(b64);
        lines.push("img=" + (img ? img.width + "x" + img.height : "null"));
        let w = 300, h = Math.round(img.height * w / img.width);
        let canvas = Graphics.createCanvas(w, h);
        canvas.drawImage(img, 0, 0, w, h);
        let out = canvas.capture();
        lines.push("captured=" + (out ? out.length : "null") + " ratio=" + (out ? (out.length / b64.length).toFixed(2) : ""));
    } catch (e) {
        lines.push("graphics ERROR " + e);
    }
    return Response.success(lines.join("\n"));
}
