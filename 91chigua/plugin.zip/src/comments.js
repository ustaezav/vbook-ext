load('config.js');

// The comment timestamp is epoch seconds; show it as a local date and time.
function displayTime(seconds) {
    if (!seconds) return "";
    let date = new Date(Number(seconds) * 1000);
    let pad = function (n) { return n < 10 ? "0" + n : String(n); };
    return date.getFullYear() + "-" + pad(date.getMonth() + 1) + "-" + pad(date.getDate()) +
        " " + pad(date.getHours()) + ":" + pad(date.getMinutes());
}

function parseRows(rows) {
    let comments = [];
    for (let i = 0; i < rows.length; i++) {
        let row = rows[i];
        comments.push({
            name: row.author,
            content: row.content_html || row.content,
            description: displayTime(row.created_at)
        });
    }
    return comments;
}

// `input` is the article's cid; `next` is the page number of the previous call.
function execute(input, next) {
    let cid = String(input || "");
    if (!cid) return Response.success([], "");
    let page = next ? parseInt(next, 10) : 1;

    let url = BASE_URL + "/action/comments?action=list&cid=" + encodeURIComponent(cid) + "&filter=hot&page=" + page;
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let json = response.json();
    if (!json || json.status !== 1 || !json.data) return Response.success([], "");

    let data = json.data;
    let nextPage = page * (data.page_size || 20) < (data.total || 0) ? String(page + 1) : "";
    return Response.success(parseRows(data.rows || []), nextPage);
}
