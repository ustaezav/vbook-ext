load('config.js');

// List script for the home tabs and every genre. `query` is the path declared by
// the tab/genre, `page` is the next-page token: a URL from this site's pager, or
// a bare page number when the caller starts counting itself.
function execute(query, page) {
    page = String(page || "");
    let url;
    if (!page || page === "1") {
        url = absoluteUrl(query || "/");
    } else if (page.indexOf("http") === 0 || page.indexOf("/") === 0) {
        url = normalizeUrl(page);
    } else {
        url = pageUrl(absoluteUrl(query || "/"), page);
    }

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = parseCards(doc);
    if (!items.length) items = parseRealtimeCards(doc);
    if (!items.length) items = parseBricks(doc);
    return Response.success(items, nextPageUrl(doc));
}
