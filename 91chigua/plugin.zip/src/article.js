load('config.js');
load('crypto.js');

// Every CDN upload is an AES-128-CBC (NoPadding) blob; the browser decrypts it
// with the key from the site's own crypto script. The reader draws plain bytes,
// so body images are decrypted here and inlined as data URIs.
let IMAGE_KEY = "f5d965df75336270";
let IMAGE_IV = "97b60394abc2fbe1";

function decryptImage(url) {
    let response = fetch(url, { timeout: 30000 });
    if (!response.ok) return "";
    let plain;
    try {
        plain = CryptoJS.AES.decrypt(
            CryptoJS.lib.CipherParams.create({ ciphertext: CryptoJS.enc.Base64.parse(response.base64()) }),
            CryptoJS.enc.Utf8.parse(IMAGE_KEY),
            {
                iv: CryptoJS.enc.Utf8.parse(IMAGE_IV),
                mode: CryptoJS.mode.CBC,
                padding: CryptoJS.pad.NoPadding
            }
        );
    } catch (error) {
        return "";
    }
    let base64 = plain.toString(CryptoJS.enc.Base64);
    // A JPEG starts with /9j/ once base64-encoded; anything else is a failed decrypt.
    return base64 && base64.indexOf("/9j/") === 0 ? "data:image/jpeg;base64," + base64 : "";
}

// Body images are lazy: src points at a placeholder and the real file sits in
// data-xkrkllgl. Relative links are made absolute so a tap opens the right page.
function rewriteMedia(html) {
    if (!html) return "";
    html = html.replace(/<!--[\s\S]*?-->/g, "");
    html = html.replace(/<a\b[^>]*\bhref="([^"]*)"[^>]*>/gi, function (tag, href) {
        return tag.replace('href="' + href + '"', 'href="' + linkUrl(href) + '"');
    });
    return html.replace(/<img\b[^>]*>/gi, function (tag) {
        let lazy = /data-xkrkllgl="([^"]+)"/i.exec(tag);
        let src = /src="([^"]*)"/i.exec(tag);
        let url = lazy ? lazy[1] : (src ? src[1] : "");
        if (!url) return "";
        // The site's own address poster is a promo, not article media.
        if (url.indexOf("/usr/plugins/tbxw/") !== -1) return "";
        let alt = /alt="([^"]*)"/i.exec(tag);
        let altAttr = alt ? ' alt="' + alt[1] + '"' : "";

        let resolved = mediaUrl(url);
        if (!isEncryptedImage(resolved)) {
            return '<img src="' + resolved + '"' + altAttr + ">";
        }
        let inline = decryptImage(resolved);
        // A failed decrypt keeps the URL so the image can still be opened directly.
        return inline
            ? '<img src="' + inline + '"' + altAttr + ">"
            : '<img src="' + resolved + '"' + altAttr + ">";
    });
}

// The video is an AES-128 HLS stream inside a DPlayer shell: neither the reader
// nor an Android WebView can play it. The site's own page can, so link there.
function videoLink(container, pageUrl) {
    if (container.select(".dplayer").size() === 0) return "";
    return '<p><a href="' + pageUrl + '">▶ 观看视频（在浏览器中打开）</a></p>';
}

// Promo blocks repeat in every article; drop them by their text.
function isPromo(el) {
    let text = el.text();
    return text.indexOf("请截图保存") !== -1 ||
        text.indexOf("最新吃瓜网址") !== -1 ||
        text.indexOf("91吃瓜推荐") !== -1 ||
        text.indexOf("加入91吃瓜官方") !== -1;
}

// Live-camera pages wrap the player in their own layout instead of prose.
function cleanVideoPage(container) {
    container.select(".realtime-video-content, .video-description, .candid-video-recommend").remove();
    container.select("style").remove();
}

// A player frame URL is only usable as a cover when the site set a real still;
// some articles point it at the theme's generic placeholder.
function usablePic(pic) {
    if (!pic) return "";
    let url = pic.replace(/\\\//g, "/");
    if (url.indexOf("video-placeholder") !== -1 || url.indexOf("/usr/themes/") !== -1) return "";
    return mediaUrl(url);
}

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let tags = doc.select("div.tags a[href*='/tag/']").map(function (a) {
        return a.text();
    });
    let cid = doc.select("section#comments").attr("data-cid");

    let body = doc.select("div.post-content").first();
    if (!body) return Response.error("Không tìm thấy nội dung bài viết");
    if (body.select("p").size() === 0 && body.select(".dplayer").size() === 0) {
        return Response.error("Không tìm thấy nội dung bài viết");
    }

    let player = videoLink(body, url);
    // Read the player frame now: the cleanup below drops the player wrapper.
    let config = body.select(".dplayer").attr("data-config");
    let pic = /"pic"\s*:\s*"([^"]+)"/.exec(config || "");

    body.select(".ssp-placement, template, script, style, iframe").remove();
    body.select(".opt-stage, .content-tabs, .tags, .content-copyright, nav.post-contribution-actions").remove();
    body.select(".top_picks_title, .top_picks_wrapper, .btn-download").remove();
    cleanVideoPage(body);
    // Address mirrors, app download and group invites arrive as blockquotes.
    body.select("blockquote").forEach(function (quote) {
        let html = quote.html();
        if (html.indexOf("sponsored") !== -1 || html.indexOf("/app.html") !== -1 || html.indexOf("/qun.html") !== -1) {
            quote.remove();
        }
    });
    // The "91吃瓜推荐" table only links to category and archive pages.
    body.select("table").forEach(function (table) {
        let links = table.select("a[href]");
        let navOnly = links.size() > 0;
        links.forEach(function (a) {
            let href = a.attr("href");
            if (href.indexOf("/category/") !== 0 && href.indexOf("/archives/") !== 0) navOnly = false;
        });
        if (navOnly) table.remove();
    });
    body.select("p").forEach(function (el) {
        if (isPromo(el)) el.remove();
    });

    let content = rewriteMedia(body.html());
    // Emptied promo wrappers and the autogenerated table-of-contents anchors.
    content = content.replace(/<div\b[^>]*>\s*<\/div>/gi, "");
    content = content.replace(/<p\b[^>]*>\s*(?:&nbsp;)?\s*<\/p>/gi, "");
    content = content.replace(/<span\b[^>]*id="menu_index_[^"]*"[^>]*>\s*<\/span>/gi, "");
    content = content.replace(/(?:\s|&nbsp;)+$/g, "");
    if (player) content = player + content;

    // The 2022-era template has no h1/post-meta header: the headline and the
    // publish date only live in the schema.org meta tags.
    let name = doc.select("h1.post-title").text() || doc.select("meta[itemprop='headline']").attr("content");
    let author = doc.select(".post-meta a[href^='/author/']").first().text();
    if (!author) author = doc.select("div[itemprop='author'] meta[itemprop='name']").attr("content");

    let cover = doc.select("meta[itemprop='image']").attr("content");
    if (!cover) cover = usablePic(pic ? pic[1] : "");
    if (!cover) {
        // Otherwise the first real body image; the site's placeholder poster is
        // served from /usr/plugins and is never the article's own cover.
        body.select("img").forEach(function (img) {
            if (cover) return;
            let url = img.attr("data-xkrkllgl") || img.attr("src");
            if (url && url.indexOf("usr/plugins") === -1) cover = coverUrl(url);
        });
    } else {
        cover = coverUrl(cover);
    }

    let published = doc.select("meta[itemprop='datePublished']").attr("content");
    if (!published) published = doc.select(".post-meta time").attr("datetime");
    return Response.success({
        name: name,
        author: author,
        cover: cover,
        time: epochSeconds(published) || doc.select(".post-meta time").text(),
        edited_time: doc.select("meta[itemprop='dateModified']").attr("content"),
        source_name: "91吃瓜",
        tags: tags,
        content: content,
        content_format: "html",
        comments: cid ? [{ title: "Bình luận", input: cid, script: "comments.js" }] : []
    });
}
