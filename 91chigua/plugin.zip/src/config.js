// DOMAIN (plugin.json config) overrides the default; try/catch covers it not being injected.
let BASE_URL = "https://www.91cg1.com";
try {
    if (DOMAIN) BASE_URL = String(DOMAIN).replace(/\/+$/, "");
} catch (error) {
}

// Move any incoming URL (old/mirror/www host, relative, //host) onto BASE_URL, keeping path/query.
function normalizeUrl(url) {
    if (!url) return BASE_URL;
    url = String(url);
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("http") !== 0) {
        return BASE_URL + (url.charAt(0) === "/" ? "" : "/") + url;
    }
    return url.replace(/^https?:\/\/(?:[^\/?#]+)/i, BASE_URL);
}

// Absolute form of an href found on a page. Site links are moved onto BASE_URL.
function absoluteUrl(href) {
    if (!href) return "";
    href = String(href);
    if (href.indexOf("//") === 0) return "https:" + href;
    if (href.indexOf("http") === 0) return normalizeUrl(href);
    return BASE_URL + (href.charAt(0) === "/" ? "" : "/") + href;
}

// Absolute media URL: a foreign CDN host is kept, only relative paths are resolved.
function mediaUrl(url) {
    if (!url) return "";
    url = String(url);
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("http") === 0) return url;
    return BASE_URL + (url.charAt(0) === "/" ? "" : "/") + url;
}

// The CMS stores every CDN upload as an AES-128-CBC blob and decrypts it in the
// browser, so the raw bytes are not an image the reader can draw.
function isEncryptedImage(url) {
    if (!url) return false;
    url = String(url);
    return url.indexOf("/new/") !== -1 ||
        url.indexOf("/xiao/") !== -1 ||
        url.indexOf("/upload/upload/") !== -1 ||
        url.indexOf("/upload_01/") !== -1 ||
        url.indexOf("/uploads/") !== -1 ||
        url.indexOf("/upload-images/") !== -1;
}

// Covers are loaded through cover.js because their bytes are encrypted. The
// version query keeps an earlier install's cached (undecrypted) cover from
// being reused for the same URL.
let COVER_VERSION = "2";

function coverUrl(url) {
    let resolved = mediaUrl(url);
    if (!resolved) return "";
    if (!isEncryptedImage(resolved)) return resolved;
    let sep = resolved.indexOf("?") === -1 ? "?" : "&";
    return resolved + sep + "v=" + COVER_VERSION + "#script=cover.js";
}

// A link found inside article text: relative paths are resolved, links to other
// sites stay as they are, and the source's own host follows DOMAIN.
function linkUrl(href) {
    if (!href) return "";
    href = String(href);
    if (href.indexOf("//") === 0) return "https:" + href;
    if (href.indexOf("http") === 0) {
        // Only the site's own host is moved; external links are left alone.
        return href.replace(/^(https?:\/\/(?:www\.)?91cg[0-9a-z]*\.[a-z]+)/i, BASE_URL);
    }
    if (href.indexOf("/") === 0) return BASE_URL + href;
    return href;
}

function cleanText(text) {
    return String(text || "").replace(/•/g, " ").replace(/\s+/g, " ").trim();
}

// The site publishes ISO timestamps; the reader formats a plain epoch instead.
function epochSeconds(iso) {
    let m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:([+-])(\d{2}):(\d{2}))?/.exec(String(iso || ""));
    if (!m) return 0;
    let epoch = Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4]), Number(m[5]), Number(m[6]));
    if (m[7]) {
        let offset = (Number(m[8]) * 60 + Number(m[9])) * 60 * 1000;
        epoch += m[7] === "+" ? -offset : offset;
    }
    return Math.floor(epoch / 1000);
}

// Article cards on home, category, tag and search pages. Each card is
// <article itemscope itemtype="http://schema.org/BlogPosting">; cards without a
// banner script carry no cover and the reader falls back to the article's own.
function parseCards(doc) {
    let items = [];
    doc.select("article[itemtype='http://schema.org/BlogPosting']").forEach(function(el) {
        let link = el.select("meta[itemprop='url mainEntityOfPage']").attr("content");
        if (!link) link = el.select("a[href]").attr("href");
        if (link) link = normalizeUrl(link);

        let title = el.select("h2.post-card-title").first();
        // The hot badge lives in a nested <div class="wrap">; drop it before reading the title.
        title.select(".wrap").remove();
        let name = cleanText(title.text());

        // Covers are painted by an inline loadBannerDirect('<url>', ...) call.
        let cover = "";
        let script = el.select("script").html();
        let match = /loadBannerDirect\(\s*'([^']+)'/.exec(script);
        if (match) cover = coverUrl(match[1]);

        let author = cleanText(el.select("span[itemprop='author']").text());

        let published = el.select("span[itemprop='datePublished']");
        let time = epochSeconds(published.attr("content")) || cleanText(published.text());

        let tag = "";
        let spans = el.select(".post-card-info > span");
        for (let i = 0; i < spans.size(); i++) {
            if (!spans.get(i).attr("itemprop")) tag = cleanText(spans.get(i).text());
        }

        if (name && link) {
            items.push({
                name: name,
                cover: cover,
                link: link,
                author: author,
                time: time,
                tag: tag
            });
        }
    });
    return items;
}

// The 实时监控 category lists live-camera clips with a different card.
function parseRealtimeCards(doc) {
    let items = [];
    doc.select("a.realtime-card[href]").forEach(function(a) {
        let img = a.select("img[data-xkrkllgl]").first();
        let name = cleanText(a.attr("aria-label") || img.attr("alt"));
        if (!name) return;
        items.push({
            name: name,
            cover: coverUrl(img.attr("data-xkrkllgl")),
            link: normalizeUrl(a.attr("href")),
            tag: "实时监控"
        });
    });
    return items;
}

// Fallback: the /archives.html date-ordered list uses <div class="brick"> rows.
function parseBricks(doc) {
    let items = [];
    doc.select(".archives[data-date]").forEach(function(group) {
        let month = group.attr("data-date");
        group.select(".brick a[href]").forEach(function(a) {
            let day = a.select("span.time");
            // "11-26" beside a "2026-11" group heading → the day of that month.
            let dayText = day.size() ? day.text().trim() : "";
            let time = month ? month + dayText.substring(dayText.indexOf("-")) : dayText;
            day.remove();
            let name = cleanText(a.text());
            if (!name) return;
            items.push({
                name: name,
                link: normalizeUrl(a.attr("href")),
                time: time
            });
        });
    });
    return items;
}

// Page-number form of a list URL, for callers that pass a bare number:
// home is /page/2/, categories and tags are /category/x/2/, the archive index
// is /archives/page/2/.
function pageUrl(base, page) {
    base = String(base || "").replace(/[?#].*$/, "").replace(/\/+$/, "");
    if (base === BASE_URL) return BASE_URL + "/page/" + page + "/";
    if (/\/archives\.html$/.test(base)) return BASE_URL + "/archives/page/" + page + "/";
    return base + "/" + page + "/";
}

// Next page's absolute URL from the pager, or "" at the end.
function nextPageUrl(doc) {
    let next = doc.select("ul.page-navigator li.next a[href]").attr("href");
    if (!next) next = doc.select("a.tags-pagination__next[href]").attr("href");
    if (!next) {
        // Live-camera lists put "上一页" and "下一页" in the same button row.
        doc.select("a.candid-list-pagination__btn[href]").forEach(function(a) {
            if (a.text().indexOf("下一页") !== -1) next = a.attr("href");
        });
    }
    if (!next || next.indexOf("javascript") === 0) return "";
    return normalizeUrl(next);
}
