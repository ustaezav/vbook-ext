load('config.js');

// The site navigation lists every article category; ask-page sections that have
// no articles at all (wish wall, submission centre) are left out.
function execute() {
    let response = fetch(BASE_URL);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let genres = [];
    let seen = {};
    doc.select("#menu-menu-1 a[href]").forEach(function (a) {
        let href = a.attr("href");
        if (href.indexOf("/category/") !== 0) return;
        if (href.indexOf("/category/wish/") === 0 || href.indexOf("/category/contribution/") === 0) return;
        if (seen[href]) return;
        seen[href] = true;
        genres.push({ title: a.text(), input: href, script: "list.js" });
    });
    return Response.success(genres);
}
