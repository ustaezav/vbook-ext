// The CMS encrypts every CDN upload with AES-128-CBC (NoPadding) and decrypts it
// in the browser with the key shipped in its crypto script. The app loads a cover
// through this file when the URL carries "#script=cover.js"; it must return the
// image bytes as a bare base64 string (no Response, no data: prefix).
load('crypto.js');

let COVER_KEY = "f5d965df75336270";
let COVER_IV = "97b60394abc2fbe1";

// JPEG / PNG / WebP / GIF magic once base64-encoded.
function isImageBase64(base64) {
    return base64.indexOf("/9j/") === 0 ||
        base64.indexOf("iVBORw0KGgo") === 0 ||
        base64.indexOf("UklGR") === 0 ||
        base64.indexOf("R0lGOD") === 0;
}

function decrypt(base64) {
    let plain;
    try {
        plain = CryptoJS.AES.decrypt(
            CryptoJS.lib.CipherParams.create({ ciphertext: CryptoJS.enc.Base64.parse(base64) }),
            CryptoJS.enc.Utf8.parse(COVER_KEY),
            {
                iv: CryptoJS.enc.Utf8.parse(COVER_IV),
                mode: CryptoJS.mode.CBC,
                padding: CryptoJS.pad.NoPadding
            }
        );
    } catch (error) {
        return "";
    }
    return plain.toString(CryptoJS.enc.Base64);
}

function execute(url) {
    let response = fetch(url, { timeout: 30000 });
    if (!response.ok) return "";

    let base64 = response.base64();
    // Some CDN paths already hold a plain image; pass it through untouched.
    if (isImageBase64(base64)) return base64;

    let image = decrypt(base64);
    return isImageBase64(image) ? image : "";
}
