// A tab's script is the paged list script below; a tap on an item opens article.js.
function execute() {
    return Response.success([
        { title: "最新", input: "/", script: "list.js" },
        { title: "今日吃瓜", input: "/category/zxcghl/", script: "list.js" },
        { title: "91探花", input: "/category/91th/", script: "list.js" },
        { title: "必吃大瓜", input: "/category/bcdg/", script: "list.js" },
        { title: "周榜", input: "/category/zdtop/", script: "list.js" },
        { title: "往期回顾", input: "/archives.html", script: "list.js" }
    ]);
}
