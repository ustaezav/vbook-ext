load('config.js');

// Pages past the first are path numbers: /search/<keyword>/2/.
function searchUrl(query, page) {
    let path = BASE_URL + "/search/" + encodeURIComponent(query) + "/";
    if (page && page !== "1") path += page + "/";
    return path;
}

// Keyword search lives at /search/<keyword>/; page 2 onward: /search/<keyword>/2/.
function execute(query, page) {
    query = String(query || "").trim();
    page = String(page || "");
    if (!query) return Response.success([], "");

    // "1" and a full URL both arrive as the page token for later pages.
    let url;
    let isSitePath = query.indexOf("/") === 0 || query.indexOf("http") === 0;
    if (page && page.indexOf("/") === -1 && page.indexOf("http") !== 0) {
        url = isSitePath ? pageUrl(absoluteUrl(query), page) : searchUrl(query, page);
    } else if (page) {
        url = normalizeUrl(page);
    } else if (isSitePath) {
        // A genre/tab input arrives as a site path or URL: treat it as a paged list.
        url = absoluteUrl(query);
    } else {
        url = searchUrl(query, "");
    }

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = parseCards(doc);
    if (!items.length) items = parseRealtimeCards(doc);
    if (!items.length) items = parseBricks(doc);
    return Response.success(items, nextPageUrl(doc));
}
