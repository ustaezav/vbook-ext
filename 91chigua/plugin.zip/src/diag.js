load('config.js');

// Diagnostic list: every cover is a plain (unencrypted) JPEG from the site's own
// theme, so it exercises the app's normal cover path with no cover.js involved.
function execute(query, page) {
    let response = fetch(absoluteUrl(query || "/"));
    let doc = response.html();
    let items = parseCards(doc);
    for (let i = 0; i < items.length; i++) {
        items[i].cover = "https://www.91cg1.com/usr/themes/Mirages/images/91cg3.jpg";
    }
    return Response.success(items, nextPageUrl(doc));
}
