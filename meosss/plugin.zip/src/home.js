function execute() {
    return Response.success([
        { title: "Mới cập nhật", input: "/moi-cap-nhat/", script: "list.js" },
        { title: "Truyện mới", input: "/truyen/", script: "list.js" },
        { title: "Đã hoàn thành", input: "/truyen-da-hoan-thanh/", script: "list.js" }
    ]);
}
