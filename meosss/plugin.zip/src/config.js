let BASE_URL = "https://meosss.com";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

// One listing page of manga cards. Covers the archive pages (/moi-cap-nhat/,
// /truyen/, /truyen-da-hoan-thanh/, /the-loai/<slug>/) — all share this markup.
function parseListItems(doc) {
    let items = [];
    doc.select("div.manga-item-grid").forEach(function (el) {
        let link = el.select("h2 a").attr("href");
        if (!link) link = el.select("a").attr("href");
        let name = el.select("h2 a").text().trim();
        if (!name) name = el.select("img").attr("alt").replace(/^Ảnh bìa của\s*/, "");
        if (!name || !link) return;

        // The card lists the newest chapters; the first one doubles as the
        // "last chapter" hint. Its own span drops the trailing "Mới" badge.
        let lastChap = el.select("p a span.uk-text-truncate").first().text().trim();
        let age = el.select(".badge-age").first().text().trim();

        items.push({
            name: name,
            cover: el.select("img").attr("src"),
            link: link,
            description: lastChap,
            tag: age
        });
    });
    return items;
}

// Highest page number in the archive pagination, 0 when the list is single-page.
function lastPage(doc) {
    let max = 0;
    doc.select(".uk-pagination a[href*=page]").forEach(function (el) {
        let m = el.attr("href").match(/\/page\/(\d+)\//);
        if (!m) return;
        let n = parseInt(m[1], 10);
        if (n > max) max = n;
    });
    return max;
}

// Browse url for a listing tab: `query` is a path ("/moi-cap-nhat/") or a full
// URL passed from home/genre entries; empty falls back to the latest tab.
function listUrl(query, page) {
    let base = "";
    if (query && query.indexOf("http") === 0) {
        base = query;
    } else if (query && query.charAt(0) === "/") {
        base = BASE_URL + query;
    } else {
        base = BASE_URL + "/moi-cap-nhat/";
    }
    base = normalizeUrl(base).replace(/\/+$/, "");
    let n = parseInt(page, 10) || 1;
    return n > 1 ? base + "/page/" + n + "/" : base + "/";
}

// Text safe for the app: decode the HTML entities WordPress escapes into
// REST titles/excerpts (&#8220;, &amp;, …) through jsoup.
function decodeText(html) {
    return Html.parse("<span>" + html + "</span>").select("span").text();
}

// Manga post id from a detail page — comments are fetched per post id.
function postIdFromPage(url) {
    let response = fetch(normalizeUrl(url.indexOf("http") === 0 ? url : BASE_URL + url));
    if (!response.ok) return "";
    return response.html().select("#manga-title").attr("data-id");
}

// "2026-06-28T07:39:54" (site-local time) -> "28/06/2026 lúc 07:39", the format
// the site itself prints next to a comment.
function formatCommentDate(value) {
    let m = String(value).match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
    if (m == null) return "";
    return m[3] + "/" + m[2] + "/" + m[1] + " lúc " + m[4] + ":" + m[5];
}

// One /wp-json/wp/v2/comments row as an app comment item. The site has no
// threaded replies, so `replies` stays empty.
function commentItem(c) {
    let avatar = "";
    let sizes = c.author_avatar_urls;
    if (sizes) avatar = sizes["96"] || sizes["128"] || sizes["48"] || sizes["24"] || "";
    return {
        name: c.author_name || "",
        avatar: avatar,
        content: c.content && c.content.rendered ? c.content.rendered : "",
        description: formatCommentDate(c.date || c.date_gmt || ""),
        replies: []
    };
}

// Map one /wp-json/wp/v2/manga row (requested with _embed=1) to a list item.
function restItem(row) {
    let name = row.title && row.title.rendered ? decodeText(row.title.rendered).trim() : "";
    if (!name) return null;

    let cover = "";
    let media = row._embedded && row._embedded["wp:featuredmedia"];
    if (media && media.length > 0) {
        cover = media[0].source_url || "";
    }

    let tag = "";
    let terms = row._embedded && row._embedded["wp:term"];
    if (terms && terms.length > 0 && terms[0].length > 0) {
        tag = terms[0][0].name || "";
    }

    return { name: name, cover: cover, link: row.link, tag: tag };
}
