load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let genres = [];
    doc.select("#genre-tags a").forEach(function (el) {
        let title = el.text().trim();
        if (title) genres.push({ title: title, input: el.attr("href"), script: "list.js" });
    });

    // "Đang tiến hành" (ongoing) / "Trọn bộ" (completed).
    let status = doc.select("#manga-status").text().trim();
    let ongoing = !/hoàn thành|trọn bộ|end/i.test(status);

    let cover = doc.select("#view-comic .story-cover img").attr("src");
    if (!cover) cover = doc.select(".story-cover img").attr("src");

    let comments = [];
    let id = doc.select("#manga-title").attr("data-id");
    if (id) comments.push({ title: "Bình luận", input: id, script: "comments.js" });

    return Response.success({
        name: doc.select("#manga-title").text().trim(),
        author: doc.select(".manga-info-details a[href*='/tac-gia/']").text().trim(),
        cover: cover,
        description: doc.select("#manga-description").html(),
        detail: doc.select(".manga-info-details").html(),
        url: url,
        type: "comic",
        format: "comic",
        ongoing: ongoing,
        nsfw: true,
        locale: "vi",
        genres: genres,
        comments: comments
    });
}
