load('config.js');

function execute() {
    let response = fetch(BASE_URL + "/the-loai/");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let genres = [];
    doc.select("div.grid-cards a").forEach(function (el) {
        let title = el.select("h2").text().trim();
        let href = el.attr("href");
        if (title && href) {
            genres.push({ title: title, input: href, script: "list.js" });
        }
    });
    return Response.success(genres);
}
