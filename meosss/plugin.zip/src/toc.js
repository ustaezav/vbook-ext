load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let chapters = [];
    doc.select("div.chapter-list div.chapter-item").forEach(function (el) {
        let a = el.select("a").first();
        let href = a.attr("href");
        if (!href) return;
        chapters.push({
            name: el.select("h3").text().trim() || a.text().trim(),
            url: href,
            description: el.select("time").text().trim(),
            lock: false,
            pay: false
        });
    });

    // The site prints chapters newest first; the chapter list should read from
    // the first chapter onward.
    chapters.reverse();
    return Response.success(chapters);
}
