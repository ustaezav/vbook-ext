load('config.js');

// Comments — referenced from detail.js `comments`. input is the manga post id
// (a detail url is also accepted); page = page number.
//
// The theme prints at most 50 comments into the detail page and has no paging,
// so comments come from the WordPress comment collection, which reports the
// real total and pages through every one of them.
function execute(input, page) {
    let post = String(input || "");
    if (post.indexOf("http") === 0 || post.charAt(0) === "/") {
        post = postIdFromPage(post);
    }
    post = post.replace(/[^\d]/g, "");
    if (!post) return Response.error("Thiếu mã truyện");

    let n = parseInt(page, 10) || 1;
    let url = BASE_URL + "/wp-json/wp/v2/comments?post=" + post
        + "&per_page=20&page=" + n + "&orderby=date&order=desc";

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let rows = response.json();
    if (!rows || rows.length == null) return Response.success([], "");

    let items = [];
    for (let i = 0; i < rows.length; i++) items.push(commentItem(rows[i]));

    let totalPages = parseInt(response.header("x-wp-totalpages"), 10) || 0;
    return Response.success(items, n < totalPages ? String(n + 1) : "");
}
