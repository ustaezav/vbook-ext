load('config.js');

// The chapter list is split over /truyen/<slug>/chap/page/N/ pages once a title
// has more than one page of chapters; below that the book url itself is the
// only TOC page. Pages are walked from the last (oldest chapters) back to the
// first, because the site lists chapters newest first: toc reverses each page,
// so this order lets the app concatenate them into reading order.
function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let max = lastPage(doc);
    if (max <= 1) return Response.success([url]);

    let base = url.replace(/\/+$/, "");
    let pages = [];
    for (let i = max; i >= 1; i--) {
        pages.push(base + "/chap/page/" + i + "/");
    }
    return Response.success(pages);
}
