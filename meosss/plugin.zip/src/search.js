load('config.js');

// The site search page has no pagination, so search uses the manga REST
// collection, which pages through every match and carries the cover along.
function execute(query, page) {
    query = (query || "").replace(/^\s+|\s+$/g, "");
    if (!query) return Response.success([], "");

    let n = parseInt(page, 10) || 1;
    let url = BASE_URL + "/wp-json/wp/v2/manga?search=" + encodeURIComponent(query)
        + "&per_page=20&page=" + n + "&_embed=1";

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);

    let rows = response.json();
    if (!rows || rows.length == null) return Response.success([], "");

    let items = [];
    for (let i = 0; i < rows.length; i++) {
        let item = restItem(rows[i]);
        if (item) items.push(item);
    }

    let totalPages = parseInt(response.header("x-wp-totalpages"), 10) || 0;
    return Response.success(items, n < totalPages ? String(n + 1) : "");
}
