load('config.js');

function execute(query, page) {
    let n = parseInt(page, 10) || 1;
    let response = fetch(listUrl(query, n));
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = parseListItems(doc);
    let max = lastPage(doc);
    return Response.success(items, n < max ? String(n + 1) : "");
}
