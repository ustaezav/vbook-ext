load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    // Lazy images carry the real file in data-original-src; the first image of a
    // chapter still has a plain src (and lazy placeholders are inline data URIs).
    let images = [];
    doc.select("#chapter-content img").forEach(function (el) {
        let src = el.attr("data-original-src") || el.attr("src");
        if (src && src.indexOf("data:") !== 0) images.push(src);
    });

    if (images.length === 0) return Response.error("Không tìm thấy ảnh chương");
    return Response.success(images);
}
