load('config.js');

function asciiSlug(text) {
    let str = String(text || "").toLowerCase();
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
    str = str.replace(/ì|í|ị|ỉ|ĩ/g, "i");
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
    str = str.replace(/đ/g, "d");
    return str.replace(/\s+/g, "-");
}

function parseItems(doc) {
    let items = [];
    doc.select("#video-list .video-item").forEach(function (el) {
        let link = el.select(".video-name a").attr("href");
        let name = el.select(".video-name a").text().trim() || el.select("a").first().attr("title");
        if (!name || !link) return;

        let cover = el.select("img.video-image").attr("data-original");
        if (!cover || cover.indexOf("data:") === 0) {
            cover = el.select("img.video-image").attr("src");
        }
        if (cover && cover.indexOf("data:") === 0) cover = "";

        items.push({
            name: name,
            cover: absoluteUrl(cover),
            link: absoluteUrl(link),
            tag: el.select(".ribbon").text().trim()
        });
    });
    return items;
}

function nextPageUrl(doc) {
    let next = "";
    doc.select(".pagenavi a").forEach(function (el) {
        if (next) return;
        if (String(el.attr("title")).toLowerCase() === "next page") {
            next = absoluteUrl(el.attr("href"));
        }
    });
    return next;
}

function execute(query, page) {
    query = String(query || "").trim();
    page = String(page || "").trim();

    let url;
    if (page && page.indexOf("http") === 0) {
        url = page;
    } else if (query.indexOf("http") === 0) {
        url = query;
    } else if (query.indexOf("/") === 0) {
        url = BASE_URL + query;
    } else if (query) {
        url = BASE_URL + "/search/" + encodeURIComponent(asciiSlug(query)) + "/";
    } else {
        url = BASE_URL + "/";
    }

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    return Response.success(parseItems(doc), nextPageUrl(doc));
}
