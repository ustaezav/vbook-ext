function execute() {
    return Response.success([
        { title: "Mới nhất", input: "/", script: "search.js" },
        { title: "JAV", input: "/jav/", script: "search.js" },
        { title: "Vietsub", input: "/vietsub/", script: "search.js" },
        { title: "Không che", input: "/khong-che/", script: "search.js" },
        { title: "Phim sex hay", input: "/phim-sex-hay/", script: "search.js" }
    ]);
}
