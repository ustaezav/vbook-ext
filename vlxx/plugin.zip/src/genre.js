load('config.js');

function execute() {
    let response = fetch(BASE_URL + "/");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let genres = [];
    doc.select("#primary-nav .menu a").forEach(function (el) {
        let href = el.attr("href");
        let title = el.text().trim();
        if (!href || !title) return;
        let input = absoluteUrl(href);
        if (input === BASE_URL + "/" || input === BASE_URL) return;
        genres.push({
            title: title,
            input: input,
            script: "search.js"
        });
    });

    return Response.success(genres);
}
