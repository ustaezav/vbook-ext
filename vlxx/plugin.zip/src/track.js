load('config.js');

function nativeTrack(stream, referer, base) {
    return {
        type: "native",
        data: stream,
        host: base || BASE_URL,
        mimeType: /\.mp4(\?|#|$)/i.test(stream) ? "video/mp4" : "application/x-mpegURL",
        headers: {
            "User-Agent": UserAgent.chrome(),
            "Referer": referer
        },
        timeSkip: []
    };
}

// The embed page keeps its sources in an inline `window.__SRC` JSON array, so
// the stream URL can only be read from the script text, not the DOM.
function streamFromEmbed(embed) {
    let response = fetch(embed, {
        timeout: 30000,
        headers: {
            "User-Agent": UserAgent.chrome(),
            "Referer": BASE_URL + "/"
        }
    });
    if (!response.ok) return "";

    let match = response.text().match(/window\.__SRC\s*=\s*(\[[\s\S]*?\]);/);
    if (!match) return "";

    let sources;
    try {
        sources = JSON.parse(match[1]);
    } catch (error) {
        return "";
    }

    for (let i = 0; i < sources.length; i++) {
        let file = sources[i] && sources[i].file ? String(sources[i].file) : "";
        if (file) return file;
    }
    return "";
}

function playerUrl(base, id, server, page) {
    let response = fetch(base + "/ajax.php", {
        method: "POST",
        timeout: 30000,
        headers: {
            "User-Agent": UserAgent.chrome(),
            "Referer": page || base + "/",
            "X-Requested-With": "XMLHttpRequest",
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "vlxx_server=1&id=" + encodeURIComponent(id) + "&server=" + encodeURIComponent(server)
    });
    if (!response.ok) return "";

    let data;
    try {
        data = response.json();
    } catch (error) {
        return "";
    }

    let player = String(data.player || "");
    if (!player) return "";

    let iframe = Html.parse(player).select("iframe").attr("src");
    if (iframe) return iframe;

    let match = player.match(/src=["']([^"']+)["']/i);
    return match ? match[1] : "";
}

function execute(data) {
    data = String(data || "").trim();
    if (!data) return Response.error("Không có nguồn phát");

    if (/\.(m3u8|mp4)(\?|#|$)/i.test(data)) {
        return Response.success(nativeTrack(data, BASE_URL + "/"));
    }

    let payload = null;
    if (data.charAt(0) === "{") {
        try {
            payload = JSON.parse(data);
        } catch (error) {
            payload = null;
        }
    }

    let page = payload && payload.page ? payload.page : BASE_URL + "/";
    let base = payload && payload.base ? String(payload.base).replace(/\/+$/, "") : BASE_URL;
    let embed = data;

    if (payload) {
        if (!payload.id) return Response.error("Nguồn phát không hợp lệ");
        embed = playerUrl(base, payload.id, payload.server, page);
        if (!embed && base !== BASE_URL) {
            base = BASE_URL;
            page = String(page).replace(/^https?:\/\/[^\/]+/i, base);
            embed = playerUrl(base, payload.id, payload.server, page);
        }
        if (!embed) return Response.error("Không tìm thấy link phát");
    }

    let stream = streamFromEmbed(embed);
    if (stream) return Response.success(nativeTrack(stream, embed, base));

    return Response.success({
        type: "auto",
        data: embed,
        host: base,
        headers: {
            "User-Agent": UserAgent.chrome(),
            "Referer": page
        },
        timeSkip: []
    });
}
