load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let name = doc.select("h1.page-title").text().trim();
    if (!name) {
        name = doc.select("meta[property=og:title]").attr("content").replace(/\s*-\s*VLXX.*$/i, "");
    }

    let cover = doc.select("meta[property=og:image]").attr("content");

    let info = [];
    let code = doc.select(".video-info .video-code").text().trim();
    if (code) info.push("Mã phim: " + code);

    let views = doc.select(".video-stats .views span").text().trim();
    if (views) info.push("Lượt xem: " + views);

    let likes = doc.select(".video-stats .likes span").text().trim();
    let dislikes = doc.select(".video-stats .dislikes span").text().trim();
    if (likes) info.push("Thích: " + likes + (dislikes ? " - Không thích: " + dislikes : ""));

    let rating = doc.select(".video-stats .rating span").text().trim();
    if (rating) info.push("Đánh giá: " + rating);

    let genres = [];
    doc.select(".video-tags .category-tag a").forEach(function (el) {
        let title = el.text().trim();
        let link = el.attr("href");
        if (!title || !link) return;
        genres.push({
            title: title,
            input: absoluteUrl(link),
            script: "search.js"
        });
    });

    let tags = [];
    doc.select(".video-tags .actress-tag a").forEach(function (el) {
        let title = el.text().trim();
        let link = el.attr("href");
        if (!title || !link) return;
        tags.push({
            title: title,
            input: absoluteUrl(link),
            script: "search.js"
        });
    });

    let suggests = [];
    if (!doc.select("#video-list .video-item").isEmpty()) {
        suggests.push({
            title: "Phim liên quan",
            input: url,
            script: "similar.js"
        });
    }

    return Response.success({
        name: name,
        cover: cover,
        description: doc.select(".video-description").text().trim(),
        detail: info.join("\n"),
        url: url,
        type: "video",
        format: "series",
        ongoing: true,
        nsfw: true,
        locale: "vi",
        tags: tags,
        genres: genres,
        suggests: suggests
    });
}
