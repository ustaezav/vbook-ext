load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let name = doc.select("h1.page-title").text().trim() || "Full";

    return Response.success([
        {
            name: name,
            url: url,
            description: "",
            lock: false,
            pay: false
        }
    ]);
}
