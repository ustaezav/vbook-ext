load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let id = doc.select("#video").attr("data-id");
    if (!id) id = (url.match(/\/(\d+)\/?$/) || [])[1] || "";
    if (!id) return Response.error("Không tìm thấy video");

    // Mirror hosts can serve pages while their /ajax.php stays dead, so the
    // canonical host from og:url is what /ajax.php must be called on.
    let canonical = String(doc.select("meta[property=og:url]").attr("content"));
    let base = (canonical.match(/^https?:\/\/[^\/]+/i) || [])[0] || BASE_URL;
    let page = base === BASE_URL ? url : url.replace(/^https?:\/\/[^\/]+/i, base);

    let tracks = [];
    doc.select("#video-actions .video-server").forEach(function (el) {
        let server = String(el.attr("id") || "").replace(/[^0-9]/g, "");
        if (!server) server = String(tracks.length + 1);
        tracks.push({
            title: "Server #" + server,
            data: JSON.stringify({ id: id, server: server, page: page, base: base })
        });
    });

    if (tracks.length === 0) {
        tracks.push({
            title: "Server #1",
            data: JSON.stringify({ id: id, server: "1", page: page, base: base })
        });
    }

    return Response.success(tracks);
}
