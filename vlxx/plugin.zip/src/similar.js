load('config.js');

function execute(url) {
    let response = fetch(normalizeUrl(url));
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = [];
    let seen = {};
    doc.select("#video-list .video-item").forEach(function (el) {
        let link = el.select(".video-name a").attr("href");
        let name = el.select(".video-name a").text().trim() || el.select("a").first().attr("title");
        if (!name || !link || seen[link]) return;
        seen[link] = true;

        let cover = el.select("img.video-image").attr("data-original");
        if (!cover || cover.indexOf("data:") === 0) cover = el.select("img.video-image").attr("src");
        if (cover && cover.indexOf("data:") === 0) cover = "";

        items.push({
            name: name,
            cover: absoluteUrl(cover),
            link: absoluteUrl(link),
            tag: el.select(".ribbon").text().trim()
        });
    });

    return Response.success(items, "");
}
