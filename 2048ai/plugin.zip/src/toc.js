load('config.js');

function withStream(pageUrl, stream) {
    if (!stream) return pageUrl;
    return pageUrl + "?stream=" + encodeURIComponent(stream);
}

function dramaToc(id) {
    let result = fetchJson(apiUrl("/short-dramas/" + id + "?productId=" + PRODUCT_ID));
    if (result.error) return Response.error(result.error);

    let data = result.data || {};
    let episodes = data.episodes || [];
    if (episodes.length === 0) return Response.error("Không có tập phát");

    episodes.sort(function (a, b) {
        return parseInt(a.episodeNo, 10) - parseInt(b.episodeNo, 10);
    });

    let chapters = [];
    for (let i = 0; i < episodes.length; i++) {
        let episode = episodes[i];
        let number = parseInt(episode.episodeNo, 10);
        if (isNaN(number) || number <= 0) continue;
        let pageUrl = dramaUrl(id, number);
        chapters.push({
            name: episode.titleOverride || episode.title || ("Tập " + number),
            url: withStream(pageUrl, streamUrl(episode.videoUrl)),
            description: formatDuration(episode.durationSec),
            lock: false,
            pay: false
        });
    }

    if (chapters.length === 0) return Response.error("Không có tập phát");
    return Response.success(chapters);
}

function videoToc(id) {
    let result = fetchJson(apiUrl("/videos/" + id));
    if (result.error) return Response.error(result.error);

    let data = result.data || {};
    let stream = streamUrl(data.videoUrl);
    if (!stream) return Response.error("Không tìm thấy nguồn phát");

    return Response.success([
        {
            name: data.title || ("Video " + id),
            url: withStream(videoUrl(id), stream),
            description: formatDuration(data.durationSec),
            lock: false,
            pay: false
        }
    ]);
}

function execute(url) {
    url = normalizeUrl(url);
    let dramaId = shortDramaId(url);
    if (dramaId) return dramaToc(dramaId);
    let id = videoId(url);
    if (id) return videoToc(id);
    return Response.error("Liên kết không hợp lệ");
}
