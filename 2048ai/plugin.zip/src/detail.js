load('config.js');

function esc(value) {
    return String(value === null || value === undefined ? "" : value)
        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function line(label, value) {
    if (value === null || value === undefined || String(value) === "") return "";
    return "<b>" + esc(label) + ":</b> " + esc(value);
}

function detailText(lines) {
    let output = [];
    for (let i = 0; i < lines.length; i++) {
        if (lines[i]) output.push(lines[i]);
    }
    return output.join("<br>");
}

function dramaDetail(id) {
    let result = fetchJson(apiUrl("/short-dramas/" + id + "?productId=" + PRODUCT_ID));
    if (result.error) return Response.error(result.error);

    let data = result.data || {};
    let episodes = data.episodes || [];
    let completed = data.episodeCount > 0 && episodes.length >= data.episodeCount;

    let lines = [];
    lines.push(line("Đánh giá", data.rating ? String(data.rating) + "/10" : ""));
    lines.push(line("Số tập", data.episodeCount ? data.episodeCount + " tập" : ""));
    lines.push(line("Lượt xem", formatNumber(data.heatCount)));
    lines.push(line("Phát hành", formatDate(data.publishedAt)));

    return Response.success({
        name: data.title || ("Short drama " + id),
        author: "2048AI",
        cover: absoluteUrl(data.coverUrl),
        description: data.description || "",
        detail: detailText(lines),
        url: dramaUrl(id, (episodes[0] && episodes[0].episodeNo) || 1),
        type: "video",
        format: "series",
        ongoing: !completed,
        nsfw: true,
        locale: "zh-CN",
        suggests: [
            { title: "Short drama liên quan", input: String(id), script: "similar.js" }
        ]
    });
}

function videoDetail(id) {
    let result = fetchJson(apiUrl("/videos/" + id));
    if (result.error) return Response.error(result.error);

    let data = result.data || {};
    let lines = [];
    lines.push(line("Chuyên mục", data.categoryName));
    lines.push(line("Thời lượng", formatDuration(data.durationSec)));
    lines.push(line("Lượt xem", formatNumber(data.viewCount)));
    lines.push(line("Yêu thích", formatNumber(data.likeCount)));
    lines.push(line("Đăng", formatDate(data.publishedAt)));

    let tags = [];
    if (data.categoryId && data.categoryName) {
        tags.push({
            title: data.categoryName,
            input: "cat:" + data.categoryId,
            script: "search.js"
        });
    }

    return Response.success({
        name: data.title || ("Video " + id),
        author: data.authorName || "2048AI",
        cover: absoluteUrl(data.coverUrl),
        description: data.description || "",
        detail: detailText(lines),
        url: videoUrl(id),
        type: "video",
        format: "series",
        ongoing: false,
        nsfw: true,
        locale: "zh-CN",
        tags: tags
    });
}

function execute(url) {
    url = normalizeUrl(url);
    let dramaId = shortDramaId(url);
    if (dramaId) return dramaDetail(dramaId);
    let id = videoId(url);
    if (id) return videoDetail(id);
    return Response.error("Liên kết không hợp lệ");
}
