// The media CDN XORs the first 100 bytes of every cover with a fixed key and
// the web bundle undoes it before drawing. The app loads those covers through
// this file when the URL carries "#script=cover.js"; it must return the image
// bytes as a bare base64 string (no Response, no data: prefix).
load('crypto.js');

let COVER_KEY = "2020-zq3-888";
let SCRAMBLED_BYTES = 100;

// JPEG / PNG / WebP / GIF magic once base64-encoded.
function isImageBase64(base64) {
    return base64.indexOf("/9j/") === 0 ||
        base64.indexOf("iVBORw0KGgo") === 0 ||
        base64.indexOf("UklGR") === 0 ||
        base64.indexOf("R0lGOD") === 0;
}

function unscramble(base64) {
    let bytes = CryptoJS.enc.Base64.parse(base64);
    let words = bytes.words;
    let length = bytes.sigBytes;

    for (let i = 0; i < SCRAMBLED_BYTES && i < length; i++) {
        let key = COVER_KEY.charCodeAt(i % COVER_KEY.length);
        words[i >>> 2] ^= key << (24 - (i % 4) * 8);
    }

    return CryptoJS.enc.Base64.stringify(bytes);
}

function execute(url) {
    let response = fetch(url, { timeout: 30000 });
    if (!response.ok) return "";

    let base64 = response.base64();
    // Some CDN paths already hold a plain image; pass it through untouched.
    if (isImageBase64(base64)) return base64;

    let image = unscramble(base64);
    return isImageBase64(image) ? image : "";
}
