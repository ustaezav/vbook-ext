let BASE_URL = "https://2048ai.vip";
try {
    if (DOMAIN) BASE_URL = String(DOMAIN).replace(/\/+$/, "");
} catch (error) {
}

let PRODUCT_ID = "1";

function normalizeUrl(url) {
    let value = String(url || "");
    if (!value) return BASE_URL;
    if (/^https?:\/\//i.test(value)) {
        let host = value.match(/^https?:\/\/[^\/]+/i);
        if (host) return BASE_URL + value.substring(host[0].length);
        return value;
    }
    if (value.charAt(0) === "/") return BASE_URL + value;
    return BASE_URL + "/" + value;
}

function apiUrl(path) {
    return BASE_URL + "/api/v1" + path;
}

function absoluteUrl(path) {
    let value = String(path || "");
    if (!value) return "";
    if (/^https?:\/\//i.test(value)) return value;
    return BASE_URL + (value.charAt(0) === "/" ? "" : "/") + value;
}

function shortDramaId(url) {
    let match = String(url || "").match(/\/short-dramas\/(\d+)/);
    return match ? match[1] : "";
}

function episodeNo(url) {
    let match = String(url || "").match(/\/episodes\/(\d+)/);
    return match ? match[1] : "";
}

function videoId(url) {
    let match = String(url || "").match(/\/videos\/(\d+)/);
    return match ? match[1] : "";
}

function dramaUrl(id, number) {
    return BASE_URL + "/short-dramas/" + id + "/episodes/" + (number || 1);
}

function videoUrl(id) {
    return BASE_URL + "/videos/" + id;
}

// The site plays storage paths through its own proxy, which resolves the platform
// and returns an absolute HLS playlist.
function streamUrl(path) {
    let value = String(path || "");
    if (!value) return "";
    if (/^https?:\/\//i.test(value)) {
        let host = value.match(/^https?:\/\/[^\/]+/i);
        if (host) value = value.substring(host[0].length);
    }
    value = value.replace(/^\/+/, "");
    if (value.indexOf(".m3u8") !== -1) {
        return apiUrl("/m3u8/proxy?path=" + encodeURIComponent(value));
    }
    return absoluteUrl(path);
}

function streamParam(url) {
    let match = String(url || "").match(/[?&]stream=([^&]+)/);
    if (!match) return "";
    try {
        return decodeURIComponent(match[1]);
    } catch (error) {
        return match[1];
    }
}

function pageHeaders() {
    return {
        "User-Agent": UserAgent.chrome(),
        "Referer": BASE_URL + "/"
    };
}

function fetchJson(url) {
    let response = fetch(url, { headers: pageHeaders(), timeout: 30000 });
    if (!response.ok) return { error: "HTTP " + response.status };
    let json;
    try {
        json = response.json();
    } catch (error) {
        return { error: "Phản hồi không hợp lệ" };
    }
    if (!json || parseInt(json.code, 10) !== 200) {
        return { error: json && json.message ? String(json.message) : "Yêu cầu thất bại" };
    }
    return { data: json.data };
}

function formatNumber(value) {
    let number = parseInt(value, 10);
    if (isNaN(number) || number <= 0) return "";
    return String(number).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function formatDuration(seconds) {
    let total = parseInt(seconds, 10);
    if (isNaN(total) || total <= 0) return "";
    let hours = Math.floor(total / 3600);
    let minutes = Math.floor((total % 3600) / 60);
    let rest = total % 60;
    function pad(value) {
        return value < 10 ? "0" + value : String(value);
    }
    if (hours > 0) return hours + ":" + pad(minutes) + ":" + pad(rest);
    return pad(minutes) + ":" + pad(rest);
}

function formatDate(value) {
    let text = String(value || "");
    return text.length >= 10 ? text.substring(0, 10) : text;
}

function toDramaItem(raw) {
    if (!raw || !raw.id) return null;
    let tag = raw.rating ? String(raw.rating) + " điểm" : "";
    if (raw.episodeCount) tag += (tag ? " · " : "") + raw.episodeCount + " tập";
    let description = raw.heatCount ? formatNumber(raw.heatCount) + " lượt xem" : "";
    return {
        name: raw.title || ("Short drama " + raw.id),
        cover: absoluteUrl(raw.coverUrl),
        link: dramaUrl(raw.id, raw.firstEpisodeNo || 1),
        description: description,
        tag: tag,
        host: BASE_URL
    };
}

function toVideoItem(raw) {
    if (!raw || !raw.id) return null;
    let description = formatDuration(raw.durationSec);
    if (raw.authorName) description += (description ? " · " : "") + raw.authorName;
    return {
        name: raw.title || ("Video " + raw.id),
        cover: absoluteUrl(raw.coverUrl),
        link: videoUrl(raw.id),
        description: description,
        tag: raw.categoryName || "",
        host: BASE_URL
    };
}
