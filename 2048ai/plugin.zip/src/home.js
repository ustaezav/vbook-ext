load('config.js');

function execute() {
    return Response.success([
        { title: "Short drama hot", input: "drama:heat", script: "list.js" },
        { title: "Short drama mới", input: "drama:latest", script: "list.js" },
        { title: "Video AI mới", input: "video:latest", script: "list.js" },
        { title: "Video AI xem nhiều", input: "video:views", script: "list.js" }
    ]);
}
