load('config.js');

let CACHE_KEY = "short_dramas_v1";
let CACHE_TTL = 30 * 60 * 1000;

function readCache() {
    try {
        let raw = cacheStorage.getItem(CACHE_KEY);
        let at = parseInt(cacheStorage.getItem(CACHE_KEY + "_at") || "0", 10);
        if (!raw || !at) return null;
        if (new Date().getTime() - at > CACHE_TTL) return null;
        return JSON.parse(raw);
    } catch (error) {
        return null;
    }
}

function writeCache(items) {
    try {
        cacheStorage.setItem(CACHE_KEY, JSON.stringify(items));
        cacheStorage.setItem(CACHE_KEY + "_at", String(new Date().getTime()));
    } catch (error) {
    }
}

function fetchAllDramas() {
    let first = fetchJson(
        apiUrl("/short-dramas?productId=" + PRODUCT_ID + "&sortBy=latest&page=1&size=100")
    );
    if (first.error) return [];

    let data = first.data || {};
    let items = (data.items || []).slice();
    let totalPages = parseInt(data.totalPages, 10) || 1;

    for (let page = 2; page <= totalPages; page++) {
        let result = fetchJson(
            apiUrl("/short-dramas?productId=" + PRODUCT_ID + "&sortBy=latest&page=" +
                page + "&size=100")
        );
        if (!result.error && result.data && result.data.items) {
            items = items.concat(result.data.items);
        }
    }

    if (items.length > 0) writeCache(items);
    return items;
}

function allDramas() {
    return readCache() || fetchAllDramas();
}

function searchDramas(query) {
    let needle = String(query).toLowerCase();
    let source = allDramas();
    let items = [];
    for (let i = 0; i < source.length; i++) {
        let title = String(source[i].title || "").toLowerCase();
        if (title.indexOf(needle) === -1) continue;
        let item = toDramaItem(source[i]);
        if (item) items.push(item);
    }
    return items;
}

function execute(query, page) {
    query = String(query || "").trim();
    let current = parseInt(page, 10);
    if (isNaN(current) || current < 1) current = 1;

    let category = query.match(/^cat:(\d+)$/);
    let listUrl;
    if (category) {
        listUrl = apiUrl("/videos?categoryId=" + category[1] + "&page=" + current + "&size=20");
    } else if (!query) {
        listUrl = apiUrl("/videos?page=" + current + "&size=20");
    } else {
        listUrl = apiUrl("/videos/search?q=" + encodeURIComponent(query) +
            "&page=" + current + "&size=20");
    }

    let result = fetchJson(listUrl);
    if (result.error) return Response.error(result.error);

    let data = result.data || {};
    let raw = data.items || data.content || data.list || [];
    let items = [];

    if (current === 1 && query && !category) {
        items = items.concat(searchDramas(query));
    }

    for (let i = 0; i < raw.length; i++) {
        let item = toVideoItem(raw[i]);
        if (item) items.push(item);
    }

    let totalPages = parseInt(data.totalPages, 10) || 0;
    let next = totalPages > current ? String(current + 1) : "";
    return Response.success(items, items.length > 0 ? next : "");
}
