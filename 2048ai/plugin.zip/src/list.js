load('config.js');

function nextToken(data, current, count) {
    let totalPages = parseInt(data.totalPages, 10) || 0;
    if (count === 0 || totalPages <= current) return "";
    return String(current + 1);
}

function dramaList(sortBy, current) {
    if (sortBy !== "latest") sortBy = "heat";

    let result = fetchJson(
        apiUrl("/short-dramas?productId=" + PRODUCT_ID + "&sortBy=" + sortBy +
            "&page=" + current + "&size=24")
    );
    if (result.error) return Response.error(result.error);

    let data = result.data || {};
    let raw = data.items || [];
    let items = [];
    for (let i = 0; i < raw.length; i++) {
        let item = toDramaItem(raw[i]);
        if (item) items.push(item);
    }

    return Response.success(items, nextToken(data, current, items.length));
}

function videoList(option, current) {
    let params = ["page=" + current, "size=24"];

    if (/^\d+$/.test(option)) {
        params.push("categoryId=" + option);
    } else if (option === "views" || option === "hot") {
        params.push("sortBy=" + option);
    }

    let result = fetchJson(apiUrl("/videos?" + params.join("&")));
    if (result.error) return Response.error(result.error);

    let data = result.data || {};
    let raw = data.items || data.content || data.list || [];
    let items = [];
    for (let i = 0; i < raw.length; i++) {
        let item = toVideoItem(raw[i]);
        if (item) items.push(item);
    }

    return Response.success(items, nextToken(data, current, items.length));
}

function execute(query, page) {
    let input = String(query || "");
    let current = parseInt(page, 10);
    if (isNaN(current) || current < 1) current = 1;

    if (input.indexOf("drama:") === 0) {
        return dramaList(input.substring(6), current);
    }
    if (input.indexOf("video:") === 0) {
        return videoList(input.substring(6), current);
    }
    if (input.indexOf("cat:") === 0) {
        return videoList(input.substring(4), current);
    }

    return dramaList(input, current);
}
