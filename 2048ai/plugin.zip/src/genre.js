load('config.js');

function execute() {
    let result = fetchJson(apiUrl("/categories?type=video"));
    if (result.error) return Response.error(result.error);

    let categories = result.data || [];
    let genres = [];
    for (let i = 0; i < categories.length; i++) {
        let category = categories[i];
        if (!category || !category.id || category.enabled === false) continue;
        genres.push({
            title: category.name || ("Thể loại " + category.id),
            input: "video:" + category.id,
            script: "list.js"
        });
    }

    return Response.success(genres);
}
