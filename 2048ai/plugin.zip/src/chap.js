load('config.js');

function resolveFromDrama(id, number) {
    let result = fetchJson(apiUrl("/short-dramas/" + id + "?productId=" + PRODUCT_ID));
    if (result.error) return "";
    let episodes = (result.data && result.data.episodes) || [];
    for (let i = 0; i < episodes.length; i++) {
        if (String(episodes[i].episodeNo) === String(number)) {
            return streamUrl(episodes[i].videoUrl);
        }
    }
    return "";
}

function resolveFromVideo(id) {
    let result = fetchJson(apiUrl("/videos/" + id));
    if (result.error) return "";
    return streamUrl(result.data && result.data.videoUrl);
}

function execute(url) {
    let normalized = normalizeUrl(url);
    let stream = streamParam(normalized);

    if (!stream) {
        let dramaId = shortDramaId(normalized);
        if (dramaId) stream = resolveFromDrama(dramaId, episodeNo(normalized));
    }
    if (!stream) {
        let id = videoId(normalized);
        if (id) stream = resolveFromVideo(id);
    }
    if (!stream) return Response.error("Không tìm thấy nguồn phát");

    return Response.success([{ title: "Auto", data: stream }]);
}
