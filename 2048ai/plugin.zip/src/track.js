load('config.js');

function execute(data) {
    data = String(data || "");
    if (data.indexOf("http") !== 0) return Response.error("Nguồn phát không hợp lệ");

    let mimeType = "application/x-mpegURL";
    if (data.indexOf(".m3u8") === -1) mimeType = data.indexOf(".mp4") !== -1 ? "video/mp4" : "";

    return Response.success({
        type: "native",
        data: data,
        host: BASE_URL,
        mimeType: mimeType,
        headers: pageHeaders(),
        timeSkip: []
    });
}
