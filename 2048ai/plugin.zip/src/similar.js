load('config.js');

function execute(input) {
    let id = String(input || "").match(/\d+/);
    if (!id) return Response.success([], "");

    let result = fetchJson(
        apiUrl("/short-dramas/" + id[0] + "/related?productId=" + PRODUCT_ID + "&limit=12")
    );
    if (result.error) return Response.error(result.error);

    let raw = result.data || [];
    let items = [];
    for (let i = 0; i < raw.length; i++) {
        let item = toDramaItem(raw[i]);
        if (item) items.push(item);
    }
    return Response.success(items, "");
}
