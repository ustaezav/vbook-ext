load('api.js');

// Posts that contain media for the user picked in genre.js.
// `page` is the opaque cursor returned as data2 by the previous call.
function execute(query, page) {
    var handle = xNormalizeHandle(query);
    if (!handle) return Response.error("Chưa chọn user");

    var result = xUserMedia(handle, String(page || ""));
    if (result.error) {
        // An empty page can surface as 404; that only means the list ended.
        if (page) return Response.success([], "");
        return Response.error(result.error);
    }
    return Response.success(result.items, result.next);
}
