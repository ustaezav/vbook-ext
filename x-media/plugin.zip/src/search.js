load('api.js');

// Search takes a handle (or profile link) and lists that user's media posts.
function execute(query, page) {
    var handle = xNormalizeHandle(query);
    if (!handle) return Response.success([], "");

    var result = xUserMedia(handle, String(page || ""));
    if (result.error) {
        if (page) return Response.success([], "");
        return Response.error(result.error);
    }
    return Response.success(result.items, result.next);
}
