load('api.js');

// Comic chapters return images; video/GIF chapters return the mp4 ladder.
function execute(url) {
    var post = xPost(url);
    if (!post) return Response.error("URL bài đăng không hợp lệ");

    var status = xStatus(post.id);
    if (!status) return Response.error("Không tải được bài đăng");

    var mediaList = xMedia(status);
    var index = 0;
    var match = String(url).match(/[?&]m=(\d+)/);
    if (match) index = parseInt(match[1], 10);

    if (!mediaList.length || index < 0 || index >= mediaList.length) {
        return Response.error("Media không tồn tại");
    }

    var media = mediaList[index];
    if (media.type === "photo") {
        var image = { link: xPhoto(media.url, "orig") };
        if (media.width) image.width = media.width;
        if (media.height) image.height = media.height;
        return Response.success([image]);
    }

    var tracks = xTracks(media);
    if (!tracks.length) return Response.error("Không tìm thấy video");
    return Response.success(tracks);
}
