load('api.js');

// A post is a book. Photo-only posts open in the comic reader; posts with a
// video/GIF open in the player. `?m=<index>` on the chapter URL selects media.
function execute(url) {
    var post = xPost(url);
    if (!post) return Response.error("URL bài đăng không hợp lệ");

    var status = xStatus(post.id);
    if (!status) return Response.error("Không tải được bài đăng");

    var media = xMedia(status);
    if (!media.length) return Response.error("Bài đăng không có media");

    var hasVideo = false;
    for (var i = 0; i < media.length; i++) {
        if (media[i].type !== "photo") hasVideo = true;
    }

    var author = status.author || {};
    var handle = author.screen_name || post.handle || "i";
    var canonical = "https://x.com/" + handle + "/status/" + status.id;

    var info = [];
    if (author.name) info.push("Tác giả: " + author.name + " (@" + handle + ")");
    if (xDate(status)) info.push("Ngày đăng: " + xDate(status));
    info.push("Media: " + media.length);
    if (status.views !== undefined && status.views !== null) info.push("Lượt xem: " + status.views);
    info.push("Nguồn: " + canonical);

    var detail = {
        name: xTitle(status),
        author: author.name || ("@" + handle),
        cover: xCover(status),
        description: xText(status),
        detail: info.join("\n"),
        url: canonical,
        type: hasVideo ? "video" : "comic",
        format: hasVideo ? "short" : "comic",
        ongoing: true,
        nsfw: status.possibly_sensitive === true
    };
    if (status.lang) detail.locale = status.lang;

    return Response.success(detail);
}
