// FxTwitter API helpers shared by every script. Loaded with load('api.js').
// The /2 endpoints return a paged list for a profile's media-only timeline.

var X_API = "https://api.fxtwitter.com";
var X_PAGE_SIZE = 20;

function xTrim(value) {
    return String(value == null ? "" : value).replace(/^\s+|\s+$/g, "");
}

// One retry: the public API occasionally answers 404/500 for a request that
// succeeds immediately after.
function xJson(url) {
    var status = 0;
    for (var attempt = 0; attempt < 2; attempt++) {
        var response = fetch(url, { timeout: 30000 });
        status = response ? response.status : 0;
        if (response && response.ok) {
            try {
                var body = response.json();
                if (body) return { ok: true, data: body };
            } catch (error) {
            }
        }
    }
    return { ok: false, status: status };
}

function xStatus(id) {
    var result = xJson(X_API + "/2/status/" + id);
    if (!result.ok || !result.data || result.data.code !== 200) return null;
    return result.data.status || null;
}

function xNormalizeHandle(value) {
    var handle = xTrim(value);
    if (!handle) return "";
    handle = handle.replace(/[?#].*$/, "");

    var fromUrl = handle.match(/(?:x|twitter)\.com\/([^\/\s]+)/i);
    if (fromUrl) handle = fromUrl[1];
    handle = handle.replace(/^@/, "");

    if (/^id:\d+$/i.test(handle)) return handle.toLowerCase();
    if (!/^[A-Za-z0-9_]{1,15}$/.test(handle)) return "";

    var lower = handle.toLowerCase();
    if (lower === "i" || lower === "home" || lower === "explore") return "";
    return handle;
}

// USERS is a JSON array string ("[\"NASA\"]") from the list-mode setting.
// Accept plain lines/commas as a fallback so a malformed value still works.
function xUsers(raw) {
    var users = [];
    var text = xTrim(raw);
    if (!text) return users;

    var values = null;
    try {
        values = JSON.parse(text);
    } catch (error) {
        values = null;
    }
    if (!values || values.length === undefined) values = text.split(/[\n,]+/);

    var seen = {};
    for (var i = 0; i < values.length; i++) {
        var handle = xNormalizeHandle(values[i]);
        if (!handle) continue;
        var key = handle.toLowerCase();
        if (seen[key]) continue;
        seen[key] = true;
        users.push(handle);
    }
    return users;
}

function xPost(value) {
    var text = String(value || "");
    var match = text.match(/status\/(\d+)/);
    if (!match) return null;
    var handle = "";
    var byHandle = text.match(/(?:x|twitter)\.com\/([A-Za-z0-9_]+)\/status\//i);
    if (byHandle) handle = byHandle[1];
    return { id: match[1], handle: handle };
}

function xMedia(status) {
    var media = status && status.media;
    return media && media.all ? media.all : [];
}

// pbs.twimg.com photos are served at any requested size; "orig" is the source
// file, list covers use "small" to keep the feed light.
function xPhoto(url, size) {
    var text = String(url || "");
    if (text.indexOf("pbs.twimg.com/media/") === -1) return text;
    text = text.replace(/[?&]name=[^&]*/g, "");
    return text + (text.indexOf("?") === -1 ? "?" : "&") + "name=" + (size || "orig");
}

function xCover(status) {
    var media = xMedia(status);
    if (!media.length) return "";
    if (media[0].type === "photo") return xPhoto(media[0].url, "small");
    return media[0].thumbnail_url || "";
}

function xDuration(seconds) {
    var total = Math.round(Number(seconds) || 0);
    var minutes = Math.floor(total / 60);
    var rest = total % 60;
    return minutes + ":" + (rest < 10 ? "0" : "") + rest;
}

// "Wed Mar 18 20:03:38 +0000 2026" -> "18 Mar 2026"
function xDate(status) {
    var parts = xTrim(status && status.created_at).split(" ");
    if (parts.length >= 6) return parts[2] + " " + parts[1] + " " + parts[5];
    return "";
}

function xText(status) {
    var text = xTrim(status && status.text);
    return text.replace(/https:\/\/t\.co\/[A-Za-z0-9]+/g, "").replace(/\s+$/, "");
}

function xTitle(status) {
    var text = xText(status);
    if (text) {
        var line = text.split(/\r?\n/)[0];
        if (line.length > 90) line = line.substring(0, 87) + "...";
        return line;
    }
    var author = status && status.author ? status.author.screen_name : "";
    return author ? "@" + author + " media" : "Media";
}

function xMediaLabel(media) {
    if (!media) return "Media";
    if (media.type === "photo") return "Photo";
    if (media.type === "gif") return "GIF";
    return "Video";
}

function xItem(status) {
    var media = xMedia(status);
    if (!media.length) return null;

    var author = status.author ? status.author.screen_name : "";
    var first = media[0];
    var description = xDate(status);
    if (media.length > 1) {
        description += (description ? " · " : "") + media.length + " media";
    } else {
        description += (description ? " · " : "") + xMediaLabel(first);
        if (first.type !== "photo" && first.duration) description += " " + xDuration(first.duration);
    }

    var item = {
        name: xTitle(status),
        cover: xCover(status),
        link: "https://x.com/" + (author || "i") + "/status/" + status.id,
        description: description,
        tag: media.length > 1 ? "Media x" + media.length : xMediaLabel(first)
    };

    // The vertical short feed resolves toc -> chap -> track per item. Only
    // video/GIF posts can be queued there; photos keep the normal detail path.
    for (var i = 0; i < media.length; i++) {
        if (media[i].type !== "photo") {
            item.type = "short";
            break;
        }
    }
    return item;
}

// Video tracks, best bitrate first. FxTwitter already picks the top mp4 as
// media.url, but formats carries the full ladder for the quality switcher.
function xTrackTitle(media, format) {
    var label = xMediaLabel(media);
    var parts = [];
    var resolution = String(format.url || "").match(/\/vid\/[^\/]+\/(\d+x\d+)\//);
    if (resolution) parts.push(resolution[1]);
    if (format.bitrate) parts.push(Math.round(Number(format.bitrate) / 1000) + " kbps");
    return parts.length ? label + " · " + parts.join(" · ") : label;
}

function xTracks(media) {
    var formats = media.formats || [];
    var seen = {};
    var tracks = [];

    for (var i = 0; i < formats.length; i++) {
        var format = formats[i];
        if (!format || !format.url || format.container !== "mp4") continue;
        if (seen[format.url]) continue;
        seen[format.url] = true;
        tracks.push({
            title: xTrackTitle(media, format),
            data: format.url,
            bitrate: Number(format.bitrate) || 0
        });
    }
    if (!tracks.length && media.url) {
        tracks.push({ title: xTrackTitle(media, { url: media.url }), data: media.url, bitrate: 0 });
    }

    tracks.sort(function (a, b) { return b.bitrate - a.bitrate; });

    var result = [];
    for (var j = 0; j < tracks.length; j++) {
        result.push({ title: tracks[j].title, data: tracks[j].data });
    }
    return result;
}

function xUserMedia(handle, page) {
    var url = X_API + "/2/profile/" + encodeURIComponent(handle) + "/media?count=" + X_PAGE_SIZE;
    if (page) url += "&cursor=" + encodeURIComponent(page);

    var result = xJson(url);
    if (!result.ok) return { error: "HTTP " + result.status };

    var data = result.data;
    if (!data || data.code !== 200) return { error: "API " + (data && data.code ? data.code : 0) };

    var items = [];
    var results = data.results || [];
    for (var i = 0; i < results.length; i++) {
        var item = xItem(results[i]);
        if (item) items.push(item);
    }

    return {
        items: items,
        next: items.length && data.cursor && data.cursor.bottom ? String(data.cursor.bottom) : ""
    };
}
