load('api.js');

// One chapter per media attachment. The query string is what chap.js reads.
function execute(url) {
    var post = xPost(url);
    if (!post) return Response.error("URL bài đăng không hợp lệ");

    var status = xStatus(post.id);
    if (!status) return Response.error("Không tải được bài đăng");

    var media = xMedia(status);
    if (!media.length) return Response.error("Bài đăng không có media");

    var author = status.author || {};
    var base = "https://x.com/" + (author.screen_name || post.handle || "i") + "/status/" + status.id;
    var chapters = [];

    for (var i = 0; i < media.length; i++) {
        var item = media[i];
        var name = xMediaLabel(item);
        if (item.type === "photo") {
            name += " " + (i + 1) + (media.length > 1 ? "/" + media.length : "");
        } else if (item.duration) {
            name += " · " + xDuration(item.duration);
        }

        chapters.push({
            name: name,
            url: base + "?m=" + i,
            description: item.type === "photo" || !item.width ? "" : item.width + "x" + item.height
        });
    }

    return Response.success(chapters);
}
