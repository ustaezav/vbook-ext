load('api.js');

// One genre per configured user. Tapping it opens that user's media timeline.
function execute() {
    var users = xUsers(USERS);
    var genres = [];

    for (var i = 0; i < users.length; i++) {
        genres.push({
            title: "@" + users[i],
            input: users[i],
            script: "genre_items.js"
        });
    }

    if (!genres.length) return Response.error("Thêm user trong Cài đặt → Users");
    return Response.success(genres);
}
