// video.twimg.com serves plain mp4; the native resolver can play it directly.
function execute(data) {
    var url = String(data || "");
    if (!url) return Response.error("Thiếu URL stream");

    var hls = url.indexOf(".m3u8") !== -1;
    return Response.success({
        type: "native",
        data: url,
        mimeType: hls ? "application/x-mpegURL" : "video/mp4",
        headers: { "Referer": "https://x.com/" }
    });
}
