load('config.js');
load('thumb.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let name = cleanText(doc.select(".novel_title_box h1").text());
    if (!name) return Response.error("Không tìm thấy truyện");

    let author = cleanText(doc.select(".novel_title_box .info_box span.hl").text());

    let intro = doc.select(".novel_intro_box.pc p").first();
    let description = intro === null ? "" : intro.text().trim();

    let info = [];
    let summary = doc.select(".novel_summary_box.pc > div");
    for (let i = 0; i < summary.size(); i++) {
        let text = cleanText(summary.get(i).text());
        if (text) info.push(text);
    }

    let status = cleanText(doc.select(".novel_summary_box.pc .serializing").text());

    let genres = [];
    doc.select(".category_list li a").forEach(function (el) {
        let title = cleanText(el.text());
        if (title) genres.push({ title: title, input: absUrl(el.attr("href")), script: "list.js" });
    });

    let tags = [];
    doc.select(".novel_tag_list.pc li a").forEach(function (el) {
        let title = cleanText(el.text());
        if (title) tags.push({ title: title, input: absUrl(el.attr("href")), script: "list.js" });
    });

    return Response.success({
        name: name,
        author: author,
        cover: thumb(name),
        description: description,
        detail: info.join("<br>"),
        url: url,
        type: "novel",
        format: "novel",
        ongoing: status.indexOf("完结") === -1,
        nsfw: true,
        locale: "zh",
        genres: genres,
        tags: tags
    });
}
