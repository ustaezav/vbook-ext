load('config.js');

// Generic listing behind the home tabs and genre chips.
//   "/all/<gender>-<cat>-<sub>-<status>-<words>-<tag>-<sort>-<page>/"  filtered list
//   "rank:<n>"                                                       排行榜 (1 周榜, 2 月榜,
//                                                                    3 年榜, 4 新作榜, 5 收藏榜)
function execute(query, page) {
    query = query || "";

    if (query.indexOf("rank:") === 0) {
        return Response.success(rankList(query.substring(5)), "");
    }

    let response = fetch(allUrl(query, page));
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    return Response.success(parseList(doc), nextPageNumber(doc));
}

function rankList(range) {
    let response = fetch(BASE_URL + "/api/rank", { queries: { range: String(range || "1") } });
    if (!response.ok) return [];
    let model = response.json().model || [];
    let items = [];
    for (let i = 0; i < model.length; i++) {
        let item = apiItem(model[i]);
        if (item.name) items.push(item);
    }
    return items;
}
