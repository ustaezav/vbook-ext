load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let box = doc.select(".chapter_content_box").first();
    if (box === null) return Response.error("Không tìm thấy nội dung chương");

    // The body is <h2>title</h2> plus one <p> per paragraph; each paragraph also
    // carries a <span class="z"> paragraph-comment marker.
    box.select("h2").remove();
    box.select("span.z").remove();
    box.select("script, style").remove();

    let content = box.html();
    if (cleanText(content) === "") return Response.error("Chương trống");

    return Response.success(content);
}
