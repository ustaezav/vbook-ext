load('config.js');

function execute(query, page) {
    query = query || "";
    page = page || "1";

    let response = fetch(BASE_URL + "/api/search", {
        queries: { keyword: query, page: page }
    });
    if (!response.ok) return Response.error("HTTP " + response.status);

    let model = response.json().model;
    if (!model) return Response.success([]);

    let data = model.data || [];
    let items = [];
    for (let i = 0; i < data.length; i++) {
        let item = apiItem(data[i]);
        if (item.name) items.push(item);
    }

    let current = parseInt(model.currentPage, 10) || 1;
    let total = parseInt(model.totalPage, 10) || 1;
    return Response.success(items, current < total ? String(current + 1) : "");
}
