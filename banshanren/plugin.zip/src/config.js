// Shared code for the Banshanren extension. Every other script starts with
// load('config.js'); a loaded library must not load another file, so all helpers
// live here.

// The site ships every book cover AES-encrypted for its own page scripts to decode
// in the browser, so the app cannot display the raw file. Covers are omitted (the
// reader falls back to its own placeholder) rather than pointing at a broken image.
let BASE_URL = "https://www.banshanren.com";

try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

// Rewrite an incoming url's host (old/mirror/www-prefixed) to BASE_URL, keeping
// path and query. Call this first thing in every url-receiving execute(url).
function normalizeUrl(url) {
    return String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function absUrl(href) {
    if (!href) return "";
    href = String(href);
    if (/^https?:\/\//i.test(href)) return href;
    if (href.charAt(0) === "/") return BASE_URL + href;
    return BASE_URL + "/" + href;
}

function cleanText(text) {
    return String(text === undefined || text === null ? "" : text)
        .replace(/[\s\u3000]+/g, " ")
        .trim();
}

function statusTag(meta) {
    if (meta.indexOf("连载") !== -1) return "连载中";
    if (meta.indexOf("完结") !== -1) return "完结";
    return "";
}

// One card of a listing page (`.novel_list .novel_li`).
function bookItem(el) {
    let link = el.select("a.title").first();
    if (link === null) return null;
    let href = link.attr("href");
    let name = cleanText(link.text());
    if (!name || !href) return null;

    // The two `.info_box` rows are "推荐度 N%" and "作者 · 状态 · N章 · N万字".
    let meta = "";
    let boxes = el.select(".title_box .info_box");
    for (let i = 0; i < boxes.size(); i++) {
        let text = cleanText(boxes.get(i).text());
        if (text && text.indexOf("推荐度") === -1) {
            meta = text;
            break;
        }
    }

    return {
        name: name,
        link: absUrl(href),
        description: meta,
        tag: statusTag(meta),
        host: BASE_URL
    };
}

function parseList(doc) {
    let items = [];
    let lists = doc.select("ul.novel_list");
    for (let i = 0; i < lists.size(); i++) {
        let ul = lists.get(i);
        // The header search box also renders a `novel_list`; it is not a result list.
        if (String(ul.attr("class")).indexOf("search_hot_box") !== -1) continue;
        let rows = ul.select("li.novel_li");
        for (let j = 0; j < rows.size(); j++) {
            let item = bookItem(rows.get(j));
            if (item) items.push(item);
        }
    }
    return items;
}

// Next page number from the pager; the page is the last field of url segment 7 of
// "/all/<filters>-<sort>-<page>/".
function nextPageNumber(doc) {
    let links = doc.select(".pagination_box a");
    for (let i = 0; i < links.size(); i++) {
        let href = links.get(i).attr("href");
        let match = String(href).match(/\/all\/([0-9-]+)\//);
        if (match && cleanText(links.get(i).attr("title")) === "下一页") {
            let parts = match[1].split("-");
            return parts.length > 7 ? parts[7] : "";
        }
    }
    return "";
}

// Build an /all/ listing url. The filters are one dash-separated token whose last
// two fields are sort and page, e.g. /all/0-3-0-0-0-0-1-1/ is category 3, sort 1,
// page 1; page 2 at sort 2 is /all/0-3-0-0-0-0-2-2/.
function allUrl(query, page) {
    let path = String(query || "/all/0-0-0-0-0-0-1-1/");
    let match = path.match(/\/all\/([0-9-]+)/);
    let parts = match ? match[1].split("-") : [];
    while (parts.length < 8) parts.push("0");
    parts[6] = (!parts[6] || parts[6] === "0") ? "1" : parts[6];
    parts[7] = "1";
    if (page && parseInt(page, 10) > 0) parts[7] = String(parseInt(page, 10));
    return BASE_URL + "/all/" + parts.slice(0, 8).join("-") + "/";
}

// One item from the site's JSON API (/api/search, /api/rank).
function apiItem(it) {
    let finished = String(it.finished) === "1";
    let meta = [];
    if (it.authors) meta.push(it.authors);
    meta.push(finished ? "完结" : "连载中");
    if (it.chapterCount) meta.push(it.chapterCount + "章");
    if (it.wordCountFormat) meta.push(it.wordCountFormat + "字");

    return {
        name: it.title,
        link: BASE_URL + "/novel/" + it.slug,
        description: meta.join(" · "),
        tag: finished ? "完结" : "连载中",
        host: BASE_URL
    };
}
