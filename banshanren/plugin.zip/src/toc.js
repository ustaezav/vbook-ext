load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    // Works for both single-volume and multi-volume books: chapters are the only
    // anchors under .chapter_list (volume headers are divs, not links).
    let chapters = [];
    let seen = {};
    doc.select(".catalog_box .chapter_list li a").forEach(function (el) {
        let href = el.attr("href");
        if (!href || seen[href]) return;
        seen[href] = true;
        chapters.push({
            name: cleanText(el.attr("title") || el.text()),
            url: absUrl(href),
            host: BASE_URL,
            description: "",
            lock: false,
            pay: false
        });
    });

    if (chapters.length === 0) return Response.error("Không tìm thấy mục lục");
    return Response.success(chapters);
}
