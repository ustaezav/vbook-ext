load('config.js');

// Category and tag chips, read from the /all page's filter panels. Each links to
// an /all/ listing path that list.js pages through.
function execute() {
    let response = fetch(BASE_URL + "/all/0-0-0-0-0-0-1-1/");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let genres = [];
    let seen = {};

    function add(el) {
        let href = el.attr("href");
        let title = cleanText(el.text());
        if (!href || !title || href.indexOf("/all/") !== 0) return;
        if (href === "/all/0-0-0-0-0-0-1-1/" || seen[href]) return;
        seen[href] = true;
        genres.push({ title: title, input: href, script: "list.js" });
    }

    let categories = doc.select("#category_box li a");
    for (let i = 0; i < categories.size(); i++) add(categories.get(i));

    let tags = doc.select(".tag_filter_box .tag_box li a");
    for (let j = 0; j < tags.size(); j++) add(tags.get(j));

    return Response.success(genres);
}
