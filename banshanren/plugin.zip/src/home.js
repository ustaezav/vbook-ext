// Home tabs. Each tab passes its input to list.js as the listing query.
function execute() {
    return Response.success([
        { title: "最新更新", input: "/all/0-0-0-0-0-0-2-1/", script: "list.js" },
        { title: "热门浏览", input: "/all/0-0-0-0-0-0-3-1/", script: "list.js" },
        { title: "新书上架", input: "/all/0-0-0-0-0-0-1-1/", script: "list.js" },
        { title: "周榜", input: "rank:1", script: "list.js" },
        { title: "新作榜", input: "rank:4", script: "list.js" }
    ]);
}
