load('config.js');

function execute() {
    let genres = [
        { title: "Video mới", input: "/vi/bits-of-news/", script: "list.js" },
        { title: "người đẹp sexy", input: "/vi/type/1/", script: "list.js" },
        { title: "Gái đẹp Vớ chân", input: "/vi/type/3/", script: "list.js" },
        { title: "Cosplay", input: "/vi/type/6/", script: "list.js" },
        { title: "Đồng phục quyến rũ", input: "/vi/type/7/", script: "list.js" },
        { title: "Phụ Nữ Đẹp Lớn", input: "/vi/type/9/", script: "list.js" }
    ];

    let response = fetch(BASE_URL + PREFIX + "/tag/", { timeout: 30000 });
    if (response.ok) {
        let doc = response.html();
        doc.select(".tagslist li a.name").forEach(function (el) {
            let title = el.text().trim();
            let href = el.attr("href");
            if (title && href) genres.push({ title: title, input: href, script: "list.js" });
        });
    }

    return Response.success(genres);
}
