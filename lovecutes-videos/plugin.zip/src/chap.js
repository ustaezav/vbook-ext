load('config.js');

function execute(url) {
    let index = -1;
    let m = String(url).match(/[?&]v=(\d+)/);
    if (m) index = parseInt(m[1], 10);

    let pageUrl = articleUrl(url);
    let response = fetch(pageUrl, { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let sources = [];
    doc.select(".article-video-block video source").forEach(function (el) {
        let src = el.attr("src");
        if (src) sources.push(src);
    });

    let tracks = [];
    for (let i = 0; i < sources.length; i++) {
        if (index > 0 && i !== index - 1) continue;
        tracks.push({
            title: sources.length > 1 ? "Video " + (i + 1) : "Full",
            data: sources[i]
        });
    }

    if (tracks.length === 0) return Response.error("Không có link phát");
    return Response.success(tracks);
}
