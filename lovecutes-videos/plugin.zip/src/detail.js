load('config.js');

function execute(url) {
    url = articleUrl(url);
    let response = fetch(url, { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let entities = articleEntities(doc);
    let videoCount = doc.select(".article-video-block video source").size();

    let genres = [];
    let category = articleCategory(doc);
    if (category) {
        doc.select(".seo-breadcrumbs a").forEach(function (el) {
            if (el.attr("href").indexOf("/type/") !== -1 && genres.length === 0) {
                genres.push({ title: category, input: el.attr("href"), script: "list.js" });
            }
        });
    }
    doc.select(".article-tags a").forEach(function (el) {
        let href = el.attr("href");
        let title = el.text().trim();
        if (href && title) genres.push({ title: title, input: href, script: "list.js" });
    });

    return Response.success({
        name: articleTitle(doc),
        author: entities.join(", "),
        cover: absUrl(metaContent(doc, "og:image")),
        description: articleDescription(doc),
        detail: articleInfo(doc, videoCount, articleDownloadInfo(articleId(url))),
        url: url,
        type: "video",
        format: "short",
        nsfw: true,
        ongoing: false,
        genres: genres
    });
}
