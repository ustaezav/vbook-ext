function execute() {
    return Response.success([
        { title: "Video mới", input: "/vi/bits-of-news/", script: "list.js" },
        { title: "Mới cập nhật", input: "/vi/sort/new/", script: "list.js" },
        { title: "Phổ biến", input: "/vi/sort/hot/", script: "list.js" }
    ]);
}
