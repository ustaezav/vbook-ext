load('config.js');

function browserUserAgent() {
    try {
        if (UserAgent && UserAgent.system) {
            let ua = UserAgent.system();
            if (ua) return ua;
        }
    } catch (e) {
    }
    return "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36";
}

function execute(data) {
    data = String(data || "").trim();
    if (!data) return Response.error("Không có link phát");

    let headers = {
        "User-Agent": browserUserAgent(),
        "Referer": BASE_URL + "/"
    };

    if (data.indexOf(".m3u8") !== -1) {
        return Response.success({
            type: "native",
            data: data,
            mimeType: "application/x-mpegURL",
            headers: headers
        });
    }

    if (data.indexOf(".mp4") !== -1) {
        return Response.success({
            type: "native",
            data: data,
            mimeType: "video/mp4",
            headers: headers
        });
    }

    return Response.success({ type: "auto", data: data, headers: headers });
}
