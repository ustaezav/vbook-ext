load('config.js');

function execute(url) {
    url = articleUrl(url);
    let response = fetch(url, { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let count = doc.select(".article-video-block video source").size();
    if (count === 0) return Response.error("Bài viết không có video");

    let base = url.replace(/\/+$/, "");
    let chapters = [];
    if (count === 1) {
        chapters.push({ name: "Full", url: base + "/", description: "", lock: false, pay: false });
    } else {
        for (let i = 1; i <= count; i++) {
            chapters.push({
                name: "Video " + i,
                url: base + "/?v=" + i,
                description: "",
                lock: false,
                pay: false
            });
        }
    }

    return Response.success(chapters);
}
