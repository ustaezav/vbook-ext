load('config.js');

// Kept fetch-free: the short feed resolves toc -> chap -> track for the next items
// while the current one plays, so this must stay fast.
function execute(url) {
    url = articleUrl(url);
    return Response.success([
        { name: "Full", url: url, description: "", lock: false, pay: false }
    ]);
}
