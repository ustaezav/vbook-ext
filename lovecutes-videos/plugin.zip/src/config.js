let BASE_URL = "https://www.lovecutes.com";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

let PREFIX = "/vi";

function normalizeUrl(url) {
    return String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function absUrl(url) {
    url = String(url || "");
    if (!url) return "";
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("http") === 0) return url;
    return BASE_URL + (url.charAt(0) === "/" ? url : "/" + url);
}

function metaContent(doc, key) {
    let metas = doc.select("meta");
    for (let i = 0; i < metas.size(); i++) {
        let m = metas.get(i);
        if (m.attr("property") === key || m.attr("name") === key) {
            return m.attr("content");
        }
    }
    return "";
}

function listFromDoc(doc, videosOnly) {
    let items = [];
    doc.select("article.excerpt").forEach(function (el) {
        if (videosOnly && el.select(".play-icon").isEmpty()) return;
        let link = el.select("a.imgbox-link").attr("href");
        let name = el.select("h2 a").text().trim();
        if (!link || !name) return;
        items.push({
            name: name,
            cover: absUrl(el.select("img.imgbox-img").attr("src")),
            link: absUrl(link),
            description: el.select("a.imgbox-a").attr("title"),
            tag: el.select("a.imgbox-a").text().trim(),
            type: "short",
            host: BASE_URL
        });
    });
    return items;
}

function hasNextPage(doc) {
    return !doc.select("link[rel=next]").isEmpty();
}

function jsonLd(doc, type) {
    let scripts = doc.select("script");
    for (let i = 0; i < scripts.size(); i++) {
        let s = scripts.get(i);
        if (s.attr("type") !== "application/ld+json") continue;
        let txt = s.html();
        if (!txt) continue;
        try {
            let obj = JSON.parse(txt);
            if (obj && obj["@type"] === type) return obj;
        } catch (e) {
        }
    }
    return null;
}

function articleTitle(doc) {
    let name = doc.select("h1.focusbox-title").text().trim();
    if (!name) {
        name = metaContent(doc, "og:title").replace(/\s*-\s*Yêu em gái\s*$/, "").trim();
    }
    return name;
}

function articleDescription(doc) {
    let g = jsonLd(doc, "VideoObject") || jsonLd(doc, "ImageGallery");
    if (g && g.description) return String(g.description);
    return metaContent(doc, "og:description") || metaContent(doc, "description");
}

function articleCategory(doc) {
    let category = "";
    doc.select(".seo-breadcrumbs a").forEach(function (el) {
        if (!category && el.attr("href").indexOf("/type/") !== -1) category = el.text().trim();
    });
    return category;
}

function articleEntities(doc) {
    let names = [];
    doc.select(".article-entity-chip__name").forEach(function (el) {
        let t = el.text().trim();
        if (t) names.push(t);
    });
    return names;
}

function articleImageCount(doc) {
    let g = jsonLd(doc, "ImageGallery");
    if (g && g.mainEntity && g.mainEntity.numberOfItems) {
        return parseInt(g.mainEntity.numberOfItems, 10) || 0;
    }
    return 0;
}

function articleUploadDate(doc) {
    let g = jsonLd(doc, "VideoObject") || jsonLd(doc, "ImageGallery");
    if (g && g.uploadDate) return String(g.uploadDate).substring(0, 10);
    return "";
}

function articleInfo(doc, videoCount) {
    let lines = [];
    let category = articleCategory(doc);
    if (category) lines.push("Danh mục: " + category);

    let entities = articleEntities(doc);
    if (entities.length) lines.push("Người mẫu / Tác giả: " + entities.join(", "));

    let count = articleImageCount(doc);
    if (count) lines.push("Số ảnh: " + count);
    if (videoCount) lines.push("Video: " + videoCount);

    let date = articleUploadDate(doc);
    if (date) lines.push("Ngày đăng: " + date);

    doc.select(".download-info-box .info-item:not(.password-item)").forEach(function (el) {
        let t = el.text().replace(/\s+/g, " ").trim();
        if (t) lines.push(t);
    });

    return lines.join("\n");
}

function articleId(url) {
    let m = String(url).match(/\/article\/(\d+)/);
    return m ? m[1] : "";
}

function articleUrl(url) {
    let id = articleId(url);
    if (id) return BASE_URL + PREFIX + "/article/" + id + "/";
    return normalizeUrl(url);
}
