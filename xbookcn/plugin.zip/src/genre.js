load('config.js');
// Genres come from the hub page: novel catalogue pages (/p/*.html) on the book
// subdomain and short-story label categories on the blog subdomain.
function execute() {
    let res = fetchDoc(BASE_URL);
    if (res.error) return Response.error("Không tải được trang chủ: " + res.error);

    let seen = {};
    let genres = [];
    res.doc.select("a[href]").forEach(function (el) {
        let title = el.text().replace(/\s+/g, " ").trim();
        if (!title) return;

        let parts = splitUrl(el.attr("href"));
        if (!parts) return;

        let script = "";
        if (parts.prefix === "book" && parts.path.indexOf("/p/") === 0) script = "novels.js";
        else if (parts.prefix === "blog" && parts.path.indexOf("/search/label/") === 0) script = "stories.js";
        if (!script) return;

        let link = zoneUrl(zoneRoot(), parts.prefix, parts.path);
        if (seen[link]) return;
        seen[link] = true;
        genres.push({ title: title, input: link, script: script });
    });

    if (genres.length === 0) return Response.error("Không tìm thấy thể loại");
    return Response.success(genres);
}
