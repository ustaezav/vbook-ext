load('config.js');
// Blogger post pages keep the article in .post-body (classic template) or
// .post__content (the modern template used by the .net blog).
function execute(url) {
    url = normalizeUrl(url);

    let res = fetchDoc(url, 60000);
    if (res.error) return Response.error(res.error);
    let doc = res.doc;

    let content = firstEl(doc, [".post-body.entry-content", ".content.post__content", ".post__content"]);
    if (!content) return Response.error("Không tìm thấy nội dung");

    let title = text(firstEl(doc, ["h1.post__title", ".post-title.entry-title"])) || pageTitle(doc);
    return Response.success(content.html(), title);
}
