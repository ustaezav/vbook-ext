load('config.js');
load('thumb.js');
// Three shapes reach detail: a book label page (serialised novel), a blog label
// page (short-story category) and a post (a chapter or a one-shot story).
function execute(url) {
    url = normalizeUrl(url);
    if (isLabelUrl(url)) {
        if (isBookHost(url)) return novelDetail(url);
        if (isBlogHost(url)) return categoryDetail(url);
    }
    return postDetail(url);
}

function novelDetail(url) {
    let res = fetchDoc(ensureMaxResults(url, LABEL_PAGE_SIZE), 60000);
    if (res.error) return Response.error(res.error);
    let doc = res.doc;

    let name = text(doc.select(".status-msg-body").first()) || pageTitle(doc);
    if (!name) return Response.error("Không tìm thấy truyện");

    let chapters = chapterLinks(doc);
    if (chapters.size() === 0) return Response.error("Không có chương");

    let count = chapters.size() >= LABEL_PAGE_SIZE ? chapters.size() + "+" : "" + chapters.size();

    return Response.success({
        name: name,
        cover: thumb(name),
        description: introText(doc, url),
        detail: count + " chương",
        url: url,
        type: "novel",
        format: "novel",
        ongoing: true,
        nsfw: true,
        locale: "zh_CN"
    });
}

// The synopsis is the first entry of the chapter list, which only exists on its
// own post page.
function introText(doc, url) {
    let entries = doc.select("h3.post-title.entry-title a");
    let intro = "";
    for (let i = 0; i < entries.size(); i++) {
        let title = entries.get(i).text();
        if (/簡介|简介/.test(title)) {
            intro = absUrl(entries.get(i), url);
            break;
        }
    }
    if (!intro) return "";

    let res = fetchDoc(intro, 60000);
    if (res.error) return "";

    let body = firstEl(res.doc, [".post-body.entry-content", ".content.post__content"]);
    return body ? body.html() : "";
}

function categoryDetail(url) {
    let res = fetchDoc(url, 60000);
    if (res.error) return Response.error(res.error);

    let name = text(firstEl(res.doc, ["h1.main__title", ".status-msg-body", "h1"])) || pageTitle(res.doc);
    if (!name) return Response.error("Không tìm thấy thể loại");

    return Response.success({
        name: name,
        cover: thumb(name),
        description: "Truyện ngắn",
        url: url,
        type: "novel",
        format: "novel",
        ongoing: true,
        nsfw: true,
        locale: "zh_CN"
    });
}

function postDetail(url) {
    let res = fetchDoc(url, 60000);
    if (res.error) return Response.error(res.error);
    let doc = res.doc;

    let content = firstEl(doc, [".post-body.entry-content", ".content.post__content", ".post__content"]);
    if (!content) return Response.error("Không tìm thấy nội dung");

    let name = text(firstEl(doc, ["h1.post__title", ".post-title.entry-title"])) || pageTitle(doc);
    if (!name) return Response.error("Không tìm thấy tiêu đề");

    // The story body starts with "作者：X" and the title line, so the synopsis
    // comes from the first substantial paragraphs.
    let paragraphs = content.select("p");
    let description = "";
    let taken = 0;
    for (let i = 0; i < paragraphs.size() && taken < 2; i++) {
        let value = paragraphs.get(i).text().trim();
        if (value.length < 30) continue;
        description += value + "\n";
        taken++;
    }

    // Tag links are category labels, which only the blog listings understand.
    let tags = [];
    if (isBlogHost(url)) {
        doc.select("a[rel=tag]").forEach(function (el) {
            let title = el.text().trim();
            if (title) tags.push({ title: title, input: absUrl(el, res.url), script: "stories.js" });
        });
    }

    return Response.success({
        name: name,
        author: postAuthor(content),
        cover: thumb(name),
        description: description,
        detail: "",
        url: url,
        type: "novel",
        format: "novel",
        ongoing: true,
        nsfw: true,
        locale: "zh_CN",
        tags: tags
    });
}

function postAuthor(content) {
    let match = /作者[：:]\s*([^\s<，,。]{1,20})/.exec(content.text());
    return match ? match[1] : "";
}
