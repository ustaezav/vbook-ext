load('config.js');
load('thumb.js');
// There is no server-side search: the blog search page is disabled and search
// result items carry no labels, so the hub's catalogue of novel and short-story
// category links is fetched once and filtered locally.
function execute(query, page) {
    let q = String(query || "").trim();

    let res = fetchDoc(BASE_URL);
    if (res.error) return Response.error("Không tải được trang chủ: " + res.error);

    let seen = {};
    let novels = [];
    let categories = [];

    res.doc.select("a[href]").forEach(function (el) {
        let parts = splitUrl(el.attr("href"));
        if (!parts || parts.path.indexOf("/search/label/") !== 0) return;

        let name = el.text().replace(/\s+/g, " ").trim();
        if (!name) return;

        let link = zoneUrl(zoneRoot(), parts.prefix, parts.path);
        if (seen[link]) return;
        seen[link] = true;
        if (!matches(q, name, parts.path)) return;

        if (parts.prefix === "book") novels.push({ name: name, link: link, tag: "Truyện dài" });
        else if (parts.prefix === "blog") categories.push({ name: name, link: link, tag: "Truyện ngắn" });
    });

    let items = novels.concat(categories);
    if (items.length > 80) items = items.slice(0, 80);
    return Response.success(thumbAll(items), "");
}

// Labels are stored percent-encoded, so a query in the wrong script can still
// match through the raw label value.
function matches(query, name, path) {
    if (!query) return true;

    if (name.toLowerCase().indexOf(query.toLowerCase()) !== -1) return true;

    let decoded = String(path);
    try {
        decoded = decodeURIComponent(decoded);
    } catch (error) {
    }
    return decoded.toLowerCase().indexOf(query.toLowerCase()) !== -1;
}
