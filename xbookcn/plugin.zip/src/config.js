// xbookcn.net is a static hub; the books live on two Blogger subdomains of the
// same zone: book.* (serialised novels) and blog.* (short stories). The .com
// zone mirrors the .net one with its own label names (traditional vs simplified),
// so links are rebuilt on whichever zone the user selected.
let BASE_URL = "https://www.xbookcn.com";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

// Zone root of the configured domain, e.g. "xbookcn.com" or "xbookcn.net".
function zoneRoot() {
    return String(BASE_URL)
        .replace(/^https?:\/\//i, "")
        .replace(/\/.*$/, "")
        .replace(/^(?:www|book|blog)\./i, "");
}

function zoneUrl(root, prefix, path) {
    return "https://" + (prefix ? prefix + "." : "") + root + (path || "");
}

function bookUrl(path) {
    return zoneUrl(zoneRoot(), "book", path);
}

function blogUrl(path) {
    return zoneUrl(zoneRoot(), "blog", path);
}

// Split a URL into its subdomain role ("book" / "blog" / "") and path, so the
// same link can be rebuilt on whichever zone the user selected.
function splitUrl(url) {
    let match = /^(?:https?:\/\/)?([^\/?#]+)(.*)$/i.exec(String(url || ""));
    if (!match) return null;

    let host = match[1].toLowerCase();
    let prefix = "";
    if (host.indexOf("book.") === 0) prefix = "book";
    else if (host.indexOf("blog.") === 0) prefix = "blog";

    return { prefix: prefix, path: match[2] || "" };
}

// xbookcn.net and xbookcn.com mirror each other, so every link is rebuilt on the
// zone the user selected (labels exist under translated names in each zone).
function normalizeUrl(url) {
    let parts = splitUrl(url);
    return parts ? zoneUrl(zoneRoot(), parts.prefix, parts.path) : String(url || "");
}

function isBookHost(url) {
    return String(url || "").indexOf("//book.") !== -1;
}

function isBlogHost(url) {
    return String(url || "").indexOf("//blog.") !== -1;
}

function isLabelUrl(url) {
    return String(url || "").indexOf("/search/label/") !== -1;
}

// First element matching any selector in order, or null (an empty selection's
// .first() is not reliably null in this runtime).
function firstEl(scope, selectors) {
    if (!scope) return null;
    for (let i = 0; i < selectors.length; i++) {
        let list = scope.select(selectors[i]);
        if (list.size() > 0) return list.first();
    }
    return null;
}

function child(el, selector) {
    if (!el) return null;
    let list = el.select(selector);
    return list.size() > 0 ? list.first() : null;
}

function text(el) {
    return el ? el.text().trim() : "";
}

function attr(el, name) {
    return el ? el.attr(name) || "" : "";
}

// The classic Blogger template hides the post title on item pages, so the only
// reliable title source there is the og:title meta / <title> tag.
function pageTitle(doc) {
    let meta = doc.select("meta[property=og:title]");
    let value = attr(meta.first(), "content").trim();
    if (value) return value;

    value = text(doc.select("title").first()).replace(/[-|]\s*(?:长|長|短)篇成人情色小[说說](?:网|網)?\s*$/, "");
    let cut = value.indexOf("-");
    return cut > 0 ? value.substring(0, cut).trim() : value.trim();
}

// Resolve an href against the page it was parsed from: Blogger mixes absolute
// links with "../../.." ones, and the app joins relative links with the
// extension source, which would point at the wrong host.
function resolveUrl(base, href) {
    let value = String(href || "");
    if (!value) return "";
    if (value.indexOf("//") === 0) return "https:" + value;
    if (value.indexOf("http") === 0) return value;

    let match = /^(https?:\/\/[^\/?#]+)(\/[^?#]*)?/.exec(String(base || ""));
    if (!match) return value;
    let origin = match[1];
    if (value.charAt(0) === "/") return origin + value;

    let segments = (match[2] || "/").split("/");
    segments.pop();

    let parts = value.split("/");
    for (let i = 0; i < parts.length; i++) {
        if (parts[i] === "" || parts[i] === ".") continue;
        if (parts[i] === "..") {
            if (segments.length > 0) segments.pop();
        } else {
            segments.push(parts[i]);
        }
    }
    return origin + segments.join("/");
}

function absUrl(el, pageUrl) {
    return resolveUrl(pageUrl, attr(el, "href"));
}

// Link of an element that may either be an <a> itself or wrap one (Blogger puts
// the pager id on the span and the href on its child anchor).
function linkOf(el, pageUrl) {
    if (!el) return "";
    if (attr(el, "href")) return absUrl(el, pageUrl);
    return absUrl(el.select("a[href]").first(), pageUrl);
}

function excerpt(el, limit) {
    if (!el) return "";
    let value = el.text().replace(/\s+/g, " ").trim();
    let max = limit || 140;
    return value.length > max ? value.substring(0, max) + "…" : value;
}

function withQuery(url, param) {
    return url + (url.indexOf("?") === -1 ? "?" : "&") + param;
}

// Override Blogger's 20-entry default without duplicating an existing value.
function ensureMaxResults(url, size) {
    return url.indexOf("max-results=") !== -1 ? url : withQuery(url, "max-results=" + size);
}

function fetchDoc(url, timeout) {
    let response = fetch(url, { timeout: timeout || 45000 });
    if (!response.ok) return { error: "HTTP " + response.status };
    return { doc: response.html(), url: response.url || url };
}

// Blogger serves at most 500 entries per label page before it paginates by date.
let LABEL_PAGE_SIZE = 500;

function chapterLinks(doc) {
    return doc.select("h3.post-title.entry-title a");
}
