load('config.js');
// The hub has no browse API; these tabs point at the zone-independent listing
// pages (novel catalogue pages and the short-story root) that both zones share.
function execute() {
    return Response.success([
        { title: "Truyện dài · Tất cả", input: bookUrl("/p/all.html"), script: "novels.js" },
        { title: "Truyện dài · Nổi bật", input: bookUrl("/p/columnist.html"), script: "novels.js" },
        { title: "Truyện ngắn · Mới nhất", input: blogUrl("/"), script: "stories.js" }
    ]);
}
