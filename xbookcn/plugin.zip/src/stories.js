load('config.js');
// Blogger serves its static nav pages (index / search / contact) inside the same
// post stream as the stories, so they have to be skipped explicitly.
function isNavPage(href) {
    let slugs = ["/2000/01/list.html", "/2000/01/site.html", "/2000/01/contact.html"];
    for (let i = 0; i < slugs.length; i++) {
        if (String(href).indexOf(slugs[i]) !== -1) return true;
    }
    return false;
}

// Lists one short-story page: a blog category label, or the blog root for the
// newest stories. The .com zone serves the classic Blogger template (post-outer
// + date cursor), the .net zone a modern one (article.list__item + /page/N/).
function execute(query, page) {
    let base = normalizeUrl(query || blogUrl("/"));
    let url = page ? String(page) : ensureMaxResults(base, 40);

    let res = fetchDoc(url, 60000);
    if (res.error) return Response.error(res.error);
    let doc = res.doc;
    let pageUrl = res.url;

    let items = [];
    let seen = {};

    let modern = doc.select("article.list__item").size() > 0;
    if (modern) {
        doc.select("article.list__item").forEach(function (el) {
            let link = firstEl(el, ["h2.list__title a", "a[rel=bookmark]", "h2 a"]);
            let href = absUrl(link, pageUrl);
            let name = text(link);
            if (!name || !href || seen[href] || isNavPage(href)) return;
            seen[href] = true;
            items.push({
                name: name,
                link: href,
                description: excerpt(child(el, ".list__content"), 160),
                tag: text(child(el, "a[rel=tag]"))
            });
        });
    } else {
        doc.select("div.post-outer").forEach(function (el) {
            let link = el.select("h3.post-title.entry-title a").first();
            let href = absUrl(link, pageUrl);
            let name = text(link);
            if (!name || !href || seen[href] || isNavPage(href)) return;
            seen[href] = true;
            items.push({
                name: name,
                link: href,
                description: excerpt(el.select(".post-body").first(), 160),
                tag: text(el.select("a[rel=tag]").first())
            });
        });
    }

    if (items.length === 0) return Response.error("Không có dữ liệu");
    return Response.success(items, nextStoryPage(doc, pageUrl, modern, items.length));
}

// The classic template always renders the "older posts" link, so a full page is
// the only signal that more may exist; the modern template numbers its pages.
function nextStoryPage(doc, url, modern, count) {
    if (modern) {
        let current = 1;
        let match = /Page\s+(\d+)/i.exec(text(doc.select("span.pagination__item--current").first()));
        if (match) current = parseInt(match[1], 10);

        let links = doc.select("div.pagination a.pagination__item");
        for (let i = 0; i < links.size(); i++) {
            let found = /\/page\/(\d+)\//.exec(attr(links.get(i), "href"));
            if (found && parseInt(found[1], 10) === current + 1) return absUrl(links.get(i), url);
        }
        return "";
    }

    if (count < 40) return "";
    return linkOf(child(doc, "#blog-pager-older-link"), url);
}