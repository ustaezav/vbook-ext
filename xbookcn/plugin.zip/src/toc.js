load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    if (isLabelUrl(url)) {
        if (isBookHost(url)) return novelToc(url);
        if (isBlogHost(url)) return categoryToc(url);
    }
    return singleChapterToc(url);
}

// A novel lives on its label page: every entry is a chapter post, whose title is
// prefixed with the novel name.
function novelToc(url) {
    let res = fetchDoc(ensureMaxResults(url, LABEL_PAGE_SIZE), 60000);
    if (res.error) return Response.error(res.error);
    let doc = res.doc;

    let novel = text(doc.select(".status-msg-body").first());
    let chapters = [];
    let seen = {};

    chapterLinks(doc).forEach(function (el) {
        let link = absUrl(el, url);
        if (!link || seen[link]) return;
        seen[link] = true;

        let name = el.text().trim();
        if (novel && name.indexOf(novel) === 0) {
            let stripped = name.substring(novel.length).replace(/^[\s\-—:：]+/, "");
            if (stripped) name = stripped;
        }
        chapters.push({ name: name, url: link, description: "", lock: false, pay: false });
    });

    if (chapters.length === 0) return Response.error("Không có chương");
    return Response.success(chapters);
}

// A blog label page is a short-story category; its entries are stories, so the
// chapter list is only the first page of that category.
function categoryToc(url) {
    let res = fetchDoc(ensureMaxResults(url, LABEL_PAGE_SIZE), 60000);
    if (res.error) return Response.error(res.error);

    let chapters = [];
    let seen = {};
    let modern = res.doc.select("article.list__item").size() > 0;

    let links = modern ? res.doc.select("article.list__item a[rel=bookmark]") : res.doc.select("h3.post-title.entry-title a");
    links.forEach(function (el) {
        let link = absUrl(el, res.url);
        let name = el.text().trim();
        if (!name || !link || seen[link]) return;
        seen[link] = true;
        chapters.push({ name: name, url: link, description: "", lock: false, pay: false });
    });

    if (chapters.length === 0) return Response.error("Không có truyện");
    return Response.success(chapters);
}

// A one-shot story (or a pasted chapter post) is a book of its own.
function singleChapterToc(url) {
    let res = fetchDoc(url, 60000);
    if (res.error) return Response.error(res.error);

    let name = text(firstEl(res.doc, ["h1.post__title", ".post-title.entry-title"])) || pageTitle(res.doc);
    if (!name) return Response.error("Không tìm thấy tiêu đề");

    return Response.success([{ name: name, url: url, description: "", lock: false, pay: false }]);
}
