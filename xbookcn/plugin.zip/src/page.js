load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    if (!(isBookHost(url) && isLabelUrl(url))) return Response.success([url]);

    let first = ensureMaxResults(url, LABEL_PAGE_SIZE);
    let res = fetchDoc(first, 60000);
    if (res.error) return Response.error(res.error);

    let pages = [first];
    let doc = res.doc;
    let count = chapterLinks(doc).size();
    let guard = 0;

    // Blogger caps one label page at 500 entries and paginates by date, so the
    // "older posts" link is the only cursor for longer novels.
    while (count >= LABEL_PAGE_SIZE && guard < 20) {
        let older = linkOf(child(doc, "#blog-pager-older-link"), first);
        if (!older) break;

        let next = fetchDoc(older, 60000);
        if (next.error) break;

        count = chapterLinks(next.doc).size();
        if (count === 0) break;

        pages.push(older);
        doc = next.doc;
        first = older;
        guard++;
    }

    return Response.success(pages);
}
