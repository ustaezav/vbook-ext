load('config.js');
load('thumb.js');
// Lists one novel catalogue page (book.*/p/*.html). Those pages are curated
// single-page lists: each entry is a paragraph with a bold 《title》 label link
// followed by a synopsis paragraph.
function execute(query, page) {
    let url = normalizeUrl(query);
    let res = fetchDoc(url);
    if (res.error) return Response.error(res.error);

    let paragraphs = res.doc.select(".post-body p");
    let items = [];
    let seen = {};

    for (let i = 0; i < paragraphs.size(); i++) {
        let el = paragraphs.get(i);
        let link = el.select("strong a").first();
        if (!link) continue;

        let href = absUrl(link, url);
        if (href.indexOf("/search/label/") === -1 || href.indexOf("xbookcn") === -1) continue;

        let name = link.text().trim();
        if (!name || seen[href]) continue;
        seen[href] = true;

        // The synopsis is the paragraph right after the entry, unless that is the
        // next entry's heading.
        let description = "";
        if (i + 1 < paragraphs.size()) {
            let nextEl = paragraphs.get(i + 1);
            if (nextEl.select("strong a").size() === 0) {
                description = nextEl.text().replace(/\s+/g, " ").trim();
                if (description.length > 160) description = description.substring(0, 160) + "…";
            }
        }

        let author = "";
        let strong = el.select("strong").first();
        let match = /作者[：:]\s*([^\s，,》]+)/.exec(strong ? strong.text() : "");
        if (match) author = match[1];

        items.push({
            name: name,
            link: href,
            description: description,
            tag: author
        });
    }

    if (items.length === 0) return Response.error("Không có dữ liệu");
    // Blogger label pages carry no cover; give each novel a stable thumb.
    return Response.success(thumbAll(items), "");
}
