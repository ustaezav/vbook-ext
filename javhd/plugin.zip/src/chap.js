load('config.js');
load('crypto.js');

function execute(url) {
    let sv = (url.match(/[?&]sv=(\d+)/) || [])[1] || "1";
    let page = url.replace(/[?&]sv=\d+/, "");
    page = normalizeUrl(page);
    let id = (page.match(/-(\d+)\.html/) || [])[1] || "";
    if (!id) return Response.error("URL không hợp lệ");

    let response = fetch(BASE_URL + "/ajax", {
        method: "POST",
        headers: { "Referer": page, "Content-Type": "application/json" },
        body: JSON.stringify({ id: Number(id), server: Number(sv) })
    });
    if (!response.ok) return Response.error("HTTP " + response.status);

    let data;
    try {
        data = response.json();
    } catch (e) {
        return Response.error("Phản hồi không hợp lệ");
    }

    let player = String(data.player || "");
    let stream = "";
    let m = player.match(/atob\("([^"]+)"\)/);
    if (m) {
        try {
            stream = CryptoJS.enc.Utf8.stringify(CryptoJS.enc.Base64.parse(m[1]));
        } catch (e) {
            stream = "";
        }
    }
    if (!stream) {
        let ifr = player.match(/src="([^"]+)"/);
        if (ifr && ifr[1].indexOf("http") === 0) stream = ifr[1];
    }
    if (!stream) return Response.error("Không tìm thấy nguồn phát");

    return Response.success([{ title: "Server " + sv, data: stream }]);
}
