load('config.js');

function execute(query, page) {
    query = String(query || "");
    page = String(page || "1");

    let base;
    if (query.indexOf("http") === 0) {
        base = query;
    } else if (query.indexOf("/") === 0) {
        base = BASE_URL + query;
    } else if (query) {
        base = BASE_URL + "/search/" + encodeURIComponent(query) + "/";
    } else {
        base = BASE_URL + "/video/";
    }

    let response = fetch(pageUrl(base, page));
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = [];
    doc.select("#movie-last-movie a.movie-item").forEach(function (el) {
        let name = el.select(".movie-title-1").text() || el.attr("title");
        let href = el.attr("href");
        if (!name || !href) return;
        items.push({
            name: name,
            cover: el.select("img.public-film-item-thumb").attr("src"),
            link: href.indexOf("http") === 0 ? href : BASE_URL + "/" + href.replace(/^\//, ""),
            description: el.select(".meta-sub, .ribbon-sub").text(),
            host: BASE_URL
        });
    });

    let p = parseInt(page, 10) || 1;
    let hasNext = false;
    doc.select(".navigation a.page-numbers").forEach(function (a) {
        let href = a.attr("href");
        if (href && href.indexOf("/page/" + (p + 1) + "/") !== -1) hasNext = true;
    });

    return Response.success(items, hasNext ? String(p + 1) : "");
}
