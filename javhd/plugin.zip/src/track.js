load('config.js');

function execute(data) {
    data = data || "";
    if (data.indexOf("http") !== 0) return Response.error("Nguồn phát không hợp lệ");

    if (data.indexOf(".m3u8") !== -1) {
        return Response.success({
            type: "native",
            data: data,
            host: BASE_URL,
            mimeType: "application/x-mpegURL",
            headers: { "User-Agent": UserAgent.chrome(), "Referer": BASE_URL + "/" },
            timeSkip: []
        });
    }
    if (data.indexOf(".mp4") !== -1) {
        return Response.success({
            type: "native",
            data: data,
            host: BASE_URL,
            mimeType: "video/mp4",
            headers: { "User-Agent": UserAgent.chrome(), "Referer": BASE_URL + "/" },
            timeSkip: []
        });
    }

    return Response.success({
        type: "auto",
        data: data,
        host: BASE_URL,
        headers: { "User-Agent": UserAgent.chrome(), "Referer": BASE_URL + "/" },
        timeSkip: []
    });
}
