function execute() {
    return Response.success([
        { title: "Mới nhất", input: "/video/", script: "search.js" },
        { title: "Trending", input: "/trending/", script: "search.js" },
        { title: "Uncensored", input: "/category/uncensored-3/", script: "search.js" },
        { title: "Censored", input: "/category/censored-2/", script: "search.js" },
        { title: "Beauty and more", input: "/category/beauty-4/", script: "search.js" }
    ]);
}
