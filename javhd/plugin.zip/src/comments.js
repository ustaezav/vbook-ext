load('config.js');

function execute(url, page) {
    url = normalizeUrl(url);
    let idMatch = url.match(/-(\d+)\.html/);
    let id = idMatch ? idMatch[1] : "";
    if (!id) return Response.success([], "");

    let offset = parseInt(page || "0", 10) || 0;

    let response = fetch(BASE_URL + "/loadComment", {
        method: "POST",
        headers: {
            "Referer": url,
            "X-Requested-With": "XMLHttpRequest",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        },
        body: "video_id=" + id + "&offset=" + offset + "&total=9999"
    });
    if (!response.ok) return Response.error("HTTP " + response.status);

    let data;
    try {
        data = response.json();
    } catch (e) {
        return Response.error("Phản hồi không hợp lệ");
    }

    let doc = Html.parse(String(data.movies || ""));
    let items = doc.select(".item").map(function (el) {
        let avatar = el.select("img.avatar").attr("src");
        if (avatar && avatar.indexOf("http") !== 0) {
            avatar = BASE_URL + "/" + avatar.replace(/^\//, "");
        }
        let text = el.select("p.comment-text .original-text");
        return {
            name: el.select(".title .pr-2").first().text(),
            avatar: avatar,
            content: text.size() > 0 ? text.html() : el.select("p.comment-text").html(),
            description: el.select(".inactive-color").text(),
            replies: []
        };
    });

    let count = parseInt(data.count, 10) || items.length;
    let next = count >= 10 ? String(offset + items.length) : "";
    return Response.success(items, next);
}
