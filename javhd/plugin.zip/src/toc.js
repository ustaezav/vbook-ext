load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let servers = doc.select(".user-action .server");
    let list = [];
    if (servers.size() === 0) {
        list.push({ name: "Server 1", url: url + "?sv=1", description: "", lock: false, pay: false });
    } else {
        for (let i = 0; i < servers.size(); i++) {
            let el = servers.get(i);
            let n = String(el.attr("id") || "").replace(/[^0-9]/g, "") || String(i + 1);
            list.push({ name: "Server " + n, url: url + "?sv=" + n, description: "", lock: false, pay: false });
        }
    }
    return Response.success(list);
}
