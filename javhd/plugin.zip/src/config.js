let BASE_URL = "https://javhdz.la";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function pageUrl(base, page) {
    page = parseInt(page, 10) || 1;
    if (base.charAt(base.length - 1) !== "/") base += "/";
    return page > 1 ? base + "page/" + page + "/" : base;
}
