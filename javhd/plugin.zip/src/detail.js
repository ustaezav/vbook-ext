load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let cover = doc.select("meta[property=og:image]").attr("content");
    if (cover && cover.indexOf("http") !== 0) {
        cover = BASE_URL + "/" + cover.replace(/^\//, "");
    }

    let description = doc.select(".block-movie-content").text().trim();
    if (!description) {
        description = doc.select("meta[name=description]").attr("content");
    }

    let genres = doc.select(".category a").map(function (el) {
        return { title: el.text(), input: el.attr("href"), script: "search.js" };
    });
    let tagItems = doc.select(".tag-list .tag-item a").map(function (el) {
        return { title: el.text(), input: el.attr("href"), script: "search.js" };
    });

    let view = doc.select(".icon-view").text().trim();
    let like = doc.select(".icon-like").text().trim();
    let category = doc.select(".category a").text().trim();

    let info = [];
    if (category) info.push("Thể loại: " + category);
    if (tagItems.length > 0) info.push("Từ khóa: " + tagItems.map(function (t) { return t.title; }).join(", "));
    if (view) info.push("Lượt xem: " + view);
    if (like) info.push("Thích: " + like);

    return Response.success({
        name: doc.select("h1").text().trim(),
        cover: cover,
        description: description,
        detail: info.join("\n"),
        url: url,
        type: "video",
        format: "series",
        ongoing: true,
        genres: genres.concat(tagItems),
        comments: [
            { title: "Bình luận", input: url, script: "comments.js" }
        ]
    });
}
