function execute() {
    return Response.success([
        { title: "Phim JavHD", input: "/video/", script: "search.js" },
        { title: "Trending", input: "/trending/", script: "search.js" },
        { title: "Uncensored", input: "/category/uncensored-3/", script: "search.js" },
        { title: "Censored", input: "/category/censored-2/", script: "search.js" },
        { title: "Beauty and more", input: "/category/beauty-4/", script: "search.js" },

        { title: "Vietsub", input: "/tag/vietsub/", script: "search.js" },
        { title: "JAV việt sub", input: "/tag/jav+việt+sub/", script: "search.js" },
        { title: "Sex HD", input: "/tag/sex+hd/", script: "search.js" },
        { title: "JAV full HD", input: "/tag/jav+full+hd/", script: "search.js" },
        { title: "Sex teen", input: "/tag/sex+teen/", script: "search.js" },
        { title: "Loạn luân", input: "/tag/loạn+luân/", script: "search.js" },
        { title: "Gái xinh", input: "/tag/gái+xinh/", script: "search.js" },
        { title: "Vụng trộm", input: "/tag/vụng+trộm/", script: "search.js" },
        { title: "Gái dâm", input: "/tag/gái+dâm/", script: "search.js" },
        { title: "Tập thể", input: "/tag/tập+thể/", script: "search.js" },
        { title: "Sex học đường", input: "/tag/sex+học+đường/", script: "search.js" },
        { title: "Hiếp dâm", input: "/tag/hiếp+dâm/", script: "search.js" },
        { title: "Bố chồng nàng dâu", input: "/tag/bố+chồng+nàng+dâu/", script: "search.js" },
        { title: "Sex văn phòng", input: "/tag/sex+văn+phòng/", script: "search.js" },
        { title: "Tokyo Hot", input: "/tag/Tokyo+Hot/", script: "search.js" },
        { title: "S-Cute", input: "/tag/S-Cute/", script: "search.js" }
    ]);
}
