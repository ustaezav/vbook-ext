load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    let doc = fetchDoc(url);
    if (!doc) return Response.error("Không mở được trang truyện");

    let titleEl = doc.select(".trangcon h1").first();
    if (titleEl === null) titleEl = doc.select("h1").first();
    let name = cleanText(titleEl === null ? "" : titleEl.text());

    let box = doc.select(".trangcon .box").first();
    let body = box === null ? "" : cleanText(box.text());

    // Stories are labelled "(Full)" when finished and "(Update ...)" while ongoing.
    let ongoing = name.indexOf("Full") === -1;
    let comic = isComic(doc);

    // Author and translator are usually written at the start of the first part.
    let author = "";
    let authorMatch = body.match(/(?:Tác giả|Tác Giả)\s*[::]\s*([^,<]{1,60})/);
    if (authorMatch) author = cleanText(authorMatch[1]);

    // Category comes from the breadcrumb; skip the home link.
    let genres = [];
    doc.select("#crumbs a").forEach(function (el) {
        let href = absUrl(el.attr("href"));
        let text = cleanText(el.text());
        if (!href || !text || text === "Trang chủ") return;
        if (href === siteOrigin() || href === siteOrigin() + "/") return;
        genres.push({ title: text, input: href, script: "search.js" });
    });

    return Response.success({
        name: name,
        author: author,
        cover: "",
        description: body.substring(0, 500),
        detail: "",
        url: url,
        type: comic ? "comic" : "novel",
        format: comic ? "comic" : "novel",
        ongoing: ongoing,
        genres: genres,
        tags: []
    });
}
