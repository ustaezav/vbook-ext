load('config.js');
// Each "Phần" of a story is one WordPress page of the same post; the part list
// ("Danh sách các phần") is rendered on every part, with the current part as a
// <span> and the others as <a>. The current span has no href, so rebuild it.
function execute(url) {
    url = normalizeUrl(url);
    let doc = fetchDoc(url);
    if (!doc) return Response.error("Không mở được mục lục");

    let base = url.replace(/\/+$/, "").replace(/\/\d+$/, "");

    let chapters = [];
    doc.select(".phantrangcon .post-page-numbers").forEach(function (el) {
        let name = cleanText(el.text());
        if (!name) return;
        let number = parseInt(name.replace(/[^0-9]/g, ""), 10);
        let href = el.attr("href");
        let link;
        if (href) {
            link = absUrl(href);
        } else if (!isNaN(number) && number > 1) {
            link = base + "/" + number + "/";
        } else {
            link = base + "/";
        }
        chapters.push({ name: name, url: link, description: "", lock: false, pay: false });
    });

    if (chapters.length === 0) {
        chapters.push({ name: "Phần 1", url: base + "/", description: "", lock: false, pay: false });
    }

    return Response.success(chapters);
}
