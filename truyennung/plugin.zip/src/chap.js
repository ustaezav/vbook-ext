load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    let doc = fetchDoc(url);
    if (!doc) return Response.error("Không mở được chương");

    let box = doc.select(".trangcon .box").first();
    if (box === null) return Response.error("Không tìm thấy nội dung chương");

    box.select("script, style, iframe, ins, .quangcao, .quangcaopc1, .quangcaomb1").forEach(function (el) {
        el.remove();
    });

    // Comic parts are an ordered list of page images.
    if (isComic(doc)) {
        let images = [];
        box.select("img").forEach(function (el) {
            let src = el.attr("src") || el.attr("data-src") || el.attr("data-lazy-src");
            if (src) images.push(absUrl(src));
        });
        if (images.length === 0) return Response.error("Không tìm thấy ảnh chương");
        return Response.success(images);
    }

    // The real chapter heading sits in the first bold line of the part text.
    let heading = cleanText(box.select("strong").first().text());

    return Response.success(box.html(), heading);
}
