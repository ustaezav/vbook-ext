load('config.js');
// search.js also powers the browse tabs (home/genre/explore "more"): those pass a
// category or tag URL as `query`. A keyword is anything that is neither a URL nor
// a "/"-prefixed path.
function execute(query, page) {
    query = query || "";
    page = page || "1";

    let url;
    if (query.indexOf("http") === 0) {
        let path = normalizeUrl(query).replace(/^https?:\/\/[^\/]+/, "");
        url = pagedPath(path, page);
    } else if (query.indexOf("/") === 0) {
        url = pagedPath(query, page);
    } else if (query) {
        url = pagedSearch(query, page);
    } else {
        url = pagedPath("/", page);
    }

    let doc = fetchDoc(url);
    if (!doc) return Response.error("Không tải được danh sách");

    return Response.success(listItems(doc), nextPageToken(doc, page));
}
