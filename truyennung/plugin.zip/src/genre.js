load('config.js');
// The main menu mixes categories and tag shortcuts; both are browsable through
// search.js, so expose them all as genres.
function execute() {
    let doc = fetchDoc(BASE_URL + "/");
    if (!doc) return Response.error("Không tải được thể loại");

    let genres = [];
    let seen = {};
    doc.select("#menu-menu-chinh a").forEach(function (el) {
        let href = absUrl(el.attr("href")).split("#")[0];
        let title = cleanText(el.text());
        if (!href || !title || title === "Trang Chủ" || seen[href]) return;
        seen[href] = true;
        genres.push({ title: title, input: href, script: "search.js" });
    });

    return Response.success(genres);
}
