// Shared code for the Truyennung extension. Every other script starts with
// load('config.js'); a loaded library must not load another file, so all helpers
// live here.

let BASE_URL = "https://truyennung.net";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

function siteOrigin() {
    let match = BASE_URL.match(/^(https?:\/\/[^\/]+)/);
    return match ? match[1] : BASE_URL;
}

// Rewrite an incoming url's host (mirror/www-prefixed) to BASE_URL, keeping path
// and query. Call this first thing in every url-receiving execute(url).
function normalizeUrl(url) {
    let match = String(url).match(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?[^\/\n]+(\/.*)$/);
    return match ? siteOrigin() + match[1] : String(url);
}

// Resolve a link found on a page into an absolute site url.
function absUrl(href) {
    if (!href) return "";
    href = String(href);
    if (/^https?:\/\//i.test(href)) return href;
    if (href.charAt(0) === "/") return siteOrigin() + href;
    return BASE_URL + "/" + href;
}

function cleanText(text) {
    return String(text === undefined || text === null ? "" : text)
        .replace(/[\s\u3000]+/g, " ")
        .trim();
}

// The site answers a first, cookie-less request with a small JS challenge page
// (it loads /min.js, computes a cookie and reloads). The challenge body always
// mentions slowAES; a solved session never contains it.
function isChallenge(text) {
    return text.indexOf("slowAES") !== -1 || text.indexOf("/min.js") !== -1;
}

// Solve the JS challenge with a headless WebView: loading the page runs the
// site's own script, which writes the anti-bot cookie; copy that cookie into the
// app's cookie jar so plain fetch() works for the rest of the session.
function solveChallenge() {
    let cookie = "";
    let browser = null;
    try {
        browser = Engine.newBrowser();
        browser.launch(BASE_URL + "/", 30000);
        cookie = cleanText(browser.callJs("document.cookie", 5000).text());
    } catch (error) {
        cookie = "";
    }
    if (browser) {
        try {
            browser.close();
        } catch (error) {
        }
    }
    if (cookie) {
        try {
            localCookie.setCookie(cookie);
        } catch (error) {
        }
        return true;
    }
    return false;
}

// Fetch a page and parse it. If the anti-bot challenge comes back instead of the
// real page, solve it once and retry. Returns a jsoup document, or null.
function fetchDoc(url) {
    let response = fetch(url);
    if (!response.ok) return null;

    let text = response.text();
    if (isChallenge(text)) {
        if (!solveChallenge()) return null;
        response = fetch(url);
        if (!response.ok) return null;
        text = response.text();
        if (isChallenge(text)) return null;
    }
    return Html.parse(text);
}

// Hentai posts are image comics while the other categories are text novels. The
// category link sits in the breadcrumb of both the detail page and every part
// page, so detail and chap classify a book identically. The image-heavy content
// check is a fallback for comic posts published outside that category.
function isComic(doc) {
    let comic = false;
    doc.select("#crumbs a").forEach(function (el) {
        if (String(el.attr("href")).indexOf("/truyen-heta") !== -1) comic = true;
    });
    if (comic) return true;

    let box = doc.select(".trangcon .box").first();
    if (box === null) return false;
    return box.select("img").size() >= 3 && cleanText(box.text()).length < 400;
}

// Home page renders each story as a bare link (div.ndnho a.post-title); search,
// category and tag pages render richer cards (div.news-image + div.news-desc).
function linkItem(el) {
    let link = el.select("a.post-title").first();
    if (link === null) return null;
    let href = absUrl(link.attr("href"));
    if (!href) return null;
    let name = cleanText(link.select("em").text()) || cleanText(link.attr("title"));
    if (!name) return null;
    return { name: name, link: href, host: siteOrigin() };
}

function cardItem(el) {
    let link = el.select(".news-desc a").first();
    if (link === null) return null;
    let href = absUrl(link.attr("href"));
    if (!href) return null;
    let name = cleanText(link.select("h2").text()) || cleanText(link.attr("title"));
    if (!name) return null;

    let img = el.select(".news-image img").first();
    let cover = img === null ? "" : (img.attr("src") || img.attr("data-src") || img.attr("data-lazy-src"));

    let description = el.select(".news-desc .desc").first();

    return {
        name: name,
        cover: cover,
        link: href,
        description: description === null ? "" : cleanText(description.text()),
        host: siteOrigin()
    };
}

// Read one listing page: prefer the card layout, fall back to the home-page links.
// The page wrapper is also a `.row.no-gutters`, so scope the cards to the listing.
function listItems(doc) {
    let items = [];
    let seen = {};
    function push(item) {
        if (!item || seen[item.link]) return;
        seen[item.link] = true;
        items.push(item);
    }

    doc.select(".row.listpost .row.no-gutters > div").forEach(function (el) {
        push(cardItem(el));
    });
    if (items.length === 0) {
        doc.select("div.ndnho").forEach(function (el) {
            push(linkItem(el));
        });
    }
    return items;
}

// WP-PageNavi renders a.nextpostslink only when a further page exists.
function nextPageToken(doc, page) {
    return doc.select("a.nextpostslink").isEmpty() ? "" : String(parseInt(page, 10) + 1);
}

// Build a paged URL for a path-style route (category, tag, home). WordPress
// serves page 1 at the base path and later pages under base/page/<n>/.
function pagedPath(path, page) {
    let number = parseInt(page, 10);
    if (isNaN(number) || number < 1) number = 1;
    let base = siteOrigin() + (String(path).charAt(0) === "/" ? path : "/" + path);
    base = base.replace(/\/+$/, "");
    return number === 1 ? base + "/" : base + "/page/" + number + "/";
}

// Same idea for the keyword search route: /?s=<q> and /page/<n>/?s=<q>.
function pagedSearch(query, page) {
    let number = parseInt(page, 10);
    if (isNaN(number) || number < 1) number = 1;
    let suffix = "?s=" + encodeURIComponent(query);
    return number === 1 ? siteOrigin() + suffix : siteOrigin() + "/page/" + number + "/" + suffix;
}
