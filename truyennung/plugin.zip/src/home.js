// Home tabs mirror the site's main menu. Each tab is a browse route handled by
// search.js; the empty input is the home "Mới cập nhật" feed.
function execute() {
    return Response.success([
        { title: "Mới cập nhật", input: "", script: "search.js" },
        { title: "Truyện 18+", input: "/truyen-18/", script: "search.js" },
        { title: "Dâm", input: "/truyen-dam/", script: "search.js" },
        { title: "Sex", input: "/truyen-sex/", script: "search.js" },
        { title: "Truyện Tình", input: "/truyen-tinh/", script: "search.js" },
        { title: "Giới Tính", input: "/gioi-tinh/", script: "search.js" },
        { title: "Truyện Hentai", input: "/truyen-heta/", script: "search.js" }
    ]);
}
