load('config.js');
// home.js — one tab per configured site; each tab's `input` is that site's list
// root, passed to search.js as `query` ("" = the primary site's newest posts).
function execute() {
    let tabs = [
        { title: "KR · Mới nhất", input: "", script: "search.js" }
    ];
    if (BASE_URL2) {
        tabs.push({ title: "JP · Mới nhất", input: BASE_URL2, script: "search.js" });
    }
    return Response.success(tabs);
}
