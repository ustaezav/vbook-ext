load('config.js');
// track.js — video only: an image post is a comic book, so it never reaches the
// player. `data` comes from chap.js and is always a direct media url; host and
// Referer follow the site that url belongs to (the two sources serve media from
// their own hosts).
function execute(data) {
    data = String(data || "");

    if (data.indexOf(".mp4") !== -1 || data.indexOf(".m3u8") !== -1) {
        let base = baseFor(data);
        return Response.success({
            type: "native",
            data: data,
            host: base,
            mimeType: data.indexOf(".mp4") !== -1 ? "video/mp4" : "application/x-mpegURL",
            headers: { "User-Agent": UserAgent.chrome(), "Referer": base + "/" },
            timeSkip: []
        });
    }

    return Response.error("Không hỗ trợ nguồn này");
}
