load('config.js');
// search.js — search screen, and the listing script for the home tabs ("" = the
// primary site's newest posts, an absolute url = that site's list) and every genre
// entry (an absolute idol-list url).
//
// Each site's own query endpoint (search.php) returns IDOLS, not posts, so a
// keyword is resolved to the posts of its top matching idols on every configured
// site.
let MAX_IDOLS_PER_SITE = 3;

// The site paginates with "/page/<n>/"; page 1 has no page segment.
function listingUrl(base, page) {
    let p = parseInt(page, 10);
    if (!p || p < 1) p = 1;
    let root = String(base).replace(/\/+$/, "");
    if (root === "") return p === 1 ? BASE_URL + "/" : BASE_URL + "/page/" + p + "/";
    if (root.indexOf("http") !== 0) root = BASE_URL + root;
    return p === 1 ? root + "/" : root + "/page/" + p + "/";
}

function readItems(doc, base) {
    let items = [];
    doc.select("article.post").forEach(function (el) {
        // Premium posts cannot be viewed without an account, so hide them.
        if (isPremiumItem(el)) return;

        let link = el.select("a[href^='/post/']").attr("href");
        if (!link) return;

        let name = el.select(".post-details-left a").text().trim();
        if (!name) name = el.select(".post-image img").attr("alt").trim();

        let cats = [];
        el.select(".post-categories a").forEach(function (tag) {
            let text = tag.text().trim();
            if (text) cats.push(text);
        });

        // The listing marks video posts with a video icon; only those may enter the
        // vertical short feed. An image post is a normal item that detail.js opens
        // as a comic, because the feed cannot render a still picture.
        let isVideo = el.select(".post-details-set i.icon-video").size() > 0;

        let thumb = el.select(".post-image img");
        items.push({
            name: name,
            cover: mediaUrl(thumb.attr("data-src") || thumb.attr("src"), base),
            link: base + link,
            description: cats.join(", "),
            tag: isVideo ? "Video" : "Ảnh",
            type: isVideo ? "short" : ""
        });
    });
    return items;
}

function fetchDoc(url) {
    let response = fetch(url, { headers: { "User-Agent": UserAgent.chrome() } });
    if (!response.ok) return null;
    return response.html();
}

// Keyword search: each site's search.php lists matching idols; collect the newest
// posts of the top matches from every configured site, primary site first.
function collectSite(keyword, base, items, seen) {
    let response = fetch(base + "/search.php?search=" + encodeURIComponent(keyword), {
        headers: { "User-Agent": UserAgent.chrome() }
    });
    if (!response.ok) return false;

    let idols = [];
    try {
        idols = response.json();
    } catch (error) {
        return false;
    }
    if (!idols || !idols.length) return true;

    let used = 0;
    for (let i = 0; i < idols.length && used < MAX_IDOLS_PER_SITE; i++) {
        let link = idols[i] ? String(idols[i].link) : "";
        if (!link) continue;
        used++;

        let full = link.indexOf("http") === 0 ? link : base + link;
        let doc = fetchDoc(listingUrl(full, 1));
        if (!doc) continue;

        let found = readItems(doc, base);
        for (let j = 0; j < found.length; j++) {
            if (seen[found[j].link]) continue;
            seen[found[j].link] = true;
            items.push(found[j]);
        }
    }
    return true;
}

function searchPosts(keyword) {
    let items = [];
    let seen = {};
    let ok = collectSite(keyword, BASE_URL, items, seen);
    if (BASE_URL2) {
        ok = collectSite(keyword, BASE_URL2, items, seen) || ok;
    }
    return ok ? items : null;
}

function execute(query, page) {
    query = String(query || "").trim();
    page = String(page || "1");

    if (query.indexOf("http") !== 0 && query.indexOf("/") !== 0 && query !== "") {
        let items = searchPosts(query);
        if (items === null) return Response.error("Không tìm được kết quả");
        return Response.success(items);
    }

    let listUrl = listingUrl(query, page);
    let doc = fetchDoc(listUrl);
    if (!doc) return Response.error("Không tải được danh sách");

    let hasNext = doc.select("a.page-link[aria-label=Next]").size() > 0;
    let next = hasNext ? (parseInt(page, 10) + 1).toString() : "";
    return Response.success(readItems(doc, baseFor(listUrl)), next);
}
