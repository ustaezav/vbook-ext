load('config.js');
// toc.js — a post is one chapter (the post page itself); its media are returned by
// chap.js. No request here on purpose: the short feed resolves many items in the
// background, so every request it skips keeps swiping smooth.
function execute(url) {
    url = siteUrl(url);
    return Response.success([
        { name: "Xem", url: url, description: "", lock: false, pay: false }
    ]);
}
