load('config.js');
// chap.js — the content of one post, shaped by the book type detail.js chose:
// a video post returns its switchable .mp4 tracks, an image post returns the plain
// image array the comic reader expects.
function execute(url) {
    url = siteUrl(url);

    let response = fetch(url, { headers: { "User-Agent": UserAgent.chrome() } });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    if (isPremiumPage(doc)) return Response.error("Bài viết Premium, cần tài khoản để xem");

    let media = readMedia(doc, baseFor(url));
    let tracks = [];

    for (let i = 0; i < media.videos.length; i++) {
        tracks.push({
            title: media.videos.length > 1 ? "Video " + (i + 1) : "Video",
            data: media.videos[i]
        });
    }

    if (tracks.length > 0) return Response.success(tracks);
    if (media.images.length > 0) return Response.success(media.images);
    return Response.error("Không có nội dung");
}
