load('config.js');
// detail.js — a post is either a "short" video or an image set, and the type is
// per post: video posts play in the vertical short feed, image posts are comics
// read in the image reader (the feed cannot display a still picture).
function execute(url) {
    url = siteUrl(url);

    let response = fetch(url, { headers: { "User-Agent": UserAgent.chrome() } });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    if (isPremiumPage(doc)) return Response.error("Bài viết Premium, cần tài khoản để xem");

    let media = readMedia(doc, baseFor(url));
    let isVideo = media.videos.length > 0;
    if (!isVideo && media.images.length === 0) return Response.error("Không tìm thấy nội dung");

    let tags = [];
    doc.select(".pb-block-tags a").forEach(function (el) {
        let href = el.attr("href");
        if (!href || href.indexOf("/") !== 0) return;
        let title = el.text().trim();
        if (!title) return;
        tags.push({ title: title, input: href, script: "search.js" });
    });

    return Response.success({
        name: postTitle(doc),
        author: doc.select("title").text(),
        cover: media.cover,
        description: doc.select("meta[name=description]").attr("content"),
        url: url,
        type: isVideo ? "video" : "comic",
        format: isVideo ? "short" : "comic",
        ongoing: true,
        nsfw: true,
        locale: "en",
        tags: tags,
        genres: [],
        suggests: [],
        reviews: [],
        comments: []
    });
}
