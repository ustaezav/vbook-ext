let BASE_URL = "https://example.com";
let BASE_URL2 = "https://example.com";
try {
  if (DOMAIN) {
    BASE_URL = DOMAIN;
  }
} catch (error) {}
try {
  if (DOMAIN2) {
    BASE_URL2 = DOMAIN2;
  }
} catch (error) {}
BASE_URL = String(BASE_URL).replace(/\/+$/, "");
BASE_URL2 = String(BASE_URL2).replace(/\/+$/, "");

// Host of an absolute or protocol-relative url, without a "www." prefix.
function hostOf(url) {
  let match = String(url)
    .replace(/^\/\//, "https://")
    .match(/^(?:https?:\/\/)?(?:[^@\n]+@)?([^:\/\n?#]+)/);
  if (!match) return "";
  return match[1].replace(/^www\./, "");
}

// The site a url belongs to: the second site keeps its own host, everything else
// (the primary site, mirrors, old domains) resolves to the primary one.
function baseFor(url) {
  if (BASE_URL2 && hostOf(url) === hostOf(BASE_URL2)) return BASE_URL2;
  return BASE_URL;
}

// Rewrite an incoming url's host to the site that owns it, keeping path/query.
// Relative paths are returned untouched.
function normalizeUrl(url) {
  let full = String(url);
  if (full.indexOf("http") !== 0 && full.indexOf("//") !== 0) return full;
  return full.replace(
    /^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/gim,
    baseFor(full),
  );
}

// The app strips a trailing "/" from url arguments, but both sites need it:
// /idols/<slug> 404s and /post/<id> answers 302 to the slashed form.
function siteUrl(url) {
  let full = normalizeUrl(url);
  let base = baseFor(full);
  if (full.indexOf(base) !== 0) return full;
  let cut = full.indexOf("?");
  let path = cut === -1 ? full : full.slice(0, cut);
  let query = cut === -1 ? "" : full.slice(cut);
  if (path.charAt(path.length - 1) !== "/") path += "/";
  return path + query;
}

// Media files are site-relative ("/files/src/...") on both sites and served from a
// protocol-relative media host elsewhere; return an absolute https url either way.
// `base` is the site the page was loaded from.
function mediaUrl(url, base) {
  if (!url) return "";
  if (url.indexOf("//") === 0) return "https:" + url;
  if (url.charAt(0) === "/") return (base || BASE_URL) + url;
  return url;
}

// A creator can mark a post premium: for anyone without access the site replaces
// the media with a paywall, so the post has nothing to play or read. The listing
// flags it with "post-premium" / a dashed creator badge ("btn-premium" without
// "dashed" is an ordinary creator tag), and the post page swaps the media for a
// ".premium" block.
function isPremiumItem(el) {
  if (el.attr("class").indexOf("post-premium") !== -1) return true;
  return el.select(".btn-premium-dashed").size() > 0;
}

function isPremiumPage(doc) {
  if (doc.select(".premium").size() > 0) return true;
  return doc.select("article.post-premium").size() > 0;
}

// The post page never prints its title; it is only in the meta description as
// "<title>. <comma,separated,tags>".
function postTitle(doc) {
  let meta = doc.select("meta[name=description]").attr("content");
  if (!meta) return doc.select("title").text();
  let cut = meta.indexOf(". ");
  return cut === -1 ? meta : meta.slice(0, cut);
}

// One post is one media list: <video><source> files and/or <a href> images.
// Only the first media item is loaded eagerly; the rest carry the real url in
// data-src and leave src empty, so read both.
// Cover is the first thumbnail (post-thumb row on galleries, video poster otherwise).
function readMedia(doc, base) {
  let videos = [];
  let images = [];

  doc.select(".post-media-item").forEach(function (el) {
    let src =
      el.select("source").attr("src") || el.select("source").attr("data-src");
    if (!src)
      src =
        el.select("video").attr("src") || el.select("video").attr("data-src");
    if (src) {
      videos.push(mediaUrl(src, base));
      return;
    }
    let href =
      el.attr("href") ||
      el.select("img").attr("data-src") ||
      el.select("img").attr("src");
    if (href) images.push(mediaUrl(href, base));
  });

  let cover =
    doc.select(".post-thumb").attr("src") ||
    doc.select("video").attr("data-poster") ||
    doc.select(".post-media-item img").attr("src");

  return { videos: videos, images: images, cover: mediaUrl(cover, base) };
}
