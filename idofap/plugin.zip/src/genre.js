load('config.js');
// genre.js — the idol A-Z list of every configured site; each entry opens that
// idol's post list through search.js. Entries carry the site they belong to, so
// the prefixes are the only place the two sources are told apart.
function readIdols(url, base, prefix) {
    let response = fetch(url, { headers: { "User-Agent": UserAgent.chrome() } });
    if (!response.ok) return [];

    let doc = response.html();
    let idols = [];
    doc.select("#az-slider .letter-section li a").forEach(function (el) {
        let href = el.attr("href");
        if (!href || href.indexOf("/idols/") !== 0) return;
        let title = el.text().trim();
        if (!title) return;
        idols.push({ title: prefix + title, input: base + href, script: "search.js" });
    });
    return idols;
}

function execute() {
    let genres = readIdols(BASE_URL + "/idols/", BASE_URL, "KR · ");
    if (BASE_URL2) {
        let jp = readIdols(BASE_URL2 + "/idols/", BASE_URL2, "JP · ");
        for (let i = 0; i < jp.length; i++) {
            genres.push(jp[i]);
        }
    }
    if (genres.length === 0) return Response.error("Không tải được thể loại");
    return Response.success(genres);
}
