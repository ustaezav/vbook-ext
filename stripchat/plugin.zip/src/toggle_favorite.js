load('config.js');

function bookName() {
    let info = localBook.getInfo();
    if (!info || !info.name) return "";
    let n = info.name;
    if (typeof n === "string") return n;
    if (typeof n === "object") {
        if (typeof n.raw === "string") return n.raw;
        for (let k in n) {
            if (typeof n[k] === "string") return n[k];
        }
    }
    return "";
}

function coverOf(info) {
    if (!info || !info.cover) return "";
    if (typeof info.cover === "string") return info.cover;
    return info.cover.raw || "";
}

function execute() {
    let info = localBook.getInfo();
    let name = bookName();
    if (!name) return Response.error("Không xác định được model.");

    if (storeHas("favorites", name)) {
        storeRemove("favorites", name);
        return Response.success("Đã xoá " + name + " khỏi Yêu thích.");
    }

    storePush("favorites", { n: name, c: coverOf(info), ts: Date.now() }, 0);
    return Response.success("Đã thêm " + name + " vào Yêu thích.");
}
