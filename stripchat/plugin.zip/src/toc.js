load('config.js');

function usernameFromUrl(url) {
    return url.split("?")[0].replace(/^https?:\/\/[^\/]+\//, "").replace(/\/+$/, "");
}

function pageInfo(username) {
    let out = { status: "", stream: "" };
    if (!username) return out;

    let response = fetch(BASE_URL + "/" + username, {
        headers: { "Accept": "text/html", "User-Agent": UserAgent.chrome() },
        timeout: 30000
    });
    if (!response || !response.ok) return out;

    let html = String(response.text() || "");
    let status = html.match(/"status":"(public|groupShow|private|privateGroupShow|p2p|virtual|off|offline)"/);
    if (status) out.status = status[1];
    let stream = html.match(/"streamName":"(\d+)"/);
    if (stream) out.stream = stream[1];
    return out;
}

// A non-watchable model is exposed as a locked episode so the app shows a locked
// state instead of opening the (unplayable) stream.
function execute(url) {
    url = normalizeUrl(url);
    let info = pageInfo(usernameFromUrl(url));

    let name = "Live";
    let lock = false;
    if (info.status === "off" || info.status === "offline") {
        name = "Model đã Offline";
        lock = true;
    } else if (info.status === "private" || info.status === "privateGroupShow" || info.status === "p2p") {
        name = "Model đang trong Private Show";
        lock = true;
    } else if (info.status === "groupShow") {
        name = "Model đang Group Show (cần ticket để xem)";
        lock = true;
    }

    // Favorite / history links carry no stream; hand it to chap.
    let episodeUrl = url;
    if (!queryParam(url, "s") && info.stream) {
        episodeUrl = url + (url.indexOf("?") === -1 ? "?" : "&") + "s=" + info.stream;
    }

    return Response.success([
        { name: name, url: episodeUrl, description: lock ? name : "", lock: lock, pay: false }
    ]);
}
