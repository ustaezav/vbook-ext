load('config.js');

let SOCIAL_LABELS = {
    twitter: "Twitter",
    instagram: "Instagram",
    snapchat: "Snapchat",
    facebook: "Facebook",
    faphouse: "FapHouse",
    xhamster: "xHamster",
    xhamsterPornstar: "xHamster Pornstar",
    fancentro: "FanCentro",
    myClub: "My Club"
};

function esc(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function unesc(s) {
    return String(s).replace(/\\u002F/g, "/");
}

function usernameFromUrl(url) {
    return url.split("?")[0].replace(/^https?:\/\/[^\/]+\//, "").replace(/\/+$/, "");
}

// Extract the double-quoted strings from a JSON array body like "\"en\",\"vi\"".
function strArray(body) {
    if (!body) return [];
    let out = [];
    let re = /"((?:[^"\\]|\\.)*)"/g;
    let m;
    while ((m = re.exec(body)) !== null) out.push(unesc(m[1]));
    return out;
}

function socialLabel(key) {
    if (SOCIAL_LABELS[key]) return SOCIAL_LABELS[key];
    return key.charAt(0).toUpperCase() + key.substring(1);
}

function socialLinks(h) {
    let block = h.match(/"socialLinks":\{"\d+":\{(.*?)\}\}/);
    if (!block) return [];
    let out = [];
    let re = /"([A-Za-z]+)":"((?:[^"\\]|\\.)*)"/g;
    let m;
    while ((m = re.exec(block[1])) !== null) {
        if (m[2]) out.push(socialLabel(m[1]));
    }
    return out;
}

// The model's private-show tip menu: [{activity, fullPrice, price}].
function tipMenu(h) {
    let block = h.match(/"tipMenu":\{.*?"settings":\[(.*?)\]\}/);
    if (!block) return [];
    let out = [];
    let re = /"activity":"((?:[^"\\]|\\.)*)","fullPrice":\d+,"price":(\d+)/g;
    let m;
    while ((m = re.exec(block[1])) !== null) {
        out.push(esc(unesc(m[1])) + " (" + m[2] + " token)");
    }
    return out;
}

function execute(url) {
    url = normalizeUrl(url);
    let stream = queryParam(url, "s");

    let username = usernameFromUrl(url);
    let cover = queryParam(url, "sn") || imgUrl(queryParam(url, "p")) || imgUrl(queryParam(url, "a"));
    let description = "";
    let details = [];

    let response = fetch(BASE_URL + "/" + username, {
        headers: { "Accept": "text/html", "User-Agent": UserAgent.chrome() },
        timeout: 30000
    });
    if (response && response.ok) {
        let h = String(response.text() || "");

        let ogd = h.match(/property="og:description" content="([^"]*)"/);
        let ogDescription = ogd ? ogd[1] : "";

        // Profile block, anchored on the unique "interestedIn" field.
        let anchor = h.indexOf('"interestedIn":"');
        let win = anchor >= 0 ? h.substring(Math.max(0, anchor - 900), anchor + 900) : h;

        // Prefer the freshly-built live snapshot.
        if (!cover) {
            let ts = win.match(/"snapshotTimestamp":"?(\d+)/);
            let mid = win.match(/"id":(\d+)/);
            cover = snapshotUrl(mid ? mid[1] : stream, ts ? ts[1] : "");
        }
        if (!cover) {
            let pv = h.match(/"previewUrl":"([^"]+)"/);
            if (pv) cover = unesc(pv[1]);
        }
        if (!cover) {
            let av = h.match(/"avatarUrl":"([^"]+)"/);
            if (av) cover = unesc(av[1]);
        }

        // The model's own name is the last "name" before the interestedIn field.
        let name = "";
        let nameRe = /"name":"((?:[^"\\]|\\.)*)"/g;
        let nameEnd = win.indexOf('"interestedIn":"');
        let scan = nameEnd >= 0 ? win.substring(0, nameEnd) : win;
        let nm;
        while ((nm = nameRe.exec(scan)) !== null) name = nm[1];

        let langs = win.match(/"languages":\[([^\]]*)\]/);
        let age = win.match(/"age":(\d+)/);
        let interestedIn = win.match(/"interestedIn":"([^"]*)"/);
        let bodyType = win.match(/"bodyType":"([^"]*)"/);
        let specifics = win.match(/"specifics":\[([^\]]*)\]/);
        let ethnicity = win.match(/"ethnicity":"([^"]*)"/);
        let hairColor = win.match(/"hairColor":"([^"]*)"/);
        let eyeColor = win.match(/"eyeColor":"([^"]*)"/);
        let subculture = win.match(/"subculture":"([^"]*)"/);
        let online = win.match(/"isOnline":(true|false)/);
        let country = win.match(/"country":"([^"]*)"/);
        let off = win.match(/"offlineStatus":"((?:[^"\\]|\\.)*)"/);

        let statusMatch = h.match(/"status":"(public|groupShow|private|privateGroupShow|p2p|virtual|off|offline)"/);
        let status = statusMatch ? statusMatch[1] : "";
        let notice = statusNotice(status);

        // Live show description (room topic) and the model's current token goal.
        let topic = liveTopic(h);
        let goal = liveGoal(h);

        let descLines = [];
        if (notice) descLines.push(notice);
        if (topic) descLines.push(topic);
        else if (ogDescription) descLines.push(ogDescription);
        if (goal) descLines.push("Mục tiêu: " + goal);
        description = descLines.join("\n");

        let langNames = strArray(langs ? langs[1] : "").map(langLabel);
        let specs = strArray(specifics ? specifics[1] : "").map(modelLabel);
        let socials = socialLinks(h);
        let menu = tipMenu(h);

        let lines = [];
        let add = function (label, value) {
            if (value) lines.push("<b>" + label + ":</b> " + value);
        };

        add("Tên", esc(unesc(name || username)));
        add("Mô tả", esc(topic || ogDescription));
        add("Mục tiêu", esc(goal));
        add("Ngôn ngữ", esc(langNames.join(", ")));
        add("Tuổi", age ? age[1] + " tuổi" : "");
        add("Quan tâm đến", esc(modelLabel(interestedIn ? interestedIn[1] : "")));
        add("Dáng người", esc(modelLabel(bodyType ? bodyType[1] : "")));
        add("Chi tiết", esc(specs.join(", ")));
        add("Dân tộc", esc(modelLabel(ethnicity ? ethnicity[1] : "")));
        add("Tóc", esc(modelLabel(hairColor ? hairColor[1] : "")));
        add("Màu mắt", esc(modelLabel(eyeColor ? eyeColor[1] : "")));
        add("Tiểu văn hóa", esc(modelLabel(subculture ? subculture[1] : "")));
        add("Quốc gia", esc(country ? country[1] : ""));
        let label = statusLabel(status);
        if (!label) label = (online && online[1] === "true" ? "Đang live" : "Offline");
        add("Trạng thái", esc(label));
        add("Liên kết mạng xã hội", esc(socials.join(", ")));
        add("Hoạt động của tôi trong Show Riêng Tư", menu.join("<br>"));
        add("Ghi chú", esc(unesc(off ? off[1] : "")));

        details.push(lines.join("<br>"));
    }

    return Response.success({
        name: username,
        cover: cover,
        description: description,
        detail: details.length ? details[0] : "",
        url: url,
        type: "video",
        format: "short",
        ongoing: true,
        nsfw: true
    });
}
