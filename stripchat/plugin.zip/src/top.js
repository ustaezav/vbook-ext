load('config.js');

// Top rankings. query = "<gender>/<slug>", e.g. "female/current-month-asia-and-pacific".
// The API needs gender + period (+ continent for the geo groups) and pages by offset.
function execute(query, page) {
    let parts = String(query || "").split("/");
    let gender = parts[0] || "female";
    let slug = parts[1] || "current-month";

    let offset = parseInt(page || "0", 10);
    if (isNaN(offset) || offset < 0) offset = 0;

    let period = "current";
    if (slug.indexOf("recent-month") === 0) period = "monthly";
    else if (slug === "recent") period = "hourly";
    else if (slug === "hall-of-fame") period = "hallOfFame";

    let continent = "";
    if (slug.indexOf("africa") !== -1) continent = "af";
    else if (slug.indexOf("asia") !== -1) continent = "as";
    else if (slug.indexOf("europe") !== -1) continent = "eu";
    else if (slug.indexOf("north-america") !== -1) continent = "na";
    else if (slug.indexOf("south-america") !== -1) continent = "sa";

    let url = BASE_URL + "/api/front/v5/models/top?gender=" + gender + "&period=" + period +
        "&limit=100&offset=" + offset + (continent ? "&continent=" + continent : "");

    let response = fetch(url, { headers: apiHeaders(), timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);

    let json;
    try {
        json = response.json();
    } catch (error) {
        return Response.error("Phản hồi không hợp lệ");
    }

    let data = (json && json.items) ? json.items : [];
    let items = [];
    let seen = {};
    for (let i = 0; i < data.length; i++) {
        let m = data[i] ? data[i].model : null;
        if (!m || !m.username || (!m.streamName && !m.id)) continue;
        if (seen[m.username]) continue;
        seen[m.username] = 1;
        let item = modelToItem(m);
        item.description = "#" + data[i].position + (m.country ? " · " + m.country : "");
        items.push(item);
    }

    let total = json && json.total ? json.total : 0;
    let next = (data.length > 0 && offset + 100 < total) ? String(offset + 100) : "";
    return Response.success(items, next);
}
