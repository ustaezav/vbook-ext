// Vietnamese labels for the site's i18n codes (from the site's vi translations).
let LABELS = {
  "bodyType": "Dáng người",
  "bodyTypeAthletic": "Cơ bắp",
  "bodyTypeAverage": "Cân đối",
  "bodyTypeBBW": "BBW",
  "bodyTypeBig": "Lớn",
  "bodyTypeChunky": "Mập mạp",
  "bodyTypeCurvy": "Mập mạp",
  "bodyTypeLarge": "Lớn",
  "bodyTypeMedium": "Vừa",
  "bodyTypeMuscular": "Cơ bắp",
  "bodyTypePetite": "Nhỏ nhắn",
  "bodyTypeSkinny": "Gầy",
  "bodyTypeThin": "Gầy",
  "ethnicity": "Dân tộc",
  "ethnicityAsian": "Châu Á",
  "ethnicityEbony": "Da màu",
  "ethnicityFrench": "Pháp",
  "ethnicityGerman": "Đức",
  "ethnicityIndian": "Người Ấn",
  "ethnicityItalian": "Ý",
  "ethnicityLatino": "Latina",
  "ethnicityMiddleEastern": "Ả Rập",
  "ethnicityMixed": "Hỗn hợp",
  "ethnicityMultiracial": "Hỗn hợp",
  "ethnicityRussian": "Nga",
  "ethnicitySpanish": "Tây Ban Nha",
  "ethnicityWhite": "Da trắng",
  "eyeColor": "Màu mắt",
  "eyeColorBlack": "Đen",
  "eyeColorBlue": "Xanh",
  "eyeColorBrown": "Nâu",
  "eyeColorGreen": "Xanh lục",
  "eyeColorGrey": "Xám",
  "eyeColorHazel": "Hạt dẻ",
  "hairColor": "Tóc",
  "hairColorBlack": "Tóc Nâu",
  "hairColorBlonde": "Tóc vàng",
  "hairColorBrown": "Đen",
  "hairColorBrownJustBlack": "Tóc đen",
  "hairColorBrunettes": "Tóc nâu",
  "hairColorColorful": "Sặc Sỡ",
  "hairColorHairless": "Hói",
  "hairColorOther": "Khác",
  "hairColorRed": "red",
  "interestedIn": "Quan tâm đến",
  "interestedInEverybody": "Mọi người",
  "interestedInMen": "Nam",
  "interestedInTranssexuals": "Người chuyển giới",
  "interestedInWomen": "Nữ",
  "specific": "Chi tiết",
  "specificBBC": "BBC",
  "specificBeardy": "Râu quai nón",
  "specificBigAss": "Mông To",
  "specificBigBalls": "Viên Bi To",
  "specificBigClit": "Âm Vật Lớn",
  "specificBigCock": "Dương Vật To",
  "specificBigNipples": "Núm Vú Lớn",
  "specificBigTits": "Ngực Khủng",
  "specificBoots": "Ủng",
  "specificBubblebutt": "Mông nảy",
  "specificCD": "Mặc đồ khác giới",
  "specificCut": "Cắt",
  "specificFemboy": "Chàng gái",
  "specificFtM": "Nữ thành nam",
  "specificHairy": "Cô Bé Rậm Lông",
  "specificHairyArmpits": "Nách rậm lông",
  "specificHairyMan": "Rậm lông",
  "specificInterracial": "Đa chủng tộc",
  "specificJeans": "Đồ Jeans",
  "specificLesbians": "Đồng tính nữ",
  "specificMtF": "Nam thành nữ",
  "specificMustache": "Ria mép",
  "specificNoPiercing": "Không xỏ khuyên",
  "specificNoTattoos": "Không có hình xăm",
  "specificNonBinary": "Phi nhị phân",
  "specificPOV": "POV",
  "specificPiercing": "Xỏ khuyên",
  "specificPowerBottom": "Bot Mạnh",
  "specificPowerTop": "Top Mạnh",
  "specificPregnant": "Mang thai",
  "specificQueer": "Đồng tính",
  "specificShaven": "Cạo Trọc",
  "specificShemale": "Nàng trai",
  "specificSide": "Bên",
  "specificSissy": "Chị em",
  "specificSkinny": "Gầy",
  "specificSmallCock": "Dương Vật Nhỏ",
  "specificSmallTits": "Ngực Nhỏ",
  "specificSneakersSocks": "Giày thể thao & Tất",
  "specificSportGear": "Phụ kiện Thể thao",
  "specificTG": "Người chuyển giới",
  "specificTS": "Người chuyển giới tính",
  "specificTV": "Đảo trang phục",
  "specificTattoos": "Hình xăm",
  "specificTomboy": "Nàng trai",
  "specificTrimmed": "Gọn gàng",
  "specificUncut": "Chưa cắt",
  "specificUniform": "Đồng phục",
  "specificVers": "Linh hoạt",
  "specifics": "Chi tiết",
  "specificsBBC": "BBC",
  "specificsBeardy": "Râu quai nón",
  "specificsBigAss": "Mông To",
  "specificsBigBalls": "Viên Bi To",
  "specificsBigClit": "Âm Vật Lớn",
  "specificsBigCock": "Dương Vật To",
  "specificsBigNipples": "Núm Vú Lớn",
  "specificsBigTits": "Ngực Khủng",
  "specificsBoots": "Ủng",
  "specificsBubblebutt": "Mông nảy",
  "specificsCD": "Mặc đồ khác giới",
  "specificsCut": "Cắt",
  "specificsFemboy": "Chàng gái",
  "specificsFtM": "Nữ thành nam",
  "specificsHairy": "Cô Bé Rậm Lông",
  "specificsHairyArmpits": "Nách rậm lông",
  "specificsHairyMan": "Rậm lông",
  "specificsInterracial": "Đa chủng tộc",
  "specificsJeans": "Đồ Jeans",
  "specificsLesbians": "Đồng tính nữ",
  "specificsMtF": "Nam thành nữ",
  "specificsMustache": "Ria mép",
  "specificsNoPiercing": "Không xỏ khuyên",
  "specificsNoTattoos": "Không có hình xăm",
  "specificsNonBinary": "Phi nhị phân",
  "specificsPOV": "POV",
  "specificsPiercing": "Xỏ khuyên",
  "specificsPowerBottom": "Bot Mạnh",
  "specificsPowerTop": "Top Mạnh",
  "specificsPregnant": "Mang thai",
  "specificsQueer": "Đồng tính",
  "specificsShaven": "Cạo Trọc",
  "specificsShemale": "Nàng trai",
  "specificsSide": "Bên",
  "specificsSissy": "Chị em",
  "specificsSkinny": "Gầy",
  "specificsSmallCock": "Dương Vật Nhỏ",
  "specificsSmallTits": "Ngực Nhỏ",
  "specificsSneakersSocks": "Giày thể thao & Tất",
  "specificsSportGear": "Phụ kiện Thể thao",
  "specificsTG": "Người chuyển giới",
  "specificsTS": "Người chuyển giới tính",
  "specificsTV": "Đảo trang phục",
  "specificsTattoos": "Hình xăm",
  "specificsTomboy": "Nàng trai",
  "specificsTrimmed": "Gọn gàng",
  "specificsUncut": "Chưa cắt",
  "specificsUniform": "Đồng phục",
  "specificsVers": "Linh hoạt",
  "subculture": "Tiểu văn hóa",
  "subcultureAnime": "Anime",
  "subcultureBdsm": "BDSM",
  "subcultureBears": "Gay già",
  "subcultureBottom": "Thụ",
  "subcultureChubbies": "Mũm mĩm",
  "subcultureClubber": "Người đi club",
  "subcultureCubs": "Trai trẻ",
  "subcultureCuckold": "Quan hệ tay ba",
  "subcultureDragQueens": "Drag Queen",
  "subcultureEboy": "E-boy",
  "subcultureEgirl": "E-girl",
  "subcultureEmo": "Emo",
  "subcultureGamers": "Game thủ",
  "subcultureGlamour": "Huyền ảo",
  "subcultureGoth": "Goth",
  "subcultureGymBabe": "Mấy Bé tập Gym",
  "subcultureGymRats": "Mấy Bé mê Gym",
  "subcultureHousewives": "Nội trợ",
  "subcultureHunks": "Vạm vỡ",
  "subcultureJocks": "Vận động viên",
  "subcultureKpop": "Thần tượng Hàn Quốc",
  "subcultureMistresses": "Tình nhân",
  "subcultureNerds": "Mọt sách",
  "subcultureNone": "Không có",
  "subcultureOtters": "Đồng tính nam",
  "subculturePunks": "Nổi loạn",
  "subcultureRomantic": "Lãng mạn",
  "subcultureStudent": "Học sinh",
  "subcultureStuds": "Cá tính mạnh",
  "subcultureSwingers": "Đổi bạn tình",
  "subcultureTop": "Công"
};

let LANGUAGES = {
  "ar": "Tiếng Ả Rập",
  "as": "Tiếng Assam",
  "bg": "Tiếng Bulgaria",
  "bn": "Tiếng Bengal",
  "br": "Tiếng Bồ Đào Nha (BR)",
  "cs": "Tiếng Séc",
  "da": "Tiếng Đan Mạch",
  "de": "Tiếng Đức",
  "el": "Tiếng Hy Lạp",
  "en": "Tiếng Anh",
  "es": "Tiếng Tây Ban Nha",
  "fi": "Tiếng Phần Lan",
  "fr": "Tiếng Pháp",
  "gu": "Tiếng Gujarat",
  "he": "Tiếng Do Thái",
  "hi": "Tiếng Hindi",
  "hr": "Tiếng Croatia",
  "hu": "Tiếng Hungary",
  "id": "Tiếng Indonesia",
  "it": "Tiếng Ý",
  "ja": "Tiếng Nhật",
  "kn": "Tiếng Kannada",
  "ko": "Tiếng Hàn",
  "ml": "Tiếng Malayalam",
  "mr": "Tiếng Marathi",
  "ms": "Tiếng Mã Lai",
  "nl": "Tiếng Hà Lan",
  "nn": "Tiếng Na Uy (Nynorsk)",
  "no": "Tiếng Na Uy",
  "or": "Tiếng Odia",
  "pa": "Tiếng Punjabi",
  "pl": "Tiếng Ba Lan",
  "pt": "Tiếng Bồ Đào Nha",
  "ro": "Tiếng Romania",
  "ru": "Tiếng Nga",
  "sk": "Tiếng Slovak",
  "sq": "Tiếng Albania",
  "sr": "Tiếng Serbia",
  "sv": "Tiếng Thụy Điển",
  "ta": "Tiếng Tamil",
  "te": "Tiếng Telugu",
  "th": "Tiếng Thái",
  "tr": "Tiếng Thổ Nhĩ Kỳ",
  "uk": "Tiếng Ukraina",
  "vi": "Tiếng Việt",
  "zh": "Tiếng Trung Giản thể",
  "zt": "Tiếng Trung Phồn Thể"
};
// Category tags from /tags/girls, in popularity order: [code, Vietnamese title].
let CATEGORIES = [
  ["girls", "Nữ"],
  ["autoTagHandy", "The Handy"],
  ["autoTagP2P", "Cuộc gọi Video (Cam2Cam)"],
  ["doFingering", "Móc cua"],
  ["doDoggyStyle", "Quan hệ kiểu Doggy"],
  ["autoTagHd", "HD"],
  ["doMasturbation", "Thủ dâm"],
  ["doSpanking", "Đánh đòn"],
  ["doEroticDance", "Nhảy Khiêu Dâm"],
  ["doDildoOrVibrator", "Củ dildo hay Máy rung"],
  ["doBlowjob", "Thổi kèn"],
  ["autoTagRecordablePrivate", "Buổi Riêng tư Có thể ghi lại"],
  ["doStriptease", "Múa Thoát Y"],
  ["autoTagRecordablePublic", "Có thể ghi lại"],
  ["doOilShow", "Diễn với dầu"],
  ["smallAudience", "Đầy Hứa Hẹn & Đúng Gu của Bạn"],
  ["doTalk", "Cách nói Gợi Dục"],
  ["sexting", "Nhắn tin sex"],
  ["doSexToys", "Đồ chơi Tình dục"],
  ["doTopless", "Ở trần"],
  ["doTwerk", "Twerk"],
  ["doFootFetish", "Mê bàn chân"],
  ["doOrgasm", "Cực khoái"],
  ["doDeepThroat", "Bú tràn họng"],
  ["specificsBigAss", "Mông To"],
  ["doAhegao", "Ahegao"],
  ["heels", "Cao gót"],
  ["doTittyFuck", "Đẩy ngực"],
  ["ageYoung", "Người trẻ 22+"],
  ["autoTagInteractiveToy", "Đồ Chơi Tương Tác"],
  ["autoTagLovense", "Lovense"],
  ["doCowgirl", "Kiểu Cưỡi Ngựa"],
  ["doCamelToe", "Ngón chân lạc đà"],
  ["specificShaven", "Cạo Trọc"],
  ["doSquirt", "Phụt nước"],
  ["doRolePlay", "Đóng vai"],
  ["tagLanguageSpanishSpeaking", "Nói tiếng Tây Ban Nha"],
  ["privatePriceEight", "8-12 tk"],
  ["cockRating", "Đánh giá Dương vật"],
  ["doHandjob", "Sóc lọ"],
  ["autoTagBestPrivates", "Tốt nhất {#desktop}cho {/desktop}Riêng tư"],
  ["tagLanguageColombian", "Người Colombia"],
  ["doFlashing", "Lộ hàng"],
  ["doHumiliation", "Làm nhục"],
  ["hairColorBlack", "Tóc Nâu"],
  ["ethnicityLatino", "Latina"],
  ["specificsBigTits", "Ngực Khủng"],
  ["doAnal", "Hậu môn"],
  ["jerkOffInstruction", "Hướng dẫn Tự sướng"],
  ["doFootjob", "Xóc bằng chân"],
  ["privateP2PPriceTwelveTwentyFour", "P2P: 12-24 token/phút"],
  ["bodyTypePetite", "Nhỏ nhắn"],
  ["doAnalToys", "Đồ Chơi Hậu Môn"],
  ["doUpskirt", "Vén váy"],
  ["doMassage", "Mát-xa"],
  ["hairColorBrown", "Tóc đen"],
  ["privateP2PPriceThirtyTwoSixty", "P2P: 32-60 token/phút"],
  ["doSmoking", "Hút thuốc"],
  ["bodyTypeMedium", "Vừa"],
  ["subcultureStudent", "Học sinh"],
  ["specificSmallTits", "Ngực Nhỏ"],
  ["doNippleToys", "Đồ chơi núm vú"],
  ["specificBigNipples", "Núm Vú Lớn"],
  ["doShower", "Tắm vòi sen"],
  ["doCreamPie", "Xuất Trong"],
  ["privatePriceSixteenToTwentyFour", "16-24 tk"],
  ["doGagging", "Bịt miệng"],
  ["doFacial", "Xuất lên mặt"],
  ["ethnicityWhite", "Da trắng"],
  ["doCumshot", "Xuất tinh"],
  ["doFacesitting", "Ngồi lên mặt"],
  ["doDoublePenetration", "Thâm Nhập Kép"],
  ["nylon", "Nylon"],
  ["specificBigClit", "Âm Vật Lớn"],
  ["bodyTypeCurvy", "Tròn trịa"],
  ["specificTrimmed", "Gọn gàng"],
  ["mobile", "Di Động"],
  ["subcultureMistresses", "Nhân tình"],
  ["privatePriceThirtyTwoSixty", "32-60 tk"],
  ["doAssToMouth", "Mông đến Miệng"],
  ["ageTeen", "Thiếu nữ 18+"],
  ["doYoga", "Yoga"],
  ["autoTagNew", "Mới{#desktop} Người Mẫu{/desktop}"],
  ["subcultureRomantic", "Lãng mạn"],
  ["specificPOV", "POV"],
  ["ethnicityEbony", "Da màu"],
  ["ageMilf", "Gái Mẹ MILF"],
  ["leather", "Da"],
  ["doCooking", "Nấu ăn"],
  ["do69Position", "Tư thế 69"],
  ["doCosplay", "Hoá trang"],
  ["doPublicPlace", "Ngoài trời"],
  ["specificsHairy", "Cô Bé Rậm Lông"],
  ["hairColorBlonde", "Tóc vàng"],
  ["subcultureGlamour", "Huyền ảo"],
  ["doOffice", "Văn phòng"],
  ["latex", "Latex"],
  ["subcultureCuckold", "Quan hệ tay ba"],
  ["corset", "Áo coóc-xê"],
  ["doFisting", "Nắm đấm tay"],
  ["specificsTattoos", "Hình Xăm"],
  ["privateP2PNinetyPlus", "P2P: 90+ token/phút"],
  ["european", "Cặp Đôi Châu Âu"],
  ["doPussyLicking", "Liếm \"cô bé\""],
  ["subcultureGymBabe", "Mấy Bé tập Gym"],
  ["tagLanguageAfrican", "Người châu Phi"],
  ["doGape", "Há miệng"],
  ["subcultureHousewives", "Nội trợ"],
  ["fuckMachine", "Cỗ Máy Làm Tình"],
  ["specificSportGear", "Phụ kiện Thể thao"],
  ["specificJeans", "Đồ Jeans"],
  ["bodyTypeAthletic", "Thể thao"],
  ["doStrapon", "Dây strapon"],
  ["tagLanguageKenyan", "Người Kenya"],
  ["specificsPiercing", "Xỏ khuyên"],
  ["subcultureAnime", "Anime"],
  ["doKissing", "Hôn"],
  ["couples", "Cặp đôi"],
  ["specificHairyArmpits", "Nách rậm lông"],
  ["ethnicityAsian", "Châu Á"],
  ["subcultureGoth", "Goth"],
  ["doPegging", "Nữ đóng cọc"],
  ["autoTagSpy", "Xem lén{#desktop} các Buổi diễn{/desktop}"],
  ["hairColorColorful", "Sặc Sỡ"],
  ["hairColorRed", "Tóc đỏ"],
  ["subcultureGamers", "Game thủ"],
  ["subcultureClubber", "Người đi club"],
  ["privatePriceNinetyPlus", "90+ tk"],
  ["subcultureTop", "Công"],
  ["bodyTypeBBW", "BBW"],
  ["bodyTypeBig", "Lớn"],
  ["privateP2PPriceEight", "P2P: 8 token/phút"],
  ["subcultureEgirl", "E-girl"],
  ["ethnicityIndian", "Người Ấn"],
  ["tagLanguageRussianSpeaking", "Nói tiếng Nga"],
  ["doGloryHole", "Lỗ Xuyên Tường"],
  ["ethnicityMultiracial", "Hỗn hợp"],
  ["doBukkake", "Bắn đầy mặt"],
  ["doHardcore", "Cực mạnh"],
  ["subcultureSwingers", "Đổi đào"],
  ["subcultureNerds", "Mọt sách"],
  ["ageMature", "Trưởng thành"],
  ["doSwallow", "Nuốt"],
  ["subcultureEmo", "Emo"],
  ["tagLanguageSouthAfrican", "Người Nam Phi"],
  ["doRimming", "Liếm hậu môn"],
  ["subcultureKpop", "Thần tượng Hàn Quốc"],
  ["tagLanguageRomanian", "Người Romania"],
  ["autoTagVr", "VR{#desktop} Cam{/desktop}"],
  ["doEjaculation", "Xuất tinh"],
  ["ethnicityMiddleEastern", "Ả Rập"],
  ["tagLanguageHindi", "Nói tiếng Hindi"],
  ["promoted", "Lựa Chọn Biên Tập"],
  ["groupShow", "Show có vé & Show nhóm"],
  ["doCumPlay", "Xuất Cực Khoái"],
  ["tagLanguageUSModels", "Người Mỹ"],
  ["tagLanguageVenezuelan", "Người Venezuela"],
  ["autoTagLesbian", "Đồng tính nữ"],
  ["tagLanguageUkrainian", "Người Ukraine"],
  ["doRubbing", "Cọ xát"],
  ["specificTomboy", "Nàng trai"],
  ["doSph", "SPH (Sự hạ nhục dương vật nhỏ)"],
  ["asmr", "ASMR"],
  ["doSelfsucking", "Tự bú mút"],
  ["doCei", "CEI (Chỉ dẫn ăn tinh trùng)"],
  ["subcultureBottom", "Thụ"],
  ["subcultureBdsm", "BDSM"],
  ["specificBubblebutt", "Mông nảy"],
  ["subculturePunks", "Nổi loạn"],
  ["tagLanguagePortugueseSpeaking", "Nói Tiếng Bồ Đào Nha"],
  ["doFlexing", "Uốn éo"],
  ["tagLanguageFilipino", "Mẫu Philippines"],
  ["tagLanguageChinese", "Người Trung"],
  ["tagLanguageUKModels", "Người mẫu Anh quốc"],
  ["tagLanguageBrazilian", "Người Brazil"],
  ["specificBigBalls", "Viên Bi To"],
  ["tagGroupSex", "Sex theo Nhóm"],
  ["specificQueer", "Đồng tính"],
  ["doPenisRing", "Nhẫn Dương Vật"],
  ["specificPowerTop", "Top Mạnh"],
  ["tagLanguageFrench", "Pháp"],
  ["tagLanguageItalian", "Ý"],
  ["tagLanguageVietnamese", "Người Việt"],
  ["doPrecum", "Tinh đầu"],
  ["specificNonBinary", "Phi nhị phân"],
  ["tagLanguageGermanSpeaking", "Đức"],
  ["videoGames", "Trò Chơi Điện Tử"],
  ["specificSneakersSocks", "Giày thể thao & Tất"],
  ["ageOld", "Bà lão"],
  ["doThreesome", "Chơi tay ba"],
  ["autoTagOldYoung", "Người già & Người trẻ 22+"],
  ["specificBeardy", "Râu quai nón"],
  ["tagLanguageTurkish", "Người Thổ Nhĩ Kỳ"],
  ["tagLanguageMoroccan", "Ma Rốc"],
  ["doGangbang", "Quan hệ tập thể"],
  ["subcultureChubbies", "Mũm mĩm"],
  ["specificPregnant", "Mang thai"],
  ["doChastity", "Kiềm chế"],
  ["subcultureJocks", "Vận động viên"],
  ["specificVers", "Linh hoạt"],
  ["doPump", "Bơm"],
  ["tagLanguageSpanish", "Tây Ban Nha"],
  ["specificMustache", "Ria mép"],
  ["specificPowerBottom", "Bot Mạnh"],
  ["tagLanguageArgentinian", "Người Argentina"],
  ["tagLanguageZimbabwean", "Người Zimbabwe\\n"],
  ["specificUniform", "Đồng phục"],
  ["hairColorHairless", "Hói"],
  ["subcultureStuds", "Cá tính mạnh"],
  ["tagLanguageBengali", "Nói tiếng Bengali"],
  ["trans", "Chuyển giới"],
  ["doFoursome", "Chơi tay tư"],
  ["specificBoots", "Ủng"],
  ["subcultureGymRats", "Mấy Bé mê Gym"],
  ["tagLanguageCanadian", "Người Canada"],
  ["tagLanguageMexican", "Người Mexico"],
  ["autoTagNonNude", "Tán tỉnh"],
  ["tagLanguageBangladeshi", "Người Bangladesh"],
  ["tagLanguageJapanese", "Tiếng Nhật"],
  ["tagLanguagePunjabi", "Nói tiếng Punjabi"],
  ["subcultureHunks", "Vạm vỡ"],
  ["tagLanguageTamil", "Nói tiếng Tamil"],
  ["specificCut", "Cắt"],
  ["tagLanguageDutch", "Người Hà Lan"],
  ["tagLanguageSriLankan", "Người Sri Lanka"],
  ["specificSide", "Bên"],
  ["subcultureCubs", "Trai trẻ"],
  ["subcultureEboy", "E-boy"],
  ["tagLanguageHungarian", "Người Hungary"],
  ["tagLanguagePortuguese", "Người Bồ Đào Nha"],
  ["tagLanguageTelugu", "Nói tiếng Telugu"],
  ["subcultureDragQueens", "Drag Queen"],
  ["tagLanguageAustrian", "Người Áo"],
  ["tagLanguageEcuadorian", "Người Ecuador"],
  ["tagLanguagePolish", "Người Ba Lan"],
  ["specificBBC", "BBC"],
  ["specificLesbians", "Đồng tính nữ"],
  ["tagLanguageChilean", "Người Chile"],
  ["specificTS", "Người chuyển giới tính"],
  ["subcultureOtters", "Đồng tính nam"],
  ["tagLanguageEgyptian", "Ai Cập"],
  ["tagLanguageGreek", "Tiếng Hy Lạp"],
  ["tagLanguageNordic", "Bắc Âu"],
  ["tagLanguagePeruvian", "Người Peru"],
  ["specificInterracial", "Đa chủng tộc"],
  ["tagLanguageMarathi", "Nói tiếng Marathi"],
  ["tagLanguageSerbian", "Người Serbia"],
  ["tagLanguageThai", "Người Thái"],
  ["vTubers", "YouTuber ảo"],
  ["specificShemale", "Nàng trai"],
  ["specificTG", "Người chuyển giới"],
  ["specificTV", "Đảo trang phục"],
  ["tagLanguageNigerian", "Người Nigeria"],
  ["tagLanguageSwiss", "Tiếng Thụy Sĩ"],
  ["specificFtM", "Nữ thành nam"],
  ["tagLanguageAlgerian", "Algérie"],
  ["tagLanguageDominican", "Người Dominica"],
  ["tagLanguageIrish", "Người Ireland"],
  ["tagLanguageKannada", "Nói tiếng Kannada"],
  ["tagLanguageSwedish", "Người Thụy Điển"],
  ["autoTagKiiroo", "Kiiroo"],
  ["specificMtF", "Nam thành nữ"],
  ["specificsBigCock", "Dương Vật To"],
  ["tagLanguageAustralian", "Người Úc"],
  ["tagLanguageBelgian", "Người Bỉ"],
  ["tagLanguageCzech", "Người Séc"],
  ["tagLanguageIsraeli", "Người Israel"],
  ["tagLanguageMalayalam", "Nói tiếng Malayalam"],
  ["tagLanguageSlovakian", "Người Slovakia"],
  ["pornStar", "Ngôi sao khiêu dâm"],
  ["privateSpyPriceFourEight", "Spy: 4-8 token"],
  ["specificCD", "Mặc đồ khác giới"],
  ["tagLanguageBulgarian", "Người Bulgary"],
  ["tagLanguageCroatian", "Người Croatia"],
  ["tagLanguageDanish", "Người Đan Mạch"],
  ["tagLanguageEstonian", "Tiếng Estonia"],
  ["tagLanguageFinnish", "Người Phần Lan"],
  ["tagLanguageNorwegian", "Người Na Uy"],
  ["tagLanguageSlovenian", "Người Slovenia"],
  ["tagLanguageUgandan", "Người Uganda"]
];

let BASE_URL = "https://stripchat.global";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

// Image CDN (cdnBaseUrl from the site config).
let CDN = "https://static-proxy.strpst.com";
// HLS edge that serves a plain playlist (the doppiocdn edge returns an ad/decoy).
let HLS_EDGE = "https://edge-hls.saawsedge.com";

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function imgUrl(path) {
    if (!path) return "";
    if (path.indexOf("http") === 0) return path;
    return CDN + (path.charAt(0) === "/" ? path : "/" + path);
}

function masterUrl(streamName) {
    return HLS_EDGE + "/hls/" + streamName + "/master/" + streamName + ".m3u8";
}

// Live snapshot of the current broadcast (the model's real preview image).
function snapshotUrl(modelId, timestamp) {
    if (!modelId || !timestamp) return "";
    return "https://img.doppiocdn.org/snapshot/" + modelId + "/" + timestamp;
}

// Build a feed item from one model object of the models API.
function modelToItem(m) {
    let stream = m.streamName || m.id;
    // The live snapshot only exists for a broadcasting model; offline ones (top
    // rankings) fall back to the profile avatar.
    let live = m.status === "public" && m.isOnline !== false;
    let snap = live ? snapshotUrl(m.id, m.snapshotTimestamp || m.popularSnapshotTimestamp) : "";
    let cover = snap;
    if (!cover) cover = imgUrl(m.avatarUrl);
    if (!cover) cover = m.previewUrlThumbSmall ? imgUrl(m.previewUrlThumbSmall) : "";
    // The live stream name rotates each broadcast; it is carried in the link so the
    // feed can play without a per-item API round-trip.
    let link = BASE_URL + "/" + m.username +
        "?s=" + encodeURIComponent(stream) +
        "&a=" + encodeURIComponent(m.avatarUrl || "") +
        "&p=" + encodeURIComponent(m.previewUrlThumbSmall || "") +
        "&sn=" + encodeURIComponent(snap);
    return {
        name: m.username,
        cover: cover,
        link: link,
        description: m.country ? String(m.country) : "",
        tag: statusLabel(m.status),
        type: "short",
        host: BASE_URL
    };
}

// Keep only public, online models and drop duplicates.
function modelsToItems(models) {
    let seen = {};
    let items = [];
    for (let i = 0; i < models.length; i++) {
        let m = models[i];
        if (!m || !m.username || (!m.streamName && !m.id)) continue;
        if (m.isOnline === false) continue;
        if (m.status !== "public") continue;
        if (seen[m.username]) continue;
        seen[m.username] = 1;
        items.push(modelToItem(m));
    }
    return items;
}

// --- persistent per-extension storage (favorites / history) ---

function lsReadList(key) {
    let raw = localStorage.getItem(key);
    if (!raw) return [];
    let arr;
    try {
        arr = JSON.parse(raw);
    } catch (error) {
        return [];
    }
    return arr && arr.length ? arr : [];
}

function lsWriteList(key, arr) {
    localStorage.setItem(key, JSON.stringify(arr));
}

// Stored entries ({n: name, c: cover, t: text}) as feed items.
function storedItems(key) {
    let arr = lsReadList(key);
    let items = [];
    for (let i = 0; i < arr.length; i++) {
        let e = arr[i];
        if (!e || !e.n) continue;
        items.push({
            name: e.n,
            cover: e.c || "",
            link: BASE_URL + "/" + e.n,
            tag: e.t || "",
            type: "short",
            host: BASE_URL
        });
    }
    return items;
}

// Most-recent-first, de-duplicated by name.
function storePush(key, entry, cap) {
    let arr = lsReadList(key);
    let out = [entry];
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] && arr[i].n !== entry.n) out.push(arr[i]);
    }
    if (cap > 0 && out.length > cap) out = out.slice(0, cap);
    lsWriteList(key, out);
}

function storeRemove(key, name) {
    let arr = lsReadList(key);
    let out = [];
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] && arr[i].n !== name) out.push(arr[i]);
    }
    lsWriteList(key, out);
}

function storeHas(key, name) {
    let arr = lsReadList(key);
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] && arr[i].n === name) return true;
    }
    return false;
}

// stream -> { u: username, c: cover }. Written by chap, read by track on playback.
function rememberStream(stream, entry) {
    if (!stream) return;
    let map = null;
    let raw = localStorage.getItem("streams");
    if (raw) {
        try {
            map = JSON.parse(raw);
        } catch (error) {
            map = null;
        }
    }
    if (!map) map = {};
    map[stream] = entry;
    let keys = [];
    for (let k in map) keys.push(k);
    if (keys.length > 300) {
        keys.sort(function (a, b) { return Number(a) - Number(b); });
        for (let i = 0; i < keys.length - 300; i++) delete map[keys[i]];
    }
    localStorage.setItem("streams", JSON.stringify(map));
}

function streamEntry(stream) {
    if (!stream) return null;
    let raw = localStorage.getItem("streams");
    if (!raw) return null;
    let map;
    try {
        map = JSON.parse(raw);
    } catch (error) {
        return null;
    }
    return (map && map[stream]) ? map[stream] : null;
}

// Live show description (the room topic).
function liveTopic(html) {
    let m = String(html || "").match(/"topic":"((?:[^"\\]|\\.)*)"/);
    return m ? m[1].replace(/\\u002F/g, "/") : "";
}

// The live goal widget, e.g. "2045 tk — get naked and play dildo".
function liveGoal(html) {
    let block = String(html || "").match(/epic-goal-progress__information--view-cam">([\s\S]*?)<\/div>/);
    if (!block) return "";
    let inner = block[1];
    let tok = inner.match(/epic-goal-progress__tokens">([^<]*)</);
    let tokens = tok ? tok[1].replace(/\s+/g, " ").trim() : "";
    let text = "";
    let spans = inner.match(/<span>[\s\S]*?<\/span>/g) || [];
    for (let i = 0; i < spans.length; i++) {
        let t = spans[i].replace(/<[^>]*>/g, "").replace(/<!-- -->/g, "").replace(/\s+/g, " ").trim();
        if (t && t.indexOf("Goal") !== 0) text = t;
    }
    if (!tokens) return text;
    return tokens + (text ? " — " + text : "");
}

function streamHeaders() {
    return { "User-Agent": UserAgent.chrome(), "Referer": BASE_URL + "/" };
}

function apiHeaders() {
    return {
        "Accept": "application/json, text/plain, */*",
        "User-Agent": UserAgent.chrome(),
        "Referer": BASE_URL + "/"
    };
}

// Short Vietnamese label for a model status key.
function statusLabel(status) {
    switch (String(status)) {
        case "public": return "Đang live";
        case "groupShow": return "Group show (cần ticket)";
        case "privateGroupShow": return "Private group show (cần ticket)";
        case "private": return "Private show";
        case "p2p": return "Show riêng (P2P)";
        case "virtual": return "Virtual show";
        case "off":
        case "offline": return "Offline";
        default: return status ? String(status) : "";
    }
}

// One-line Vietnamese explanation for a non-public status ("" when watchable).
function statusNotice(status) {
    switch (String(status)) {
        case "groupShow": return "Model đang Group Show: cần mua ticket để vào xem chung.";
        case "privateGroupShow": return "Model đang Private Group Show: cần ticket để vào xem nhóm riêng.";
        case "private": return "Model đang trong Private Show: chỉ người được mời mới xem được.";
        case "p2p": return "Model đang trong show riêng (P2P): không xem công khai được.";
        case "virtual": return "Model đang trong Virtual Show.";
        case "off":
        case "offline": return "Model hiện đang Offline.";
        default: return "";
    }
}

// The site's strings embed device variants like "{#desktop}...{/desktop}"; strip the markers.
function cleanLabel(text) {
    return String(text || "")
        .replace(/\{#\w+\}/g, "")
        .replace(/\{\/\w+\}/g, "")
        .replace(/\s{2,}/g, " ")
        .trim();
}

// Vietnamese label for a profile i18n code (falls back to the raw code).
function modelLabel(code) {
    code = String(code || "");
    return cleanLabel(LABELS[code] ? LABELS[code] : code);
}

// Vietnamese name for a spoken-language code.
function langLabel(code) {
    code = String(code || "");
    return cleanLabel(LANGUAGES[code] ? LANGUAGES[code] : code);
}

function queryParam(url, key) {
    let q = url.indexOf("?");
    if (q === -1) return "";
    let parts = url.substring(q + 1).split("&");
    for (let i = 0; i < parts.length; i++) {
        let idx = parts[i].indexOf("=");
        if (idx === -1) continue;
        if (parts[i].substring(0, idx) === key) {
            let v = parts[i].substring(idx + 1);
            try {
                return decodeURIComponent(v);
            } catch (error) {
                return v;
            }
        }
    }
    return "";
}
