let LABELS = {
  bodyType: "Dáng người",
  bodyTypeAthletic: "Thể thao",
  bodyTypeAverage: "Cân đối",
  bodyTypeBBW: "BBW",
  bodyTypeBig: "To con",
  bodyTypeChunky: "Mập mạp",
  bodyTypeCurvy: "Đẫy đà",
  bodyTypeLarge: "Cỡ lớn",
  bodyTypeMedium: "Trung bình",
  bodyTypeMuscular: "Cơ bắp",
  bodyTypePetite: "Nhỏ nhắn",
  bodyTypeSkinny: "Gầy",
  bodyTypeThin: "Mảnh mai",
  ethnicity: "Sắc tộc",
  ethnicityAsian: "Châu Á",
  ethnicityEbony: "Da màu",
  ethnicityFrench: "Pháp",
  ethnicityGerman: "Đức",
  ethnicityIndian: "Ấn Độ",
  ethnicityItalian: "Ý",
  ethnicityLatino: "Mỹ Latinh",
  ethnicityMiddleEastern: "Trung Đông",
  ethnicityMixed: "Đa sắc tộc",
  ethnicityMultiracial: "Đa sắc tộc",
  ethnicityRussian: "Nga",
  ethnicitySpanish: "Tây Ban Nha",
  ethnicityWhite: "Da trắng",
  eyeColor: "Màu mắt",
  eyeColorBlack: "Đen",
  eyeColorBlue: "Xanh dương",
  eyeColorBrown: "Nâu",
  eyeColorGreen: "Xanh lục",
  eyeColorGrey: "Xám",
  eyeColorHazel: "Hạt dẻ",
  hairColor: "Màu tóc",
  hairColorBlack: "Tóc đen",
  hairColorBlonde: "Tóc vàng",
  hairColorBrown: "Tóc nâu",
  hairColorBrownJustBlack: "Tóc đen",
  hairColorBrunettes: "Tóc nâu",
  hairColorColorful: "Tóc nhiều màu",
  hairColorHairless: "Không tóc",
  hairColorOther: "Màu khác",
  hairColorRed: "Tóc đỏ",
  interestedIn: "Quan tâm đến",
  interestedInEverybody: "Mọi người",
  interestedInMen: "Nam",
  interestedInTranssexuals: "Người chuyển giới",
  interestedInWomen: "Nữ",
  specific: "Đặc điểm",
  specificBBC: "BBC",
  specificBeardy: "Râu quai nón",
  specificBigAss: "Mông to",
  specificBigBalls: "Bi to",
  specificBigClit: "Âm vật lớn",
  specificBigCock: "Dương vật to",
  specificBigNipples: "Núm vú lớn",
  specificBigTits: "Ngực khủng",
  specificBoots: "Đi bốt",
  specificBubblebutt: "Mông căng tròn",
  specificCD: "Mặc đồ khác giới (CD)",
  specificCut: "Đã cắt bao quy đầu",
  specificFemboy: "Femboy",
  specificFtM: "Chuyển giới nam (FtM)",
  specificHairy: "Vùng kín rậm lông",
  specificHairyArmpits: "Nách rậm lông",
  specificHairyMan: "Nam rậm lông",
  specificInterracial: "Đa chủng tộc",
  specificJeans: "Quần jeans",
  specificLesbians: "Đồng tính nữ",
  specificMtF: "Chuyển giới nữ (MtF)",
  specificMustache: "Ria mép",
  specificNoPiercing: "Không xỏ khuyên",
  specificNoTattoos: "Không hình xăm",
  specificNonBinary: "Phi nhị phân",
  specificPOV: "POV",
  specificPiercing: "Xỏ khuyên",
  specificPowerBottom: "Bot chủ động",
  specificPowerTop: "Top chủ động",
  specificPregnant: "Mang thai",
  specificQueer: "Queer",
  specificShaven: "Cạo sạch lông",
  specificShemale: "Chuyển giới nữ (Shemale)",
  specificSide: "Không xâm nhập (Side)",
  specificSissy: "Nữ tính hóa (Sissy)",
  specificSkinny: "Gầy",
  specificSmallCock: "Dương vật nhỏ",
  specificSmallTits: "Ngực nhỏ",
  specificSneakersSocks: "Giày thể thao & tất",
  specificSportGear: "Đồ thể thao",
  specificTG: "Người chuyển giới (TG)",
  specificTS: "Người chuyển giới (TS)",
  specificTV: "Mặc đồ khác giới (TV)",
  specificTattoos: "Hình xăm",
  specificTomboy: "Tomboy",
  specificTrimmed: "Tỉa gọn",
  specificUncut: "Chưa cắt bao quy đầu",
  specificUniform: "Đồng phục",
  specificVers: "Linh hoạt (Vers)",
  specifics: "Đặc điểm",
  specificsBBC: "BBC",
  specificsBeardy: "Râu quai nón",
  specificsBigAss: "Mông to",
  specificsBigBalls: "Bi to",
  specificsBigClit: "Âm vật lớn",
  specificsBigCock: "Dương vật to",
  specificsBigNipples: "Núm vú lớn",
  specificsBigTits: "Ngực khủng",
  specificsBoots: "Đi bốt",
  specificsBubblebutt: "Mông căng tròn",
  specificsCD: "Mặc đồ khác giới (CD)",
  specificsCut: "Đã cắt bao quy đầu",
  specificsFemboy: "Femboy",
  specificsFtM: "Chuyển giới nam (FtM)",
  specificsHairy: "Vùng kín rậm lông",
  specificsHairyArmpits: "Nách rậm lông",
  specificsHairyMan: "Nam rậm lông",
  specificsInterracial: "Đa chủng tộc",
  specificsJeans: "Quần jeans",
  specificsLesbians: "Đồng tính nữ",
  specificsMtF: "Chuyển giới nữ (MtF)",
  specificsMustache: "Ria mép",
  specificsNoPiercing: "Không xỏ khuyên",
  specificsNoTattoos: "Không hình xăm",
  specificsNonBinary: "Phi nhị phân",
  specificsPOV: "POV",
  specificsPiercing: "Xỏ khuyên",
  specificsPowerBottom: "Bot chủ động",
  specificsPowerTop: "Top chủ động",
  specificsPregnant: "Mang thai",
  specificsQueer: "Queer",
  specificsShaven: "Cạo sạch lông",
  specificsShemale: "Chuyển giới nữ (Shemale)",
  specificsSide: "Không xâm nhập (Side)",
  specificsSissy: "Nữ tính hóa (Sissy)",
  specificsSkinny: "Gầy",
  specificsSmallCock: "Dương vật nhỏ",
  specificsSmallTits: "Ngực nhỏ",
  specificsSneakersSocks: "Giày thể thao & tất",
  specificsSportGear: "Đồ thể thao",
  specificsTG: "Người chuyển giới (TG)",
  specificsTS: "Người chuyển giới (TS)",
  specificsTV: "Mặc đồ khác giới (TV)",
  specificsTattoos: "Hình xăm",
  specificsTomboy: "Tomboy",
  specificsTrimmed: "Tỉa gọn",
  specificsUncut: "Chưa cắt bao quy đầu",
  specificsUniform: "Đồng phục",
  specificsVers: "Linh hoạt (Vers)",
  subculture: "Phong cách",
  subcultureAnime: "Anime",
  subcultureBdsm: "BDSM",
  subcultureBears: "To con rậm lông (Bear)",
  subcultureBottom: "Thụ (Bottom)",
  subcultureChubbies: "Mũm mĩm",
  subcultureClubber: "Dân đi club",
  subcultureCubs: "Trai trẻ mũm mĩm (Cub)",
  subcultureCuckold: "Cắm sừng (Cuckold)",
  subcultureDragQueens: "Drag Queen",
  subcultureEboy: "E-boy",
  subcultureEgirl: "E-girl",
  subcultureEmo: "Emo",
  subcultureGamers: "Game thủ",
  subcultureGlamour: "Quyến rũ",
  subcultureGoth: "Goth",
  subcultureGymBabe: "Nàng tập gym",
  subcultureGymRats: "Dân mê gym",
  subcultureHousewives: "Bà nội trợ",
  subcultureHunks: "Vạm vỡ",
  subcultureJocks: "Vận động viên",
  subcultureKpop: "K-pop",
  subcultureMistresses: "Nữ chủ (Mistress)",
  subcultureNerds: "Mọt sách",
  subcultureNone: "Không có",
  subcultureOtters: "Mảnh khảnh rậm lông (Otter)",
  subculturePunks: "Phong cách Punk",
  subcultureRomantic: "Lãng mạn",
  subcultureStudent: "Sinh viên",
  subcultureStuds: "Cá tính mạnh",
  subcultureSwingers: "Đổi bạn tình",
  subcultureTop: "Công (Top)",
};

let LANGUAGES = {
  ar: "Tiếng Ả Rập",
  as: "Tiếng Assam",
  bg: "Tiếng Bulgaria",
  bn: "Tiếng Bengal",
  br: "Tiếng Bồ Đào Nha (Brazil)",
  cs: "Tiếng Séc",
  da: "Tiếng Đan Mạch",
  de: "Tiếng Đức",
  el: "Tiếng Hy Lạp",
  en: "Tiếng Anh",
  es: "Tiếng Tây Ban Nha",
  fi: "Tiếng Phần Lan",
  fr: "Tiếng Pháp",
  gu: "Tiếng Gujarat",
  he: "Tiếng Do Thái",
  hi: "Tiếng Hindi",
  hr: "Tiếng Croatia",
  hu: "Tiếng Hungary",
  id: "Tiếng Indonesia",
  it: "Tiếng Ý",
  ja: "Tiếng Nhật",
  kn: "Tiếng Kannada",
  ko: "Tiếng Hàn",
  ml: "Tiếng Malayalam",
  mr: "Tiếng Marathi",
  ms: "Tiếng Mã Lai",
  nl: "Tiếng Hà Lan",
  nn: "Tiếng Na Uy (Nynorsk)",
  no: "Tiếng Na Uy",
  or: "Tiếng Odia",
  pa: "Tiếng Punjabi",
  pl: "Tiếng Ba Lan",
  pt: "Tiếng Bồ Đào Nha",
  ro: "Tiếng Romania",
  ru: "Tiếng Nga",
  sk: "Tiếng Slovak",
  sq: "Tiếng Albania",
  sr: "Tiếng Serbia",
  sv: "Tiếng Thụy Điển",
  ta: "Tiếng Tamil",
  te: "Tiếng Telugu",
  th: "Tiếng Thái",
  tr: "Tiếng Thổ Nhĩ Kỳ",
  uk: "Tiếng Ukraina",
  vi: "Tiếng Việt",
  zh: "Tiếng Trung Giản thể",
  zt: "Tiếng Trung Phồn thể",
};

// Category tags from /tags/girls, in popularity order: [code, Vietnamese title].
let CATEGORIES = [
  ["girls", "Nữ"],
  ["autoTagHandy", "The Handy"],
  ["autoTagP2P", "Gọi video (Cam2Cam)"],
  ["doFingering", "Móc cua"],
  ["doDoggyStyle", "Tư thế Doggy"],
  ["autoTagHd", "HD"],
  ["doMasturbation", "Thủ dâm"],
  ["doSpanking", "Đánh đòn"],
  ["doEroticDance", "Nhảy khiêu dâm"],
  ["doDildoOrVibrator", "Dương vật giả hoặc máy rung"],
  ["doBlowjob", "Thổi kèn"],
  ["autoTagRecordablePrivate", "Show riêng cho phép ghi hình"],
  ["doStriptease", "Múa thoát y"],
  ["autoTagRecordablePublic", "Cho phép ghi hình"],
  ["doOilShow", "Diễn với dầu"],
  ["smallAudience", "Đầy hứa hẹn & đúng gu bạn"],
  ["doTalk", "Nói chuyện gợi dục"],
  ["sexting", "Nhắn tin sex"],
  ["doSexToys", "Đồ chơi tình dục"],
  ["doTopless", "Ngực trần"],
  ["doTwerk", "Nhảy Twerk"],
  ["doFootFetish", "Sở thích bàn chân"],
  ["doOrgasm", "Cực khoái"],
  ["doDeepThroat", "Bú ngập họng"],
  ["specificsBigAss", "Mông to"],
  ["doAhegao", "Ahegao"],
  ["heels", "Giày cao gót"],
  ["doTittyFuck", "Kẹp ngực"],
  ["ageYoung", "Trẻ trung 22+"],
  ["autoTagInteractiveToy", "Đồ chơi tương tác"],
  ["autoTagLovense", "Lovense"],
  ["doCowgirl", "Tư thế cưỡi ngựa"],
  ["doCamelToe", "Hằn khe (Camel toe)"],
  ["specificShaven", "Cạo sạch lông"],
  ["doSquirt", "Phụt nước"],
  ["doRolePlay", "Nhập vai"],
  ["tagLanguageSpanishSpeaking", "Nói tiếng Tây Ban Nha"],
  ["privatePriceEight", "8-12 tk"],
  ["cockRating", "Đánh giá dương vật"],
  ["doHandjob", "Thủ dâm bằng tay"],
  ["autoTagBestPrivates", "Tuyệt đỉnh {#desktop}phòng {/desktop}riêng tư"],
  ["tagLanguageColombian", "Người Colombia"],
  ["doFlashing", "Lộ hàng"],
  ["doHumiliation", "Hạ nhục"],
  ["hairColorBlack", "Tóc đen"],
  ["ethnicityLatino", "Mỹ Latinh"],
  ["specificsBigTits", "Ngực khủng"],
  ["doAnal", "Quan hệ hậu môn"],
  ["jerkOffInstruction", "Hướng dẫn tự sướng"],
  ["doFootjob", "Thủ dâm bằng chân"],
  ["privateP2PPriceTwelveTwentyFour", "P2P: 12-24 token/phút"],
  ["bodyTypePetite", "Nhỏ nhắn"],
  ["doAnalToys", "Đồ chơi hậu môn"],
  ["doUpskirt", "Vén váy"],
  ["doMassage", "Mát-xa"],
  ["hairColorBrown", "Tóc nâu"],
  ["privateP2PPriceThirtyTwoSixty", "P2P: 32-60 token/phút"],
  ["doSmoking", "Hút thuốc"],
  ["bodyTypeMedium", "Trung bình"],
  ["subcultureStudent", "Sinh viên"],
  ["specificSmallTits", "Ngực nhỏ"],
  ["doNippleToys", "Đồ chơi đầu ti"],
  ["specificBigNipples", "Núm vú lớn"],
  ["doShower", "Tắm vòi sen"],
  ["doCreamPie", "Xuất tinh trong"],
  ["privatePriceSixteenToTwentyFour", "16-24 tk"],
  ["doGagging", "Bịt miệng"],
  ["doFacial", "Xuất tinh lên mặt"],
  ["ethnicityWhite", "Da trắng"],
  ["doCumshot", "Xuất tinh"],
  ["doFacesitting", "Ngồi lên mặt"],
  ["doDoublePenetration", "Hai lỗ cùng lúc (DP)"],
  ["nylon", "Tất da chân (Nylon)"],
  ["specificBigClit", "Âm vật lớn"],
  ["bodyTypeCurvy", "Đẫy đà"],
  ["specificTrimmed", "Tỉa gọn"],
  ["mobile", "Di động"],
  ["subcultureMistresses", "Nữ chủ (Mistress)"],
  ["privatePriceThirtyTwoSixty", "32-60 tk"],
  ["doAssToMouth", "Từ hậu môn lên miệng"],
  ["ageTeen", "Thiếu nữ"],
  ["doYoga", "Yoga"],
  ["autoTagNew", "Mới {#desktop}ra mắt{/desktop}"],
  ["subcultureRomantic", "Lãng mạn"],
  ["specificPOV", "POV"],
  ["ethnicityEbony", "Da màu"],
  ["ageMilf", "Quý bà (MILF)"],
  ["leather", "Đồ da"],
  ["doCooking", "Nấu ăn"],
  ["do69Position", "Tư thế 69"],
  ["doCosplay", "Hóa trang"],
  ["doPublicPlace", "Nơi công cộng"],
  ["specificsHairy", "Vùng kín rậm lông"],
  ["hairColorBlonde", "Tóc vàng"],
  ["subcultureGlamour", "Quyến rũ"],
  ["doOffice", "Văn phòng"],
  ["latex", "Đồ cao su (Latex)"],
  ["subcultureCuckold", "Cắm sừng (Cuckold)"],
  ["corset", "Áo nịt ngực (Corset)"],
  ["doFisting", "Đút cả nắm tay (Fisting)"],
  ["specificsTattoos", "Hình xăm"],
  ["privateP2PNinetyPlus", "P2P: 90+ token/phút"],
  ["european", "Châu Âu"],
  ["doPussyLicking", "Liếm cô bé"],
  ["subcultureGymBabe", "Nàng tập gym"],
  ["tagLanguageAfrican", "Người châu Phi"],
  ["doGape", "Banh rộng (Gape)"],
  ["subcultureHousewives", "Bà nội trợ"],
  ["fuckMachine", "Máy làm tình"],
  ["specificSportGear", "Đồ thể thao"],
  ["specificJeans", "Quần jeans"],
  ["bodyTypeAthletic", "Thể thao"],
  ["doStrapon", "Đeo dương vật giả (Strap-on)"],
  ["tagLanguageKenyan", "Người Kenya"],
  ["specificsPiercing", "Xỏ khuyên"],
  ["subcultureAnime", "Anime"],
  ["doKissing", "Hôn"],
  ["couples", "Cặp đôi"],
  ["specificHairyArmpits", "Nách rậm lông"],
  ["ethnicityAsian", "Châu Á"],
  ["subcultureGoth", "Goth"],
  ["doPegging", "Nữ chơi sau (Pegging)"],
  ["autoTagSpy", "Xem lén {#desktop}show diễn{/desktop}"],
  ["hairColorColorful", "Tóc nhiều màu"],
  ["hairColorRed", "Tóc đỏ"],
  ["subcultureGamers", "Game thủ"],
  ["subcultureClubber", "Dân đi club"],
  ["privatePriceNinetyPlus", "90+ tk"],
  ["subcultureTop", "Công (Top)"],
  ["bodyTypeBBW", "BBW"],
  ["bodyTypeBig", "To con"],
  ["privateP2PPriceEight", "P2P: 8 token/phút"],
  ["subcultureEgirl", "E-girl"],
  ["ethnicityIndian", "Ấn Độ"],
  ["tagLanguageRussianSpeaking", "Nói tiếng Nga"],
  ["doGloryHole", "Lỗ xuyên tường (Gloryhole)"],
  ["ethnicityMultiracial", "Đa sắc tộc"],
  ["doBukkake", "Xuất tinh tập thể (Bukkake)"],
  ["doHardcore", "Làm tình mạnh bạo"],
  ["subcultureSwingers", "Đổi bạn tình"],
  ["subcultureNerds", "Mọt sách"],
  ["ageMature", "Trưởng thành"],
  ["doSwallow", "Nuốt tinh"],
  ["subcultureEmo", "Emo"],
  ["tagLanguageSouthAfrican", "Người Nam Phi"],
  ["doRimming", "Liếm hậu môn"],
  ["subcultureKpop", "K-pop"],
  ["tagLanguageRomanian", "Người Romania"],
  ["autoTagVr", "VR{#desktop} Cam{/desktop}"],
  ["doEjaculation", "Xuất tinh"],
  ["ethnicityMiddleEastern", "Trung Đông"],
  ["tagLanguageHindi", "Nói tiếng Hindi"],
  ["promoted", "Biên tập viên đề xuất"],
  ["groupShow", "Show vé & Show nhóm"],
  ["doCumPlay", "Chơi với tinh dịch"],
  ["tagLanguageUSModels", "Người Mỹ"],
  ["tagLanguageVenezuelan", "Người Venezuela"],
  ["autoTagLesbian", "Đồng tính nữ"],
  ["tagLanguageUkrainian", "Người Ukraina"],
  ["doRubbing", "Cọ xát"],
  ["specificTomboy", "Tomboy"],
  ["doSph", "Chê dương vật nhỏ (SPH)"],
  ["asmr", "ASMR"],
  ["doSelfsucking", "Tự bú"],
  ["doCei", "Hướng dẫn nuốt tinh (CEI)"],
  ["subcultureBottom", "Thụ (Bottom)"],
  ["subcultureBdsm", "BDSM"],
  ["specificBubblebutt", "Mông căng tròn"],
  ["subculturePunks", "Phong cách Punk"],
  ["tagLanguagePortugueseSpeaking", "Nói tiếng Bồ Đào Nha"],
  ["doFlexing", "Uốn dẻo"],
  ["tagLanguageFilipino", "Người Philippines"],
  ["tagLanguageChinese", "Người Trung Quốc"],
  ["tagLanguageUKModels", "Người Anh"],
  ["tagLanguageBrazilian", "Người Brazil"],
  ["specificBigBalls", "Bi to"],
  ["tagGroupSex", "Quan hệ tập thể"],
  ["specificQueer", "Queer"],
  ["doPenisRing", "Vòng đeo dương vật"],
  ["specificPowerTop", "Top chủ động"],
  ["tagLanguageFrench", "Người Pháp"],
  ["tagLanguageItalian", "Người Ý"],
  ["tagLanguageVietnamese", "Người Việt"],
  ["doPrecum", "Dịch hưng phấn"],
  ["specificNonBinary", "Phi nhị phân"],
  ["tagLanguageGermanSpeaking", "Nói tiếng Đức"],
  ["videoGames", "Trò chơi điện tử"],
  ["specificSneakersSocks", "Giày thể thao & tất"],
  ["ageOld", "Lớn tuổi"],
  ["doThreesome", "Quan hệ tay ba"],
  ["autoTagOldYoung", "Lớn tuổi & Trẻ trung 22+"],
  ["specificBeardy", "Râu quai nón"],
  ["tagLanguageTurkish", "Người Thổ Nhĩ Kỳ"],
  ["tagLanguageMoroccan", "Người Ma Rốc"],
  ["doGangbang", "Nhiều người với một (Gangbang)"],
  ["subcultureChubbies", "Mũm mĩm"],
  ["specificPregnant", "Mang thai"],
  ["doChastity", "Khóa trinh tiết"],
  ["subcultureJocks", "Vận động viên"],
  ["specificVers", "Linh hoạt (Vers)"],
  ["doPump", "Bơm kích thích"],
  ["tagLanguageSpanish", "Người Tây Ban Nha"],
  ["specificMustache", "Ria mép"],
  ["specificPowerBottom", "Bot chủ động"],
  ["tagLanguageArgentinian", "Người Argentina"],
  ["tagLanguageZimbabwean", "Người Zimbabwe"],
  ["specificUniform", "Đồng phục"],
  ["hairColorHairless", "Không tóc"],
  ["subcultureStuds", "Cá tính mạnh"],
  ["tagLanguageBengali", "Nói tiếng Bengal"],
  ["trans", "Chuyển giới"],
  ["doFoursome", "Quan hệ tay tư"],
  ["specificBoots", "Đi bốt"],
  ["subcultureGymRats", "Dân mê gym"],
  ["tagLanguageCanadian", "Người Canada"],
  ["tagLanguageMexican", "Người Mexico"],
  ["autoTagNonNude", "Gợi cảm không khỏa thân"],
  ["tagLanguageBangladeshi", "Người Bangladesh"],
  ["tagLanguageJapanese", "Nói tiếng Nhật"],
  ["tagLanguagePunjabi", "Nói tiếng Punjabi"],
  ["subcultureHunks", "Vạm vỡ"],
  ["tagLanguageTamil", "Nói tiếng Tamil"],
  ["specificCut", "Đã cắt bao quy đầu"],
  ["tagLanguageDutch", "Người Hà Lan"],
  ["tagLanguageSriLankan", "Người Sri Lanka"],
  ["specificSide", "Không xâm nhập (Side)"],
  ["subcultureCubs", "Trai trẻ mũm mĩm (Cub)"],
  ["subcultureEboy", "E-boy"],
  ["tagLanguageHungarian", "Người Hungary"],
  ["tagLanguagePortuguese", "Người Bồ Đào Nha"],
  ["tagLanguageTelugu", "Nói tiếng Telugu"],
  ["subcultureDragQueens", "Drag Queen"],
  ["tagLanguageAustrian", "Người Áo"],
  ["tagLanguageEcuadorian", "Người Ecuador"],
  ["tagLanguagePolish", "Người Ba Lan"],
  ["specificBBC", "BBC"],
  ["specificLesbians", "Đồng tính nữ"],
  ["tagLanguageChilean", "Người Chile"],
  ["specificTS", "Người chuyển giới (TS)"],
  ["subcultureOtters", "Mảnh khảnh rậm lông (Otter)"],
  ["tagLanguageEgyptian", "Người Ai Cập"],
  ["tagLanguageGreek", "Nói tiếng Hy Lạp"],
  ["tagLanguageNordic", "Người Bắc Âu"],
  ["tagLanguagePeruvian", "Người Peru"],
  ["specificInterracial", "Đa chủng tộc"],
  ["tagLanguageMarathi", "Nói tiếng Marathi"],
  ["tagLanguageSerbian", "Người Serbia"],
  ["tagLanguageThai", "Người Thái"],
  ["vTubers", "VTuber"],
  ["specificShemale", "Chuyển giới nữ (Shemale)"],
  ["specificTG", "Người chuyển giới (TG)"],
  ["specificTV", "Mặc đồ khác giới (TV)"],
  ["tagLanguageNigerian", "Người Nigeria"],
  ["tagLanguageSwiss", "Người Thụy Sĩ"],
  ["specificFtM", "Chuyển giới nam (FtM)"],
  ["tagLanguageAlgerian", "Người Algérie"],
  ["tagLanguageDominican", "Người Dominica"],
  ["tagLanguageIrish", "Người Ireland"],
  ["tagLanguageKannada", "Nói tiếng Kannada"],
  ["tagLanguageSwedish", "Người Thụy Điển"],
  ["autoTagKiiroo", "Kiiroo"],
  ["specificMtF", "Chuyển giới nữ (MtF)"],
  ["specificsBigCock", "Dương vật to"],
  ["tagLanguageAustralian", "Người Úc"],
  ["tagLanguageBelgian", "Người Bỉ"],
  ["tagLanguageCzech", "Người Séc"],
  ["tagLanguageIsraeli", "Người Israel"],
  ["tagLanguageMalayalam", "Nói tiếng Malayalam"],
  ["tagLanguageSlovakian", "Người Slovakia"],
  ["pornStar", "Ngôi sao"],
  ["privateSpyPriceFourEight", "Xem lén: 4-8 token"],
  ["specificCD", "Mặc đồ khác giới (CD)"],
  ["tagLanguageBulgarian", "Người Bulgaria"],
  ["tagLanguageCroatian", "Người Croatia"],
  ["tagLanguageDanish", "Người Đan Mạch"],
  ["tagLanguageEstonian", "Người Estonia"],
  ["tagLanguageFinnish", "Người Phần Lan"],
  ["tagLanguageNorwegian", "Người Na Uy"],
  ["tagLanguageSlovenian", "Người Slovenia"],
  ["tagLanguageUgandan", "Người Uganda"],
];

let BASE_URL = "https://stripchat.global";
try {
  if (DOMAIN) {
    BASE_URL = String(DOMAIN).replace(/\/+$/, "");
  }
} catch (error) {}

// Image CDN (cdnBaseUrl from the site config).
let CDN = "https://static-proxy.strpst.com";
// HLS edge that serves a plain playlist (the doppiocdn edge returns an ad/decoy).
let HLS_EDGE = "https://edge-hls.saawsedge.com";

function normalizeUrl(url) {
  return url.replace(
    /^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/gim,
    BASE_URL,
  );
}

function imgUrl(path) {
  if (!path) return "";
  if (path.indexOf("http") === 0) return path;
  return CDN + (path.charAt(0) === "/" ? path : "/" + path);
}

function masterUrl(streamName) {
  return HLS_EDGE + "/hls/" + streamName + "/master/" + streamName + ".m3u8";
}

// Live snapshot of the current broadcast (the model's real preview image).
function snapshotUrl(modelId, timestamp) {
  if (!modelId || !timestamp) return "";
  return "https://img.doppiocdn.org/snapshot/" + modelId + "/" + timestamp;
}

// Build a feed item from one model object of the models API.
function modelToItem(m) {
  let stream = m.streamName || m.id;
  // The live snapshot only exists for a broadcasting model; offline ones (top
  // rankings) fall back to the profile avatar.
  let live = m.status === "public" && m.isOnline !== false;
  let snap = live
    ? snapshotUrl(m.id, m.snapshotTimestamp || m.popularSnapshotTimestamp)
    : "";
  let cover = snap;
  if (!cover) cover = imgUrl(m.avatarUrl);
  if (!cover)
    cover = m.previewUrlThumbSmall ? imgUrl(m.previewUrlThumbSmall) : "";
  // The live stream name rotates each broadcast; it is carried in the link so the
  // feed can play without a per-item API round-trip.
  let link =
    BASE_URL +
    "/" +
    m.username +
    "?s=" +
    encodeURIComponent(stream) +
    "&a=" +
    encodeURIComponent(m.avatarUrl || "") +
    "&p=" +
    encodeURIComponent(m.previewUrlThumbSmall || "") +
    "&sn=" +
    encodeURIComponent(snap);
  return {
    name: m.username,
    cover: cover,
    link: link,
    description: m.country ? String(m.country) : "",
    tag: statusLabel(m.status),
    type: "short",
    host: BASE_URL,
  };
}

// Keep only public, online models and drop duplicates.
function modelsToItems(models) {
  let seen = {};
  let items = [];
  for (let i = 0; i < models.length; i++) {
    let m = models[i];
    if (!m || !m.username || (!m.streamName && !m.id)) continue;
    if (m.isOnline === false) continue;
    if (m.status !== "public") continue;
    if (seen[m.username]) continue;
    seen[m.username] = 1;
    items.push(modelToItem(m));
  }
  return items;
}

// --- persistent per-extension storage (favorites / history) ---

function lsReadList(key) {
  let raw = localStorage.getItem(key);
  if (!raw) return [];
  let arr;
  try {
    arr = JSON.parse(raw);
  } catch (error) {
    return [];
  }
  return arr && arr.length ? arr : [];
}

function lsWriteList(key, arr) {
  localStorage.setItem(key, JSON.stringify(arr));
}

// Stored entries ({n: name, c: cover, t: text}) as feed items.
function storedItems(key) {
  let arr = lsReadList(key);
  let items = [];
  for (let i = 0; i < arr.length; i++) {
    let e = arr[i];
    if (!e || !e.n) continue;
    items.push({
      name: e.n,
      cover: e.c || "",
      link: BASE_URL + "/" + e.n,
      tag: e.t || "",
      type: "short",
      host: BASE_URL,
    });
  }
  return items;
}

// Most-recent-first, de-duplicated by name.
function storePush(key, entry, cap) {
  let arr = lsReadList(key);
  let out = [entry];
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] && arr[i].n !== entry.n) out.push(arr[i]);
  }
  if (cap > 0 && out.length > cap) out = out.slice(0, cap);
  lsWriteList(key, out);
}

function storeRemove(key, name) {
  let arr = lsReadList(key);
  let out = [];
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] && arr[i].n !== name) out.push(arr[i]);
  }
  lsWriteList(key, out);
}

function storeHas(key, name) {
  let arr = lsReadList(key);
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] && arr[i].n === name) return true;
  }
  return false;
}

// stream -> { u: username, c: cover }. Written by chap, read by track on playback.
function rememberStream(stream, entry) {
  if (!stream) return;
  let map = null;
  let raw = localStorage.getItem("streams");
  if (raw) {
    try {
      map = JSON.parse(raw);
    } catch (error) {
      map = null;
    }
  }
  if (!map) map = {};
  map[stream] = entry;
  let keys = [];
  for (let k in map) keys.push(k);
  if (keys.length > 300) {
    keys.sort(function (a, b) {
      return Number(a) - Number(b);
    });
    for (let i = 0; i < keys.length - 300; i++) delete map[keys[i]];
  }
  localStorage.setItem("streams", JSON.stringify(map));
}

function streamEntry(stream) {
  if (!stream) return null;
  let raw = localStorage.getItem("streams");
  if (!raw) return null;
  let map;
  try {
    map = JSON.parse(raw);
  } catch (error) {
    return null;
  }
  return map && map[stream] ? map[stream] : null;
}

// Live show description (the room topic).
function liveTopic(html) {
  let m = String(html || "").match(/"topic":"((?:[^"\\]|\\.)*)"/);
  return m ? m[1].replace(/\\u002F/g, "/") : "";
}

// The live goal widget, e.g. "2045 tk — get naked and play dildo".
function liveGoal(html) {
  let block = String(html || "").match(
    /epic-goal-progress__information--view-cam">([\s\S]*?)<\/div>/,
  );
  if (!block) return "";
  let inner = block[1];
  let tok = inner.match(/epic-goal-progress__tokens">([^<]*)</);
  let tokens = tok ? tok[1].replace(/\s+/g, " ").trim() : "";
  let text = "";
  let spans = inner.match(/<span>[\s\S]*?<\/span>/g) || [];
  for (let i = 0; i < spans.length; i++) {
    let t = spans[i]
      .replace(/<[^>]*>/g, "")
      .replace(/<!-- -->/g, "")
      .replace(/\s+/g, " ")
      .trim();
    if (t && t.indexOf("Goal") !== 0) text = t;
  }
  if (!tokens) return text;
  return tokens + (text ? " — " + text : "");
}

function streamHeaders() {
  return { "User-Agent": UserAgent.chrome(), Referer: BASE_URL + "/" };
}

function apiHeaders() {
  return {
    Accept: "application/json, text/plain, */*",
    "User-Agent": UserAgent.chrome(),
    Referer: BASE_URL + "/",
  };
}

// Short Vietnamese label for a model status key.
function statusLabel(status) {
  switch (String(status)) {
    case "public":
      return "Đang live";
    case "groupShow":
      return "Group show (cần ticket)";
    case "privateGroupShow":
      return "Private group show (cần ticket)";
    case "private":
      return "Private show";
    case "p2p":
      return "Show riêng (P2P)";
    case "virtual":
      return "Virtual show";
    case "off":
    case "offline":
      return "Offline";
    default:
      return status ? String(status) : "";
  }
}

// One-line Vietnamese explanation for a non-public status ("" when watchable).
function statusNotice(status) {
  switch (String(status)) {
    case "groupShow":
      return "Model đang Group Show: cần mua ticket để vào xem chung.";
    case "privateGroupShow":
      return "Model đang Private Group Show: cần ticket để vào xem nhóm riêng.";
    case "private":
      return "Model đang trong Private Show: chỉ người được mời mới xem được.";
    case "p2p":
      return "Model đang trong show riêng (P2P): không xem công khai được.";
    case "virtual":
      return "Model đang trong Virtual Show.";
    case "off":
    case "offline":
      return "Model hiện đang Offline.";
    default:
      return "";
  }
}

// The site's strings embed device variants like "{#desktop}...{/desktop}"; strip the markers.
function cleanLabel(text) {
  return String(text || "")
    .replace(/\{#\w+\}/g, "")
    .replace(/\{\/\w+\}/g, "")
    .replace(/\s{2,}/g, " ")
    .trim();
}

// Vietnamese label for a profile i18n code (falls back to the raw code).
function modelLabel(code) {
  code = String(code || "");
  return cleanLabel(LABELS[code] ? LABELS[code] : code);
}

// Vietnamese name for a spoken-language code.
function langLabel(code) {
  code = String(code || "");
  return cleanLabel(LANGUAGES[code] ? LANGUAGES[code] : code);
}

function queryParam(url, key) {
  let q = url.indexOf("?");
  if (q === -1) return "";
  let parts = url.substring(q + 1).split("&");
  for (let i = 0; i < parts.length; i++) {
    let idx = parts[i].indexOf("=");
    if (idx === -1) continue;
    if (parts[i].substring(0, idx) === key) {
      let v = parts[i].substring(idx + 1);
      try {
        return decodeURIComponent(v);
      } catch (error) {
        return v;
      }
    }
  }
  return "";
}
