load('config.js');

function usernameFromUrl(url) {
    return url.split("?")[0].replace(/^https?:\/\/[^\/]+\//, "").replace(/\/+$/, "");
}

function execute(url) {
    url = normalizeUrl(url);
    let username = usernameFromUrl(url);
    let cover = queryParam(url, "sn");
    let stream = queryParam(url, "s");

    // Favorite / history links carry no stream; take it from the model page.
    if (!stream || !cover) {
        let page = fetch(BASE_URL + "/" + username, {
            headers: { "Accept": "text/html", "User-Agent": UserAgent.chrome() },
            timeout: 30000
        });
        if (page && page.ok) {
            let html = String(page.text() || "");
            let sm = html.match(/"streamName":"(\d+)"/);
            if (sm && !stream) stream = sm[1];
            if (!cover) {
                let ts = html.match(/"snapshotTimestamp":"?(\d+)/);
                let mid = html.match(/"id":(\d+)/);
                cover = snapshotUrl(mid ? mid[1] : stream, ts ? ts[1] : "");
            }
        }
    }
    if (!stream) return Response.error("Model đã Offline");

    // The saawsedge master lists plain variant URLs (no per-session token needed),
    // unlike the doppiocdn edge whose media playlist is an ad/decoy.
    let master = fetch(masterUrl(stream), { headers: streamHeaders(), timeout: 30000 });
    if (!master.ok) return Response.error("Model đã Offline");
    let text = String(master.text() || "");

    let lines = text.split("\n");
    let tracks = [];
    for (let i = 0; i < lines.length; i++) {
        if (lines[i].indexOf("#EXT-X-STREAM-INF:") !== 0) continue;
        let nameMatch = lines[i].match(/NAME="([^"]+)"/);
        let title = nameMatch ? nameMatch[1] : "Stream";
        let j = i + 1;
        while (j < lines.length && lines[j].replace(/\s/g, "") === "") j++;
        if (j >= lines.length) continue;
        let variant = lines[j].replace(/^\s+|\s+$/g, "");
        if (variant.indexOf("http") !== 0) continue;
        tracks.push({ title: title, data: variant });
    }

    if (tracks.length === 0) return Response.error("Không tìm thấy luồng phát");

    // Let track.js map the played stream back to its model for the history list.
    rememberStream(stream, { u: username, c: cover });
    return Response.success(tracks);
}
