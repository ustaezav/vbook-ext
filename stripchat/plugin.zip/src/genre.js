load('config.js');

// Category list from https://stripchat.global/tags/girls (bundled, popularity order).
function execute() {
    let genres = [];
    for (let i = 0; i < CATEGORIES.length; i++) {
        genres.push({
            title: cleanLabel(CATEGORIES[i][1]),
            input: CATEGORIES[i][0],
            script: "genre_items.js"
        });
    }
    return Response.success(genres);
}
