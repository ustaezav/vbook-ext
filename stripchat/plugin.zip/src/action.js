load('config.js');

// The model username of the book the detail screen was opened from.
function bookName() {
    let info = localBook.getInfo();
    if (!info || !info.name) return "";
    let n = info.name;
    if (typeof n === "string") return n;
    if (typeof n === "object") {
        if (typeof n.raw === "string") return n.raw;
        for (let k in n) {
            if (typeof n[k] === "string") return n[k];
        }
    }
    return "";
}

function execute() {
    let actions = {};
    let name = bookName();
    if (!name) return Response.success(actions);

    if (storeHas("favorites", name)) {
        actions.favorite = { name: "Xoá khỏi Yêu thích", description: name, script: "toggle_favorite.js" };
    } else {
        actions.favorite = { name: "Thêm vào Yêu thích", description: name, script: "toggle_favorite.js" };
    }
    return Response.success(actions);
}
