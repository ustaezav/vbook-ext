load('config.js');

// Models of one category tag. The tag filter is a POST body field (filterGroupTags);
// a GET "tag" parameter is silently ignored by the API.
function execute(query, page) {
    let tag = String(query || "").trim();
    if (!tag) return Response.success([], "");

    let offset = parseInt(page || "0", 10);
    if (isNaN(offset) || offset < 0) offset = 0;

    let response = fetch(BASE_URL + "/api/front/v2/models", {
        method: "POST",
        headers: apiHeaders(),
        body: JSON.stringify({
            primaryTag: "girls",
            filterGroupTags: [[tag]],
            limit: 60,
            offset: offset
        }),
        timeout: 30000
    });
    if (!response.ok) return Response.error("HTTP " + response.status);

    let json;
    try {
        json = response.json();
    } catch (error) {
        return Response.error("Phản hồi không hợp lệ");
    }

    let models = (json && json.blocks && json.blocks[0] && json.blocks[0].models) ? json.blocks[0].models : [];
    let items = modelsToItems(models);

    let total = json && json.totalCount ? json.totalCount : 0;
    let next = (items.length > 0 && offset + 60 < total) ? String(offset + 60) : "";
    return Response.success(items, next);
}
