load('config.js');

// Browse a top-level tag (the home tabs).
function browse(tag) {
    let response = fetch(BASE_URL + "/api/front/v2/models?limit=60&offset=0&primaryTag=" + tag, {
        headers: apiHeaders(),
        timeout: 30000
    });
    if (!response.ok) return Response.error("HTTP " + response.status);

    let json;
    try {
        json = response.json();
    } catch (error) {
        return Response.error("Phản hồi không hợp lệ");
    }

    let blocks = (json && json.blocks) ? json.blocks : [];
    let models = [];
    for (let b = 0; b < blocks.length; b++) {
        let list = blocks[b].models || [];
        for (let i = 0; i < list.length; i++) models.push(list[i]);
    }
    return Response.success(modelsToItems(models), "");
}

// Keyword search: the API groups matches by username, topic, tip menu, activity and
// interest. Merge them, keep public/online models, page by offset.
function search(query, page) {
    let offset = parseInt(page || "0", 10);
    if (isNaN(offset) || offset < 0) offset = 0;

    let url = BASE_URL + "/api/front/v5/models/search/group/all?primaryTag=girls&query=" +
        encodeURIComponent(query) + "&limit=60&offset=" + offset;

    let response = fetch(url, { headers: apiHeaders(), timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);

    let json;
    try {
        json = response.json();
    } catch (error) {
        return Response.error("Phản hồi không hợp lệ");
    }

    let groups = (json && json.groups) ? json.groups : {};
    let models = [];
    for (let key in groups) {
        let list = (groups[key] && groups[key].models) ? groups[key].models : [];
        for (let i = 0; i < list.length; i++) models.push(list[i]);
    }

    let items = modelsToItems(models);
    let next = (items.length > 0 && offset + 60 < 300) ? String(offset + 60) : "";
    return Response.success(items, next);
}

function execute(query, page) {
    query = String(query || "").trim();

    // Home tabs pass "tab:<tag>"; anything else is a keyword search.
    if (query === "") return browse("girls");
    if (query.indexOf("tab:") === 0) return browse(query.substring(4));
    return search(query, page);
}
