load('config.js');

function execute(query, page) {
    query = String(query || "");

    let tag = "girls";
    if (query === "girls" || query === "couples") {
        tag = query;
    }

    let response = fetch(BASE_URL + "/api/front/v2/models?limit=60&offset=0&primaryTag=" + tag, {
        headers: apiHeaders(),
        timeout: 30000
    });
    if (!response.ok) return Response.error("HTTP " + response.status);

    let json;
    try {
        json = response.json();
    } catch (error) {
        return Response.error("Phản hồi không hợp lệ");
    }

    let blocks = (json && json.blocks) ? json.blocks : [];
    let models = [];
    for (let b = 0; b < blocks.length; b++) {
        let list = blocks[b].models || [];
        for (let i = 0; i < list.length; i++) models.push(list[i]);
    }

    return Response.success(modelsToItems(models), "");
}
