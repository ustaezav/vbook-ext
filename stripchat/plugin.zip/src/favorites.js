load('config.js');

// Locally saved favorite models (see action.js / toggle_favorite.js).
function execute() {
    return Response.success(storedItems("favorites"), "");
}
