load('config.js');

function execute(data) {
    data = String(data || "");
    if (data.indexOf(".m3u8") === -1 && data.indexOf(".mp4") === -1) {
        return Response.error("Không phát được luồng");
    }

    // Record watch history for the model that is actually playing.
    try {
        let m = data.match(/(\d+)\/\1[^\/]*\.m3u8/);
        if (m) {
            let entry = streamEntry(m[1]);
            if (entry && entry.u) {
                storePush("history", { n: entry.u, c: entry.c || "", ts: Date.now() }, 200);
            }
        }
    } catch (error) {
    }

    return Response.success({
        type: "native",
        data: data,
        host: BASE_URL,
        mimeType: "application/x-mpegURL",
        headers: streamHeaders(),
        timeSkip: []
    });
}
