function execute() {
  return Response.success([
    { title: "Girls", input: "girls", script: "search.js" },
    { title: "Couples", input: "couples", script: "search.js" },
    { title: "Yêu thích", input: "", script: "favorites.js" },
    { title: "Lịch sử", input: "", script: "history.js" },
    {
      title: "Top Girls · Châu Á - Thái Bình Dương",
      input: "female/current-month-asia-and-pacific",
      script: "top.js",
    },
    {
      title: "Top Girls · Bắc Mỹ",
      input: "female/current-month-north-america",
      script: "top.js",
    },
    {
      title: "Top Girls · Châu Âu",
      input: "female/current-month-europe",
      script: "top.js",
    },
    {
      title: "Top Girls · Châu Phi",
      input: "female/current-month-africa",
      script: "top.js",
    },
    {
      title: "Top Girls · Nam Mỹ",
      input: "female/current-month-south-america",
      script: "top.js",
    },
    { title: "Top Couples", input: "couple/current-month", script: "top.js" },
  ]);
}
