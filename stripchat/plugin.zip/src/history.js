load('config.js');

// Models actually played (recorded by track.js), newest first.
function execute() {
    return Response.success(storedItems("history"), "");
}
