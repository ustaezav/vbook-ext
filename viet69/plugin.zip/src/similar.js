load('config.js');

function itemFrom(el) {
    return {
        name: el.select(".entry-title a").text().trim(),
        cover: el.select(".thumb img").attr("src"),
        link: el.select(".entry-title a").attr("href"),
        description: el.select(".entry-summary").text().trim()
    };
}

function execute(input) {
    input = String(input || "").trim();
    if (!input) return Response.success([], "");

    let doc;
    let selector;
    if (input.charAt(0) === "<") {
        doc = Html.parse(input);
        selector = ".item";
    } else {
        let response = fetch(normalizeUrl(input));
        if (!response.ok) return Response.error("HTTP " + response.status);
        doc = response.html();
        selector = ".related-posts .item, .app-related-videos .item";
    }

    let items = [];
    let seen = {};
    doc.select(selector).forEach(function (el) {
        let item = itemFrom(el);
        if (!item.name || !item.link || seen[item.link]) return;
        seen[item.link] = true;
        items.push(item);
    });

    return Response.success(items, "");
}
