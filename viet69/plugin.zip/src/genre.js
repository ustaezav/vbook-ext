load('config.js');

function execute() {
    let response = fetch(BASE_URL + "/");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let genres = [];
    let seen = {};
    doc.select("#menu-home .menu-new-badge").remove();
    doc.select("#menu-home a").forEach(function (el) {
        let link = el.attr("href");
        let title = el.text().trim();
        if (!link || !title) return;
        if (link.indexOf("/lienhe") !== -1) return;
        if (seen[link]) return;
        seen[link] = true;
        genres.push({
            title: title,
            input: link,
            script: "list.js"
        });
    });

    doc.select(".widget_tag_cloud .tagcloud a").forEach(function (el) {
        let link = el.attr("href");
        let title = el.text().trim();
        if (!link || !title || seen[link]) return;
        seen[link] = true;
        genres.push({
            title: title,
            input: link,
            script: "list.js"
        });
    });

    return Response.success(genres);
}
