load('config.js');

function execute(query, page) {
    let url;
    if (page) {
        url = normalizeUrl(page);
    } else {
        let value = String(query || "").trim();
        url = value ? normalizeUrl(value) : BASE_URL + "/";
    }

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = [];
    doc.select(".loop-content .item").forEach(function (el) {
        let name = el.select(".entry-title a").text().trim();
        let link = el.select(".entry-title a").attr("href");
        if (!name || !link) return;
        items.push({
            name: name,
            cover: el.select(".thumb img").attr("src"),
            link: link,
            description: el.select(".entry-summary").text().trim(),
            tag: el.select(".entry-date").text().trim()
        });
    });

    return Response.success(items, nextPageUrl(doc));
}
