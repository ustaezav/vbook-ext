let BASE_URL = "https://viet69.be";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

function normalizeUrl(url) {
    let value = String(url || "").trim();
    if (!value) return BASE_URL + "/";
    if (value.charAt(0) === "/") return BASE_URL + value;
    return value.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function nextPageUrl(doc) {
    return doc.select("link[rel=next]").attr("href");
}
