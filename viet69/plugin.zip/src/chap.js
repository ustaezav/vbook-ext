load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let tracks = [];
    doc.select(".movieLoader-server .video2-btn").forEach(function (el) {
        let id = el.attr("data-video");
        if (!id) return;
        tracks.push({
            title: el.text().trim() || "Server " + (tracks.length + 1),
            data: JSON.stringify({
                id: id,
                type: el.attr("data-type"),
                index: tracks.length + 1,
                page: url
            })
        });
    });

    if (tracks.length === 0) {
        doc.select("video.app-plyr-player").forEach(function (el) {
            let src = el.attr("data-src") || el.attr("src");
            if (!src) return;
            tracks.push({
                title: "Server " + (tracks.length + 1),
                data: src
            });
        });
    }

    if (tracks.length === 0) {
        let loader = doc.select(".movieLoader").first();
        let id = loader.attr("data-movie");
        if (id) {
            tracks.push({
                title: "Server #1",
                data: JSON.stringify({
                    id: id,
                    type: loader.attr("data-type"),
                    index: 1,
                    page: url
                })
            });
        }
    }

    if (tracks.length === 0) return Response.error("Không có link phát");

    return Response.success(tracks);
}
