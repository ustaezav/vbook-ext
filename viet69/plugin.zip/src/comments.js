load('config.js');

function emptyResult() {
    return Response.success([], "");
}

function parseComment(el) {
    let replies = [];
    el.select("ul.children > li.comment").forEach(function (reply) {
        replies.push(parseComment(reply));
    });

    let avatar = el.select(".comment-avatar img.avatar").attr("src");
    if (!avatar) avatar = el.select("img.avatar").attr("src");

    return {
        name: el.select(".comment-author cite.fn").first().text().trim(),
        avatar: avatar,
        content: el.select(".comment-content").first().html(),
        description: el.select(".comment-time").first().text().trim(),
        replies: replies
    };
}

function execute(input, page) {
    let url = normalizeUrl(input);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let nonceMatch = doc.html().match(/"nonce":"([^"]+)"/);
    if (!nonceMatch) return emptyResult();

    let form = doc.select("#respond").first();
    let source = form.select('input[name="source"]').attr("value") || "main";
    let postId = form.select('input[name="post_id"]').attr("value");
    let sourcePostId = form.select('input[name="source_post_id"]').attr("value");
    let id = source === "community" ? postId : sourcePostId;
    if (!id) return emptyResult();

    page = parseInt(page || "1", 10);
    if (!page || page < 1) page = 1;

    let api = BASE_URL + "/wp-admin/admin-ajax.php" +
        "?action=app_load_comments" +
        "&nonce=" + encodeURIComponent(nonceMatch[1]) +
        "&post_id=" + encodeURIComponent(id) +
        "&page=" + page +
        "&source=" + encodeURIComponent(source);

    let result = fetch(api, { headers: { "Referer": url } });
    if (!result.ok) return Response.error("HTTP " + result.status);

    let data;
    try {
        data = result.json();
    } catch (error) {
        return emptyResult();
    }
    if (!data || !data.success || !data.data) return emptyResult();

    let html = data.data.html || "";
    if (!html) return emptyResult();

    let parsed = Html.parse('<ul class="comment-list">' + html + "</ul>");
    let items = parsed.select("ul.comment-list > li.comment").map(function (el) {
        return parseComment(el);
    });

    let pagination = data.data.pagination || {};
    let current = parseInt(pagination.current_page, 10) || page;
    let total = parseInt(pagination.total_pages, 10) || 0;
    let next = current < total ? String(current + 1) : "";

    return Response.success(items, next);
}
