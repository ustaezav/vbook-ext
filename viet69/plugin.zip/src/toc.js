load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let name = doc.select(".siteheading").first().text().trim() || "Xem video";

    return Response.success([
        {
            name: name,
            url: url,
            description: "",
            lock: false,
            pay: false
        }
    ]);
}
