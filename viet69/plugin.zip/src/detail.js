load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let name = doc.select(".siteheading").first().text().trim();
    if (!name) name = doc.select("meta[property=og:title]").attr("content").replace(/\s*-\s*Viet69\s*$/i, "");

    let cover = doc.select("meta[property=og:image]").attr("content");
    if (!cover) {
        let source = doc.select("video.app-plyr-player").attr("data-src");
        let id = (source.match(/\/([0-9a-f-]{36})\/playlist\.m3u8/i) || [])[1] || "";
        if (!id) id = (source.match(/\/([0-9a-f-]{36})\//i) || [])[1] || "";
        if (id) cover = "https://img2.vscd.net/thumbnails/" + id + ".jpg";
    }

    let info = [];
    let time = doc.select(".entry-meta .time").first().text().trim();
    if (time) info.push(time.replace(/^on\s+/i, "Ngày: "));
    let author = doc.select(".entry-meta .author").first().text().trim();
    if (author) info.push("Đăng bởi: " + author);

    let genres = [];
    doc.select(".entry-tags a").forEach(function (el) {
        let title = el.text().trim();
        let link = el.attr("href");
        if (!title || !link) return;
        genres.push({
            title: title,
            input: link,
            script: "list.js"
        });
    });

    let related = doc.select(".related-posts, .app-related-videos");
    let suggests = [];
    if (related.size() > 0) {
        suggests.push({
            title: "Có thể bạn thích",
            input: related.first().html(),
            script: "similar.js"
        });
    }

    return Response.success({
        name: name,
        author: author,
        cover: cover,
        description: doc.select(".entry-content p").text().trim(),
        detail: info.join("\n"),
        url: url,
        type: "video",
        format: "series",
        ongoing: true,
        nsfw: true,
        locale: "vi",
        tags: [],
        genres: genres,
        suggests: suggests,
        comments: [
            { title: "Bình luận", input: url, script: "comments.js" }
        ]
    });
}
