load('config.js');

function isDirectMedia(url) {
    return /^https?:\/\//i.test(url) && /\.(m3u8|mp4|mkv|webm|m4v)(\?|#|$)/i.test(url);
}

function extractEmbed(html) {
    let doc = Html.parse(html);
    let src = doc.select("iframe").attr("src");
    if (src) return src;
    let match = String(html).match(/src=["']([^"']+)["']/i);
    return match ? match[1] : "";
}

function playable(stream, referer) {
    let mime = "";
    if (/\.m3u8(\?|#|$)/i.test(stream)) mime = "application/x-mpegURL";
    else if (/\.mp4(\?|#|$)/i.test(stream) || stream.indexOf("videoplayback") !== -1) mime = "video/mp4";

    return {
        type: "native",
        data: stream,
        mimeType: mime,
        headers: {
            "User-Agent": UserAgent.chrome(),
            "Referer": referer
        }
    };
}

function decodeEscapes(value) {
    return value.replace(/\\u([0-9a-fA-F]{4})/g, function (match, hex) {
        return String.fromCharCode(parseInt(hex, 16));
    }).replace(/\\\//g, "/").replace(/&amp;/g, "&");
}

// Blogger's video.g page embeds the real googlevideo URL inside escaped JSON.
function resolveBlogger(url, embed) {
    let response = fetch(url, {
        timeout: 30000,
        headers: { "User-Agent": UserAgent.chrome(), "Referer": embed }
    });
    if (!response.ok) return "";

    let text = response.text();
    let id = text.indexOf("googlevideo.com/videoplayback");
    if (id < 0) return "";

    let start = text.lastIndexOf("https://", id);
    let end = text.indexOf("&quot;", id);
    if (end < 0) end = text.indexOf('"', id);
    if (start < 0 || end < 0) return "";

    return decodeEscapes(text.substring(start, end));
}

function resolveEmbed(embed, page) {
    let origin = (embed.match(/^https?:\/\/[^\/]+/) || [""])[0];
    let idMatch = embed.match(/\/embed\/([^\/?#]+)/);
    if (!origin || !idMatch) return null;

    let api = origin + "/api/get-video?id=" + encodeURIComponent(idMatch[1]) + "&counter=0&tried_ids=";
    let response = fetch(api, {
        timeout: 30000,
        headers: { "User-Agent": UserAgent.chrome(), "Referer": embed }
    });
    if (!response.ok) return null;

    let info;
    try {
        info = response.json();
    } catch (error) {
        return null;
    }
    let stream = info && info.url ? String(info.url) : "";
    if (!stream) return null;
    if (isDirectMedia(stream)) return playable(stream, embed);

    if (stream.indexOf("blogger.com/video.g") !== -1) {
        let blogger = resolveBlogger(stream, embed);
        if (blogger) return playable(blogger, "https://www.blogger.com/");
    }

    return { type: "auto", data: embed, headers: { "User-Agent": UserAgent.chrome(), "Referer": page } };
}

function execute(data) {
    data = String(data || "").trim();
    if (!data) return Response.error("Không có link phát");

    if (isDirectMedia(data)) {
        return Response.success(playable(data, BASE_URL + "/"));
    }

    let payload = null;
    if (data.charAt(0) === "{") {
        try {
            payload = JSON.parse(data);
        } catch (error) {
            payload = null;
        }
    }

    if (!payload) {
        return Response.success({
            type: "auto",
            data: data,
            headers: { "User-Agent": UserAgent.chrome(), "Referer": BASE_URL + "/" }
        });
    }

    let page = payload.page || BASE_URL + "/";
    let endpoint = payload.type === "10" ? "/get.xvideo.php" : "/get.video.php";
    let response = fetch(BASE_URL + endpoint, {
        method: "POST",
        timeout: 30000,
        headers: {
            "User-Agent": UserAgent.chrome(),
            "Referer": page,
            "X-Requested-With": "XMLHttpRequest",
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "movie_id=" + encodeURIComponent(String(payload.id || "")) +
            "&type=" + encodeURIComponent(String(payload.type || "")) +
            "&index=" + encodeURIComponent(String(payload.index || 1))
    });
    if (!response.ok) return Response.error("HTTP " + response.status);

    let embed = extractEmbed(response.text());
    if (!embed) return Response.error("Không tìm thấy link phát");

    let resolved = resolveEmbed(embed, page);
    if (resolved) return Response.success(resolved);

    return Response.success({
        type: "auto",
        data: embed,
        headers: { "User-Agent": UserAgent.chrome(), "Referer": page }
    });
}
