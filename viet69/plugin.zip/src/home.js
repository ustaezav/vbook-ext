load('config.js');

function execute() {
    return Response.success([
        { title: "Mới nhất", input: "/", script: "list.js" },
        { title: "Lượt xem", input: "/xem-nhieu/", script: "list.js" },
        { title: "Lượt thích", input: "/yeu-thich/", script: "list.js" },
        { title: "Bình luận", input: "/binh-luan/", script: "list.js" },
        { title: "Video thành viên", input: "/bai-viet/", script: "list.js" }
    ]);
}
