load('config.js');

const DEFAULT_COVER = "https://www.sinodan.link/images/jipin-default.jpg";

function execute(url, page) {
    let full_url = BASE_URL;
    if (page) full_url += page;
    else full_url += url;

    full_url = full_url.replace(/\/+$/, ""); // Remove trailing slashes
    full_url = full_url.replace(/"/g, "");
    let response = fetch(full_url);
    if (response.ok) {
        let doc = response.html();
        const data = [];
        doc.select(".bd .column-2").forEach(e => {
            let nameElement = e.select(".name");
            let updateElement = e.select(".update a");
            let link = BASE_URL + nameElement.attr("href");
            let cover = DEFAULT_COVER;

            data.push({
                name: nameElement.text(),
                link: link,
                description: `最新章节：${updateElement.text()}`,
                cover: cover,
                host: BASE_URL
            });
        });
        let next = doc.select(".pagelistbox .nextPage").last().attr("href") || '';

        return Response.success(data, next);
    }
    return Response.success([{
      name: "ERROR DEBUG",
      link: full_url,
      description: full_url,
      cover: DEFAULT_COVER,
      host: BASE_URL
    }]);
}
