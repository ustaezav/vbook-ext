load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();

        // Extract cover image
        let cover = doc.select(".bd.column-2 .left img").attr("src");
        cover = cover ? BASE_URL + cover : null;

        // Extract other details
        let title = doc.select(".bd.column-2 .right h1").text();
        let detail = doc.select(".bd.column-2 .right .info")
        let author = doc.select(".bd.column-2 .right .info").text().match(/作者：([^<]+)/)[1].trim();
        let category = doc.select(".bd.column-2 .right .info").text().match(/类型：([^<]+)/)[1].trim();

        // Extract book intro
        let bookIntro = doc.select(".mod.book-intro .bd").text().trim();

        // Create the response object
        return Response.success({
            name: title,
            author: author,
            description: bookIntro,
            detail: detail,
            cover: cover,
            host: BASE_URL,
            genres: [{
              title: category
          }]
        });
    }
    return null;
}
