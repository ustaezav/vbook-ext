let BASE_URL = 'http://www.sinodan.link';
// let NIGHT_API_ENDPOINT = 'https://api.night-api.com/images/nsfw'
// let NIGHT_API_KEY = 'bUFgpNP344-nN34lBqegLilpd1i0HgN-1Jbe1Ep0kb'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}

// let imgRes = fetch(NIGHT_API_ENDPOINT, {
//   headers: {
//     "authorization": NIGHT_API_KEY
//   },
// });
// if (imgRes) {
//   let json = imgRes.json();
//   cover = json.content.url || DEFAULT_COVER;
// };