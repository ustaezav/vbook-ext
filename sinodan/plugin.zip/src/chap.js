load('config.js');

function pageContent(doc) {
    let nr1 = doc.select("#nr1").first();
    if (nr1 === null) return "";
    let nav = nr1.select(".chapterPages");
    if (nav.size() > 0) nav.remove();
    let hints = nr1.select("font");
    for (let k = 0; k < hints.size(); k++) {
        if (hints.get(k).text().indexOf("本章未完") >= 0) hints.get(k).remove();
    }
    return nr1.html().replace(/<p><\/p>/g, "");
}

function pageNumber(link) {
    let m = link.match(/_(\d+)\.html/);
    return m ? parseInt(m[1], 10) : 1;
}

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    if (doc.select("#nr1").first() === null) {
        return Response.error("Không tìm thấy nội dung chương");
    }

    // The chapter text may be split over several pages; ".chapterPages" lists them all.
    let seen = {};
    let pageUrls = [url];
    seen[url] = true;
    let links = doc.select(".chapterPages a");
    for (let i = 0; i < links.size(); i++) {
        let href = links.get(i).attr("href");
        if (!href) continue;
        if (href.indexOf("http") !== 0) href = BASE_URL + href;
        if (seen[href]) continue;
        seen[href] = true;
        pageUrls.push(href);
    }

    pageUrls.sort(function (a, b) { return pageNumber(a) - pageNumber(b); });

    let content = "";
    for (let j = 0; j < pageUrls.length; j++) {
        if (j === 0) {
            content += pageContent(doc);
        } else {
            let pageRes = fetch(pageUrls[j]);
            if (pageRes.ok) content += pageContent(pageRes.html());
        }
    }

    return Response.success(content);
}
