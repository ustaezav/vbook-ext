load('config.js');
function execute(url) {
    // url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    url = "https://www.sinodan.link/view/752584_1.html"
    const doc = fetch(url).html();
    var content = doc.select("#nr1").html();
    var chapterPages = doc.select('.chapterPages');
    var pageLinks = chapterPages.select('a');

    // Process current page content
    content = content.replace(/<p><\/p>/g,'');
    
    // Process next pages
    for (let i = 0; i < pageLinks.length; i++) {
        var link = pageLinks.get(i);
        var href = link.attr('href');
        if (href) {
            var doc2 = fetch(BASE_URL + href).html();
            var pageContent = doc2.select("#nr1").html();
            if (pageContent) {
                content += pageContent.replace(/<p><\/p>/g,'');
            }
        }
    }
    
    return Response.success(content);
}