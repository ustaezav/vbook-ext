function execute() {
    return Response.success([
        {title: "最近", input: "/book/15219_1.html", script: "updates.js"},
        {title: "点击榜", input: "/class/8.html#0", script: "rank.js"},
        {title: "推荐榜", input: "/class/8.html#1", script: "rank.js"},
        {title: "字数榜", input: "/class/8.html#2", script: "rank.js"},
    ]);
}