load('config.js');

const DEFAULT_COVER = "https://www.sinodan.link/images/jipin-default.jpg";

function execute(input, page) {
    input = input || "";
    let parts = input.split("#");
    let path = parts[0];
    let index = parseInt(parts[1] || "0", 10);
    if (isNaN(index) || index < 0) index = 0;

    let url = path;
    if (url.indexOf("http") !== 0) url = BASE_URL + url;

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);

    let doc = response.html();
    let lists = doc.select(".rank-switch .bd ul.list");
    if (lists.size() === 0) return Response.success([]);

    let ul = lists.get(Math.min(index, lists.size() - 1));
    const data = [];
    ul.select("li").forEach(function (li) {
        let linkEl = li.select("a").first();
        let name = linkEl.text();
        let href = linkEl.attr("href");
        if (!name || !href) return;
        data.push({
            name: name,
            link: href.indexOf("http") === 0 ? href : BASE_URL + href,
            description: li.select("dt").text(),
            cover: DEFAULT_COVER,
            host: BASE_URL
        });
    });

    return Response.success(data);
}
