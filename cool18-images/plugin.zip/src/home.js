// Home tabs. Every tab is a paged list.js run with its own input token.
function execute() {
    return Response.success([
        { title: "最新更新", input: "", script: "list.js" },
        { title: "本版精华区", input: "gold", script: "list.js" },
        { title: "人气热贴", input: "hot", script: "list.js" }
    ]);
}
