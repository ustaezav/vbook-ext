load('config.js');

// Home tabs. Each board contributes its own lists; the token is "<board>|<action>".
function execute() {
    let tabs = [];
    for (let i = 0; i < BOARDS.length; i++) {
        let board = BOARDS[i];
        tabs.push({ title: board.title + " · 最新", input: board.id + "|", script: "list.js" });
        tabs.push({ title: board.title + " · 精华", input: board.id + "|gold", script: "list.js" });
        if (i === 0) {
            tabs.push({ title: board.title + " · 人气", input: board.id + "|hot", script: "list.js" });
        }
    }
    return Response.success(tabs);
}
