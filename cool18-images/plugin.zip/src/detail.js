load('config.js');

// A picture set: one thread whose root post holds every image.
function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let subject = doc.select("h1.main-title").text().trim();
    // A later reply links back to the first post of the set; prefer that title.
    let firstPost = doc.select(".reply-info a").first();
    if (firstPost !== null && firstPost.text().trim()) subject = firstPost.text().trim();

    let poster = doc.select(".sender a").first();
    let author = poster !== null ? poster.text().trim() : "";
    let sentAt = doc.select(".sender").text().match(/于\s*([0-9]{4}-[0-9]{2}-[0-9]{2}[^\s]*)/);
    let views = doc.select(".views").text().trim();

    let images = postImages(doc);
    let text = postText(doc);

    let info = [];
    if (author) info.push("Người đăng: " + author);
    if (sentAt) info.push("Ngày: " + sentAt[1]);
    if (views) info.push(views);
    info.push("Số ảnh: " + images.length);

    let uid = firstUid(doc);
    let suggests = [];
    if (uid) suggests.push({ title: "Cùng người đăng", input: boardOf(url) + "|uid:" + uid, script: "list.js" });

    return Response.success({
        name: subject || "Cool18 GIF",
        author: author,
        cover: images.length > 0 ? images[0] : "",
        description: text || ("Gồm " + images.length + " ảnh"),
        detail: info.join("<br>"),
        url: url,
        type: "comic",
        format: "comic",
        ongoing: true,
        nsfw: true,
        locale: "zh",
        suggests: suggests
    });
}
