load('config.js');

function execute(query, page) {
    let feed = keywordFeed(query || "", page);
    if (feed === null) return Response.error("Không tải được kết quả tìm kiếm");
    return Response.success(attachThumbs(feed.items), feed.next);
}
