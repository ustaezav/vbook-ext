load('config.js');

// Generic paged list behind the home tabs and the genre chips.
//   ""            latest updates (tid cursor)
//   "gold"        本版精华区 — editor picks
//   "hot"         人气热贴 — reading ranking
//   "cat:<name>"  category listing
//   "uid:<id>"    one poster's threads
function execute(query, page) {
    query = query || "";
    let feed;
    if (query === "gold") {
        feed = goldFeed(page);
    } else if (query === "hot") {
        feed = hotFeed();
    } else if (query.indexOf("cat:") === 0) {
        feed = categoryFeed(query.substring(4), page);
    } else if (query.indexOf("uid:") === 0) {
        feed = posterFeed(query.substring(4), page);
    } else {
        feed = latestFeed(page);
    }
    if (feed === null) return Response.error("Không tải được danh sách");
    return Response.success(attachThumbs(feed.items), feed.next);
}
