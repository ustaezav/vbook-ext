load('config.js');

// Generic paged list behind the home tabs and the genre chips. The token is
// "<board>|<action>":
//   "<board>|"             latest updates (tid cursor)
//   "<board>|gold"         本版精华区 — editor picks
//   "<board>|hot"          人气热贴 — reading ranking
//   "<board>|cat:<name>"   category listing
//   "<board>|uid:<id>"     one poster's threads
// A bare token (no "<board>|") uses the default board, so the genre chips and
// earlier entries keep working.
function execute(query, page) {
    let spec = parseListQuery(query);
    let board = spec.board;
    let key = spec.key;
    let feed;
    if (key === "gold") {
        feed = goldFeed(board, page);
    } else if (key === "hot") {
        feed = hotFeed(board);
    } else if (key.indexOf("cat:") === 0) {
        feed = categoryFeed(board, key.substring(4), page);
    } else if (key.indexOf("uid:") === 0) {
        feed = posterFeed(board, key.substring(4), page);
    } else {
        feed = latestFeed(board, page);
    }
    if (feed === null) return Response.error("Không tải được danh sách");
    return Response.success(attachThumbs(feed.items), feed.next);
}
