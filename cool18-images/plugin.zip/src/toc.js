load('config.js');

// A picture set is one post; the root post is the whole gallery. A set that was
// split across posts uses direct replies with real content, so those become extra
// chapters. Short replies (thanks, votes) are skipped.
const MIN_PART_SIZE = 512;

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let rootTid = tidOf(url);
    let board = boardOf(url);
    let hidden = doc.select("input[name=rootid]").first();
    if (hidden !== null) {
        let parent = parseInt(hidden.attr("value"), 10);
        if (!isNaN(parent) && parent > 0 && parent !== rootTid) {
            rootTid = parent;
            url = threadUrl(board, parent);
        }
    }

    let subject = doc.select("h1.main-title").text().trim();
    let firstPost = doc.select(".reply-info a").first();
    if (firstPost !== null && firstPost.text().trim()) subject = firstPost.text().trim();

    let chapters = [{
        name: subject || "Toàn bộ",
        url: url,
        description: "",
        lock: false,
        pay: false
    }];

    if (rootTid > 0) {
        let childResponse = fetch(boardBase(board) + "/index.php?app=forum&act=achildlist&tid=" + rootTid);
        if (childResponse.ok) {
            let rows = childResponse.json();
            let parts = [];
            for (let i = 0; i < (rows ? rows.length : 0); i++) {
                let row = rows[i];
                if (parseInt(row.uptid, 10) !== rootTid) continue;
                if (parseInt(row.size, 10) < MIN_PART_SIZE) continue;
                parts.push(row);
            }
            parts.sort(function (a, b) { return parseInt(a.tid, 10) - parseInt(b.tid, 10); });
            for (let j = 0; j < parts.length; j++) {
                chapters.push({
                    name: stripTags(parts[j].subject) || subject,
                    url: threadUrl(board, parts[j].tid),
                    description: "",
                    lock: false,
                    pay: false
                });
            }
        }
    }

    return Response.success(chapters);
}
