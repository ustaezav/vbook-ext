// Shared helpers for the Cool18 GIF extension. Every script starts with
// load('config.js'); a loaded library must not load another file, so all shared code
// lives here.
//
// 性趣贴图 (cool18.com/bbs) is the board of image posts: one thread is one picture
// set, and its images sit in the root post's body. The feeds, the search and the
// board's own AJAX list all follow the same markup as the sibling Cool18 Novels
// extension, so the listing helpers are shared here.

let BASE_URL = "https://www.cool18.com/bbs";
try {
  if (DOMAIN) {
    BASE_URL = DOMAIN;
  }
} catch (error) {}

function siteOrigin() {
  let match = BASE_URL.match(/^(https?:\/\/[^\/]+)/);
  return match ? match[1] : BASE_URL;
}

// cool18.com runs every board on the same forum engine, so only the path differs and
// one extension can list several boards. `id` is the token board prefix.
let BOARDS = [
  { id: "bbs", path: "/bbs", title: "性趣贴图" },
  { id: "bbs6", path: "/bbs6", title: "私房自拍" },
  { id: "bbs2", path: "/bbs2", title: "情色靓影" },
];

function boardById(id) {
  for (let i = 0; i < BOARDS.length; i++) {
    if (BOARDS[i].id === id) return BOARDS[i];
  }
  return BOARDS[0];
}

function boardBase(id) {
  return siteOrigin() + boardById(id).path;
}

// Board of an incoming url, so a reply/root thread stays on its own board.
function boardOf(url) {
  let match = String(url).match(/\/(bbs\d*)\//);
  if (match) {
    for (let i = 0; i < BOARDS.length; i++) {
      if (BOARDS[i].id === match[1]) return BOARDS[i].id;
    }
  }
  return BOARDS[0].id;
}

// List tokens are "<board>|<action>"; a bare token keeps the default board so the
// genre chips and earlier entries still resolve.
function parseListQuery(query) {
  let text = String(query || "");
  let cut = text.indexOf("|");
  if (cut === -1) return { board: BOARDS[0].id, key: text };
  return {
    board: boardById(text.substring(0, cut)).id,
    key: text.substring(cut + 1),
  };
}

// Rewrite an incoming url's host to the configured domain, keeping path and query.
// Call this first thing in every url-receiving execute(url).
function normalizeUrl(url) {
  let match = String(url).match(
    /^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?[^\/\n]+(\/.*)$/,
  );
  return match ? siteOrigin() + match[1] : url;
}

// Resolve a link found on a page into an absolute url.
function absUrl(href) {
  if (!href) return "";
  href = String(href);
  if (/^https?:\/\//i.test(href)) return normalizeUrl(href);
  if (href.charAt(1) === "/")
    return siteOrigin().replace(/\/\/[^\/]*$/, "") + href;
  if (href.charAt(0) === "/") return siteOrigin() + href;
  return BASE_URL + "/" + href;
}

// Resolve a link that lives on one board; search and list rows are relative to it.
function boardAbs(board, href) {
  if (!href) return "";
  href = String(href);
  if (/^https?:\/\//i.test(href)) return normalizeUrl(href);
  if (href.charAt(0) === "/") return siteOrigin() + href;
  return boardBase(board) + "/" + href;
}

function threadUrl(board, tid) {
  return boardBase(board) + "/index.php?app=forum&act=threadview&tid=" + tid;
}

function tidOf(url) {
  let match = String(url).match(/[?&]tid=(\d+)/);
  return match ? parseInt(match[1], 10) : 0;
}

function stripTags(value) {
  if (!value) return "";
  return String(value)
    .replace(/<[^>]*>/g, "")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/g, "'")
    .replace(/[\s\u3000]+/g, " ")
    .trim();
}

function absoluteMedia(src) {
  if (!src) return "";
  if (/^(https?:|data:)/i.test(src)) return src;
  if (/^\/\//.test(src)) return "https:" + src;
  return absUrl(src);
}

// First uid linked from the page, used for the "more by this poster" tab.
function firstUid(doc) {
  let links = doc.select("a");
  for (let i = 0; i < links.size(); i++) {
    let href = links.get(i).attr("href");
    let match = href ? String(href).match(/[?&]uid=(\d+)/) : null;
    if (match) return match[1];
  }
  return "";
}

function categories() {
  let names = [
    "精彩炮图",
    "网友原创",
    "美女共赏",
    "妹子福利",
    "欧美炮图",
    "岛国炮图",
    "国产炮图",
  ];
  let list = [];
  for (let i = 0; i < names.length; i++) {
    list.push({ title: names[i], input: "cat:" + names[i], script: "list.js" });
  }
  return list;
}

// Board list rows (search / category / uid results). Each row is
// <li><a href=…><b>name</b></a>- <font>poster</font><i> date </i></li>.
function parseThreadList(doc, board) {
  let items = [];
  doc.select("ul.thread-list li").forEach(function (row) {
    let link = row.select("a").first();
    if (link === null) return;
    let href = link.attr("href");
    if (!href || String(href).indexOf("threadview") === -1) return;
    let name = link
      .text()
      .replace(/[\s\u3000]+/g, " ")
      .trim();
    if (!name) return;
    let poster = row.select("font").first();
    let date = row.select("i").first();
    let bits = [];
    if (poster !== null && poster.text().trim())
      bits.push(poster.text().trim());
    if (date !== null && date.text().trim()) bits.push(date.text().trim());
    items.push({
      name: name,
      link: boardAbs(board, href),
      description: bits.join(" · "),
      host: siteOrigin(),
    });
  });
  return items;
}

// Next-page token from the pager: the board numbers pages as "p=2", "p=3", …
function nextPageToken(doc) {
  let link = doc.select("nav.pagination-bar a.next").first();
  if (link === null) return "";
  let match = String(link.attr("href") || "").match(/[?&]p=(\d+)/);
  return match ? match[1] : "";
}

function pagedSearchUrl(board, extra, page) {
  let url =
    boardBase(board) +
    "/index.php?action=search&act=threadsearch&app=forum&first=1&" +
    extra +
    "&submit=" +
    encodeURIComponent("查询");
  if (page) url += "&p=" + encodeURIComponent(page);
  return url;
}

function boardFeed(board, url) {
  let response = fetch(url);
  if (!response.ok) return null;
  let doc = response.html();
  return { items: parseThreadList(doc, board), next: nextPageToken(doc) };
}

// The AJAX list glues the board category onto the subject as a trailing
// "[category]"; the thread page itself carries a plain title.
function splitListSubject(subject) {
  let text = stripTags(subject);
  let match = text.match(/^(.*?)\s*\[([^\]]+)\]\s*$/);
  if (match) return { name: match[1].trim(), tag: match[2].trim() };
  return { name: text, tag: "" };
}

// Newest posts, from the board's own AJAX feed. `page` is a tid cursor: the feed
// returns posts older than it. Reply rows (uptid != 0) are skipped; only the root
// posts are picture sets.
function latestFeed(board, page) {
  let mtid = page ? String(page) : "0";
  let response = fetch(
    boardBase(board) +
      "/index.php?app=forum&act=ajax&mtid=" +
      encodeURIComponent(mtid) +
      "&aifilter=0",
  );
  if (!response.ok) return null;
  let rows = response.json();
  let items = [];
  let cursor = 0;
  for (let i = 0; i < (rows ? rows.length : 0); i++) {
    let row = rows[i];
    let tid = parseInt(row.tid, 10);
    let uptid = parseInt(row.uptid, 10);
    if (uptid === 0 && (cursor === 0 || tid < cursor)) cursor = tid;
    if (uptid !== 0 || parseInt(row.rootid, 10) !== 0) continue;
    let meta = splitListSubject(row.subject);
    if (!meta.name) continue;
    items.push({
      name: meta.name,
      link: threadUrl(board, row.tid),
      description: meta.tag ? "『" + meta.tag + "』" : "",
      tag: meta.tag || "",
      host: siteOrigin(),
    });
  }
  return { items: items, next: cursor ? String(cursor) : "" };
}

// 精华热贴 — editor-picked threads.
function goldFeed(board, page) {
  let url = boardBase(board) + "/index.php?app=forum&act=gold";
  if (page) url += "&p=" + encodeURIComponent(page);
  let response = fetch(url);
  if (!response.ok) return null;
  let doc = response.html();
  let items = [];
  doc.select("ul.post-list li.post-item a").forEach(function (link) {
    let href = link.attr("href");
    if (!href || String(href).indexOf("threadview") === -1) return;
    let name = stripTags(link.text())
      .replace(/^[.．·\s]+/, "")
      .trim();
    if (!name) return;
    items.push({ name: name, link: boardAbs(board, href), host: siteOrigin() });
  });
  return { items: items, next: nextPageToken(doc) };
}

// 人气榜 — reading ranking, one page only.
function hotFeed(board) {
  let response = fetch(boardBase(board) + "/index.php?app=forum&act=hot");
  if (!response.ok) return null;
  let doc = response.html();
  let items = [];
  doc.select("tr").forEach(function (row) {
    let link = row.select("td.title-col a").first();
    if (link === null) return;
    let href = link.attr("href");
    if (!href || String(href).indexOf("threadview") === -1) return;
    let raw = stripTags(link.text());
    // The rank row glues "- poster (N bytes) date (M reads)" onto the title.
    let cut = raw.search(/\s-\s[^()]*\([\d,]+ bytes\)/i);
    let name = (cut > 0 ? raw.substring(0, cut) : raw).trim();
    if (!name) return;
    items.push({
      name: name,
      link: boardAbs(board, href),
      tag: stripTags(row.select("td.rank-col").text()),
      host: siteOrigin(),
    });
  });
  return { items: items, next: "" };
}

function categoryFeed(board, name, page) {
  return boardFeed(
    board,
    pagedSearchUrl(board, "type=" + encodeURIComponent(name), page),
  );
}

function keywordFeed(board, keyword, page) {
  return boardFeed(
    board,
    pagedSearchUrl(board, "keywords=" + encodeURIComponent(keyword), page),
  );
}

function posterFeed(board, uid, page) {
  return boardFeed(
    board,
    pagedSearchUrl(board, "uid=" + encodeURIComponent(uid), page),
  );
}

// ---------------------------------------------------------------------------
// Post bodies — a picture set lives in <pre> inside #content-section, with each
// image wrapped in its own <center> and paragraph separated by <p></p>/<br />.
// ---------------------------------------------------------------------------

function contentNode(doc) {
  let node = doc.select("#content-section pre").first();
  if (node === null) node = doc.select("#content-section").first();
  if (node === null) return null;
  node
    .select(".view_ad_incontent, .ai-detection-feedback, script, style, iframe")
    .remove();
  return node;
}

// Ordered, de-duplicated image urls from a post body. In-content ads are injected
// client-side, so the served HTML only carries the post's own images.
function postImages(doc) {
  let node = contentNode(doc);
  if (node === null) return [];
  let images = [];
  let seen = {};
  node.select("img").forEach(function (el) {
    let src = absoluteMedia(el.attr("data-src") || el.attr("src"));
    if (!src || !/^https?:\/\//i.test(src) || seen[src]) return;
    seen[src] = true;
    images.push(src);
  });
  return images;
}

// The post's captions, with the images removed, for the detail description.
function postText(doc) {
  let node = contentNode(doc);
  if (node === null) return "";
  node.select("img").remove();
  return stripTags(node.text());
}

// ---------------------------------------------------------------------------
// "Xem trước bìa" — the list thumbnail. The board's feeds carry no image, so when
// the PREVIEW_THUMB setting is on each list entry fetches its own thread and uses the
// post's first image as the cover. Off keeps the listing to a single request.
// ---------------------------------------------------------------------------

function previewThumbEnabled() {
  try {
    return String(PREVIEW_THUMB) === "true";
    // return false; // Disabled for now, as it is slow and not supported yet.
  } catch (error) {
    return false;
  }
}

function threadCover(url) {
  let response = fetch(url);
  if (!response.ok) return "";
  let images = postImages(response.html());
  return images.length > 0 ? images[0] : "";
}

function attachThumbs(items) {
  if (!previewThumbEnabled()) return items;
  for (let i = 0; i < items.length; i++) {
    if (items[i].cover) continue;
    let cover = threadCover(items[i].link);
    if (cover) items[i].cover = cover;
  }
  return items;
}
