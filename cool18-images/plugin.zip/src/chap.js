load('config.js');

// Comic chapter: the ordered image url array for one post.
function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let images = postImages(response.html());
    if (images.length === 0) return Response.error("Không tìm thấy ảnh");
    return Response.success(images);
}
