load('config.js');
function execute(input) {
    let doc;
    if (input && input.indexOf("<") === 0) {
        doc = Html.parse(input);
    } else {
        let response = request(absoluteUrl(input));
        if (!response.ok) return Response.error("HTTP " + response.status);
        doc = response.html();
    }

    let items = [];
    let seen = {};
    let nodes = doc.select("#related_videos .thumb-overlay-albums");

    nodes.forEach(function (el) {
        let a = el.select("a[href]").first();
        if (!a) return;
        let link = a.attr("href");
        if (!link || seen[link]) return;
        if (!/^\/(moehome-(19|20|21)-[0-9]+|showinfo-(19|20|21)-[0-9]+-[0-9]+)\.html/.test(link)) return;
        let img = el.select("img").first();
        let name = img ? img.attr("title").trim() : "";
        if (!name) name = el.select(".video-title").text().trim();
        if (!name) return;
        seen[link] = true;
        items.push({
            name: name,
            cover: img ? (img.attr("data-src") || img.attr("src")) : "",
            link: link
        });
    });

    return Response.success(items, "");
}
