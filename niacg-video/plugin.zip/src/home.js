function execute() {
    return Response.success([
        { title: "里番", input: "/listinfo-19-0.html", script: "search.js" },
        { title: "3D", input: "/listinfo-20-0.html", script: "search.js" },
        { title: "同人", input: "/listinfo-21-0.html", script: "search.js" }
    ]);
}
