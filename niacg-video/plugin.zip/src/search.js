load('config.js');

let SEARCH_CLASS_IDS = ["19", "20", "21"];

function collectItems(doc, items, seen) {
    let nodes = doc.select(".list-col .thumb-overlay-albums");
    if (nodes.isEmpty()) nodes = doc.select(".thumb-overlay-albums");

    nodes.forEach(function (el) {
        let a = el.select("a[href]").first();
        if (!a) return;
        let link = a.attr("href");
        if (!link || seen[link]) return;
        if (!/^\/(moehome-(19|20|21)-[0-9]+|showinfo-(19|20|21)-[0-9]+-[0-9]+)\.html/.test(link)) return;

        let img = el.select("img").first();
        let name = el.select("span.video-title").text().trim();
        if (!name && img) name = img.attr("title").trim();
        if (!name) return;

        seen[link] = true;
        items.push({
            name: name,
            cover: img ? (img.attr("data-src") || img.attr("src")) : "",
            link: link,
            description: el.select(".title-truncate.tags").text().replace(/^\s*标签:\s*/, ""),
            tag: el.select(".label-sub").text().trim()
        });
    });
}

function listingResult(doc) {
    let items = [];
    collectItems(doc, items, {});
    let next = doc.select("a.next-niacg").attr("href");
    return Response.success(items, next ? absoluteUrl(next) : "");
}

function searchPage(token) {
    let map = {};
    try {
        map = JSON.parse(token);
    } catch (error) {
        return Response.error("Trang tìm kiếm không hợp lệ");
    }

    let items = [];
    let seen = {};
    let nextMap = {};

    Object.keys(map).forEach(function (classid) {
        let response = request(map[classid]);
        if (!response.ok) return;
        let doc = response.html();
        collectItems(doc, items, seen);
        let next = doc.select("a.next-niacg").attr("href");
        if (next) nextMap[classid] = absoluteUrl(next);
    });

    return Response.success(items, Object.keys(nextMap).length ? JSON.stringify(nextMap) : "");
}

function execute(query, page) {
    query = query || "";
    page = page || "";

    if (page.indexOf("/") === 0 || page.indexOf("http") === 0) {
        let response = request(absoluteUrl(page));
        if (!response.ok) return Response.error("HTTP " + response.status);
        return listingResult(response.html());
    }

    if (page.indexOf("{") === 0) {
        return searchPage(page);
    }

    if (query.indexOf("/") === 0 || query.indexOf("http") === 0) {
        let response = request(absoluteUrl(query));
        if (!response.ok) return Response.error("HTTP " + response.status);
        return listingResult(response.html());
    }

    let items = [];
    let seen = {};
    let nextMap = {};

    SEARCH_CLASS_IDS.forEach(function (classid) {
        let response = request(BASE_URL + "/e/search/index.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "keyboard=" + encodeURIComponent(query) +
                "&show=title,text,keyboard,ftitle&classid=" + classid +
                "&tempid=1&Submit=" + encodeURIComponent("搜索")
        });
        if (!response.ok) return;
        let doc = response.html();
        collectItems(doc, items, seen);
        let next = doc.select("a.next-niacg").attr("href");
        if (next) nextMap[classid] = absoluteUrl(next);
    });

    return Response.success(items, Object.keys(nextMap).length ? JSON.stringify(nextMap) : "");
}
