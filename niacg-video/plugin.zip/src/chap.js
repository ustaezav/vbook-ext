load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    let response = request(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let playerScript = "";
    doc.select("script").forEach(function (el) {
        let body = el.html();
        if (body.indexOf("DPlayer") !== -1) playerScript = body;
    });

    let servers = [];
    let match;
    let qualityRe = /\{\s*name:\s*['"]([^'"]*)['"]\s*,\s*url:\s*['"]([^'"]+)['"]/g;
    while ((match = qualityRe.exec(playerScript)) !== null) {
        servers.push({ title: match[1] || "Nguồn", data: match[2] });
    }

    if (!servers.length) {
        let urlRe = /url:\s*['"]([^'"]+\.(?:mp4|m3u8)[^'"]*)['"]/gi;
        while ((match = urlRe.exec(playerScript)) !== null) {
            servers.push({ title: "Mặc định", data: match[1] });
        }
    }

    if (!servers.length) {
        servers.push({ title: "Mặc định", data: url });
    }

    return Response.success(servers);
}
