load('config.js');
function execute(data) {
    if (!data) return Response.error("Không có nguồn phát");
    data = absoluteUrl(data);

    let isHls = data.indexOf(".m3u8") !== -1;
    let isMp4 = data.indexOf(".mp4") !== -1;

    if (isHls || isMp4) {
        return Response.success({
            type: "native",
            data: data,
            host: BASE_URL,
            mimeType: isHls ? "application/x-mpegURL" : "video/mp4",
            headers: {
                "User-Agent": UserAgent.chrome(),
                "Referer": BASE_URL + "/"
            },
            timeSkip: []
        });
    }

    return Response.success({
        type: "auto",
        data: data,
        host: BASE_URL,
        headers: {
            "User-Agent": UserAgent.chrome(),
            "Referer": BASE_URL + "/"
        },
        timeSkip: []
    });
}
