load('config.js');
function execute() {
    let genres = [
        { title: "里番", input: "/listinfo-19-0.html", script: "search.js" },
        { title: "3D", input: "/listinfo-20-0.html", script: "search.js" },
        { title: "同人", input: "/listinfo-21-0.html", script: "search.js" }
    ];

    let response = request(BASE_URL + "/");
    if (!response.ok) return Response.success(genres);
    let doc = response.html();

    let seen = {};
    genres.forEach(function (item) {
        seen[item.title] = true;
    });

    doc.select(".tag-hot a[href]").forEach(function (el) {
        let title = el.text().trim();
        if (!title || seen[title]) return;
        seen[title] = true;
        genres.push({ title: title, input: el.attr("href"), script: "search.js" });
    });

    return Response.success(genres);
}
