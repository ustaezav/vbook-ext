load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    let response = request(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let chapters = [];
    doc.select(".episode a[href]").forEach(function (el) {
        let divs = el.select("li div");
        let name = divs.size() > 1 ? divs.get(1).text().trim() : "";
        if (!name) name = el.select("img").attr("alt").trim();
        if (!name) name = el.select("li").text().trim();
        if (!name) name = el.text().trim();
        chapters.push({
            name: name,
            url: el.attr("href"),
            description: "",
            lock: false,
            pay: false
        });
    });

    if (!chapters.length) {
        chapters.push({
            name: "Xem phim",
            url: url,
            description: "",
            lock: false,
            pay: false
        });
    } else {
        chapters.reverse();
    }

    return Response.success(chapters);
}
