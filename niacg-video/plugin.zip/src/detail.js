load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    let response = request(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let name = doc.select("h3.big-title-truncate").text().trim();
    if (!name) name = doc.select("h4.big-title-truncate").text().trim();
    if (!name) name = doc.select("title").text().trim();

    let playerScript = "";
    doc.select("script").forEach(function (el) {
        let body = el.html();
        if (body.indexOf("DPlayer") !== -1) playerScript = body;
    });

    let cover = "";
    let coverMatch = playerScript.match(/pic:\s*['"]([^'"]+)['"]/);
    if (coverMatch) cover = coverMatch[1];

    let tags = [];
    let seenTags = {};
    doc.select(".col-md-4 a[href*='search_query=']").forEach(function (el) {
        let title = el.text().trim();
        if (!title || seenTags[title]) return;
        seenTags[title] = true;
        tags.push({ title: title, input: title, script: "search.js" });
    });

    let info = [];
    doc.select(".col-md-4 .m-t-5").forEach(function (el) {
        let text = el.text().trim();
        if (/^(车号|日期|查看|时间)/.test(text)) info.push(text);
    });

    let result = {
        name: name,
        author: doc.select(".col-md-4 a[href*='/e/search/']").first().text().trim(),
        cover: cover,
        description: doc.select("meta[name=description]").attr("content"),
        detail: info.join(" · "),
        url: url,
        type: "video",
        format: "series",
        ongoing: true,
        nsfw: true,
        tags: tags
    };

    if (tags.length) {
        result.genres = [{ title: "Cùng thể loại", input: tags[0].input, script: "search.js" }];
    }

    result.suggests = [{ title: "Phim liên quan", input: url, script: "similar.js" }];
    if (!doc.select("script[src*='lgyPl2.0']").isEmpty()) {
        result.comments = [{ title: "Bình luận", input: url, script: "comments.js" }];
    }

    return Response.success(result);
}
