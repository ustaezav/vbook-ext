load('config.js');

// Comic threads: chapters are the starter's pages, where the images are.
// Text threads: chapters are the starter's pages too, read as a novel (text only —
// the replies stay in the comments section).
function execute(url) {
    let tid = tidOf(url);
    if (!tid) return Response.error("URL không hợp lệ");

    let doc = fetchDoc(threadUrl(tid, 1));
    if (doc === null) return Response.error("Không tải được chủ đề");

    let uid = authorId(doc);
    let opUrl = uid ? threadUrl(tid, 1) + "&authorid=" + uid : "";
    let opDoc = opUrl ? fetchDoc(opUrl) : null;
    let comic = opDoc !== null ? countContentImages(opDoc) > 0 : countContentImages(doc) > 0;

    let chapters = [];

    if (comic) {
        if (opDoc !== null) {
            let pages = totalPages(opDoc) || 1;
            for (let i = 1; i <= pages; i++) {
                let chapterUrl = threadUrl(tid, i) + "&authorid=" + uid + "&sht=images";
                let pageDoc = i === 1 ? opDoc : fetchDoc(threadUrl(tid, i) + "&authorid=" + uid);
                if (pageDoc === null) continue;
                let count = countContentImages(pageDoc);
                if (count > 0) {
                    chapters.push({ name: "Trang " + i + " (" + count + " ảnh)", url: chapterUrl });
                }
            }
        }
        if (chapters.length === 0) {
            chapters.push({ name: "Trang 1", url: threadUrl(tid, 1) + "&sht=images" });
        }
        return Response.success(chapters);
    }

    if (opDoc !== null) {
        let pages = totalPages(opDoc) || 1;
        for (let i = 1; i <= pages; i++) {
            chapters.push({ name: "Trang " + i, url: threadUrl(tid, i) + "&authorid=" + uid });
        }
        return Response.success(chapters);
    }

    chapters.push({ name: "Trang 1", url: threadUrl(tid, 1) });
    return Response.success(chapters);
}
