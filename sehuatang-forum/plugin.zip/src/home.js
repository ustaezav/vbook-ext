load('config.js');

// Home tabs. The first three read the guide feed (话题) through list.js, the last one
// shows the board tree from boards.js.
function execute() {
    return Response.success([
        { title: "最新发表", input: "/forum.php?mod=guide&view=newthread&mobile=2", script: "list.js" },
        { title: "最新热门", input: "/forum.php?mod=guide&view=hot&mobile=2", script: "list.js" },
        { title: "最新精华", input: "/forum.php?mod=guide&view=digest&mobile=2", script: "list.js" },
        { title: "版块", input: "", script: "boards.js" }
    ]);
}
