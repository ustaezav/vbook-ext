load('config.js');

// Board tree (版块): each board opens its thread list through list.js.
function execute() {
    let doc = fetchDoc(BASE_URL + "/forum.php?forumlist=1&mobile=2");
    if (doc === null) return Response.error("Không tải được danh sách chuyên mục");

    let items = parseBoards(doc);
    for (let i = 0; i < items.length; i++) {
        items[i].action = { type: "list", name: items[i].name, script: "list.js", input: items[i].link };
    }
    return Response.success(items, "");
}
