load('config.js');

// A thread with images from its starter is a comic (chapters = the starter's pages,
// chap = the images). A thread without any image is a novel instead, so its text is
// readable in the reader (chapters = the thread's Discuz pages).
function execute(url) {
    let tid = tidOf(url);
    if (!tid) return Response.error("URL không hợp lệ");

    let doc = fetchDoc(threadUrl(tid, 1));
    if (doc === null) return Response.error("Không tải được chủ đề");

    let uid = authorId(doc);
    let comic = false;
    if (uid) {
        let opDoc = fetchDoc(threadUrl(tid, 1) + "&authorid=" + uid);
        comic = opDoc !== null && countContentImages(opDoc) > 0;
    } else {
        comic = countContentImages(doc) > 0;
    }

    let title = cleanText(doc.select("h2.n5_bbsnrbt").text());
    if (!title) title = cleanText(doc.select("title").text()).replace(/\s+-\s+98堂.*$/, "");

    let first = doc.select("div.postlist div.display").first();
    let body = first.select(".message").first();

    let cover = "";
    let images = body.select("img");
    for (let i = 0; i < images.size(); i++) {
        let src = absUrl(images.get(i).attr("src") || images.get(i).attr("data-original") || images.get(i).attr("file") || "");
        if (isContentImage(src)) {
            cover = src;
            break;
        }
    }

    body.select("script, style, .blockbtn, img").remove();
    // A text thread is read chapter by chapter; its story must not be repeated as the
    // intro. Only image threads keep the starter's text (film info, download links).
    let detail = comic ? absolutize(body.html()).replace(/<a\s[^>]*><\/a>/gi, "") : "";

    let genres = [];
    let board = cleanText(doc.select(".n5_tbys .dqym").text());
    let boardLink = doc.select(".n5_tbys a.back_btn").attr("href");
    if (board && String(boardLink).indexOf("forumdisplay") !== -1) {
        genres.push({ title: board, input: absUrl(boardLink), script: "list.js" });
    }

    let book = {
        name: title,
        author: cleanText(first.select(".n5_yhmhdj h3 a").text()),
        genres: genres,
        comments: [
            { title: "Bình luận", input: threadUrl(tid, 1), script: "comments.js" }
        ],
        ongoing: true,
        nsfw: true,
        type: comic ? "comic" : "novel"
    };
    if (cover) book.cover = cover;
    if (detail) book.detail = detail;
    return Response.success(book);
}
