load('config.js');

// Thread list of one board, or one page of the guide feed (最新发表 / 热门 / 精华).
// `page` is a page number; the guide feed has no pager, so it keeps going while the
// page returns rows.
function execute(input, page) {
    let current = parseInt(page, 10);
    if (isNaN(current) || current < 1) current = 1;

    let url = withPage(mobileUrl(input || "/forum.php?mod=guide&view=newthread"), current);
    let doc = fetchDoc(url);
    if (doc === null) return Response.error("Không tải được danh sách");

    let items = parseThreads(doc);

    let total = totalPages(doc);
    let next = "";
    if (total > 0) {
        if (current < total) next = String(current + 1);
    } else if (url.indexOf("forumdisplay") === -1 && items.length > 0) {
        // The guide feed has no pager: keep going while the page returns rows.
        next = String(current + 1);
    }
    return Response.success(items, next);
}
