load('config.js');

// Category chips: every board of the forum tree, in its category order.
function execute() {
    let doc = fetchDoc(BASE_URL + "/forum.php?forumlist=1&mobile=2");
    if (doc === null) return Response.error("Không tải được danh sách chuyên mục");

    return Response.success(parseBoards(doc).map(function (board) {
        return { title: board.name, input: board.link, script: "list.js" };
    }));
}
