load('config.js');

// Comic chapter ("sht=images"): the content images of the starter's page, in reading
// order. The app loads each one itself with the chapter as Referer, which the image
// host accepts, so nothing is downloaded here.
//
// Text chapter: the starter's posts of that page as HTML — the replies are not part of
// the chapter, they are the comments section of the detail screen.
function execute(url) {
    if (isImageChapter(url)) return imageChapter(url);
    return textChapter(url);
}

function isImageChapter(url) {
    return String(url || "").indexOf("sht=images") !== -1;
}

function imageChapter(url) {
    let doc = fetchDoc(mobileUrl(url));
    if (doc === null) return Response.error("Không tải được trang");

    let images = [];
    doc.select("div.postlist div.display .message img").forEach(function (img) {
        let src = absUrl(img.attr("src") || img.attr("data-original") || img.attr("file") || "");
        if (isContentImage(src)) images.push(src);
    });

    if (images.length === 0) return Response.error("Trang này không có ảnh");
    return Response.success(images);
}

function textChapter(url) {
    let pageUrl = mobileUrl(url);
    let doc = fetchDoc(pageUrl);
    if (doc === null) return Response.error("Không tải được trang");

    let parts = [];
    doc.select("div.postlist div.display").forEach(function (el) {
        let body = el.select(".message").first();
        body.select("script, style, .blockbtn").remove();
        let html = absolutize(body.html())
            .replace(/^(?:\s|<br\s*\/?>)+/i, "")
            .replace(/(?:\s|<br\s*\/?>)+$/i, "");
        if (html) parts.push(html);
    });

    if (parts.length === 0) return Response.error("Trang này không có nội dung");
    return Response.success(inlineImages(parts.join("<hr>"), pageUrl));
}
