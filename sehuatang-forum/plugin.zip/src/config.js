// 98堂 runs on Discuz with an age gate: every new session first answers a "满18岁"
// page whose inline script holds `var safeid='…'`. Sending that value back as the
// _safe cookie unlocks the forum (the app keeps its own cookie jar).
let BASE_URL = "https://www.sehuatang.org";
try {
    if (DOMAIN) BASE_URL = String(DOMAIN).replace(/\/+$/, "");
} catch (error) {
}

// Every relative href/src on the mobile skin ("forum.php?…", "/uc_server/…") is
// resolved against the configured domain; absolute and data: URLs stay untouched.
function absUrl(value) {
    let text = String(value || "").trim();
    if (!text) return "";
    if (/^(?:https?:|data:|magnet:|ed2k:|javascript:|mailto:)/i.test(text)) return text;
    if (text.indexOf("//") === 0) return "https:" + text;
    if (text.charAt(0) === "/") return BASE_URL + text;
    return BASE_URL + "/" + text;
}

// Turns relative href/src inside already fetched HTML (post bodies) into absolute URLs.
function absolutize(html) {
    let text = String(html || "");
    text = text.replace(/(src|href)=(["'])(?!https?:|\/\/|data:|magnet:|ed2k:|javascript:|mailto:|#)([^"']+)\2/gi, function (all, attr, quote, value) {
        return attr + "=" + quote + absUrl(value) + quote;
    });
    // The skin keeps the real image in a lazy-load attribute.
    text = text.replace(/<img([^>]*?)\s(?:data-original|file)=(["'])([^"']+)\2([^>]*)>/gi, function (all, before, quote, value, after) {
        return "<img" + before + " src=" + quote + absUrl(value) + quote + after + ">";
    });
    // Magnet / ed2k links sit as plain text inside code blocks; make them tappable.
    text = text.replace(/(^|>|\s)(magnet:\?[^<\s]+|ed2k:\/\/[^<\s]+)/gi, function (all, lead, url) {
        return lead + '<a href="' + url + '">' + url + "</a>";
    });
    return text;
}

// Content images only: the skin's smilies, file-type icons and avatars are not pages.
function isContentImage(src) {
    if (!src || src.indexOf("http") !== 0) return false;
    if (src.indexOf("/static/image/") !== -1) return false;
    if (src.indexOf("/uc_server/") !== -1) return false;
    return true;
}

// One fetch that transparently passes the age gate. Returns an HtmlElement, or null
// when the request failed.
function fetchDoc(url, options) {
    let response = fetch(url, options);
    if (!response.ok) return null;
    let body = response.text();
    let gate = body.match(/var\s+safeid\s*=\s*['"]([^'"]+)['"]/);
    if (gate) {
        let retry = { headers: { "Cookie": "_safe=" + gate[1] } };
        if (options) {
            for (let key in options) retry[key] = options[key];
            retry.headers = {};
            if (options.headers) {
                for (let header in options.headers) retry.headers[header] = options.headers[header];
            }
            retry.headers["Cookie"] = "_safe=" + gate[1];
        }
        response = fetch(url, retry);
        if (!response.ok) return null;
        body = response.text();
    }
    return Html.parse(body);
}

function escapeHtml(text) {
    return String(text || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

// "只看楼主" carries the thread starter's uid: &authorid=…
function authorId(doc) {
    let href = String(doc.select("a[href*=authorid]").attr("href"));
    let match = href.match(/authorid=(\d+)/);
    return match ? match[1] : "";
}

function countContentImages(doc) {
    let count = 0;
    doc.select("div.postlist div.display .message img").forEach(function (img) {
        let src = absUrl(img.attr("src") || img.attr("data-original") || img.attr("file") || "");
        if (isContentImage(src)) count++;
    });
    return count;
}

// A text chapter can still carry a few reply images; they are fetched here with the
// chapter as Referer and inlined, bounded so one page cannot exhaust the device heap.
let CHAPTER_IMAGE_BUDGET = 8 * 1024 * 1024;

function inlineImages(html, referer) {
    let text = String(html || "");
    let seen = {};
    let budget = CHAPTER_IMAGE_BUDGET;
    let parts = text.split(/(<img[^>]*>)/i);
    for (let i = 0; i < parts.length; i++) {
        let tag = parts[i];
        if (tag.substring(0, 4).toLowerCase() !== "<img") continue;
        let match = tag.match(/\ssrc=(["'])([^"']+)\1/i);
        if (!match) continue;
        let src = match[2];
        if (src.indexOf("http") !== 0 || !isContentImage(src)) continue;
        if (!seen.hasOwnProperty(src)) {
            let data = budget > 0 ? imageDataUri(src, referer) : "";
            if (data.length > budget) data = "";
            seen[src] = data;
            budget -= data.length;
        }
        if (!seen[src]) continue;
        parts[i] = tag.replace(match[0], " src=" + match[1] + seen[src] + match[1]);
    }
    return parts.join("");
}

function imageDataUri(src, referer) {
    let response = fetch(src, { headers: { "Referer": referer } });
    if (!response.ok) return "";
    let type = String(response.header("content-type") || "");
    if (type.indexOf("image/") !== 0) return "";
    let base64 = response.base64();
    return base64 ? "data:" + type + ";base64," + base64 : "";
}

function cleanText(value) {
    return String(value || "").replace(/[\s\u3000]+/g, " ").trim();
}

// Drops empty fields so the app never receives "" where a value is optional.
function prune(item) {
    for (let key in item) {
        if (item[key] === "" || item[key] === null || item[key] === undefined) delete item[key];
    }
    return item;
}

function tidOf(url) {
    let match = String(url || "").match(/[?&]tid=(\d+)/);
    return match ? match[1] : "";
}

function threadUrl(tid, page) {
    let url = BASE_URL + "/forum.php?mod=viewthread&tid=" + tid + "&mobile=2";
    if (page && page > 1) url += "&page=" + page;
    return url;
}

// Adds or replaces the `page` query parameter, leaving the rest of the URL as it was.
function withPage(url, page) {
    let parts = String(url || "").split("?");
    let base = parts[0];
    let kept = [];
    if (parts.length > 1) {
        let chunks = parts[1].split("&");
        for (let i = 0; i < chunks.length; i++) {
            if (chunks[i] && chunks[i].indexOf("page=") !== 0) kept.push(chunks[i]);
        }
    }
    let result = base + (kept.length ? "?" + kept.join("&") : "");
    if (page > 1) result += (result.indexOf("?") === -1 ? "?" : "&") + "page=" + page;
    return result;
}

function mobileUrl(url) {
    let result = absUrl(url);
    if (result.indexOf("mobile=") === -1) result += (result.indexOf("?") === -1 ? "?" : "&") + "mobile=2";
    return result;
}

// Total pages of the pager: "共 30 页" in the label, else the `.. 30` link.
function totalPages(doc) {
    let title = doc.select(".pg label span").attr("title");
    let match = String(title).match(/(\d+)/);
    if (match) return parseInt(match[1], 10);
    match = String(doc.select(".pg a.last").attr("href")).match(/[?&]page=(\d+)/);
    return match ? parseInt(match[1], 10) : 0;
}

// Thread rows shared by the board pages and the guide (话题) pages. Advertisement
// blocks look like rows but carry no thread link, so they drop out on the href test.
function parseThreads(doc) {
    let items = [];
    // Board pages name the current board in the header; the guide feed does not.
    let boardName = cleanText(doc.select(".n5_tbys .dqym").text());
    doc.select("div.n5_htmk").forEach(function (el) {
        let title = el.select("p.n5_htnrbt a").first();
        if (!title.text()) title = el.select(".n5_htnrtp h1 a").first();
        let href = title.attr("href");
        if (!href || href.indexOf("viewthread") === -1) return;
        let name = cleanText(title.text());
        if (!name) return;

        let image = el.select(".n5_htnrtp img").first();
        let cover = image.attr("data-original") || image.attr("file") || image.attr("src");
        let description = el.select(".ztyzjj p").text() || el.select(".n5_htnrjj").text();

        items.push(prune({
            name: name,
            link: absUrl(href),
            cover: absUrl(cover),
            description: cleanText(description),
            author: cleanText(el.select(".n5_mktbhy a").text()),
            avatar: absUrl(el.select(".n5_mktbtx img").attr("src")),
            time: cleanText(el.select(".n5_mktbsj").text()).replace(/发布$/, ""),
            board: cleanText(el.select(".n5_mktbbk a").text()) || boardName,
            replies: cleanText(el.select(".n5_hthfcs").text()),
            views: cleanText(el.select(".n5_htsccs").text())
        }));
    });
    return items;
}

// Board tree of forum.php?forumlist=1: category tabs, each with a list of boards.
function parseBoards(doc) {
    let categories = doc.select(".n5_tabs li");
    let groups = doc.select("div.tab_content");
    let items = [];
    for (let i = 0; i < groups.size(); i++) {
        let category = cleanText(categories.get(i).text());
        groups.get(i).select("div.sub_forum ul li").forEach(function (el) {
            let link = el.select("a.btdb").first();
            let href = link.attr("href");
            if (!href || href.indexOf("forumdisplay") === -1) return;
            link.select("span.num").remove();
            let name = cleanText(link.text());
            if (!name) return;
            let stats = cleanText(el.select("i").text());
            let threads = stats.match(/主题:\s*(\S+)/);
            let posts = stats.match(/帖数:\s*(\S+)/);
            items.push(prune({
                name: name,
                link: absUrl(href),
                description: category + (stats ? " · " + stats : ""),
                threads: threads ? threads[1] : "",
                posts: posts ? posts[1] : ""
            }));
        });
    }
    return items;
}
