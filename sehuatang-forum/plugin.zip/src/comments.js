load('config.js');

// The thread's replies as comments: one Discuz page per call. `input` may be the
// thread URL or "tid=<id>". `next` is a page number.
function execute(input, next) {
    let text = String(input || "");
    try {
        text = decodeURIComponent(text);
    } catch (error) {
    }
    let tid = tidOf(text);
    if (!tid) {
        let match = text.match(/(?:^|[?&])tid=(\d+)/);
        if (match) tid = match[1];
    }
    if (!tid) return Response.error("URL không hợp lệ");

    let page = parseInt(next, 10);
    if (isNaN(page) || page < 1) page = 1;

    let doc = fetchDoc(threadUrl(tid, page));
    if (doc === null) return Response.error("Không tải được trang");

    let comments = [];
    doc.select("div.postlist div.display").forEach(function (el) {
        let label = cleanText(el.select(".n5_nrylc").text());
        if (label.indexOf("楼主") !== -1) return;

        let message = el.select(".message").first();
        message.select("script, style, .blockbtn").remove();
        let content = cleanText(message.text());
        if (!content) {
            content = message.select("img").size() > 0 ? "[Ảnh]" : "[Nội dung ẩn]";
        }

        let time = cleanText(el.select(".n5_sjydhf dt").text());
        comments.push(prune({
            name: cleanText(el.select(".n5_yhmhdj h3 a").text()) || "Ẩn danh",
            avatar: absUrl(el.select(".n5_nrhytx img").attr("src")),
            content: content,
            description: label && time ? label + " · " + time : (time || label),
            replies: []
        }));
    });

    let total = totalPages(doc);
    return Response.success(comments, page < total ? String(page + 1) : "");
}
