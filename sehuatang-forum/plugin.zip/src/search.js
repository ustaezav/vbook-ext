load('config.js');

// Keyword search over threads. Discuz answers the GET form directly; a new search is
// started for every page, so the page token stays a plain page number.
function execute(query, page) {
    let keyword = String(query || "").trim();
    if (!keyword) return Response.success([]);

    let current = parseInt(page, 10);
    if (isNaN(current) || current < 1) current = 1;

    let url = BASE_URL + "/search.php?mod=forum&mobile=2&searchsubmit=yes&srchtxt=" + encodeURIComponent(keyword);
    if (current > 1) url += "&page=" + current;

    let doc = fetchDoc(url);
    if (doc === null) return Response.error("Không tải được kết quả tìm kiếm");

    let items = [];
    doc.select(".n5_ssnrys ul li a").forEach(function (el) {
        let href = el.attr("href");
        let name = cleanText(el.text());
        if (!href || href.indexOf("viewthread") === -1 || !name) return;
        items.push({ name: name, link: absUrl(href) });
    });

    if (items.length === 0) {
        let notice = cleanText(doc.select("body").text());
        if (notice.indexOf("间隔") !== -1 || notice.indexOf("频繁") !== -1) {
            return Response.error("Tìm kiếm quá nhanh, vui lòng thử lại sau");
        }
    }

    let total = totalPages(doc);
    return Response.success(items, total > current ? String(current + 1) : "");
}
