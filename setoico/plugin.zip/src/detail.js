load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let name = doc.select("h1.video-title").text().trim();
    if (!name) {
        name = doc.select("meta[property=og:title]").attr("content").replace(/^\s*Phim\s+Sex\s+/i, "").trim();
    }

    let info = [];
    let country = doc.select(".prebreadcrumb .breadcrumb-item a").last();
    if (country) info.push("Quốc gia: " + country.text().trim());
    let views = doc.select(".watch-block-right .block-view span").text().trim();
    if (views) info.push("Lượt xem: " + views);

    let genres = [];
    doc.select(".video-intro .genres a").forEach(function (el) {
        let title = el.text().trim();
        let href = el.attr("href");
        if (!title || !href) return;
        genres.push({
            title: title,
            input: absoluteUrl(href),
            script: "search.js"
        });
    });

    doc.select(".detail-keywords a.keyword-item").forEach(function (el) {
        let title = el.text().trim();
        let href = el.attr("href");
        if (!title || !href) return;
        genres.push({
            title: title,
            input: absoluteUrl(href),
            script: "search.js"
        });
    });

    let suggests = [];
    if (!doc.select(".block_area-related .film_list-wrap .flw-item").isEmpty()) {
        suggests.push({
            title: "Phim tương tự",
            input: url,
            script: "similar.js"
        });
    }

    return Response.success({
        name: name,
        cover: doc.select("meta[property=og:image]").attr("content"),
        description: doc.select(".video-intro .about").text().trim(),
        detail: info.join("\n"),
        url: url,
        type: "video",
        format: "series",
        ongoing: true,
        nsfw: true,
        locale: "vi",
        genres: genres,
        suggests: suggests
    });
}
