load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = [];
    let seen = {};
    doc.select(".block_area-related .film_list-wrap .flw-item").forEach(function (el) {
        let link = el.select(".film-name a").attr("href");
        let name = el.select(".film-name a").text().trim();
        if (!name || !link) return;

        let cover = el.select("img.film-poster-img").attr("data-original");
        if (!cover) cover = el.select("img.film-poster-img").attr("src");
        let input = absoluteUrl(link);
        if (seen[input]) return;
        seen[input] = true;

        items.push({
            name: name,
            cover: absoluteUrl(cover),
            link: input,
            tag: el.select(".film-poster .pick.sub").text().trim()
        });
    });

    return Response.success(items, "");
}
