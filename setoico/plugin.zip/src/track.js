load('config.js');

function execute(data) {
    data = String(data || "").trim();
    if (!data) return Response.error("Không có nguồn phát");

    if (/\.(m3u8|mp4)(\?|#|$)/i.test(data)) {
        return Response.success({
            type: "native",
            data: data,
            host: BASE_URL,
            mimeType: /\.mp4(\?|#|$)/i.test(data) ? "video/mp4" : "application/x-mpegURL",
            headers: {
                "User-Agent": UserAgent.chrome(),
                "Referer": BASE_URL + "/"
            },
            timeSkip: []
        });
    }

    return Response.success({
        type: "auto",
        data: data,
        host: BASE_URL,
        headers: {
            "User-Agent": UserAgent.chrome(),
            "Referer": BASE_URL + "/"
        },
        timeSkip: []
    });
}
