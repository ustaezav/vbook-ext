load('config.js');

function parseItems(doc) {
    let items = [];
    doc.select(".film_list-wrap .flw-item").forEach(function (el) {
        let link = el.select(".film-name a").attr("href");
        let name = el.select(".film-name a").text().trim();
        if (!name || !link) return;

        let cover = el.select("img.film-poster-img").attr("data-original");
        if (!cover) cover = el.select("img.film-poster-img").attr("src");
        if (cover && cover.indexOf("data:") === 0) cover = "";

        items.push({
            name: name,
            cover: absoluteUrl(cover),
            link: absoluteUrl(link),
            tag: el.select(".film-poster .pick.sub").text().trim()
        });
    });
    return items;
}

function listingUrl(query, page) {
    query = String(query || "").trim();
    let url;
    if (query.indexOf("http") === 0) {
        url = normalizeUrl(query);
    } else if (query.charAt(0) === "/") {
        url = BASE_URL + query;
    } else if (query) {
        url = BASE_URL + "/?search=" + encodeURIComponent(query);
    } else {
        url = BASE_URL + "/danh-sach/phim-moi";
    }
    return url + (url.indexOf("?") === -1 ? "?" : "&") + "page=" + page;
}

function execute(query, page) {
    page = String(page || "1");
    let url = listingUrl(query, page);

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let hasNext = !doc.select(".pagination a[rel=next]").isEmpty();
    let nextPage = hasNext ? String(parseInt(page, 10) + 1) : "";

    return Response.success(parseItems(doc), nextPage);
}
