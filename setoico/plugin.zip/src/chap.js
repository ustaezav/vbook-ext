load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let tracks = [];
    doc.select("#watch-block .pu-link").forEach(function (el) {
        let stream = el.attr("data-link");
        if (!stream) return;
        let title = el.select(".sv-name").text().trim() || ("Server " + (tracks.length + 1));
        tracks.push({
            title: title,
            data: absoluteUrl(stream)
        });
    });

    if (tracks.length === 0) return Response.error("Không tìm thấy nguồn phát");
    return Response.success(tracks);
}
