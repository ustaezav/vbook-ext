function execute() {
    return Response.success([
        { title: "Mới nhất", input: "/danh-sach/phim-moi", script: "search.js" },
        { title: "Việt Nam", input: "/quoc-gia/viet-nam", script: "search.js" },
        { title: "Trung Quốc", input: "/quoc-gia/trung-quoc", script: "search.js" },
        { title: "Âu Mỹ", input: "/quoc-gia/au-my", script: "search.js" },
        { title: "Vietsub", input: "/the-loai/vietsub", script: "search.js" }
    ]);
}
