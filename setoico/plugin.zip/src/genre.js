load('config.js');

function execute() {
    let response = fetch(BASE_URL + "/");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let genres = [];
    let seen = {};
    doc.select(".sub-menu a").forEach(function (el) {
        let title = el.text().trim();
        let href = el.attr("href");
        if (!title || !href || href.charAt(0) === "#") return;
        let input = absoluteUrl(href);
        if (seen[input]) return;
        seen[input] = true;
        genres.push({
            title: title,
            input: input,
            script: "search.js"
        });
    });

    return Response.success(genres);
}
