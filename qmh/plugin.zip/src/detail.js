load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let slug = slugFromUrl(url);
    if (!slug) return Response.error("URL không hợp lệ");

    let response = fetchApi("/movies/" + encodeURIComponent(slug));
    if (!response.ok) return Response.error("HTTP " + response.status);
    let payload = readJson(response);
    if (!payload) return Response.error("Dữ liệu không hợp lệ");
    let movie = payload.data;
    if (!movie) return Response.error("Không tìm thấy phim");

    let genres = [];
    let categoryNames = [];
    let categories = movie.categories || [];
    for (let i = 0; i < categories.length; i++) {
        let category = categories[i];
        if (!category || !category.slug) continue;
        categoryNames.push(category.name);
        genres.push({
            title: category.name,
            input: "category:" + category.slug,
            script: "list.js"
        });
    }

    let actorNames = [];
    let leadStar = null;
    let pornstars = movie.pornstars || [];
    for (let i = 0; i < pornstars.length; i++) {
        let star = pornstars[i];
        if (!star || !star.slug || star.name === "Unknown") continue;
        if (!leadStar) leadStar = star;
        actorNames.push(star.name);
        genres.push({
            title: star.name,
            input: "pornstar:" + star.slug,
            script: "list.js"
        });
    }

    let suggests = [{
        title: "Video liên quan",
        input: "related:" + slug,
        script: "similar.js"
    }];
    if (leadStar) {
        suggests.push({
            title: "Thêm video với " + leadStar.name,
            input: "pornstar:" + leadStar.slug + "|" + slug,
            script: "similar.js"
        });
    }

    let detail = [];
    if (movie.quality) detail.push("Chất lượng: " + movie.quality);
    if (movie.duration) detail.push("Thời lượng: " + movie.duration);
    if (movie.views) detail.push("Lượt xem: " + formatNumber(movie.views));
    if (movie.likes) detail.push("Yêu thích: " + formatNumber(movie.likes));
    let published = formatDate(movie.created_at);
    if (published) detail.push("Ngày đăng: " + published);
    if (categoryNames.length) detail.push("Thể loại: " + categoryNames.join(", "));
    if (actorNames.length) detail.push("Diễn viên: " + actorNames.join(", "));

    return Response.success({
        name: movie.name || movie.origin_name || slug,
        cover: movie.poster_url || movie.thumbnail_url || "",
        description: movie.description || "",
        detail: detail.join("\n"),
        url: movieUrl(slug),
        type: "video",
        format: "series",
        nsfw: true,
        ongoing: false,
        genres: genres,
        suggests: suggests,
        comments: [{
            title: "Bình luận",
            input: slug,
            script: "comments.js"
        }]
    });
}
