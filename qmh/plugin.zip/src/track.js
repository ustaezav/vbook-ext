load('config.js');
load('crypto.js');

function userAgent() {
    try {
        if (UserAgent && UserAgent.chrome) return UserAgent.chrome();
    } catch (error) {
    }
    return "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36";
}

function browserHeaders(referer, site) {
    return {
        "Content-Type": "application/json",
        "Accept": "*/*",
        "Origin": BASE_URL,
        "Referer": referer,
        "Sec-Fetch-Site": site,
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty"
    };
}

function streamHeaders() {
    return {
        "User-Agent": userAgent(),
        "Origin": BASE_URL,
        "Referer": BASE_URL + "/",
        "Sec-Fetch-Site": "same-site",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty"
    };
}

function isDirect(url) {
    return /^https?:\/\//i.test(url) && /\.(m3u8|mp4|mkv|webm|m4v)(\?|#|$)/i.test(url);
}

function cleanStream(value) {
    return String(value || "")
        .replace(/\\\//g, "/")
        .replace(/\\u002F/gi, "/")
        .replace(/&amp;/g, "&")
        .replace(/^"+|"+$/g, "");
}

function extractStream(html) {
    let match = html.match(/https?:\\\/\\\/[^"'\s]+?\.(?:m3u8|mp4)[^"'\s]*/i);
    if (match) return cleanStream(match[0]);

    match = html.match(/https?:[^"'\s\\]+\.m3u8[^"'\s\\]*/i);
    if (match) return cleanStream(match[0]);

    match = html.match(/https?:[^"'\s\\]+\.mp4[^"'\s\\]*/i);
    if (match) return cleanStream(match[0]);
    return "";
}

// The site serves a plain index.m3u8 whose AES key is protected. Its player
// exchanges an obfuscated payload for a signed playlist, so native playback
// must use that resolved playlist instead of the raw source URL.
function encodePayload(payload) {
    let json = JSON.stringify(payload);
    let binary = "";
    for (let i = 0; i < json.length; i++) {
        binary += String.fromCharCode(json.charCodeAt(i) ^ ((137 + i * 17) & 255));
    }
    return CryptoJS.enc.Latin1.parse(binary).toString(CryptoJS.enc.Base64)
        .replace(/\+/g, "-")
        .replace(/\//g, "_")
        .replace(/=+$/, "");
}

function resolveSecure(rawUrl, sprite, embed) {
    let referer = embed || (BASE_URL + "/");
    let tokenResponse = fetch(BASE_URL + "/api/hls-token", {
        method: "POST",
        headers: browserHeaders(referer, "same-origin"),
        body: JSON.stringify({ data: encodePayload({ u: rawUrl, s: sprite || "" }) }),
        timeout: 30000
    });
    if (!tokenResponse.ok) return "";

    let tokenPayload = readJson(tokenResponse);
    if (!tokenPayload || !tokenPayload.token || !tokenPayload.apiBase) return "";

    let resolveResponse = fetch(tokenPayload.apiBase + "/upload/video-hls/resolve", {
        method: "POST",
        headers: browserHeaders(referer, "same-site"),
        body: JSON.stringify({
            token: tokenPayload.token,
            hash: tokenPayload.hash,
            apiBase: tokenPayload.apiBase,
            embedRequired: tokenPayload.embedRequired,
            at: null,
            accessToken: null
        }),
        timeout: 30000
    });
    if (!resolveResponse.ok) return "";

    let resolved = readJson(resolveResponse);
    let data = resolved && resolved.data ? resolved.data : resolved;
    return data && data.url ? String(data.url) : "";
}

function playable(stream) {
    let isHls = /^data:application\/vnd\.apple\.mpegurl/i.test(stream) ||
        stream.indexOf("#EXTM3U") === 0 ||
        /\.m3u8(\?|#|$)/i.test(stream);
    return Response.success({
        type: "native",
        data: stream,
        mimeType: isHls ? "application/x-mpegURL" : "video/mp4",
        headers: streamHeaders(),
        timeSkip: []
    });
}

function embedPlayer(embed) {
    return Response.success({
        type: "webview",
        data: embed,
        headers: streamHeaders(),
        timeSkip: []
    });
}

function execute(data) {
    let text = String(data || "").trim();
    if (!text) return Response.error("Không có link phát");

    let payload = null;
    if (text.charAt(0) === "{") {
        try {
            payload = JSON.parse(text);
        } catch (error) {
            payload = null;
        }
    }

    let url = payload && payload.url ? String(payload.url) : text;
    let embed = payload && payload.embed ? String(payload.embed) : "";
    let sprite = payload && payload.sprite ? String(payload.sprite) : "";

    if (!url) {
        if (embed) return embedPlayer(embed);
        return Response.error("Không có link phát");
    }

    if (isDirect(url)) {
        if (/\.m3u8(\?|#|$)/i.test(url)) {
            let resolved = resolveSecure(url, sprite, embed);
            if (resolved) return playable(resolved);
            if (embed) return embedPlayer(embed);
        }
        return playable(url);
    }

    let response = fetch(url, {
        headers: {
            "User-Agent": userAgent(),
            "Referer": BASE_URL + "/"
        },
        timeout: 30000
    });
    if (!response.ok) return Response.error("HTTP " + response.status);

    let stream = extractStream(response.text());
    if (stream && isDirect(stream)) {
        if (/\.m3u8(\?|#|$)/i.test(stream)) {
            let resolved = resolveSecure(stream, sprite, embed || url);
            if (resolved) return playable(resolved);
        }
        return playable(stream);
    }

    return Response.success({
        type: "auto",
        data: url,
        host: BASE_URL,
        headers: streamHeaders(),
        timeSkip: []
    });
}
