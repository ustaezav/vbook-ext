load('config.js');

function findEpisode(episodes, slug) {
    for (let i = 0; i < episodes.length; i++) {
        if (episodes[i] && String(episodes[i].slug) === slug) return episodes[i];
    }
    return episodes.length ? episodes[0] : null;
}

function uniqueTitle(title, used) {
    let base = title || "Server";
    let result = base;
    let index = 2;
    while (used[result]) {
        result = base + " " + index;
        index++;
    }
    used[result] = true;
    return result;
}

function trackData(url, embed, sprite) {
    return JSON.stringify({
        url: url,
        embed: embed,
        sprite: sprite || ""
    });
}

function execute(url) {
    url = normalizeUrl(url);
    let slug = slugFromUrl(url);
    if (!slug) return Response.error("URL không hợp lệ");

    let episodeSlug = "";
    let match = String(url).match(/[?&]ep=([^&#]+)/);
    if (match) {
        try {
            episodeSlug = decodeURIComponent(match[1]);
        } catch (error) {
            episodeSlug = match[1];
        }
    }

    let response = fetchApi("/movies/" + encodeURIComponent(slug));
    if (!response.ok) return Response.error("HTTP " + response.status);
    let payload = readJson(response);
    if (!payload) return Response.error("Dữ liệu không hợp lệ");
    let movie = payload.data;
    if (!movie) return Response.error("Không tìm thấy phim");

    let episode = findEpisode(movie.episodes || [], episodeSlug);
    let fallbackEmbed = BASE_URL + "/embed/" + slug +
        (episode && episode.slug ? "?server=" + encodeURIComponent(episode.slug) : "");
    let tracks = [];
    let used = {};

    if (episode && episode.sources) {
        for (let i = 0; i < episode.sources.length; i++) {
            let source = episode.sources[i];
            if (!source) continue;
            let link = source.link_m3u8 || source.link_embed;
            if (!link) continue;
            tracks.push({
                title: uniqueTitle(source.server_name || ("Server " + (tracks.length + 1)), used),
                data: trackData(link, fallbackEmbed, movie.sprite_url)
            });
        }
    }

    if (tracks.length === 0) {
        tracks.push({
            title: "Mặc định",
            data: trackData("", fallbackEmbed, movie.sprite_url)
        });
    }

    return Response.success(tracks);
}
