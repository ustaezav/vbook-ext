load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let slug = slugFromUrl(url);
    if (!slug) return Response.error("URL không hợp lệ");

    let response = fetchApi("/movies/" + encodeURIComponent(slug));
    if (!response.ok) return Response.error("HTTP " + response.status);
    let payload = readJson(response);
    if (!payload) return Response.error("Dữ liệu không hợp lệ");
    let movie = payload.data;
    if (!movie) return Response.error("Không tìm thấy phim");

    let chapters = [];
    let episodes = movie.episodes || [];
    for (let i = 0; i < episodes.length; i++) {
        let episode = episodes[i];
        if (!episode || !episode.slug) continue;
        chapters.push({
            name: episode.name || ("Tập " + (i + 1)),
            url: movieUrl(slug) + "?ep=" + encodeURIComponent(episode.slug),
            description: "",
            lock: false,
            pay: false
        });
    }

    if (chapters.length === 0) {
        chapters.push({
            name: "Full",
            url: movieUrl(slug),
            description: "",
            lock: false,
            pay: false
        });
    }

    return Response.success(chapters);
}
