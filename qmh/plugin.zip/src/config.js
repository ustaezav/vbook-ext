let BASE_URL = "https://qmhv3.cc";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

let API_URL = BASE_URL + "/api/v1";

function normalizeUrl(url) {
    return String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function movieUrl(slug) {
    return BASE_URL + "/watch/" + slug;
}

function slugFromUrl(url) {
    let match = String(url).match(/\/watch\/([^\/?#]+)/);
    if (!match) return "";
    try {
        return decodeURIComponent(match[1]);
    } catch (error) {
        return match[1];
    }
}

function readJson(response) {
    try {
        return response.json();
    } catch (error) {
        return null;
    }
}

function fetchApi(path) {
    return fetch(API_URL + path, {
        headers: {
            "Accept": "application/json",
            "Referer": BASE_URL + "/"
        },
        timeout: 30000
    });
}

function formatNumber(value) {
    let text = String(parseInt(value, 10) || 0);
    let result = "";
    let count = 0;
    for (let i = text.length - 1; i >= 0; i--) {
        result = text.charAt(i) + result;
        count++;
        if (count === 3 && i > 0) {
            result = "." + result;
            count = 0;
        }
    }
    return result;
}

function formatDate(value) {
    let match = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})/);
    return match ? match[3] + "/" + match[2] + "/" + match[1] : "";
}

function movieItems(list) {
    let items = [];
    if (!list) return items;
    for (let i = 0; i < list.length; i++) {
        let movie = list[i];
        if (!movie || !movie.slug) continue;
        let description = formatNumber(movie.views) + " lượt xem";
        if (movie.duration) description += " • " + movie.duration;
        items.push({
            name: movie.name || movie.slug,
            cover: movie.thumbnail_url || movie.poster_url || "",
            link: movieUrl(movie.slug),
            description: description,
            tag: movie.is_vip ? "VIP" : (movie.quality || "")
        });
    }
    return items;
}
