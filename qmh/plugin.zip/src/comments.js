load('config.js');

const COMMENT_LIMIT = 10;
const REPLY_LIMIT = 50;

function escapeHtml(text) {
    return String(text || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

function parseTime(value) {
    let match = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})/);
    if (!match) return 0;
    return Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]),
        Number(match[4]), Number(match[5]), Number(match[6]));
}

function timeAgo(value) {
    let time = parseTime(value);
    if (!time) return "";
    let seconds = Math.floor((new Date().getTime() - time) / 1000);
    if (seconds < 60) return "vừa xong";
    if (seconds < 3600) return Math.floor(seconds / 60) + " phút trước";
    if (seconds < 86400) return Math.floor(seconds / 3600) + " giờ trước";
    if (seconds < 2592000) return Math.floor(seconds / 86400) + " ngày trước";
    if (seconds < 31536000) return Math.floor(seconds / 2592000) + " tháng trước";
    return Math.floor(seconds / 31536000) + " năm trước";
}

function commentItem(item, replies) {
    let user = item.user || {};
    return {
        name: user.username || "Ẩn danh",
        avatar: user.avatar || "",
        content: escapeHtml(item.content).replace(/\n/g, "<br>"),
        description: timeAgo(item.created_at),
        replies: replies || []
    };
}

// Replies are a separate endpoint, so they are fetched only for comments that
// actually report replies instead of paying one request per comment.
function fetchReplies(id) {
    let response = fetchApi("/comments/" + id + "/replies?page=1&limit=" + REPLY_LIMIT);
    if (!response.ok) return [];
    let payload = readJson(response);
    let data = payload && payload.data;
    let list = data && data.data ? data.data : [];
    let replies = [];
    for (let i = 0; i < list.length; i++) {
        replies.push(commentItem(list[i]));
    }
    return replies;
}

function execute(input, page) {
    let slug = String(input || "").trim();
    if (slug.indexOf("/watch/") >= 0) slug = slugFromUrl(slug);
    if (!slug) return Response.error("Không có phim để tải bình luận");

    let current = parseInt(page, 10);
    if (!current || current < 1) current = 1;

    let response = fetchApi("/comments/movie/" + encodeURIComponent(slug) +
        "?page=" + current + "&limit=" + COMMENT_LIMIT);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let payload = readJson(response);
    if (!payload) return Response.error("Dữ liệu không hợp lệ");

    let data = payload.data;
    if (!data) return Response.success([], "");

    let list = data.data || [];
    let items = [];
    for (let i = 0; i < list.length; i++) {
        let comment = list[i];
        if (!comment) continue;
        let replies = comment.reply_count > 0 ? fetchReplies(comment.id) : [];
        items.push(commentItem(comment, replies));
    }

    let totalPages = parseInt(data.totalPages, 10) || 0;
    let next = items.length > 0 && current < totalPages ? String(current + 1) : "";
    return Response.success(items, next);
}
