load('config.js');

function apiPath(input, page) {
    if (input.indexOf("category:") === 0) {
        return "/categories/" + encodeURIComponent(input.substring(9)) + "/movies?page=" + page + "&limit=24";
    }
    if (input.indexOf("pornstar:") === 0) {
        return "/pornstars/" + encodeURIComponent(input.substring(9)) + "/movies?page=" + page + "&limit=24";
    }
    let params = input.replace(/^[?&]+/, "");
    return "/filter?page=" + page + "&limit=24" + (params ? "&" + params : "");
}

function execute(query, page) {
    query = String(query || "").trim();
    let current = parseInt(page, 10) || 1;
    if (current < 1) current = 1;

    let response = fetchApi(apiPath(query, current));
    if (!response.ok) return Response.error("HTTP " + response.status);
    let payload = readJson(response);
    if (!payload) return Response.error("Dữ liệu không hợp lệ");
    let data = payload.data;
    if (!data) return Response.success([], "");

    let list = data.data ? data.data : data;
    let totalPages = parseInt(data.totalPages, 10) || parseInt(payload.totalPages, 10) || 0;
    let items = movieItems(list);
    let hasNext = items.length > 0 && current < totalPages;
    return Response.success(items, hasNext ? String(current + 1) : "");
}
