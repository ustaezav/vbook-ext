function execute() {
    return Response.success([
        { title: "Mới cập nhật", input: "sort=desc", script: "list.js" },
        { title: "Xem nhiều", input: "sort=most_viewed", script: "list.js" },
        { title: "Yêu thích", input: "sort=most_favorited", script: "list.js" }
    ]);
}
