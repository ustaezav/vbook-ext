load('config.js');

function execute(query, page) {
    query = String(query || "").trim();
    if (!query) return Response.success([], "");

    let current = parseInt(page, 10) || 1;
    if (current < 1) current = 1;

    let response = fetchApi("/search?q=" + encodeURIComponent(query) + "&limit=24&page=" + current);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let payload = readJson(response);
    if (!payload) return Response.error("Dữ liệu không hợp lệ");
    let result = payload.data;
    if (!result) return Response.success([], "");

    let items = movieItems(result.data);
    let totalPages = parseInt(result.totalPages, 10) || 0;
    let hasNext = items.length > 0 && current < totalPages;
    return Response.success(items, hasNext ? String(current + 1) : "");
}
