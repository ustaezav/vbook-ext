load('config.js');

const SUGGEST_LIMIT = 15;

function shuffle(list) {
    let result = list.slice(0);
    for (let i = result.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        let temp = result[i];
        result[i] = result[j];
        result[j] = temp;
    }
    return result;
}

function withMovies(path, excludeSlug) {
    let response = fetchApi(path);
    if (!response.ok) return [];
    let payload = readJson(response);
    let data = payload && payload.data;
    let list = data && data.data ? data.data : (data || []);
    let filtered = [];
    for (let i = 0; i < list.length; i++) {
        let movie = list[i];
        if (!movie || !movie.slug) continue;
        if (excludeSlug && movie.slug === excludeSlug) continue;
        filtered.push(movie);
    }
    return shuffle(filtered).slice(0, SUGGEST_LIMIT);
}

// The watch page has no dedicated related endpoint: its "Related videos" tab
// pulls a random page of most viewed movies and drops the current one.
function related(slug) {
    let page = Math.floor(Math.random() * 3) + 1;
    return withMovies("/filter?page=" + page + "&limit=24&sort=most_viewed", slug);
}

function byPornstar(starSlug, excludeSlug) {
    return withMovies("/pornstars/" + encodeURIComponent(starSlug) + "/movies?page=1&limit=24", excludeSlug);
}

function execute(input) {
    let text = String(input || "").trim();
    if (!text) return Response.error("Không có gợi ý để tải");

    let excludeSlug = "";
    let separator = text.indexOf("|");
    if (separator >= 0) {
        excludeSlug = text.substring(separator + 1);
        text = text.substring(0, separator);
    }

    let list;
    if (text.indexOf("related:") === 0) {
        list = related(text.substring(8));
    } else if (text.indexOf("pornstar:") === 0) {
        list = byPornstar(text.substring(9), excludeSlug);
    } else {
        list = related(excludeSlug || text);
    }

    return Response.success(movieItems(list));
}
