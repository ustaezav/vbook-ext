load('config.js');

function execute() {
    let response = fetchApi("/categories?limit=64&sort=asc");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let payload = readJson(response);
    if (!payload) return Response.error("Dữ liệu không hợp lệ");
    let categories = payload.data || [];
    let genres = [];

    for (let i = 0; i < categories.length; i++) {
        let category = categories[i];
        if (!category || !category.slug || category.is_active === false) continue;
        genres.push({
            title: category.name,
            input: "category:" + category.slug,
            script: "list.js"
        });
    }

    return Response.success(genres);
}
