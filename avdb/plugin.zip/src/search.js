load('config.js');

function execute(query, page) {
    query = String(query || "").trim();
    if (!query) return Response.success([], "");

    page = parseInt(page, 10) || 1;
    if (page < 1) page = 1;

    let qs = "ac=detail&pg=" + page + "&pagesize=30&wd=" + encodeURIComponent(query);
    let response = fetch(API + "?" + qs, { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let data = response.json();

    let items = apiItems(data.list);
    let hasNext = items.length > 0 && page < (data.pagecount || 0);
    return Response.success(items, hasNext ? String(page + 1) : "");
}
