load('config.js');

function systemUserAgent() {
    try {
        if (UserAgent && UserAgent.system) return UserAgent.system();
    } catch (e) {
    }
    return "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36";
}

function isDirectMedia(url) {
    return /^https?:\/\//i.test(url) && /\.(m3u8|mp4|mkv|webm|m4v)(\?|#|$)/i.test(url);
}

function extractPlayerConfig(html) {
    let i = html.indexOf("PLAYER_CONFIG");
    if (i < 0) return null;
    let j = html.indexOf("{", i);
    if (j < 0) return null;
    let depth = 0, inStr = false, esc = false;
    for (let k = j; k < html.length; k++) {
        let c = html.charAt(k);
        if (inStr) {
            if (esc) esc = false;
            else if (c === "\\") esc = true;
            else if (c === '"') inStr = false;
        } else {
            if (c === '"') inStr = true;
            else if (c === "{") depth++;
            else if (c === "}") {
                depth--;
                if (depth === 0) {
                    try {
                        return JSON.parse(html.substring(j, k + 1));
                    } catch (e) {
                        return null;
                    }
                }
            }
        }
    }
    return null;
}

function execute(data) {
    data = String(data || "").trim();
    if (!data) return Response.error("Không có link phát");

    if (isDirectMedia(data)) {
        return Response.success({
            type: "native",
            data: data,
            mimeType: /\.m3u8(\?|#|$)/i.test(data) ? "application/x-mpegURL" : "",
            headers: { "Referer": BASE_URL + "/" }
        });
    }

    let ua = systemUserAgent();
    let response = fetch(data, { timeout: 30000, headers: { "User-Agent": ua } });
    if (!response.ok) return Response.error("HTTP " + response.status);

    let config = extractPlayerConfig(response.text());
    let stream = config && config.m3u8 ? config.m3u8 : "";

    if (config && config.refreshUrl) {
        let origin = (data.match(/^https?:\/\/[^\/]+/) || [""])[0];
        let refresh = fetch(origin + config.refreshUrl, {
            timeout: 30000,
            headers: { "User-Agent": ua, "Referer": data }
        });
        if (refresh.ok) {
            try {
                let updated = refresh.json();
                if (updated && updated.m3u8) stream = updated.m3u8;
            } catch (e) {
            }
        }
    }

    if (!stream) return Response.success({ type: "auto", data: data });

    return Response.success({
        type: "native",
        data: stream,
        mimeType: "application/x-mpegURL",
        headers: { "User-Agent": ua, "Referer": data }
    });
}
