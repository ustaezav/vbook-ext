let BASE_URL = "https://avdbapi.com";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

let API = BASE_URL + "/api.php/provide/vod";

function normalizeUrl(url) {
    return String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function detailUrl(id) {
    return API + "?ac=detail&ids=" + encodeURIComponent(id);
}

function joinList(value) {
    if (!value || !value.length) return "";
    let parts = [];
    for (let i = 0; i < value.length; i++) {
        if (value[i]) parts.push(value[i]);
    }
    return parts.join(", ");
}

function apiItems(list) {
    let items = [];
    if (!list) return items;
    for (let i = 0; i < list.length; i++) {
        let v = list[i];
        if (!v || !v.id) continue;
        let name = v.name || "";
        if (!name) name = v.movie_code || "";
        if (!name) name = String(v.id);
        items.push({
            name: name,
            cover: v.poster_url || v.thumb_url || "",
            link: detailUrl(v.id),
            description: joinList(v.actor),
            tag: v.type_name || v.quality || "",
            host: BASE_URL
        });
    }
    return items;
}
