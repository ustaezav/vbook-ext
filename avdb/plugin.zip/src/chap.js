load('config.js');

function execute(url) {
    let source = String(url);
    let id = (source.match(/[?&]ids=(\d+)/) || [])[1] || "";
    let ep = (source.match(/[?&]ep=([^&]+)/) || [])[1] || "";
    if (!id) return Response.error("URL không hợp lệ");

    let response = fetch(detailUrl(id), { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let data = response.json();
    let v = data.list && data.list[0];
    if (!v) return Response.error("Không tìm thấy dữ liệu");

    let sd = (v.episodes && v.episodes.server_data) ? v.episodes.server_data : {};
    let link = "";
    let title = "";

    if (ep && sd[ep] && sd[ep].link_embed) {
        link = sd[ep].link_embed;
        title = ep;
    }
    if (!link) {
        for (let key in sd) {
            if (!sd.hasOwnProperty(key)) continue;
            if ((sd[key] || {}).link_embed) {
                link = sd[key].link_embed;
                title = key;
                break;
            }
        }
    }

    if (!link) return Response.error("Không có link phát");
    if (!title) title = "Full";

    return Response.success([
        { title: decodeURIComponent(title), data: link }
    ]);
}
