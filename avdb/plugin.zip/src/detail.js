load('config.js');

function execute(url) {
    let id = (String(url).match(/[?&]ids=(\d+)/) || [])[1] || "";
    if (!id) return Response.error("URL không hợp lệ");

    let response = fetch(detailUrl(id), { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let data = response.json();
    let v = data.list && data.list[0];
    if (!v) return Response.error("Không tìm thấy dữ liệu");

    let genres = [];
    let category = v.category || [];
    for (let i = 0; i < category.length; i++) {
        if (!category[i]) continue;
        genres.push({
            title: category[i],
            input: "category=" + encodeURIComponent(category[i]),
            script: "list.js"
        });
    }

    let tags = [];
    let actor = v.actor || [];
    for (let i = 0; i < actor.length; i++) {
        if (!actor[i] || actor[i] === "Updating") continue;
        tags.push({
            title: actor[i],
            input: "actor=" + encodeURIComponent(actor[i]),
            script: "list.js"
        });
    }

    let info = [];
    if (v.movie_code) info.push("Mã: " + v.movie_code);
    if (v.type_name) info.push("Loại: " + v.type_name);
    if (joinList(v.actor)) info.push("Diễn viên: " + joinList(v.actor));
    if (joinList(v.director)) info.push("Đạo diễn: " + joinList(v.director));
    if (v.year) info.push("Năm: " + v.year);
    if (v.time) info.push("Thời lượng: " + v.time);
    if (v.quality) info.push("Chất lượng: " + v.quality);
    if (joinList(v.country)) info.push("Quốc gia: " + joinList(v.country));

    return Response.success({
        name: v.name || v.movie_code || "",
        cover: v.poster_url || v.thumb_url || "",
        description: v.description || "",
        detail: info.join("\n"),
        url: detailUrl(id),
        type: "video",
        format: "series",
        nsfw: true,
        ongoing: false,
        genres: genres,
        tags: tags
    });
}
