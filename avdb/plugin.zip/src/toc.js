load('config.js');

function execute(url) {
    let id = (String(url).match(/[?&]ids=(\d+)/) || [])[1] || "";
    if (!id) return Response.error("URL không hợp lệ");

    let response = fetch(detailUrl(id), { timeout: 30000 });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let data = response.json();
    let v = data.list && data.list[0];
    if (!v) return Response.error("Không tìm thấy dữ liệu");

    let sd = (v.episodes && v.episodes.server_data) ? v.episodes.server_data : {};
    let prefix = v.movie_code ? v.movie_code + " - " : "";

    let chapters = [];
    for (let key in sd) {
        if (!sd.hasOwnProperty(key)) continue;
        if (!(sd[key] || {}).link_embed) continue;
        chapters.push({
            name: prefix + key,
            url: detailUrl(id) + "&ep=" + encodeURIComponent(key)
        });
    }

    if (chapters.length === 0) {
        chapters.push({ name: prefix + "Full", url: detailUrl(id) + "&ep=Full" });
    }

    return Response.success(chapters);
}
