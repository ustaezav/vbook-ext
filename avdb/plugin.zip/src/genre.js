function execute() {
    return Response.success([
        { title: "Censored", input: "t=1", script: "list.js" },
        { title: "Uncensored", input: "t=2", script: "list.js" },
        { title: "Uncensored Leaked", input: "t=3", script: "list.js" },
        { title: "Amateur", input: "t=4", script: "list.js" },
        { title: "Chinese AV", input: "t=5", script: "list.js" },
        { title: "Hentai", input: "t=6", script: "list.js" },
        { title: "English Subtitle", input: "t=7", script: "list.js" }
    ]);
}
